import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateIntentLeftComponent } from './create-intent-left.component';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';

describe('CreateIntentLeftComponent', () => {
  let component: CreateIntentLeftComponent;
  let fixture: ComponentFixture<CreateIntentLeftComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateIntentLeftComponent ],
      imports: [ 
        AccordionModule.forRoot(),
        FormsModule,
        ReactiveFormsModule,
        NgSelectModule
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateIntentLeftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

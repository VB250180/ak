import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, Form, Validators, SelectControlValueAccessor } from '@angular/forms';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { Conversation, ConversationStage, GetInfo, SendMessage } from '../model/intent';
import { CreateIntentService } from '../create-intent.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-create-intent-right',
  templateUrl: './create-intent-right.component.html',
  styleUrls: ['../create-intent-left/create-intent-left.component.scss']
})
export class CreateIntentRightComponent implements OnInit{
  @Output() public getLeftPanelDataR = new EventEmitter<any>();
  conversationListRight: any; intentId; chId; langId;

  constructor(private route: ActivatedRoute, public createIntentService: CreateIntentService) {
    this.route.paramMap.subscribe((params: any) => {
      this.intentId = params.params.intId;
      let roleId = params.params.vaID;
      this.chId = params.params.chId;
      this.langId = params.params.langId;
      this.getConversationList(this.intentId, this.langId, this.chId);
    });
  }
  message:string;
  ngOnInit() {
    this.createIntentService.currentMessage.subscribe(message => this.message = message)
  }
  getConversationList(intentId, langId, chId) {
    this.createIntentService.getIntentConversionList(intentId, langId, chId)
      .subscribe((res: any) => {
        this.conversationListRight = res.conversation;
      })
  }

  // getInfoClick(e, i) {
  //   this.getLeftPanelDataR.emit(e);
  // }
  // sendMessageClick(e, d) {
  //   this.getLeftPanelDataR.emit(e);
  // }

  drop(event: CdkDragDrop<{ title: string, poster: string }[]>) {
    moveItemInArray(this.conversationListRight.conversationStages, event.previousIndex, event.currentIndex);
  }


  bindTempDataGet(e, intentId, langId, chId) {
    let temp=e;
      this.conversationListRight=temp;
  }

  bindTempData(e, intentId, langId, chId) {
    if (e != undefined) {
      this.conversationListRight = e;
    } else {

      this.conversationListRight.systemSlots.forEach((e, i) => {
        if (e.systemSlotKey.systemSlotKeyName == "") {
          this.conversationListRight.systemSlots.splice(i, 1)
        }
      });

      this.createIntentService.saveConversations(this.conversationListRight, intentId, langId, chId)
        .subscribe((res: any) => { });
    }

  }


}

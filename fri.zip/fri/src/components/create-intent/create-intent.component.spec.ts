import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateIntentComponent } from './create-intent.component';
import { CreateIntentLeftComponent } from './create-intent-left/create-intent-left.component';
import { CreateIntentRightComponent } from './create-intent-right/create-intent-right.component';
// import { TrainingPhrasesComponent } from './training-phrases/training-phrases.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule,FormBuilder  } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import {HttpClientModule} from '@angular/common/http';
import { Toast, ToastrService, ToastPackage, ToastrModule } from 'ngx-toastr';
import { APP_BASE_HREF } from '@angular/common';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { NgSelectModule } from '@ng-select/ng-select';



fdescribe('CreateIntentComponent', () => {
  let component: CreateIntentComponent;
  let fixture: ComponentFixture<CreateIntentComponent>;

  beforeEach(async(() => {
      TestBed.configureTestingModule({
          declarations: [CreateIntentComponent,CreateIntentLeftComponent,CreateIntentRightComponent],
          imports: [
              ReactiveFormsModule,
              FormsModule,
              RouterModule.forRoot([]),
              HttpClientTestingModule,
              ToastrModule.forRoot(),
              AccordionModule.forRoot(),
              NgSelectModule
          ],
          providers: [
            { provide: APP_BASE_HREF, useValue : '/' }
        ]
      })
          .compileComponents();
  }));

  beforeEach(() => {
      fixture = TestBed.createComponent(CreateIntentComponent);
      component = fixture.componentInstance;
      component.ngOnInit();
      fixture.detectChanges();
  });

  it('should create', () => {
      expect(component).toBeTruthy();
  });

  it('form invalid when empty', () => {
      expect(component.saveIntentForm.valid).toBeFalsy();
  });

  it('name field validity', () => {
      let name = component.saveIntentForm.controls['intentName'];
      let desc = component.saveIntentForm.controls['intentDescription'];

      expect(name.valid).toBeFalsy();
      expect(desc.valid).toBeFalsy();

  });

});






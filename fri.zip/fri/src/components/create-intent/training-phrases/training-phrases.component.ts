import { Component, OnInit, TemplateRef, Input, SimpleChanges, OnChanges } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, FormControl } from '@angular/forms';
import { Validators, ValidationErrors, ValidatorFn } from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CreateIntentService } from '../create-intent.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { BsModalService } from "ngx-bootstrap/modal";
import { BsModalRef } from "ngx-bootstrap/modal/bs-modal-ref.service";
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-training-phrases',
  templateUrl: './training-phrases.component.html',
  styleUrls: ['./training-phrases.component.scss'],
  host: {
    '(document:click)': 'functionClick($event)',
  }
})
export class TrainingPhrasesComponent implements OnInit, OnChanges {
  @Input() arr;

  addArray: any = [];
  phrases: any;
  posPhraseValues: any = [];
  addForm = this.fb.group({
    addtext: ['', [Validators.required]]
  });
  availablePhrases: any;
  pageNum: number = 1;
  intentId: number;
  langId: number;
  vaRoleId: number;
  chId: number;
  idToDelete: number;
  idToEdit: number;
  valueToEdit: any;
  intentSlots: any = [];
  counter: number = 1;
  slotsToDisplay: any = [];
  isLoaded: boolean = false;
  IsHidden: boolean = true;
  selectedSlot: any = [];
  slotsList: any = [];
  selectedSlotId: any = [];
  selectedSlotValue: any = [];
  selectedIntentSlots: any = [];
  newPhraseSlotDetails: any = [];
  selectedValues: any = [];
  copyofnewPhraseSlotDetails: any = [];
  valueToDelete: any = [];
  searchText: any;
  editData: boolean = false;
  id: number = 0;
  flag: number;
  checkEdited: boolean = false;
  modalRef: BsModalRef;
  config = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: "my-modal"
  };
  newData: any = [];


  constructor(private fb: FormBuilder, private route: ActivatedRoute, private intentService: CreateIntentService,
    private spinner: NgxSpinnerService, private modalService: BsModalService,
  ) {
    this.route.paramMap.subscribe((params: any) => {
      this.intentId = params.params.intId;
      this.langId = params.params.langId;
      this.flag = params.params.flag;
    });
  }

  ngOnInit() {
    this.searchText = '';
    console.log(this.flag, this.newData);

    if (!this.flag) {
      this.intentId = this.newData[0],
        this.langId = this.newData[1],
        this.chId = this.newData[2],
        this.vaRoleId = this.newData[3]
    }

    this.addPhrases(this.intentId, this.langId, this.pageNum, this.searchText);

    this.intentService.intentSlots(this.intentId, this.langId).subscribe(res => {
      console.log(res);
      this.intentSlots = res['intentSlots'];
      this.intentSlots.forEach(element => {
        this.slotsToDisplay.push(element.intentSlotName);
      });
    });
  }

  ngOnChanges() {
    this.newData = this.arr;
    console.log('arr changes', this.newData);
  }

  addPhrases(intentId, langId, pageNum, searchText) {
    this.intentService.addTrainingPhrase(intentId, langId, pageNum, searchText).subscribe(res => {
      this.phrases = res['trainingPhrases'];
      console.log(this.phrases, res['trainingPhrases']);
      console.log('res ====>', pageNum, this.phrases);
      this.spinner.show();
      setTimeout(() => {
        this.displayTrainingPhrases(this.phrases);
        this.spinner.hide();
      }, 1000);
    }, err => {
      console.log(err);
    });
  }

  displayTrainingPhrases(phrases) {
    this.isLoaded = true;
    let trainingPhraseDisplay = '';
    console.log(phrases);
    for (let i = 0; i < phrases.length; i++) {
      let intentSlotPojo = phrases[i].intentSlotMapPojos;
      let posPhrase: any,
        trainingPhrases = phrases[i],
        rxp = /%([^%/]+)%/g, curMatch;
      posPhrase = trainingPhrases.trainingPhraseText;
      if (trainingPhrases.intentSlotMapPojos !== null) {
        console.log('inside if', intentSlotPojo);
        for (let k = 0; k < trainingPhrases.intentSlotMapPojos.length; k++) {
          while ((curMatch = rxp.exec(posPhrase))) {
            if (trainingPhrases.intentSlotMapPojos[k].position === curMatch[1]) {
              posPhrase = (posPhrase.replace(
                curMatch[1],
                trainingPhrases.intentSlotMapPojos[k].value));
              this.posPhraseValues = posPhrase.replace(/%/g, "");
            }
          }
        }
        phrases[i]['trainingPhraseDisplay'] = this.posPhraseValues;
      } else {
        phrases[i]['trainingPhraseDisplay'] = phrases[i].trainingPhraseText;
      }
      this.availablePhrases = phrases[i];
      console.log('update phrases --- ', this.availablePhrases);
    }
  }

  onSelect(event) {
    if (event && event.preventDefault) { event.preventDefault(); }
    this.IsHidden = !this.IsHidden;
    this.slotsList = [];
    this.slotsList = this.slotsToDisplay;
    console.log(this.slotsList);
  }

  functionClick($event) {
    if (!this.IsHidden) {
      this.IsHidden = !this.IsHidden;
    }
  }

  getSelectionText() {
    var selectedText: any;
    if (window.getSelection) {
      selectedText = window.getSelection().toString();
    }

    this.selectedSlot.push(selectedText);
    return this.selectedSlot;
  }

  getIntentSlotValue(x) {
    console.log('selectedslot', x, this.idToEdit);
    debugger
    this.selectedIntentSlots.push(x);
    this.selectedSlotId.push(x.intentSlotId);
    this.selectedSlotValue.push(x.intentSlotName);
    console.log(x, this.selectedSlotId, this.selectedSlotValue);

    for (let i = 0; i < this.intentSlots.length; i++) {
      console.log('selectedSlot', this.selectedSlot)
      console.log('selectedSlot-', this.selectedSlot[this.selectedSlot.length - 1]);
      if (this.intentSlots[i].intentSlotName == this.selectedSlotValue[this.selectedSlotValue.length - 1]) {

        this.intentSlots[i].selectedValue = this.selectedSlot[this.selectedSlot.length - 1];

      }
      console.log(this.intentSlots[i]);
    }

  }

  addToList(text: any) {
    this.isLoaded = true;
    let addedPhrase = this.addForm.value.addtext;

    this.newPhraseSlotDetails =
      {
        "intentSlotMapPojos": [],
        "trainingPhraseId": 0,
        "trainingPhraseText": addedPhrase,
        "trainingPhraseDisplay": addedPhrase
      }

    if (this.newPhraseSlotDetails.trainingPhraseDisplay == this.valueToEdit) {
      if (this.idToEdit != 0) {
        this.newPhraseSlotDetails.trainingPhraseId = this.idToEdit;
        // this.addArray.forEach(element => {
        //   if(element.trainingPhraseId == this.newPhraseSlotDetails.trainingPhraseId){
        //     this.newPhraseSlotDetails.intentSlotMapPojos = element.intentSlotMapPojos
        //     console.log(element.trainingPhraseId);
        //   }
        // });
        console.log('idtoedit', this.idToEdit, this.newPhraseSlotDetails, this.addArray);
      }
      else {
        this.newPhraseSlotDetails.intentSlotMapPojos = [];
        if (this.addArray.length == 1) {
          this.addArray = [];
          console.log('edit addedin o id', this.newPhraseSlotDetails, this.addArray, this.valueToEdit);
        }
      }
      console.log('edit addedin o id', this.newPhraseSlotDetails, this.addArray, this.valueToEdit);
    }

    if (this.selectedSlot.length > 0) {
      this.newPhraseSlotDetails.trainingPhraseText = addedPhrase;
      this.newPhraseSlotDetails.trainingPhraseDisplay = addedPhrase;
      for (let i = 0; i < this.selectedSlot.length; i++) {
        let pos = `pos${i}`;
        this.newPhraseSlotDetails.intentSlotMapPojos.push({
          "intentSlot": {
            "intentSlotId": this.selectedSlotId[i],
            "intentSlotName": this.selectedSlotValue[i],
            "selectedValue": this.selectedSlot[i]
          },
          "position": pos,
          "value": this.selectedSlot[i]
        });
        this.newPhraseSlotDetails.trainingPhraseText = this.newPhraseSlotDetails.trainingPhraseText.replace(this.selectedSlot[i], `%${pos}%`);
      }
    }

    if (this.newPhraseSlotDetails.trainingPhraseId === 0) {
      console.log('if ', this.addArray, this.valueToEdit);
      if (this.addArray.length > 1 && this.valueToEdit) {
        console.log(this.addArray, this.valueToEdit);
        for (let i = 0; i < this.addArray.length; i++) {
          if (this.addArray[i].trainingPhraseDisplay === this.valueToEdit) {
            console.log(this.addArray, i);
            this.addArray.splice(i, 1);
            this.addArray.push(this.newPhraseSlotDetails);
          }
        } console.log(this.addArray);
        this.valueToEdit = '';
      }
      else {
        this.addArray.push(this.newPhraseSlotDetails);
        this.valueToEdit = '';
      }
    }

    else {
      console.log('id varies');
      if (this.idToEdit == this.newPhraseSlotDetails.trainingPhraseId && this.valueToEdit) {
        for (let i = 0; i < this.phrases.length; i++) {
          if (this.phrases[i].trainingPhraseId === this.idToEdit) {
            this.phrases.splice(i, 1);
            this.addArray.push(this.newPhraseSlotDetails);
            console.log(this.addArray, this.newPhraseSlotDetails, this.phrases[i], this.idToEdit);
          }
          // else{
          //   this.addArray.forEach(element => {
          //     console.log('element',element.trainingPhraseId);
          //     if (element.trainingPhraseId === this.idToEdit) {
          //       this.addArray.splice(i, 1);
          //       this.addArray.push(this.newPhraseSlotDetails);
          //       console.log(this.addArray, this.newPhraseSlotDetails, this.phrases[i], this.idToEdit);
          //     }
          //   });
          // }
        }
      }
      else {
        this.addArray.push(this.newPhraseSlotDetails);
        this.valueToEdit = '';
      }
    }


    this.addForm.reset();
    console.log('intentmappojos', this.newPhraseSlotDetails.intentSlotMapPojos)
    for (let i = 0; i < this.intentSlots.length; i++) {
      if (this.intentSlots[i].selectedValue) {
        delete this.intentSlots[i].selectedValue;
      }
    }
    this.selectedSlot = [], this.selectedSlotId = [], this.selectedSlotValue = [];
  }


  openModal(template: TemplateRef<any>, id, value) {
    console.log('phrase del', id);
    this.idToDelete = id;
    this.valueToDelete = value;
    this.modalRef = this.modalService.show(template, this.config);
  }

  deleteTrainingPhrase() {
    console.log('train delete phrase', this.idToDelete);
    if (this.idToDelete === 0) {
      for (let i = 0; i < this.addArray.length; i++) {
        if (this.addArray[i].trainingPhraseDisplay === this.valueToDelete) {
          this.addArray.splice(i, 1);
        }
      }
      this.modalRef.hide();
      console.log(this.addArray);
    }
    else {
      if (this.searchText = '' || undefined) {
        this.searchText = '';
      }
      this.intentService
        .deleteTrainingPhrase(this.intentId, this.langId, this.idToDelete, this.searchText)
        .subscribe(res => {
          console.log(res);
          this.modalRef.hide();
          this.idToDelete = null;
          this.phrases = res;
          this.displayTrainingPhrases(this.phrases);
        });
    }
  }

  removeSelectedValue(value) {
    this.intentSlots.forEach(element => {
      if (element.selectedValue == value) {
        element.selectedValue = '';
      }
    });
  }

  editPhrase(value, id) {
    this.idToEdit = id;
    this.valueToEdit = value;
    this.addForm.setValue({
      'addtext': value
    });
    console.log(this.phrases, this.addArray);
    for (let q = 0; q < this.intentSlots.length; q++) {
      console.log(this.intentSlots[q]);
      this.intentSlots[q].selectedValue = '';
      console.log(this.intentSlots[q]);
    }

    for (let i = 0; i < this.phrases.length; i++) {
      if (this.phrases[i].trainingPhraseId == this.idToEdit) {
        if (this.phrases[i].intentSlotMapPojos !== null) {
          for (let k = 0; k < this.phrases[i].intentSlotMapPojos.length; k++){
            for (let j = 0; j < this.intentSlots.length; j++) {
              console.log('looped slots mappojos', this.intentSlots, this.intentSlots[j], this.phrases[i], this.phrases[i].intentSlotMapPojos);
              if (this.intentSlots[j].intentSlotName == this.phrases[i].intentSlotMapPojos[k].intentSlot.intentSlotName) {
                this.intentSlots[j].selectedValue = this.phrases[i].intentSlotMapPojos[k].value;
                console.log('looped slots mappojos inloop', this.intentSlots, this.intentSlots[j], this.phrases[i], this.phrases[i].intentSlotMapPojos);
              }
            }
          }
            console.log('pojo list present', this.phrases[i],this.intentSlots);
        }
        else {
          for (let q = 0; q < this.intentSlots.length; q++) {
            this.intentSlots[q].selectedValue = '';
            console.log('slot selected remove value', this.intentSlots[q]);
          }
          console.log('pojos null', this.intentSlots[i]);
        }
      }
      else if (this.addArray[i]) {
        console.log(this.addArray[i], this.addArray);
        for (let r = 0; r < this.addArray.length; r++) {
          console.log(this.addArray[r]);
          if ((this.addArray[r].trainingPhraseId == this.idToEdit) && (this.idToEdit != 0)) {
            if (this.addArray[r].intentSlotMapPojos !== null) {
              for (let k = 0; k < this.addArray[r].intentSlotMapPojos.length; k++) {
                for (let j = 0; j < this.intentSlots.length; j++) {
                  console.log('looped slots mappojos', this.intentSlots, this.intentSlots[j], this.addArray[r], this.addArray[r].intentSlotMapPojos);
                  if (this.intentSlots[j].intentSlotName == this.addArray[r].intentSlotMapPojos[k].intentSlot.intentSlotName) {
                    this.intentSlots[j].selectedValue = this.addArray[r].intentSlotMapPojos[k].value;
                    console.log('looped slots mappojos inloop', this.intentSlots, this.intentSlots[j], this.addArray[r], this.addArray[r].intentSlotMapPojos);
                  }
                }
              }
            }
            else {
              console.log('add array pojos null');
            }
          }
          else {
            if (this.addArray[r].trainingPhraseDisplay == this.valueToEdit) {
              for (let k = 0; k < this.addArray[r].intentSlotMapPojos.length; k++) {
                for (let j = 0; j < this.intentSlots.length; j++) {
                  if (this.intentSlots[j].intentSlotName == this.addArray[r].intentSlotMapPojos[k].intentSlot.intentSlotName) {
                    this.intentSlots[j].selectedValue = this.addArray[r].intentSlotMapPojos[k].value;
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  cancelAdd() {
    this.addForm.reset();
    this.intentSlots.forEach(element => {
      if (element.selectedValue) {
        element.selectedValue = '';
      }
    });
  }

  saveAddedTrainingPhrases() {
    console.log(this.addArray);
    for (let i = 0; i < this.addArray.length; i++) {
      delete this.addArray[i].trainingPhraseDisplay;
    }
    console.log(this.addArray);
    this.intentService.addPhraseDetails(this.intentId, this.langId, this.addArray).subscribe(res => {
      console.log(res);
      alert('Saved successfully');
    });
    this.intentService.addTrainingPhrase(this.intentId, this.langId, this.pageNum, this.searchText)
      .subscribe((res: any[]) => {
        this.isLoaded = true;
        console.log(res, 'scrolleddata', this.phrases);
      });
    this.addArray = [];
    this.addForm.reset();
  }


  onScroll(pageNum, intentId, langId, searchText) {
    this.counter += 1;
    console.log(this.counter, pageNum, intentId, langId);
    if (searchText === ('' || undefined)) {
      this.searchText = '';
    }

    this.intentService.addTrainingPhrase(intentId, langId, pageNum, searchText).subscribe(res => {
      this.phrases = res['trainingPhrases'];
      console.log('res ====>', pageNum, this.phrases);
      //  this.phrases = res;
      // this.spinner.show();
      // setTimeout(() => {
      //   //this.displayTrainingPhrases(this.phrases);
      //   this.spinner.hide();
      // }, 1000);
    }, err => {
      console.log(err);
    });
  }

  onSearch(text) {
    console.log(text);
    this.searchText = text;
    this.intentService.addTrainingPhrase(this.intentId, this.langId, this.pageNum, this.searchText)
      .subscribe((res: any[]) => {
        this.isLoaded = true;
        this.phrases = res['trainingPhrases'];
        this.displayTrainingPhrases(this.phrases);
        console.log(res, 'searchdata');

      });
    console.log(this.searchText, this.phrases.trainingPhrases);
  }
}

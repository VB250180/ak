import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { TrainingPhrasesComponent } from './training-phrases.component';
import { CreateIntentService } from '../create-intent.service';
import { of } from 'rxjs';
import { BsModalService } from 'ngx-bootstrap/modal';


describe('TrainingPhrasesComponent', () => {
  let component: TrainingPhrasesComponent;
  let fixture: ComponentFixture<TrainingPhrasesComponent>;

  let intentSlotValues = 
    {
      "virtualAgent": null,
      "virtualAgents": null,
      "intent": null,
      "intents": null,
      "conversation": null,
      "trainingPhrases": null,
      "virtualAgentDashboardResponseObject": null,
      "virtualAgentTrendResponseObject": null,
      "systemSlotKeys": null,
      "count": null,
      "languages": null,
      "channels": null,
      "intentLanguageChannelMaps": null,
      "intentSlots": [
        {
          "intentSlotId": 7,
          "intentSlotName": "To city",
          "intentSlotDescription": "city",
          "entity": {
            "entityId": 1,
            "entityName": "fromPlace"
          }
        },
        {
          "intentSlotId": 6,
          "intentSlotName": "City from",
          "intentSlotDescription": "from city",
          "entity": {
            "entityId": 1,
            "entityName": "fromPlace"
          }
        },
        {
          "intentSlotId": 1,
          "intentSlotName": "fromPlace",
          "intentSlotDescription": "from city",
          "entity": {
            "entityId": 1,
            "entityName": "fromPlace"
          }
        },
        {
          "intentSlotId": 2,
          "intentSlotName": "toPlace",
          "intentSlotDescription": "to city",
          "entity": {
            "entityId": 2,
            "entityName": "toPlace"
          }
        }
      ],
      "entities": null,
      "errorBody": null
    };
   
  let phrases = {
  "virtualAgent": null,
  "virtualAgents": null,
  "intent": null,
  "intents": null,
  "conversation": null,
  "trainingPhrases": [
    {
      "trainingPhraseId": 130,
      "trainingPhraseText": "Book a flight ticket from Singaporee to %pos0%",
      "intentSlotMapPojos": [
        {
          "position": "pos0",
          "value": "newzealand",
          "intentSlot": {
            "intentSlotId": 1,
            "intentSlotName": "fromPlace",
            "intentSlotDescription": "from city",
            "entity": {
              "entityId": 1,
              "entityName": "fromPlace"
            }
          }
        }
      ],
      "trainingPhraseStage": "notTrained"
    },
    {
      "trainingPhraseId": 132,
      "trainingPhraseText": "i want to book a movie ticket from %pos0%",
      "intentSlotMapPojos": [
        {
          "position": "pos0",
          "value": "Bengaluru",
          "intentSlot": {
            "intentSlotId": 1,
            "intentSlotName": "fromPlace",
            "intentSlotDescription": "from city",
            "entity": {
              "entityId": 1,
              "entityName": "fromPlace"
            }
          }
        }
      ],
      "trainingPhraseStage": "notTrained"
    },
    {
      "trainingPhraseId": 135,
      "trainingPhraseText": "agile methodology in akeira 2.0 product %pos1%",
      "intentSlotMapPojos": [
        {
          "position": "pos1",
          "value": "development",
          "intentSlot": {
            "intentSlotId": 7,
            "intentSlotName": "To city",
            "intentSlotDescription": "city",
            "entity": {
              "entityId": 1,
              "entityName": "fromPlace"
            }
          }
        },
        {
          "position": "pos0",
          "value": "list",
          "intentSlot": {
            "intentSlotId": 7,
            "intentSlotName": "To city",
            "intentSlotDescription": "city",
            "entity": {
              "entityId": 1,
              "entityName": "fromPlace"
            }
          }
        }
      ],
      "trainingPhraseStage": "notTrained"
    }],
  "virtualAgentDashboardResponseObject": null,
  "virtualAgentTrendResponseObject": null,
  "systemSlotKeys": null,
  "count": null,
  "languages": null,
  "channels": null,
  "intentLanguageChannelMaps": null,
  "intentSlots": null,
  "entities": null,
  "errorBody": null
  }

  let addPhrases = 
  {
    "virtualAgent": null,
    "virtualAgents": null,
    "intent": null,
    "intents": null,
    "conversation": null,
    "trainingPhrases": [
      {
        "trainingPhraseId": 148,
        "trainingPhraseText": "Book flight ticket from Bengaluru",
        "intentSlotMapPojos": [
          {
            "position": "pos0",
            "value": "Bengaluru",
            "intentSlot": {
              "intentSlotId": 1,
              "intentSlotName": "From place",
              "intentSlotDescription": null,
              "entity": null
            }
          }
        ],
        "trainingPhraseStage": "notTrained"
      }
    ],
    "virtualAgentDashboardResponseObject": null,
    "virtualAgentTrendResponseObject": null,
    "systemSlotKeys": null,
    "count": null,
    "languages": null,
    "channels": null,
    "intentLanguageChannelMaps": null,
    "intentSlots": null,
    "entities": null,
    "errorBody": null
  }
  

  const intentService = jasmine.createSpyObj('CreateIntentService', ['intentSlots','addTrainingPhrase','addPhraseDetails']);
  intentService.intentSlots.and.returnValue( of(intentSlotValues) );
  intentService.addTrainingPhrase.and.returnValue( of(phrases) );
  intentService.addPhraseDetails.and.returnValue( of(addPhrases) );
//  intentService.addTrainingPhrase.and.returnValue( of(phrases) );


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: CreateIntentService, useValue: intentService },
        { provide: BsModalService }
      ],
      declarations: [ TrainingPhrasesComponent ],
      imports:[FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        RouterTestingModule,
        HttpClientTestingModule
      ],
      schemas: [ NO_ERRORS_SCHEMA,CUSTOM_ELEMENTS_SCHEMA ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrainingPhrasesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create', () => {
    expect(component).toBeDefined();
  });

  it('check methods', () => {
    component.onSearch('test');
    expect(component.searchText).toBe('test');
    
    let e={};   
    component.getSelectionText();
    component.saveAddedTrainingPhrases();
    component.cancelAdd();
    component.functionClick(event);
    component.onSelect(event);

    component.addPhrases(1,2,1,'');

  });
  
});

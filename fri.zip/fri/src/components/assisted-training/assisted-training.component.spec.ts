import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssistedTrainingComponent } from './assisted-training.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { BsModalService } from "ngx-bootstrap/modal";

import { AssistedTrainingService } from './assisted-training.service';
import { of } from 'rxjs';

describe('AssistedTrainingComponent', () => {
  let component: AssistedTrainingComponent;
  let fixture: ComponentFixture<AssistedTrainingComponent>;

  let assistedTrainingInputs = {
    "virtualAgents": [
      {
        "virtualAgent": {
          "vaId": 2,
          "vaName": "webBot",
          "vaIsLive": false,
          "vaAvatarName": "UMRBOT",
          "vaDescription": "web"
        },
        "languages": [
          {
            "id": 1,
            "value": "English"
          },
          {
            "id": 2,
            "value": "French"
          }
        ],
        "channels": [
          {
            "id": 1,
            "value": "WEB"
          }
        ]
      }
    ]
  };

  let intentList = {
    "mappedCount": 0,
    "inScopeCount": 0,
    "outOfScopeCount": 4,
    "conversationList": [
      {
        "sessionId": 1,
        "mapppedPhrases": [],
        "inScopePhrases": [],
        "outOfScopePhrases": [
          {
            "id": 1,
            "value": "need information"
          }
        ]
      },
      {
        "sessionId": 2,
        "mapppedPhrases": [],
        "inScopePhrases": [],
        "outOfScopePhrases": [
          {
            "id": 7,
            "value": "first class ticket from mumbai"
          },
          {
            "id": 4,
            "value": "ticket book pannanum"
          },
          {
            "id": 3,
            "value": "sollunga"
          }
        ]
      }
    ]
  };

  let intentSlots = [
    {
      "intent": {
        "id": 4,
        "value": "praveen intent"
      },
      "intentSlots": []
    },
    {
      "intent": {
        "id": 6,
        "value": "Booking Cancellation"
      },
      "intentSlots": []
    }
  ];

  let createIntentData = {
    "intent": {
      "intentId": 41,
      "intentName": "Test",
      "intentDescription": "Test",
      "virtualAgent": null,
      "businessUnit": null,
      "languages": [
        {
          "langEngId": 1,
          "langName": "English",
          "channels": [
            {
              "icmId": 65,
              "channelId": 1,
              "channelName": "WEB",
              "intentConfigStage": 0,
              "isLive": false
            }
          ]
        },
        {
          "langEngId": 2,
          "langName": "French",
          "channels": [
            {
              "icmId": 66,
              "channelId": 1,
              "channelName": "WEB",
              "intentConfigStage": 0,
              "isLive": false
            }
          ]
        }
      ]
    }
  }

  const assistedTrainingService = jasmine.createSpyObj('AssistedTrainingService', ['getInputs', 'getIntents', 'intentSlots', 'searchIntent', 'createIntent']);
  assistedTrainingService.getInputs.and.returnValue( of(assistedTrainingInputs) );
  assistedTrainingService.getIntents.and.returnValue( of(intentList) );
  assistedTrainingService.intentSlots.and.returnValue( of(intentSlots) );
  assistedTrainingService.searchIntent.and.returnValue( of(intentSlots) );
  assistedTrainingService.createIntent.and.returnValue( of(createIntentData) );

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: AssistedTrainingService, useValue: assistedTrainingService },
        { provide: BsModalService }
      ],
      declarations: [ AssistedTrainingComponent ],
      imports:[FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        RouterTestingModule],
      schemas: [ NO_ERRORS_SCHEMA,CUSTOM_ELEMENTS_SCHEMA ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssistedTrainingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeDefined();
  });

  it('check methods', () => {
    component.vaId = 2;
    component.dropdownValues();
    component.onSearch('test');
    expect(component.searchText).toBe('test');
    component.conversationListDetails();
    component.createNewIntent();

    let e = {};
    component.choosedDate(e);
    component.submitFilter(e);
    component.cancelFilter(e);
    component.showMessage('test');

    component.getIntentSlotValue({id:1, value: 1});
    expect(component.intentSlotId[0]).toBe(1);
    component.intentChanged({id:1, value: 1});
    expect(component.selectedIntentId).toBe(1);
  });
});

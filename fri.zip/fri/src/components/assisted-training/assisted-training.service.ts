import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { catchError, map, tap, delay,filter,scan } from 'rxjs/operators';
import { environment as env} from '../../environments/environment';

export interface List {
  agent: string;
  id: number;
  mandatory: boolean;
  language:string;
  channel:string;
  status:string;
}

@Injectable({
  providedIn: 'root'
})
export class AssistedTrainingService {

  constructor(private http:HttpClient) { }

  public getInputs() {
   //return this.http.get('../../assets/intent.json');
   return this.http.get(env.apiUrl+'/assistedTraining');

  }

  // public getConversationList(): Observable<List[]>{
  //   return this.http.get<List[]>('../../assets/input.json');
  // }
  
  public deleteUnmappedUserInputs(id: number):Observable<any>{
    return this.http.delete(env.apiUrl+"/unmappedUserInputs"+"?"+'chId='+id);
    // return this.http.delete(env.apiUrl+"/unmappedUserInputs"+"?"+id);
  }

  public getIntents(chn ,fromDate , langId, pageNo, sort, toDate, VA , text) {    
    return this.http.get(env.apiUrl+'/unmappedUserInputs'+"?"+'channelId='+chn+'&'+'conversationPhrase='+text+'&'+'fromDate='+fromDate+'&'+'languageId='+langId+'&'+'pageNumber='+pageNo+'&'+'sortByDesc='+sort+'&'+'toDate='+toDate+'&'+'vaId='+VA);
  }

  public searchIntent(virtualID, LangID){
      return this.http.get(env.apiUrl+'/intentsAndIntentSlots'+"?"+"languageId="+LangID+'&'+"vaId="+virtualID);
  }

  public intentSlots(virtualID, LangID){    
    return this.http.get(env.apiUrl+'/intentsAndIntentSlots'+"?"+"languageId="+LangID+'&'+"vaId="+virtualID);
  }
  
  public saveUnmappedInputs(inputs:any){
    return this.http.put(env.apiUrl+'/unmappedUserInputs', inputs);
  }

  public createIntent(body,vaId){
    console.log(body,vaId);
    return this.http.post(env.apiUrl+'/virtualAgent/'+vaId+"/"+'intents', body);
  }

  public saveIntent(body){
    console.log(body);
    return this.http.put(env.apiUrl+'/unmappedUserInputs/', body);
  }


}



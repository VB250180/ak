import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentListComponent } from './agent-list.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';

import { AgentListService } from './agent-list.service';
import { of } from 'rxjs';

describe('AgentListComponent', () => {
  let component: AgentListComponent;
  let fixture: ComponentFixture<AgentListComponent>;

  let channelAndLanguageList = {
    "languages": [
      {"langName":"French","langId":1},
      {"langName":"Spanish","langId":2}
    ],"channels": [
      {"channelId":1,"channelName":"WEB"},
      {"channelId":2,"channelName":"IVR"}
    ]
  };

  let vaListData = {
    "virtualAgentDashboardResponseObject": {
      "virtualAgentDashboardList": [
        {
          "vaAvatarName": "UMRBOT",
          "vaDescription": "webBot",
          "vaRoleName": "test",
          "vaTotalIntent": 0,
          "vaRoleMapId": 1,
          "vaDashChannelList": [
            {
              "vaChannel": "WEB",
              "vaRoleChannelMapId": 1,
              "vaDashLangList": [
                {
                  "vaLanguage": "English",
                  "vaLangEngineMapid": 1,
                  "vaUnmappedInputs": 0,
                  "vaDraftIntent": 0,
                  "vaCurrentMonthIntentAccuracy": 0,
                  "vaPreviousMonthIntentAccuracy": 0,
                  "vaCurrentWeekIntentAccuracy": 0,
                  "vaPreviousWeekIntentAccuracy": 0,
                  "vaCurrentMonthCallHandled": 0,
                  "vaPreviousMonthCallHandled": 0,
                  "vaCurrentWeekCallHandled": 0,
                  "vaPreviousWeekCallHandled": 0
                },
                {
                  "vaLanguage": "French",
                  "vaLangEngineMapid": 2,
                  "vaUnmappedInputs": 0,
                  "vaDraftIntent": 0,
                  "vaCurrentMonthIntentAccuracy": 0,
                  "vaPreviousMonthIntentAccuracy": 0,
                  "vaCurrentWeekIntentAccuracy": 0,
                  "vaPreviousWeekIntentAccuracy": 0,
                  "vaCurrentMonthCallHandled": 0,
                  "vaPreviousMonthCallHandled": 0,
                  "vaCurrentWeekCallHandled": 0,
                  "vaPreviousWeekCallHandled": 0
                }
              ]
            }
          ]
        },
        {
          "vaAvatarName": "UMRBOT",
          "vaDescription": "webBot",
          "vaRoleName": "live",
          "vaTotalIntent": 4,
          "vaRoleMapId": 2,
          "vaDashChannelList": [
            {
              "vaChannel": "WEB",
              "vaRoleChannelMapId": 1,
              "vaDashLangList": [
                {
                  "vaLanguage": "English",
                  "vaLangEngineMapid": 1,
                  "vaUnmappedInputs": 0,
                  "vaDraftIntent": 2,
                  "vaCurrentMonthIntentAccuracy": 0,
                  "vaPreviousMonthIntentAccuracy": 0,
                  "vaCurrentWeekIntentAccuracy": 0,
                  "vaPreviousWeekIntentAccuracy": 0,
                  "vaCurrentMonthCallHandled": 0,
                  "vaPreviousMonthCallHandled": 0,
                  "vaCurrentWeekCallHandled": 0,
                  "vaPreviousWeekCallHandled": 0
                },
                {
                  "vaLanguage": "French",
                  "vaLangEngineMapid": 2,
                  "vaUnmappedInputs": 6,
                  "vaDraftIntent": 1,
                  "vaCurrentMonthIntentAccuracy": 0,
                  "vaPreviousMonthIntentAccuracy": 0,
                  "vaCurrentWeekIntentAccuracy": 0,
                  "vaPreviousWeekIntentAccuracy": 0,
                  "vaCurrentMonthCallHandled": 0,
                  "vaPreviousMonthCallHandled": 0,
                  "vaCurrentWeekCallHandled": 0,
                  "vaPreviousWeekCallHandled": 0
                }
              ]
            }
          ]
        },
        {
          "vaAvatarName": "BOT",
          "vaDescription": "dummyBot",
          "vaRoleName": "test",
          "vaTotalIntent": 0,
          "vaRoleMapId": 3,
          "vaDashChannelList": [
            {
              "vaChannel": "IVR",
              "vaRoleChannelMapId": 2,
              "vaDashLangList": [
                {
                  "vaLanguage": "English",
                  "vaLangEngineMapid": 3,
                  "vaUnmappedInputs": 0,
                  "vaDraftIntent": 0,
                  "vaCurrentMonthIntentAccuracy": 0,
                  "vaPreviousMonthIntentAccuracy": 0,
                  "vaCurrentWeekIntentAccuracy": 0,
                  "vaPreviousWeekIntentAccuracy": 0,
                  "vaCurrentMonthCallHandled": 0,
                  "vaPreviousMonthCallHandled": 0,
                  "vaCurrentWeekCallHandled": 0,
                  "vaPreviousWeekCallHandled": 0
                },
                {
                  "vaLanguage": "French",
                  "vaLangEngineMapid": 4,
                  "vaUnmappedInputs": 0,
                  "vaDraftIntent": 0,
                  "vaCurrentMonthIntentAccuracy": 0,
                  "vaPreviousMonthIntentAccuracy": 0,
                  "vaCurrentWeekIntentAccuracy": 0,
                  "vaPreviousWeekIntentAccuracy": 0,
                  "vaCurrentMonthCallHandled": 0,
                  "vaPreviousMonthCallHandled": 0,
                  "vaCurrentWeekCallHandled": 0,
                  "vaPreviousWeekCallHandled": 0
                }
              ]
            }
          ]
        },
        {
          "vaAvatarName": "BOT",
          "vaDescription": "dummyBot",
          "vaRoleName": "live",
          "vaTotalIntent": 1,
          "vaRoleMapId": 4,
          "vaDashChannelList": [
            {
              "vaChannel": "IVR",
              "vaRoleChannelMapId": 2,
              "vaDashLangList": [
                {
                  "vaLanguage": "English",
                  "vaLangEngineMapid": 3,
                  "vaUnmappedInputs": 0,
                  "vaDraftIntent": 1,
                  "vaCurrentMonthIntentAccuracy": 0,
                  "vaPreviousMonthIntentAccuracy": 0,
                  "vaCurrentWeekIntentAccuracy": 0,
                  "vaPreviousWeekIntentAccuracy": 0,
                  "vaCurrentMonthCallHandled": 0,
                  "vaPreviousMonthCallHandled": 0,
                  "vaCurrentWeekCallHandled": 0,
                  "vaPreviousWeekCallHandled": 0
                },
                {
                  "vaLanguage": "French",
                  "vaLangEngineMapid": 4,
                  "vaUnmappedInputs": 0,
                  "vaDraftIntent": 0,
                  "vaCurrentMonthIntentAccuracy": 0,
                  "vaPreviousMonthIntentAccuracy": 0,
                  "vaCurrentWeekIntentAccuracy": 0,
                  "vaPreviousWeekIntentAccuracy": 0,
                  "vaCurrentMonthCallHandled": 0,
                  "vaPreviousMonthCallHandled": 0,
                  "vaCurrentWeekCallHandled": 0,
                  "vaPreviousWeekCallHandled": 0
                }
              ]
            }
          ]
        }
      ]
    }
  }

  let vaTrandData = {
    "virtualAgentTrendResponseObject": 
    {
      "monthTrendList": [
        {"trenddate":"2019-10-05","trendvalue":0},
        {"trenddate":"2019-10-12","trendvalue":33},
        {"trenddate":"2019-10-19","trendvalue":0},
        {"trenddate":"2019-10-26","trendvalue":0}
      ],
      "weekTrendList": [
        {"trenddate":"2019-10-30","trendvalue":0},
        {"trenddate":"2019-10-31","trendvalue":0},
        {"trenddate":"2019-11-01","trendvalue":0},
        {"trenddate":"2019-11-02","trendvalue":0},
        {"trenddate":"2019-11-03","trendvalue":0},
        {"trenddate":"2019-11-04","trendvalue":0},
        {"trenddate":"2019-11-05","trendvalue":0}
      ]
    }
  }

  const agebtListService = jasmine.createSpyObj('AgentListService', ['getChannels', 'getAgentList', 'getVATrandData']);
  agebtListService.getChannels.and.returnValue( of(channelAndLanguageList) );
  agebtListService.getAgentList.and.returnValue( of(vaListData) );
  agebtListService.getVATrandData.and.returnValue( of(vaTrandData) );

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: AgentListService, useValue: agebtListService }
      ],
      declarations: [ AgentListComponent ],
      imports:[FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        RouterTestingModule],
      schemas: [ NO_ERRORS_SCHEMA,CUSTOM_ELEMENTS_SCHEMA ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('check methods', () => {
    component.toggleLiveAgentGraphs(1);
    expect(component.liveAgentList[1].showTrand).toBe(true);

    component.toggleLiveAgentGraphs(1);
    expect(component.liveAgentList[1].showTrand).toBe(false);

    component.changeLiveDataTime('wtd' ,1);
    expect(component.liveAgentList[1].dataTime).toBe('wtd');

    expect(component.calculateIncreasePercent(200, 100)).toBe(100);

    component.changeLiveDataTime('wtd' ,1);
    expect(component.liveAgentList[1].dataTime).toBe('wtd');

    component.showLiveVA = false;
    component.toggleLiveVA();
    expect(component.showLiveVA).toBe(true);

    component.showTestVA = false;
    component.toggleTestVA();
    expect(component.showTestVA).toBe(true);
  });
});

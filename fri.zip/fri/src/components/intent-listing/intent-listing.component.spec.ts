import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IntentListingComponent } from './intent-listing.component';
import { FilterPipe } from '../../app/filter.pipe';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsModalService } from 'ngx-bootstrap/modal';


import { IntentService } from '../intent-listing/intent.service';

import { of } from 'rxjs';

describe('IntentListingComponent', () => {
  let component: IntentListingComponent;
  let fixture: ComponentFixture<IntentListingComponent>;

  let clonePhrase={
    "virtualAgent": null,
    "virtualAgents": null,
    "intent": {
      "intentId": 41,
      "intentName": "Test",
      "intentDescription": "Test",
      "virtualAgent": null,
      "businessUnit": null,
      "languages": [
        {
          "langEngId": 1,
          "langName": "English",
          "channels": [
            {
              "icmId": 364,
              "channelId": 1,
              "channelName": "WEB",
              "intentConfigStage": 0,
              "isLive": false
            }
          ]
        },
        {
          "langEngId": 2,
          "langName": "French",
          "channels": [
            {
              "icmId": 365,
              "channelId": 1,
              "channelName": "WEB",
              "intentConfigStage": 0,
              "isLive": false
            }
          ]
        }
      ]
    },
    "intents": null,
    "conversation": null,
    "trainingPhrases": null,
    "virtualAgentDashboardResponseObject": null,
    "virtualAgentTrendResponseObject": null,
    "systemSlotKeys": null,
    "count": null,
    "languages": null,
    "channels": null,
    "intentLanguageChannelMaps": null,
    "intentSlots": null,
    "entities": null,
    "errorBody": null
  };

let tableList = {
    "virtualAgent": null,
    "virtualAgents": null,
    "intent": null,
    "intents": [
      {
        "intentId": 78,
        "intentName": "intentForDummy17",
        "intentDescription": "intentForDummy17",
        "virtualAgent": {
          "vaId": 3,
          "vaName": "dummyBot",
          "vaIsLive": true,
          "vaAvatarName": "BOT",
          "vaDescription": "web"
        },
        "businessUnit": "categoryOne",
        "languages": [
          {
            "langEngId": 1,
            "langName": "French",
            "channels": [
              {
                "icmId": 199,
                "channelId": 1,
                "channelName": "WEB",
                "intentConfigStage": 1,
                "isLive": false
              },
              {
                "icmId": 200,
                "channelId": 2,
                "channelName": "IVR",
                "intentConfigStage": 1,
                "isLive": false
              }
            ]
          },
          {
            "langEngId": 2,
            "langName": "Spanish",
            "channels": [
              {
                "icmId": 201,
                "channelId": 1,
                "channelName": "WEB",
                "intentConfigStage": 1,
                "isLive": false
              },
              {
                "icmId": 202,
                "channelId": 2,
                "channelName": "IVR",
                "intentConfigStage": 1,
                "isLive": false
              }
            ]
          }
        ]
      }
    ],
    "conversation": null,
    "trainingPhrases": null,
    "virtualAgentDashboardResponseObject": null,
    "virtualAgentTrendResponseObject": null,
    "systemSlotKeys": null,
    "count": null,
    "languages": null,
    "channels": null,
    "intentLanguageChannelMaps": null,
    "intentSlots": null,
    "errorBody": null
};


let assistedTrainingInputs = {
  "virtualAgents": [
    {
      "virtualAgent": {
        "vaId": 1,
        "vaName": "webBot",
        "vaIsLive": false,
        "vaAvatarName": "UMRBOT",
        "vaDescription": "web"
      },
      "languages": [
        {
          "id": 1,
          "value": "English"
        },
        {
          "id": 2,
          "value": "French"
        }
      ],
      "channels": [
        {
          "id": 1,
          "value": "WEB"
        }
      ]
    }
  ]
};

  const intentService = jasmine.createSpyObj('IntentService', ['intentList','getInputs','cloneIntent']);
  intentService.intentList.and.returnValue( of(tableList) );
  intentService.getInputs.and.returnValue( of(assistedTrainingInputs) );
  intentService.cloneIntent.and.returnValue( of(clonePhrase) );




  beforeEach(async(() => {
    TestBed.configureTestingModule({
     
      providers: [ 
        { provide: IntentService, useValue: intentService }   ,
        { provide: BsModalService }    
       ],
       declarations: [ IntentListingComponent ],
       imports:[
        RouterTestingModule,  HttpClientTestingModule,BrowserAnimationsModule],
      schemas: [ NO_ERRORS_SCHEMA,CUSTOM_ELEMENTS_SCHEMA ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntentListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('check methods', () => {
    
    component.getIntentList(1,0,0,0);
    component.cloneIntentFunc(41,2);
    component.getdropdownValues();

  });

});

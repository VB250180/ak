import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { catchError, map, tap, delay, filter, scan } from 'rxjs/operators';
import { environment as env } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class IntentService {

  constructor(private http: HttpClient) { }

  public intentList(PageNo, VaId, VaChan, VaLang) {
    console.log("intentList ", PageNo, VaId, VaChan, VaLang);
    return this.http.get(env.apiUrl + '/intents/pageNumber/' + PageNo + "?" + 'channelId=' + VaChan + '&' + 'langEngId=' + VaLang + '&' + 'vaRoleId=' + VaId);
  }
  public intentListByName(PageNo, VaId, VaChan, VaLang, intenttxt) {
    console.log("intentListByName ", PageNo, VaId, VaChan, VaLang);
    return this.http.get(env.apiUrl + '/intents/pageNumber/' + PageNo + "?" + 'channelId=' + VaChan + '&' + 'langEngId=' + VaLang + '&' + 'vaRoleId=' + VaId + '&' + 'intentName=' + intenttxt);
  }

  // public intentList(PageNo, VaId, VaChan, VaLang) {

  //   return this.http.get('../../assets/listing.json');

  // }

  public getInputs() {
    return this.http.get(env.apiUrl + '/assistedTraining');
  }
  // http://10.7.138.218:8081/virtualAgent/1/intents/44/clone


  public cloneIntent(body, intId, vaId) {
    //console.log(body, intId, vaId);
    return this.http.post(env.apiUrl + '/virtualAgent/' + vaId + '/intents/' + intId + '/clone', body);
  }

  public toggleIntent(body, icmIds, vaId) {
    console.log(body, icmIds, vaId);
    return this.http.put(env.apiUrl + '/virtualAgent/' + vaId + '/intents/toggle', icmIds);
  }

  public deleteIntents(va_id, delete_intentId): Observable<any> {
    console.log('------delete---> ', va_id, delete_intentId);
    return this.http.put(env.apiUrl + "/virtualAgent/" + va_id + "/intents/", delete_intentId);
  }

}

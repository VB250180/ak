import { TestBed, async, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClientModule } from '@angular/common/http';
import { of } from 'rxjs';
import { IntentService } from './intent.service';

describe('IntentService', () => {
  let httpClientSpy: { get: jasmine.Spy, post: jasmine.Spy, put: jasmine.Spy  };
  let intentListService: IntentService;

  let clonePhrase={
      "virtualAgent": null,
      "virtualAgents": null,
      "intent": {
        "intentId": 41,
        "intentName": "Test",
        "intentDescription": "Test",
        "virtualAgent": null,
        "businessUnit": null,
        "languages": [
          {
            "langEngId": 1,
            "langName": "English",
            "channels": [
              {
                "icmId": 364,
                "channelId": 1,
                "channelName": "WEB",
                "intentConfigStage": 0,
                "isLive": false
              }
            ]
          },
          {
            "langEngId": 2,
            "langName": "French",
            "channels": [
              {
                "icmId": 365,
                "channelId": 1,
                "channelName": "WEB",
                "intentConfigStage": 0,
                "isLive": false
              }
            ]
          }
        ]
      },
      "intents": null,
      "conversation": null,
      "trainingPhrases": null,
      "virtualAgentDashboardResponseObject": null,
      "virtualAgentTrendResponseObject": null,
      "systemSlotKeys": null,
      "count": null,
      "languages": null,
      "channels": null,
      "intentLanguageChannelMaps": null,
      "intentSlots": null,
      "entities": null,
      "errorBody": null
    };
  
  let tableList = {
      "virtualAgent": null,
      "virtualAgents": null,
      "intent": null,
      "intents": [
        {
          "intentId": 78,
          "intentName": "intentForDummy17",
          "intentDescription": "intentForDummy17",
          "virtualAgent": {
            "vaId": 3,
            "vaName": "dummyBot",
            "vaIsLive": true,
            "vaAvatarName": "BOT",
            "vaDescription": "web"
          },
          "businessUnit": "categoryOne",
          "languages": [
            {
              "langEngId": 1,
              "langName": "French",
              "channels": [
                {
                  "icmId": 199,
                  "channelId": 1,
                  "channelName": "WEB",
                  "intentConfigStage": 1,
                  "isLive": false
                },
                {
                  "icmId": 200,
                  "channelId": 2,
                  "channelName": "IVR",
                  "intentConfigStage": 1,
                  "isLive": false
                }
              ]
            },
            {
              "langEngId": 2,
              "langName": "Spanish",
              "channels": [
                {
                  "icmId": 201,
                  "channelId": 1,
                  "channelName": "WEB",
                  "intentConfigStage": 1,
                  "isLive": false
                },
                {
                  "icmId": 202,
                  "channelId": 2,
                  "channelName": "IVR",
                  "intentConfigStage": 1,
                  "isLive": false
                }
              ]
            }
          ]
        }
      ],
      "conversation": null,
      "trainingPhrases": null,
      "virtualAgentDashboardResponseObject": null,
      "virtualAgentTrendResponseObject": null,
      "systemSlotKeys": null,
      "count": null,
      "languages": null,
      "channels": null,
      "intentLanguageChannelMaps": null,
      "intentSlots": null,
      "errorBody": null
  };


  let assistedTrainingInputs = {
    "virtualAgents": [
      {
        "virtualAgent": {
          "vaId": 1,
          "vaName": "webBot",
          "vaIsLive": false,
          "vaAvatarName": "UMRBOT",
          "vaDescription": "web"
        },
        "languages": [
          {
            "id": 1,
            "value": "English"
          },
          {
            "id": 2,
            "value": "French"
          }
        ],
        "channels": [
          {
            "id": 1,
            "value": "WEB"
          }
        ]
      }
    ]
  };




  beforeEach(() => {TestBed.configureTestingModule({
    imports: [HttpClientModule,HttpClientTestingModule],
    providers: [IntentService]
  })
  httpClientSpy = jasmine.createSpyObj('HttpClient', ['get', 'post', 'put']);
  intentListService = new IntentService(<any> httpClientSpy);
 });


 it(`should create`, async(inject([HttpTestingController, IntentService],
  (httpClient: HttpTestingController , service: IntentService) => {
    expect(httpClient).toBeTruthy();expect(service).toBeTruthy();
})));


 it(`should create`, () => {
  const service: IntentService = TestBed.get(IntentService);
  expect(service).toBeTruthy();
})

it('check table response', () => {
  
  httpClientSpy.get.and.returnValue(of(tableList));

  intentListService.intentList(1,0,0,0).subscribe(
    res => {
      expect(res['intents']['languages'].length).toBe(2);
    },
    fail
  );
  expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
});

it('check header response', () => {
  
  httpClientSpy.get.and.returnValue(of(assistedTrainingInputs));

  intentListService.getInputs().subscribe(
    res => {
      expect(res).toEqual(assistedTrainingInputs);
    },
    fail
  );
  expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
});


it('check clone', () => {
  httpClientSpy.post.and.returnValue(of(clonePhrase));

  intentListService.cloneIntent([],41,2).subscribe(
    res => {
      expect(res).toEqual(clonePhrase);
    },
    fail
  );
  expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
});


// it('check delete', () => {
//   httpClientSpy.put.and.returnValue(of(deletePhrase));

//   intentListService.deleteIntents(1,1).subscribe(
//     res => {
//       expect(res).toEqual(deletePhrase);
//     },
//     fail
//   );
//   expect(httpClientSpy.put.calls.count()).toBe(1, 'one call');
// });




});

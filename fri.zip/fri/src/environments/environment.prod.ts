export const environment = {
  //apiUrl:'http://10.7.138.249:8082',
  apiUrl: 'http://192.168.12.63:8082',
  production: true
};

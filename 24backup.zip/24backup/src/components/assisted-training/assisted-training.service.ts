import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { catchError, map, tap, delay,filter,scan } from 'rxjs/operators';
import { environment as env} from '../../environments/environment';

export interface List {
  agent: string;
  id: number;
  mandatory: boolean;
  language:string;
  channel:string;
  status:string;
}

@Injectable({
  providedIn: 'root'
})
export class AssistedTrainingService {

  constructor(private http:HttpClient) { }

  public getInputs() {
    // return this.http.get('http://10.7.138.21:8081/assistedTraining');
    return this.http.get(env.apiUrl+'/assistedTraining');

  }

  public getConversationList(): Observable<List[]>{
    return this.http.get<List[]>('../../assets/input.json');
  }
  
  public deleteUnmappedUserInputs(id: number):Observable<any>{
    return this.http.delete(env.apiUrl+"/unmappedUserInputs"+"?"+'vaId='+id);
  }

  public getIntents(channelId,language_id,VA_id,date,tempDate,sort,pageNumber ) {
    
    channelId=1;
    language_id=3;
    VA_id=2;
    date="2019-10-09";
    tempDate="2019-10-25";
    sort=true;
    pageNumber =1;
    
     //return this.http.get('http://10.7.138.195:8082/unmappedUserInputs?channelId=1&fromDate=2019-10-09&languageId=3&pageNumber=1&sortByDesc=true&toDate=2019-10-25&vaId=2');
    return this.http.get(env.apiUrl+'/unmappedUserInputs'+"?"+'channelId='+channelId+'&'+'fromDate='+date+'&'+'languageId='+language_id+'&'+'pageNumber='+pageNumber+'&'+'sortByDesc='+sort+'&'+'toDate='+tempDate+'&'+'vaId='+VA_id);
  }

}

//http://10.7.138.195:8082/unmappedUserInputs


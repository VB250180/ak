import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from '../components/home/home.component';
import { CallSummaryComponent } from '../components/call-summary/call-summary.component';
import { AssistedTrainingComponent } from '../components/assisted-training/assisted-training.component';
import { CreateIntentComponent } from 'src/components/create-intent/create-intent.component';
import { LandingPageComponent } from '../components/landing-page/landing-page.component';


const routes: Routes = [
  { path: 'call-summary-configuration', component: HomeComponent },
  { path: 'call-summary', component: CallSummaryComponent },
  { path: 'assisted-training', component: AssistedTrainingComponent },
  { path: 'create-intent', component: CreateIntentComponent },
  { path: 'landing-page', component: LandingPageComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

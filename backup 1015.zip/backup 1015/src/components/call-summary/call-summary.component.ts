import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-call-summary',
  templateUrl: './call-summary.component.html',
  styleUrls: ['./call-summary.component.scss']
})
export class CallSummaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

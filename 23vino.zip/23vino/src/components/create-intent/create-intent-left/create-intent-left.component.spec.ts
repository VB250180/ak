import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateIntentLeftComponent } from './create-intent-left.component';

describe('CreateIntentLeftComponent', () => {
  let component: CreateIntentLeftComponent;
  let fixture: ComponentFixture<CreateIntentLeftComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateIntentLeftComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateIntentLeftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

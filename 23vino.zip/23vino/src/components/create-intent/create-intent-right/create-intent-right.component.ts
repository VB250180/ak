import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-intent-right',
  templateUrl: './create-intent-right.component.html',
  styleUrls: ['./create-intent-right.component.scss']
})
export class CreateIntentRightComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

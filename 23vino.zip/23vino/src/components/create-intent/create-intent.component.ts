import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, Form, Validators } from '@angular/forms';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { Intent} from './model/create-intent';
import { CreateIntentLeftComponent } from './create-intent-left/create-intent-left.component';
import { CreateIntentRightComponent } from './create-intent-right/create-intent-right.component';
@Component({
  selector: 'app-create-intent',
  templateUrl: './create-intent.component.html',
  styleUrls: ['./create-intent.component.scss']
})
export class CreateIntentComponent implements OnInit {
  intent=new Intent();
  showValidation;showSendMsg;showGetInfo; showFinalRes;

  channels: any = [{ id: 1, value: "IVR" }, { id: 2, value: "Web" }, { id: 1, value: "Mobile" }];
  languages: any = [{ id: 1, value: "English" }, { id: 2, value: "Spanish" }, { id: 1, value: "English(US)" }];
  agents: any = [{ id: 1, value: "VA_one" }, { id: 2, value: "VA_two" }, { id: 1, value: "VA_three" }];
  units: any = [{ id: 1, value: "Health care" }, { id: 2, value: "BAnking" }];
  entities: any = [{ id: 1, value: "Date of Birth" }, { id: 2, value: "OTP" }, { id: 3, value: "Departure Date" }]
  systemslots: any = [{ id: 1, value: "Member Id(unique)" }, { id: 2, value: "Account number" }]

  channel: any;
  language: any;
  agent: any;
  unit: any;
  msg: any;
  msgValue: any;
  msgenteredValue: any;
  Emergencies: any = [];
  selected: any;
  clicks: number = 0;
  lastClick: any;
  createdName: any;

  showIntent: boolean = true;
  showConversation: boolean = false;
  showAddPhrases: boolean = false;
  audioupload: boolean = true;
  showCreateInfo: boolean = false;

  constructor(private fb: FormBuilder) { }

  intentInfoGroup: FormGroup;
  validationForm: FormGroup;
  sendMessageForm: FormGroup;
  getInfoForm: FormGroup;
  finalResForm: FormGroup;
  dataPoints: FormArray;
  resdataPoints: FormArray;
  sendResForm: FormGroup;

  ngOnInit() {
      this.validationForm = this.fb.group({
        slot_values: this.fb.array([this.fb.group({ slot: '' })])
      }),

      this.sendMessageForm = this.fb.group({
        msg: ['', Validators.required]
      }),

      this.intentInfoGroup = this.fb.group({
        name: ['', Validators.required],
        description: ['', Validators.required],
        agent: ['', Validators.required],
        language: ['', Validators.required],
        businessUnit: ['', Validators.required]
      }),

      this.intentInfoGroup.patchValue({
        agent: '',
        language: '',
        businessUnit: ''
      });

      this.getInfoForm = this.fb.group({
        dataPoints: this.fb.array([this.createGetInfoFields()])
      });

      this.finalResForm = this.fb.group({
        resdataPoints: this.fb.array([this.createResFields()])
      });

      this.sendResForm = this.fb.group({
        response:['', Validators.required]
      });
  }

  get slotValues() {
    return this.validationForm.get('slot_values') as FormArray;
  }

  createGetInfoFields(): FormGroup {
    return this.fb.group({
      name: '',
      description: '',
      relationship: "",
      entity: "",
      question: "",
      validationMsg: "",
    });
  }

  get datapointControls() {
    return this.getInfoForm.get('dataPoints')['controls'];
  }

  addSlotValue() {
    this.slotValues.push(this.fb.group({ slot: '' }));
  }

  deleteSlotValue(index) {
    this.slotValues.removeAt(index);
  }

  createResFields(): FormGroup {
    return this.fb.group({
      name: '',
      description: '',
      response: ''
    });
  }

  get resdatapointControls() {
    return this.finalResForm.get('resdataPoints')['controls'];
  }

  saveIntentInfo() {
    console.log(this.intentInfoGroup.value);
    alert('Intent content saved successfully');
  }


  slotSelected(slot, id) {
    console.log(slot.target.value, id);
    var selectedSlot: any = [];
    selectedSlot.push(slot.target.value);
    if (selectedSlot) {
      console.log('hrrr', slot, selectedSlot.length);
      this.addSlotValue();
    }
  }

  addEmergency() {
    var item = {
      "Name": "",
      "Description": "",
      "relationship": "",
      "entity": "",
      "question": "",
      "validationMsg": "",
      "id": this.clicks,
    }
    this.Emergencies.push(item);
    console.log("current id is ", item.id);
    this.lastClick = this.clicks;
    this.clicks += 1;
    if (this.clicks > 1) {
      if (this.clicks > this.lastClick) {
        alert("Are you sure to add one more form");
      }

    }
  }

  msgentered(msg) {
    this.msgenteredValue = msg;
  }

  addMsg() {
    this.msgValue = this.msgenteredValue;
    this.sendMessageForm.patchValue({
      msg: ''
    })
  }

  delMsg() {
    this.msgValue = '';
  }

  addInfoSlot() {
    this.showCreateInfo = true;
    console.log('entered', this.getInfoForm.controls.name)
    this.dataPoints = this.getInfoForm.get('dataPoints') as FormArray;
    this.dataPoints.push(this.createGetInfoFields());
    this.logValue();
  }

  removeInfoSlot(i: number) {
    console.log(i);
    this.dataPoints.removeAt(i);
  }

  addResSlot() {
    this.resdataPoints = this.finalResForm.get('resdataPoints') as FormArray;
    this.resdataPoints.push(this.createResFields());
    this.resValue();
  }

  removeResSlot(i: number) {
    console.log(i);
    this.resdataPoints.removeAt(i);
  }

  logValue() {
    console.log('entered', this.getInfoForm.value['dataPoints']);
    //this.createdName = this.getInfoForm.value['dataPoints'][0].name;
    console.log(this.createdName);
  }

  resValue() {
    console.log('entered', this.finalResForm.value['resdataPoints']);
    //this.createdName = this.getInfoForm.value['dataPoints'][0].name;
    console.log(this.createdName);
  }


  intentTab() {
    this.showIntent = true;
    this.showConversation = false;
    this.showAddPhrases = false;
  }

  conversationTab() {
    this.showIntent = false;
    this.showConversation = true;
    this.showAddPhrases = false;
  }

  addTab() {
    this.showIntent = false;
    this.showConversation = false;
    this.showAddPhrases = true;
  }

  uploadAudio() {
    this.audioupload = !this.audioupload;
    console.log('upload');
  }




  items =[ {
       validation: 
         [{label:"Validation Intent:",value:"Date of Birth" }],
         systemSlot:[
           {label:"System Slot:",value:"Member ID"},
           {label:"System Slot:",value:"Group ID"}
         ],
         sendMsg:[
          {label:"Send Message:",value:"sure let me get you that information"},
          {label:"Send Message:",value:"sure let me get you that information"}
        ],
        getInfo:[
          {label:"Get Info:",value:"date of birth",description:"Date when user took medical service",Question:"When did you take the service",validationMsg:"sorry i couldn't find a claim"}
        ]
   }] ;
         
  
        
  mapFunc(){
    if(this.intent.validationEntity!="" || undefined){
 this.showValidation="true"
    }
    }

    sendMsgFunc(){
      this.addMsg();
      this.showSendMsg="true"
    }
    getInfoFunc(){
      this.showGetInfo="true"
    }
    getfinalRes(){
    this.showFinalRes="true"
    console.log('res',this.finalResForm.value , this.sendResForm.value);
    }

}

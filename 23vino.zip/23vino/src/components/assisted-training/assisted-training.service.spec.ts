import { TestBed, async, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AssistedTrainingService } from './assisted-training.service';
import { HttpClientModule } from '@angular/common/http';

describe('AssistedTrainingService', () => {
  beforeEach(() => TestBed.configureTestingModule({
     imports: [HttpClientModule,HttpClientTestingModule],
    providers: [AssistedTrainingService]
  }));

  // it('should be created', () => {
  //   const service: AssistedTrainingService = TestBed.get(AssistedTrainingService);
  //   expect(service).toBeTruthy();
  // });

  it(`should create`, async(inject([HttpTestingController, AssistedTrainingService],
    (httpClient: HttpTestingController , service: AssistedTrainingService) => {
      expect(httpClient).toBeTruthy();expect(service).toBeTruthy();
  })));
});

import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';

import { NgSelectModule } from '@ng-select/ng-select';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule ,FormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';

import { MatSidenavModule } from '@angular/material/sidenav';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatStepperModule } from '@angular/material/stepper';
import { MatFormFieldModule, MatInputModule, MatSelectModule, MatProgressBarModule} from '@angular/material';
import { MatMenuModule} from '@angular/material/menu';

import { NgxSpinnerModule } from 'ngx-spinner';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import { ModalModule, BsModalRef } from 'ngx-bootstrap/modal';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { MatRadioModule } from '@angular/material/radio';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ChartsModule } from 'ng2-charts';
import {CreateIntentComponent} from '../components/create-intent/create-intent.component';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from '../components/home/home.component';
import { CallSummaryComponent } from '../components/call-summary/call-summary.component';
import { AssistedTrainingComponent } from '../components/assisted-training/assisted-training.component';
import { AgentListComponent } from '../components/agent-list/agent-list.component';
import { HeaderComponent } from '../components/header/header.component';
import { LandingPageComponent } from '../components/landing-page/landing-page.component';
import { IntentListingComponent } from '../components/intent-listing/intent-listing.component';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { FilterPipe } from './filter.pipe';
import { CreateIntentLeftComponent } from 'src/components/create-intent/create-intent-left/create-intent-left.component';
import { CreateIntentRightComponent } from 'src/components/create-intent/create-intent-right/create-intent-right.component';
// import { CompleterService } from 'ng2-completer';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CallSummaryComponent,
    AssistedTrainingComponent,
    CreateIntentComponent,
    LandingPageComponent,
    AgentListComponent,
    HeaderComponent,
    IntentListingComponent,
    FilterPipe,
    CreateIntentLeftComponent,
    CreateIntentRightComponent

    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    CommonModule,
    MatButtonModule,
    MatSidenavModule,
    MatListModule,
    MatIconModule,
    MatGridListModule,
    MatStepperModule,
    MatMenuModule,
    NgSelectModule,
    FormsModule,
    MatFormFieldModule, 
    MatInputModule,
    MatSelectModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    NgSelectModule,
    NgxSpinnerModule,
    AccordionModule.forRoot(),
    BsDropdownModule.forRoot(),
    NgxDaterangepickerMd.forRoot(),
    ModalModule.forRoot(),
    PopoverModule.forRoot(),
    MatRadioModule,
    MatSlideToggleModule,
    ChartsModule,
    MatProgressBarModule,
    PopoverModule.forRoot(),
    Ng2SmartTableModule
  ],
  schemas: [ NO_ERRORS_SCHEMA,CUSTOM_ELEMENTS_SCHEMA ],

  providers: [BsModalRef],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from '../components/home/home.component';
import { CallSummaryComponent } from '../components/call-summary/call-summary.component';
import { AssistedTrainingComponent } from '../components/assisted-training/assisted-training.component';
import { LandingPageComponent } from '../components/landing-page/landing-page.component';


const routes: Routes = [
  { path: 'call-summary-configuration', component: HomeComponent },
  { path: 'call-summary', component: CallSummaryComponent },
  { path: 'assisted-training', component: AssistedTrainingComponent },
  { path: 'landing-page', component: LandingPageComponent },
  { path: 'assisted-training', component: AssistedTrainingComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

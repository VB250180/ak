import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { catchError, map, tap, delay,filter,scan } from 'rxjs/operators';
import { environment as env} from '../../environments/environment';

export interface Inputs {
      agent: string;
      id: number;
      mandatory: boolean;
      language:string;
      channel:string;
      status:string;
}
export interface List {
  agent: string;
  id: number;
  mandatory: boolean;
  language:string;
  channel:string;
  status:string;
}

@Injectable({
  providedIn: 'root'
})
export class AssistedTrainingService {

  constructor(private http:HttpClient) { }

  public getInputs() {
    return this.http.get('http://10.7.138.21:8081/assistedTraining');
  }

  public getConversationList(): Observable<List[]>{
    return this.http.get<List[]>('../../assets/input.json');
  }

  // public getUnmapped() {
  //   return this.http.get('http://10.7.138.21:8081/assistedTraining');
  // }


  // public deleteUnmappedUserInputs(id: number):Observable<any>{
  //   return this.http.delete(env.apiUrl+"/unmappedUserInputs"+"?"+'vaId='+id);
  // }
}
import { TestBed } from '@angular/core/testing';

import { AssistedTrainingService } from './assisted-training.service';

describe('AssistedTrainingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AssistedTrainingService = TestBed.get(AssistedTrainingService);
    expect(service).toBeTruthy();
  });
});

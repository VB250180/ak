// export class  CreateIntent{
//     validation:Validation;
// }

export class Validation{
    channel:any;
    language:string;
}
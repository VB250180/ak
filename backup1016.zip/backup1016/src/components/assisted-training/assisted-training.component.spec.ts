import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssistedTrainingComponent } from './assisted-training.component';

describe('AssistedTrainingComponent', () => {
  let component: AssistedTrainingComponent;
  let fixture: ComponentFixture<AssistedTrainingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssistedTrainingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssistedTrainingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { BsDropdownConfig, BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { async, ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';

import { IntentListingComponent } from './intent-listing.component';
import { FilterPipe } from '../../app/filter.pipe';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, TemplateRef } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { NgxSpinnerService } from 'ngx-spinner';
import { of, BehaviorSubject, Observable } from 'rxjs';
import { Template } from '@angular/compiler/src/render3/r3_ast';
import { IntentService } from './intent.service';
import { ActivatedRoute } from '@angular/router';
import { ToastrModule } from 'ngx-toastr';
import { NgSelectModule } from '@ng-select/ng-select';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';


class ActivatedRouteStub {
  paramsObj = {
    name: 'name',
    id: '1',
    desc: 'desc',
    channel: 'chnl',
    lang: 'en-uk',
    chId: 'chId',
    langId: '1',
    get: (property) => {
      return this.paramsObj[property];
    }
  }
  public paramMap = new BehaviorSubject(this.paramsObj);
}

class BsModalRefStub {
  public hide() { }
}

class NgxSpinnerServiceStub {
  public show(spinnerType) { }

  public hide(spinnerType) { }
}

class BsModalServiceStub {

  public show(template, config) { }

  public hide() { }
}

class IntentServiceStub {
  public getInputs() {
    return Observable.of({
      virtualAgents: [{
        virtualAgent: {
          vaId: 1,
          vaName: 'webBot',
          vaIsLive: false,
          vaAvatarName: 'UMRBOT',
          vaDescription: 'web'
        },
        languages: [
          {
            id: 1,
            value: 'English'
          },
          {
            id: 2,
            value: 'French'
          }
        ],
        channels: [
          {
            id: 1,
            value: 'WEB'
          }
        ]
      },
      {
        virtualAgent: {
          vaId: 2,
          vaName: 'webBot',
          vaIsLive: false,
          vaAvatarName: 'UMRBOT',
          vaDescription: 'web'
        },
        languages: [
          {
            id: 1,
            value: 'English'
          },
          {
            id: 2,
            value: 'French'
          }
        ],
        channels: [
          {
            id: 1,
            value: 'WEB'
          }
        ]
      }]
    });
  }

  public intentList(PageNo, VaId, VaChan, VaLang): Observable<any> {
    return Observable.of({
      count: 1,
      virtualAgent: null,
      virtualAgents: null,
      intent: null,
      intents: [
        {
          intentId: 78,
          intentName: "intentForDummy17",
          intentDescription: "intentForDummy17",
          virtualAgent: {
            vaId: 3,
            vaName: "dummyBot",
            vaIsLive: true,
            vaAvatarName: "BOT",
            vaDescription: "web"
          },
          businessUnit: "categoryOne",
          languages: [
            {
              langEngId: 1,
              langName: "French",
              channels: [
                {
                  icmId: 199,
                  channelId: 1,
                  channelName: "WEB",
                  intentConfigStage: 1,
                  isLive: false
                },
                {
                  icmId: 200,
                  channelId: 2,
                  channelName: "IVR",
                  intentConfigStage: 1,
                  isLive: false
                }
              ]
            },
            {
              langEngId: 2,
              langName: "Spanish",
              channels: [
                {
                  icmId: 201,
                  channelId: 1,
                  channelName: "WEB",
                  intentConfigStage: 1,
                  isLive: false
                },
                {
                  icmId: 202,
                  channelId: 2,
                  channelName: "IVR",
                  intentConfigStage: 1,
                  isLive: false
                }
              ]
            }
          ]
        }
      ]
    });
  }

  public intentListByName(PageNo, VaId, VaChan, VaLang, intenttxt): Observable<any> {
    return this.intentList(PageNo, VaId, VaChan, VaLang);
  }

  public cloneIntent(body, intId, vaId) {
    if (intId == 1) {
      return Observable.of({
        intent: 'intent'
      });
    } else {
      return Observable.of({
        intent: null
      })
    }

  }

  public deleteIntents(va_id, delete_intentId): Observable<any> {
    if (va_id == 1) {
      return Observable.of({
        intents: [{ intentId: 1 }, { intentId: 2 }]
      });
    } else {
      return Observable.of({
        intents: []
      });
    }
  }
}

describe('IntentListingComponent', () => {
  let component: IntentListingComponent;
  let fixture: ComponentFixture<IntentListingComponent>;
  let template: TemplateRef<any>

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: IntentService, useClass: IntentServiceStub },
        { provide: ActivatedRoute, useClass: ActivatedRouteStub },
        { provide: BsModalService, useClass: BsModalServiceStub },
        { provide: BsModalRef, useClass: BsModalRefStub },
        { provide: NgxSpinnerService, useClass: NgxSpinnerServiceStub },
        { provide: BsDropdownConfig }
      ],
      declarations: [IntentListingComponent],
      imports: [FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
        ToastrModule.forRoot(),
        BsDropdownModule.forRoot(),
        RouterTestingModule,
        NgSelectModule
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntentListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('ngOnInit should initialize variables from ActivatedRouted and call getdropdownValues method', () => {
    const spinner = TestBed.get(NgxSpinnerService);
    const spinnerSpy = spyOn(spinner, 'show');
    const getdropdownValuesSpy = spyOn(component, 'getdropdownValues');

    component.ngOnInit();

    expect(spinnerSpy).toHaveBeenCalled();
    expect(component.vaName).toEqual('name');
    expect(component.vaId).toEqual('1');
    expect(component.vaDesc).toEqual('desc');
    expect(component.vaChan).toEqual('chnl');
    expect(component.vaLang).toEqual('en-uk');
    expect(component.vaChanId).toEqual('chId');
    expect(component.vaLangId).toEqual('1');
    expect(getdropdownValuesSpy).toHaveBeenCalled();
  });

  it('getdropdownValues should initialize vaLists and vaById call callIntentListByparam method', fakeAsync(() => {
    const callIntentListByparamSpy = spyOn(component, 'callIntentListByparam');

    component.getdropdownValues();

    expect(component.vaLists.length).toEqual(2);
    expect(Object.keys(component.vaById).length).toEqual(2);
    jasmine.clock().tick(1000);
    expect(callIntentListByparamSpy).toHaveBeenCalled();
  }));

  it('callIntentListByparam should call statusFilter and getIntentList methods', () => {
    const spinner = TestBed.get(NgxSpinnerService);
    const spinnerSpy = spyOn(spinner, 'hide');
    const statusFilterSpy = spyOn(component, 'statusFilter');
    const getIntentListSpy = spyOn(component, 'getIntentList');

    component.callIntentListByparam();

    expect(spinnerSpy).toHaveBeenCalled();
    expect(component.intentFilter.va).toEqual(Number(component.vaId));
    expect(component.intentFilter.channel).toEqual(Number(component.vaChanId));
    expect(component.intentFilter.language).toEqual(Number(component.vaLangId));
    expect(statusFilterSpy).toHaveBeenCalledBefore(getIntentListSpy);
    expect(getIntentListSpy).toHaveBeenCalled();
  });

  it('callIntentListByparam should initialize intentFilter values to zero and call getIntentList method only', () => {
    const statusFilterSpy = spyOn(component, 'statusFilter');
    const getIntentListSpy = spyOn(component, 'getIntentList');
    component.vaId = undefined;

    component.callIntentListByparam();

    expect(component.intentFilter.va).toEqual(0);
    expect(component.intentFilter.channel).toEqual(0);
    expect(component.intentFilter.language).toEqual(0);
    expect(statusFilterSpy).toHaveBeenCalledTimes(0);
    expect(getIntentListSpy).toHaveBeenCalled();
  });

  it('onScroll should increment counter and call tableDataGen once', () => {
    const tableDataGenSpy = spyOn(component, 'tableDataGen');
    component.counter = 1;

    component.onScroll();

    expect(component.counter).toEqual(2);
    expect(component.loaded).toBeTruthy();
    expect(tableDataGenSpy).toHaveBeenCalledTimes(1);
  });

  it('statusFilter should initialize intentFilter values and call getIntentList method once', () => {
    const getIntentListSpy = spyOn(component, 'getIntentList');
    const status = 0;
    const isRequestNeeded = false;

    component.statusFilter(status, isRequestNeeded);

    expect(component.intentFilter.va).toEqual(status);
    expect(component.intentFilter.channel).toEqual(0);
    expect(component.intentFilter.language).toEqual(0);
    expect(component.IntentListingForm.controls['channel'].value).toEqual(0);
    expect(component.IntentListingForm.controls['language'].value).toEqual(0);
    expect(getIntentListSpy).toHaveBeenCalledTimes(1);
  });

  it('statusFilter should initialize intentFilter values and call getIntentList method twice', () => {
    const getIntentListSpy = spyOn(component, 'getIntentList');
    const status = 0;
    const isRequestNeeded = true;

    component.statusFilter(status, isRequestNeeded);

    expect(component.intentFilter.va).toEqual(status);
    expect(component.intentFilter.channel).toEqual(0);
    expect(component.intentFilter.language).toEqual(0);
    expect(component.IntentListingForm.controls['channel'].value).toEqual(0);
    expect(component.IntentListingForm.controls['language'].value).toEqual(0);
    expect(getIntentListSpy).toHaveBeenCalledTimes(2);
  });

  it('statusFilter should not call getIntentList', () => {
    const getIntentListSpy = spyOn(component, 'getIntentList');
    const status = 1;
    const isRequestNeeded = false;

    component.statusFilter(status, isRequestNeeded);

    expect(getIntentListSpy).toHaveBeenCalledTimes(0);
  });

  it('channelFilter should call getIntentList', () => {
    const getIntentListSpy = spyOn(component, 'getIntentList');
    const channel = {
      id: '1'
    };

    component.channelFilter(channel);

    expect(component.intentFilter.channel).toEqual(channel);
    expect(getIntentListSpy).toHaveBeenCalled();
  });

  it('languageFilter should call getIntentList', () => {
    const getIntentListSpy = spyOn(component, 'getIntentList');
    const language = {
      id: '1'
    };

    component.languageFilter(language);

    expect(component.intentFilter.language).toEqual(language);
    expect(getIntentListSpy).toHaveBeenCalled();
  });

  it('getIntentList should call tableDataGen method only one time', () => {
    const spinner = TestBed.get(NgxSpinnerService);
    const spinnerShowSpy = spyOn(spinner, 'show');
    const spinnerHideSpy = spyOn(spinner, 'hide');
    const tableDataGenSpy = spyOn(component, 'tableDataGen');
    const PageNo = 1;
    const vaId = '1';
    const vaChanId = 'chId';
    const vaLangId = 'ID';

    component.getIntentList(PageNo, vaId, vaChanId, vaLangId);

    expect(spinnerShowSpy).toHaveBeenCalledBefore(spinnerHideSpy);
    expect(component.counter).toEqual(1);
    expect(component.loaded).toBeTruthy();
    expect(component.len).toEqual(1);
    expect(tableDataGenSpy).toHaveBeenCalledTimes(1);
    expect(spinnerHideSpy).toHaveBeenCalled();
  });

  it('draftORLive should return Active', () => {
    const channel = {
      isLive: true
    };

    const result = component.draftORLive(channel);

    expect(result).toEqual('Active');
  });

  it('draftORLive should return Draft', () => {
    const channel = {
      isLive: false
    };

    const result = component.draftORLive(channel);

    expect(result).toEqual('Draft');
  });

  it('onSearchIntent should return Draft', () => {
    const spinner = TestBed.get(NgxSpinnerService);
    const spinnerShowSpy = spyOn(spinner, 'show');
    const spinnerHideSpy = spyOn(spinner, 'hide');
    const tableDataGenSpy = spyOn(component, 'tableDataGen');
    const event = {
      target: {
        value: '123'
      }
    };

    component.onSearchIntent(event);

    expect(component.counter).toEqual(1);
    expect(spinnerShowSpy).toHaveBeenCalled();
    expect(component.loaded).toBeTruthy();
    expect(tableDataGenSpy).toHaveBeenCalledTimes(1);
    expect(spinnerHideSpy).toHaveBeenCalled();
  });

  it('openModal should open the modal', () => {
    const modal = TestBed.get(BsModalService);
    const modalSpy = spyOn(modal, 'show');
    const vaId = '1';
    const intentId = '2';

    component.openModal(template, vaId, intentId);

    expect(modalSpy).toHaveBeenCalled();
    expect(component.delete_vaId).toEqual(vaId);
    expect(component.delete_intentId.indexOf(intentId)).toBeGreaterThan(-1);
  });

  it('openInfoModal should open the modal', () => {
    const modal = TestBed.get(BsModalService);
    const modalSpy = spyOn(modal, 'show');

    component.openInfoModal(template);

    expect(modalSpy).toHaveBeenCalled();
  });

  it('openToggleModal should open the modal', () => {
    const modal = TestBed.get(BsModalService);
    const modalSpy = spyOn(modal, 'show');
    const intent = {};

    component.openToggleModal(template, intent);

    expect(component.intentSelected).toEqual(intent);
    expect(modalSpy).toHaveBeenCalled();
  });

  it('onchannelStatusChange should remove icmId from toggledIcmIds array', () => {
    const event = {
      checked: true
    };
    const channel = {
      isLive: true,
      icmId: 123
    };
    component.toggledIcmIds.push(123);

    component.onchannelStatusChange(event, channel);

    expect(component.toggledIcmIds).toEqual([]);
  });

  it('onchannelStatusChange should add icmId to toggledIcmIds array', () => {
    const event = {
      checked: true
    };
    const channel = {
      isLive: false,
      icmId: 123
    };

    component.onchannelStatusChange(event, channel);

    expect(component.toggledIcmIds).toEqual([123]);
  });

  it('onchannelStatusChange should add icmId to toggledIcmIds array', () => {
    const event = {
      checked: false
    };
    const channel = {
      isLive: true,
      icmId: 123
    };

    component.onchannelStatusChange(event, channel);

    expect(component.toggledIcmIds).toEqual([123]);
  });

  it('onchannelStatusChange should remove icmId from toggledIcmIds array', () => {
    const event = {
      checked: false
    };
    const channel = {
      isLive: false,
      icmId: 123
    };
    component.toggledIcmIds.push(123);

    component.onchannelStatusChange(event, channel);

    expect(component.toggledIcmIds).toEqual([]);
  });

  it('deleteIntentsFunc should call getIntentList method', () => {
    const spinner = TestBed.get(NgxSpinnerService);
    const modal = TestBed.get(BsModalService);
    component.modalRef = modal;
    const getIntentListSpy = spyOn(component, 'getIntentList');
    const modalSpy = spyOn(modal, 'hide');
    const spinnerShowSpy = spyOn(spinner, 'show');
    const spinnerHideSpy = spyOn(spinner, 'hide');
    component.delete_vaId = 1;

    component.deleteIntentsFunc();

    expect(spinnerShowSpy).toHaveBeenCalled();
    expect(modalSpy).toHaveBeenCalled();
    expect(component.searchValue).toEqual(null);
    expect(spinnerHideSpy).toHaveBeenCalled();
    expect(getIntentListSpy).toHaveBeenCalled();
  });

  it('deleteIntentsFunc should not call getIntentList method', () => {
    const modal = TestBed.get(BsModalRef);
    const spinner = TestBed.get(NgxSpinnerService);
    const getIntentListSpy = spyOn(component, 'getIntentList');
    const modalSpy = spyOn(modal, 'hide');
    const spinnerShowSpy = spyOn(spinner, 'show');
    const spinnerHideSpy = spyOn(spinner, 'hide');
    component.delete_vaId = 0;

    component.deleteIntentsFunc();

    expect(spinnerShowSpy).toHaveBeenCalled();
    expect(modalSpy).toHaveBeenCalledTimes(0);
    expect(component.searchValue).toEqual('');
    expect(spinnerHideSpy).toHaveBeenCalled();
    expect(getIntentListSpy).toHaveBeenCalledTimes(0);
  });

  it('onToggleIntentModalCancel should hide modal and set variables to empty', () => {
    const modalRef = TestBed.get(BsModalRef);
    component.modalRefInfo = modalRef;
    const modalSpy = spyOn(modalRef, 'hide');

    component.onToggleIntentModalCancel();

    expect(modalSpy).toHaveBeenCalled();
    expect(component.toggledIcmIds).toEqual([]);
    expect(component.intentSelected).toEqual({});
  });

  it('cloneIntentFunc should open modal with success message', () => {
    const spinner = TestBed.get(NgxSpinnerService);
    const modal = TestBed.get(BsModalService);
    const modalSpy = spyOn(modal, 'show');
    const spinnerShowSpy = spyOn(spinner, 'show');
    const spinnerHideSpy = spyOn(spinner, 'hide');
    const intId = 1;
    const vaId = 2;

    component.cloneIntentFunc(intId, vaId);

    expect(spinnerShowSpy).toHaveBeenCalled();
    expect(component.modalHeader).toEqual('Info');
    expect(modalSpy).toHaveBeenCalled();
    expect(component.modalMsg).toEqual('Successfully Clone to Live')
    expect(spinnerHideSpy).toHaveBeenCalled();
  });

  it('cloneIntentFunc should open modal with warning message', () => {
    const spinner = TestBed.get(NgxSpinnerService);
    const modal = TestBed.get(BsModalService);
    const modalSpy = spyOn(modal, 'show');
    const spinnerShowSpy = spyOn(spinner, 'show');
    const spinnerHideSpy = spyOn(spinner, 'hide');
    const intId = 0;
    const vaId = 2;

    component.cloneIntentFunc(intId, vaId);

    expect(spinnerShowSpy).toHaveBeenCalled();
    expect(component.modalHeader).toEqual('Warning');
    expect(modalSpy).toHaveBeenCalled();
    expect(component.modalMsg).toEqual('Already Intent exists in Live !!!')
    expect(spinnerHideSpy).toHaveBeenCalled();
  });
});

import { Component, OnInit, ViewChild, Output, AfterViewInit,EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, Form, Validators, SelectControlValueAccessor } from '@angular/forms';
import { Conversation, ConversationStage, GetInfo, SendMessage } from '../model/intent';
import { CreateIntentService } from '../create-intent.service';
import { ActivatedRoute } from '@angular/router';
import * as cloneDeep from 'lodash/cloneDeep';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
declare var $:any;

@Component({
  selector: 'app-create-intent-right',
  templateUrl: './create-intent-right.component.html',
  styleUrls: ['../create-intent-left/create-intent-left.component.scss']
})
export class CreateIntentRightComponent implements OnInit, AfterViewInit{
  @Output() public getLeftPanelDataR = new EventEmitter<any>();
  conversationListRight: any; intentId; chId; langId;

  constructor(private route: ActivatedRoute, public createIntentService: CreateIntentService) {
    this.route.paramMap.subscribe((params: any) => {
      this.intentId = params.params.intId;
      let roleId = params.params.vaID;
      this.chId = params.params.chId;
      this.langId = params.params.langId;
      this.getConversationList(this.intentId, this.langId, this.chId);
    });
  }
  message: string; sendResMessage;
  ngOnInit() {
    let message="";
    this.createIntentService.currentMessage.subscribe((message:any) => 
      {
      if(message==""){
        this.message="";
      }
        this.message = message;
        if(this.message!=null){
        // let msg1=this.message.replace(/\</g, ' ');
        //   this.sendResMessage=msg1.replace(/\>/g, ' ');
        this.sendResMessage=this.message;
        }
      });
  }

  ngAfterViewInit(){
    $(document).ready(function(){
      $('.card-body-right-panel-final-response').parent('.example-box').css('visibility','hidden');
  });
}

  

  getConversationList(intentId, langId, chId) {
    this.createIntentService.getIntentConversionList(intentId, langId, chId)
      .subscribe((res: any) => {
        this.conversationListRight = res.conversation;
        this.clonedFinalRes = this.conversationListRight;
            this.ngAfterViewInit();
      });
  }

  checkEmpty = (t) => t != '' && t != null ? true : false;


  // getInfoClick(e, i) {
  //   this.getLeftPanelDataR.emit(e);
  // }
  // sendMessageClick(e, d) {
  //   this.getLeftPanelDataR.emit(e);
  // }
 
  drop(event: CdkDragDrop<any[]>) {
    moveItemInArray(this.conversationListRight.conversationStages, event.previousIndex, event.currentIndex);
  }
 


  clonedFinalRes;
  bindTempDataFinalRes(e, intentId, langId, chId) {
    let clonedObject = cloneDeep(e);
    this.clonedFinalRes = clonedObject;
    this.conversationListRight = this.clonedFinalRes;
    this.ngAfterViewInit();
  }

  bindTempDataGet(e, intentId, langId, chId) {
    this.conversationListRight = e;
    this.ngAfterViewInit();
  }

  bindTempData(e, intentId, langId, chId) {
    this.conversationListRight = e;
    this.ngAfterViewInit();
    // if (e != undefined) {
    //   this.conversationListRight = e;
    // } else {

    //   this.conversationListRight.systemSlots.forEach((e, i) => {
    //     if (e.systemSlotKey.systemSlotKeyName == "") {
    //       this.conversationListRight.systemSlots.splice(i, 1)
    //     }
    //   });

    //   this.createIntentService.saveConversations(this.conversationListRight, intentId, langId, chId)
    //     .subscribe((res: any) => { });
    // }

  }


}

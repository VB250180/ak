import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { TrainingPhrasesComponent } from './training-phrases.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, Component, TemplateRef } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { BsModalService } from "ngx-bootstrap/modal";
import { BsDropdownConfig } from "ngx-bootstrap/dropdown";
import { ToastrService, ToastrModule } from 'ngx-toastr';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { CreateIntentService } from '../create-intent.service';
import { of } from 'rxjs';
import { TextSelectEvent } from 'src/app/shared/directives/text-select.directive';

describe('AssistedTrainingComponent', () => {
    let intentService;
    let component: TrainingPhrasesComponent;
    let fixture: ComponentFixture<TrainingPhrasesComponent>;
    let template: TemplateRef<any>;
    let template2: TemplateRef<any>;
    let template1: TemplateRef<any>;
    let event: TextSelectEvent;


    let assistedTrainingInputs = {
        "virtualAgents": [
            {
                "virtualAgent": {
                    "vaId": 2,
                    "vaName": "webBot",
                    "vaIsLive": false,
                    "vaAvatarName": "UMRBOT",
                    "vaDescription": "web"
                },
                "languages": [
                    {
                        "id": 1,
                        "value": "English"
                    },
                    {
                        "id": 2,
                        "value": "French"
                    }
                ],
                "channels": [
                    {
                        "id": 1,
                        "value": "WEB"
                    }
                ]
            }
        ]
    };

    let intentList = {
        "mappedCount": 0,
        "inScopeCount": 0,
        "outOfScopeCount": 4,
        "conversationList": [
            {
                "sessionId": 1,
                "mapppedPhrases": [],
                "inScopePhrases": [],
                "outOfScopePhrases": [
                    {
                        "id": 1,
                        "value": "need information"
                    }
                ]
            },
            {
                "sessionId": 2,
                "mapppedPhrases": [],
                "inScopePhrases": [],
                "outOfScopePhrases": [
                    {
                        "id": 7,
                        "value": "first class ticket from mumbai"
                    },
                    {
                        "id": 4,
                        "value": "ticket book pannanum"
                    },
                    {
                        "id": 3,
                        "value": "sollunga"
                    }
                ]
            }
        ]
    };

    let intentSlots = [
        {
            "intent": {
                "id": 4,
                "value": "praveen intent"
            },
            "intentSlots": []
        },
        {
            "intent": {
                "id": 6,
                "value": "Booking Cancellation"
            },
            "intentSlots": []
        }
    ];

    let createIntentData = {
        "intent": {
            "intentId": 41,
            "intentName": "Test",
            "intentDescription": "Test",
            "virtualAgent": null,
            "businessUnit": null,
            "languages": [
                {
                    "langEngId": 1,
                    "langName": "English",
                    "channels": [
                        {
                            "icmId": 65,
                            "channelId": 1,
                            "channelName": "WEB",
                            "intentConfigStage": 0,
                            "isLive": false
                        }
                    ]
                },
                {
                    "langEngId": 2,
                    "langName": "French",
                    "channels": [
                        {
                            "icmId": 66,
                            "channelId": 1,
                            "channelName": "WEB",
                            "intentConfigStage": 0,
                            "isLive": false
                        }
                    ]
                }
            ]
        }
    }

    let intentSlotValues =
    {
        "virtualAgent": null,
        "virtualAgents": null,
        "intent": null,
        "intents": null,
        "conversation": null,
        "trainingPhrases": null,
        "virtualAgentDashboardResponseObject": null,
        "virtualAgentTrendResponseObject": null,
        "systemSlotKeys": null,
        "count": null,
        "languages": null,
        "channels": null,
        "intentLanguageChannelMaps": null,
        "intentSlots": [
            {
                "intentSlotId": 7,
                "intentSlotName": "To city",
                "intentSlotDescription": "city",
                "entity": {
                    "entityId": 1,
                    "entityName": "fromPlace"
                }
            },
            {
                "intentSlotId": 6,
                "intentSlotName": "City from",
                "intentSlotDescription": "from city",
                "entity": {
                    "entityId": 1,
                    "entityName": "fromPlace"
                }
            },
            {
                "intentSlotId": 1,
                "intentSlotName": "fromPlace",
                "intentSlotDescription": "from city",
                "entity": {
                    "entityId": 1,
                    "entityName": "fromPlace"
                }
            },
            {
                "intentSlotId": 2,
                "intentSlotName": "toPlace",
                "intentSlotDescription": "to city",
                "entity": {
                    "entityId": 2,
                    "entityName": "toPlace"
                }
            }
        ],
        "entities": null,
        "errorBody": null
    };

    let phrases = {
        "virtualAgent": null,
        "virtualAgents": null,
        "intent": null,
        "intents": null,
        "conversation": null,
        "trainingPhrases": [
            {
                "trainingPhraseId": 130,
                "trainingPhraseText": "Book a flight ticket from Singaporee to %pos0%",
                "intentSlotMapPojos": [
                    {
                        "position": "pos0",
                        "value": "newzealand",
                        "intentSlot": {
                            "intentSlotId": 1,
                            "intentSlotName": "fromPlace",
                            "intentSlotDescription": "from city",
                            "entity": {
                                "entityId": 1,
                                "entityName": "fromPlace"
                            }
                        }
                    }
                ],
                "trainingPhraseStage": "notTrained"
            },
            {
                "trainingPhraseId": 132,
                "trainingPhraseText": "i want to book a movie ticket from %pos0%",
                "intentSlotMapPojos": [
                    {
                        "position": "pos0",
                        "value": "Bengaluru",
                        "intentSlot": {
                            "intentSlotId": 1,
                            "intentSlotName": "fromPlace",
                            "intentSlotDescription": "from city",
                            "entity": {
                                "entityId": 1,
                                "entityName": "fromPlace"
                            }
                        }
                    }
                ],
                "trainingPhraseStage": "notTrained"
            },
            {
                "trainingPhraseId": 135,
                "trainingPhraseText": "agile methodology in akeira 2.0 product %pos1%",
                "intentSlotMapPojos": [
                    {
                        "position": "pos1",
                        "value": "development",
                        "intentSlot": {
                            "intentSlotId": 7,
                            "intentSlotName": "To city",
                            "intentSlotDescription": "city",
                            "entity": {
                                "entityId": 1,
                                "entityName": "fromPlace"
                            }
                        }
                    },
                    {
                        "position": "pos0",
                        "value": "list",
                        "intentSlot": {
                            "intentSlotId": 7,
                            "intentSlotName": "To city",
                            "intentSlotDescription": "city",
                            "entity": {
                                "entityId": 1,
                                "entityName": "fromPlace"
                            }
                        }
                    }
                ],
                "trainingPhraseStage": "notTrained"
            }],
        "virtualAgentDashboardResponseObject": null,
        "virtualAgentTrendResponseObject": null,
        "systemSlotKeys": null,
        "count": null,
        "languages": null,
        "channels": null,
        "intentLanguageChannelMaps": null,
        "intentSlots": null,
        "entities": null,
        "errorBody": null
    }

    let addPhrases =
    {
        "virtualAgent": null,
        "virtualAgents": null,
        "intent": null,
        "intents": null,
        "conversation": null,
        "trainingPhrases": [
            {
                "trainingPhraseId": 148,
                "trainingPhraseText": "Book flight ticket from Bengaluru",
                "intentSlotMapPojos": [
                    {
                        "position": "pos0",
                        "value": "Bengaluru",
                        "intentSlot": {
                            "intentSlotId": 1,
                            "intentSlotName": "From place",
                            "intentSlotDescription": null,
                            "entity": null
                        }
                    }
                ],
                "trainingPhraseStage": "notTrained"
            }
        ],
        "virtualAgentDashboardResponseObject": null,
        "virtualAgentTrendResponseObject": null,
        "systemSlotKeys": null,
        "count": null,
        "languages": null,
        "channels": null,
        "intentLanguageChannelMaps": null,
        "intentSlots": null,
        "entities": null,
        "errorBody": null
    }

    let mappedDetails = {
        id: 3,
        intentId: 655,
        intentslots: null,
        value: "sollunga",
        mappedData: { displayValue: "sollunga", intentId: 655, sessionId: 2, mappedHighlightData: [], intentslots: { index: 0, value: "sollunga", isHighlight: false, key: "pos0" } }
    }

    let deletedResponse = {
        channels: null,
        conversation: null,
        count: 1,
        entities: null,
        errorBody: null,
        intent: null,
        intentLanguageChannelMaps: null,
        intentSlots: null,
        intents: null,
        languages: null,
        systemSlotKeys: null,
        trainingPhrases: null,
        virtualAgent: null,
        virtualAgentDashboardResponseObject: null,
        virtualAgentTrendResponseObject: null,
        virtualAgents: null
    }

    let editedText = {
        trainingPhraseId: 632, trainingPhraseText: "add new phrases", intentSlotMapPojos: [], trainingPhraseStage: "notTrained", trainingPhraseDisplay: "add new phrases",
        mappedHighlightData :[{index: 0, value: "add", isHighlight: false, key: "pos0"},
        {index: 1, value: "new", isHighlight: false, key: "pos1"},
         {index: 2, value: "phrases", isHighlight: false, key: "pos2"}]
    }

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            providers: [
                CreateIntentService,
                { provide: BsModalService },
                { provide: BsDropdownConfig }
            ],
            declarations: [TrainingPhrasesComponent],
            imports: [FormsModule,
                ReactiveFormsModule,
                BrowserAnimationsModule,
                HttpClientTestingModule,
                ToastrModule.forRoot(),
                BsDropdownModule.forRoot(),
                RouterTestingModule],
            schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
        })
            .compileComponents();
    }));

    beforeEach(inject([CreateIntentService], s => {
        let intentService = s;
        fixture = TestBed.createComponent(TrainingPhrasesComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    }));

    it("should call method subscribe", async(() => {
        spyOn(intentService, 'addTrainingPhrase').and.returnValue(of(phrases));
        component.addPhrases(1, 2, 3, '');
        component.onScroll();
        spyOn(intentService, 'addPhraseDetails').and.returnValue(of(intentSlotValues))
        component.saveAddedTrainingPhrases();
        spyOn(intentService, 'requestaddTrainingPhraseAndintentSlots').and.returnValue(of([phrases, intentSlots]))
        component.fetchPageData(1, 2, 1, '');
        spyOn(intentService, 'deleteTrainingPhrase').and.returnValue(deletedResponse);
        component.deleteTrainingPhraseCall();
    }));


    it('should create', () => {
        expect(component).toBeTruthy();
    });


    it('check methods', () => {
        component.refreshTrainingPhrase(1, 2);
        component.ngOnChanges();
        component.fetchPageData(1, 2, 1, '');
        component.addPhrases(1, 2, 1, '');
        component.displayTrainingPhrases(phrases);
        component.genrateHighlightdata('', true, []);
        component.functionClick(event);
        component.deleteTrainingPhraseCall();
        component.coloringPhrase();
        component.openSlotsDropdown();
        component.getIntentSlotValue({id:1,value:'book a ticket'});
        component.addToList('book a ticket');
        component.removeSelectedValue('book a ticket');
        component.onChangebtn('Book a ticket');
        component.editPhrase(editedText,1,false);
        component.checkCanEdit(editedText,1,false);
        component.cancelAdd();


        component.renderRectangles(event);
        component.deleteTrainingPhrase();

        // component.saveAddedTrainingPhrases();
        // component.onScroll();
        // component.onSearch('ticket');
        // component.openInfoModal(template);
        // component.showIntentSlotsDropdown();
        // component.openModalDelete(template,1,'book a ticket',true,1);

    });

    it('should check method open modal popup', () => {
       component.openModalDelete(template,1,'book a ticket',true,1);
    });

    it('should check method delete training phrase', () => {
        component.deleteTrainingPhrase();
    });

    it('should check method save', () => {
        component.saveAddedTrainingPhrases();
    });

    it('should check search', () => {
        component.onSearch('text');
        expect(component.isLoaded).toBe(true);
    });

    it('should check scroll', () => {
        component.onScroll();
    });

    it('should check openinfo modal method', () => {
        component.openInfoModal(template);
    }); 

    it('should check method rectangle render event' , () => {
        component.renderRectangles(event);
    });

    it('should check showIntentSlotsDropdown method', () => {
        component.showIntentSlotsDropdown();
    });

    it('should check method update info table', () => { 
        component.updateValueToTable();
        expect(component.intentSlots[0]['isDisable']).toEqual(false);
    });

});

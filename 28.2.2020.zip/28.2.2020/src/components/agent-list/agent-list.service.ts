import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
// import { catchError, map, tap, delay,filter,scan } from 'rxjs/operators';
import { environment as env } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AgentListService {

  constructor(private http: HttpClient) { };

  public getChannels(): Observable<any> {
    return this.http.get<any>(env.apiUrl + '/getChannelsAndLanguages');
    // return this.http.get('../../assets/channel.json');
  }

  public getVATrandData(channelId, langId, vrmId): Observable<any> {
    return this.http.get<any>(env.apiUrl + '/getVaTrendData?channelId=' + channelId + '&langEngId=' + langId + '&vrmId=' + vrmId);
    // return this.http.get('../../assets/language.json');
  }

  public getAgentList(channel, language): Observable<any> {
    let checkConidtion = "Existing_Flow";
    return this.http.get<any>(env.apiUrl + '/getVaDashboardList?channelId=' + channel + '&langId=' + language + "&checkConidtion=" + checkConidtion);
    // return this.http.get('../../assets/va.json');
  }

}



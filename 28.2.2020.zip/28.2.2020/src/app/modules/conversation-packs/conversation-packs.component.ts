import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conversation-packs',
  templateUrl: './conversation-packs.component.html',
  styleUrls: ['./conversation-packs.component.scss']
})
export class ConversationPacksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

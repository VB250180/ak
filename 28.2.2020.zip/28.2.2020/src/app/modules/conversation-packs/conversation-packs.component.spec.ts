import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConversationPacksComponent } from './conversation-packs.component';

describe('ConversationPacksComponent', () => {
  let component: ConversationPacksComponent;
  let fixture: ComponentFixture<ConversationPacksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConversationPacksComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConversationPacksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { NgSelectModule } from '@ng-select/ng-select';
import { BsDropdownModule, BsDropdownConfig } from 'ngx-bootstrap/dropdown';
import { EntitiesService } from './../../../core/services/entity.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { TextSelectEvent } from './../../../shared/directives/text-select.directive';
import { EntityListingComponent } from "./entity-listing.component";
import { ComponentFixture, async, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { TemplateRef, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AssistedTrainingService } from 'src/components/assisted-training/assisted-training.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ToastrModule } from 'ngx-toastr';
import { MatDialogModule, MatDialog, MatDialogRef } from '@angular/material';
import { RouterTestingModule } from '@angular/router/testing';
import { AssistedTrainingComponent } from 'src/components/assisted-training/assisted-training.component';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { NgxSpinnerService } from 'ngx-spinner';


class ActivatedRouteStub {
    paramsObj = {
        name: 'name',
        id: '1',
        lang: 'en-uk',
        langId: '1',
        get: (property) => {
            return this.paramsObj[property];
        }
    }
    public paramMap = new BehaviorSubject(this.paramsObj);
}

class NgxSpinnerServiceStub {
    public show(spinnerType) { }

    public hide(spinnerType) { }
}

class BsModalServiceStub {

    public show(template, config) { }

    public hide() { }
}

class MatDialogStub {
    public afterClosed = new BehaviorSubject(true);
    public open(component, config) {
        let mat = new MatDialogRefStub();
        console.log('mat dude', mat);
        return this.afterClosed;
    }
}

class MatDialogRefStub {
    public afterClosed() {
        return Observable.of({});
    }
}

class EntitiesServiceStub {
    public getVAdetailsByUserId(userId: number): Observable<any> {
        return Observable.of({
            virtualAgents: [{
                vaId: 1,
                vaName: 'Policy Insurance',
                vaIsLive: true,
                vaAvatarName: 'Akeira2.0',
                vaDescription: 'Policy',
                businessUnit: null,
                languages: null,
                channels: null,
                businessUnitData: null,
                userName: 'VAadmin'
            },
            {
                vaId: 2,
                vaName: 'Policy Insurance',
                vaIsLive: false,
                vaAvatarName: 'Akeira2.0',
                vaDescription: 'Policy',
                businessUnit: null,
                languages: null,
                channels: null,
                businessUnitData: null,
                userName: 'VAadmin'
            },
            {
                vaId: 3,
                vaName: 'Policy Insurance',
                vaIsLive: true,
                vaAvatarName: 'Akeira2.0',
                vaDescription: 'Policy',
                businessUnit: null,
                languages: null,
                channels: null,
                businessUnitData: null,
                userName: 'VAadmin'
            }]
        });
    }

    public getLanguagessByVaId(vaId: number): Observable<any> {
        if (vaId === 1) {
            return Observable.of({
                languageEngineMaps: []
            });
        } else {
            console.log('throwing error');
            return throwError({});
        }
    }

    public getEntityList(pageNo: number, vaId: number, vaLang: number, serachString: string): Observable<any> {
        return Observable.of({
            count: 1,
            entityResponseObjectList: [{
                entityId: 1,
                entityName: 'name1',
                entityDescription: 'desc1',
                virtualAgentPojo: {
                    languages: [{
                        langEngId: 1,
                        langName: 'en-us'
                    },
                    {
                        langEngId: 2,
                        langName: 'en-uk'
                    }]
                },
            },
            {
                entityId: 2,
                entityName: 'name2',
                entityDescription: 'desc2',
                virtualAgentPojo: {
                    languages: [{
                        langEngId: 1,
                        langName: 'en-us'
                    },
                    {
                        langEngId: 2,
                        langName: 'en-uk'
                    }]
                },
            }]
        })
    }

    public deleteEntity(vaId:number,entityId:number){
        if (vaId === 1) {
            return Observable.of({
                count: 1
            });
        } else {
            return Observable.of({
                count: 0
            });
        }
    }
}

describe('EntityListingComponent', () => {
    let assistedTrainingService;
    let component: EntityListingComponent;
    let fixture: ComponentFixture<EntityListingComponent>;
    let template: TemplateRef<any>;
    let template2: TemplateRef<any>;
    let template1: TemplateRef<any>;
    let event: TextSelectEvent;
    let modalService: BsModalService;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            providers: [
                BsModalRef,
                { provide: EntitiesService, useClass: EntitiesServiceStub },
                { provide: ActivatedRoute, useClass: ActivatedRouteStub },
                { provide: BsModalService, useClass: BsModalServiceStub },
                { provide: NgxSpinnerService, useClass: NgxSpinnerServiceStub },
                { provide: MatDialog, useClass: MatDialogStub },
                { provide: MatDialogRef, useClass: MatDialogRefStub },
                { provide: BsDropdownConfig }
            ],
            declarations: [EntityListingComponent],
            imports: [FormsModule,
                ReactiveFormsModule,
                BrowserAnimationsModule,
                HttpClientTestingModule,
                ToastrModule.forRoot(),
                BsDropdownModule.forRoot(),
                MatDialogModule,
                RouterTestingModule,
                NgSelectModule
            ],
            schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(EntityListingComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('ngOnInit should initialize variables from routing params and call getdropdownValues method', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const spinnerSpy = spyOn(spinner, 'show');
        const getdropdownValuesSpy = spyOn(component, 'getdropdownValues');

        component.ngOnInit();

        expect(spinnerSpy).toHaveBeenCalledWith(component.fullSpinner);
        expect(component.vaName).toEqual('name');
        expect(component.vaId).toEqual('1');
        expect(component.vaLang).toEqual('en-uk');
        expect(component.vaLangId).toEqual('1')
        expect(getdropdownValuesSpy).toHaveBeenCalled();
    });

    it('getdropdownValues should call callEntityListByparam method', fakeAsync(() => {
        const callEntityListByparamSpy = spyOn(component, 'callEntityListByparam');

        component.getdropdownValues();
        jasmine.clock().tick(500);

        expect(callEntityListByparamSpy).toHaveBeenCalled();

    }));

    it('setFormValue should set the form control value', () => {
        const keys = ['va'];

        component.setFormValue(keys, 1);

        expect(component.entityListingForm.controls['va'].value).toEqual(1);

    });

    it('callEntityListByparam should initialize entitiesFilter object and call 4 methods', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const setFormValueSpy = spyOn(component, 'setFormValue');
        const vaFilterSpy = spyOn(component, 'vaFilter');
        const getEntityListSpy = spyOn(component, 'getEntityList');
        const spinnerSpy = spyOn(spinner, 'hide');

        component.callEntityListByparam();

        expect(component.entitiesFilter.va).toEqual(Number(component.vaId));
        expect(component.entitiesFilter.language).toEqual(Number(component.vaLangId));
        expect(spinnerSpy).toHaveBeenCalledWith(component.fullSpinner);
        expect(setFormValueSpy).toHaveBeenCalledTimes(2);
        expect(vaFilterSpy).toHaveBeenCalledWith(component.entitiesFilter.va, false);
        expect(getEntityListSpy).toHaveBeenCalledWith(1, component.entitiesFilter.va, component.entitiesFilter.language, '');
    });

    it('callEntityListByparam should initialize entitiesFilter object and call 3 methods', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const setFormValueSpy = spyOn(component, 'setFormValue');
        const vaFilterSpy = spyOn(component, 'vaFilter');
        const getEntityListSpy = spyOn(component, 'getEntityList');
        const spinnerSpy = spyOn(spinner, 'hide');
        component.vaId = undefined;

        component.callEntityListByparam();

        expect(component.entitiesFilter.va).toEqual(0);
        expect(component.entitiesFilter.language).toEqual(0);
        expect(spinnerSpy).toHaveBeenCalledWith(component.fullSpinner);
        expect(setFormValueSpy).toHaveBeenCalledTimes(2);
        expect(vaFilterSpy).toHaveBeenCalledTimes(0);
        expect(getEntityListSpy).toHaveBeenCalledWith(1, component.entitiesFilter.va, component.entitiesFilter.language, '');
    });

    it('vaFilter should initialize entitiesFilter object and call getEntityList once', () => {
        const setFormValueSpy = spyOn(component, 'setFormValue');
        const getEntityListSpy = spyOn(component, 'getEntityList');
        const loadlanguageFilterSpy = spyOn(component, 'loadlanguageFilter');
        const vaId = 0;
        const isRequestNeeded = false;

        component.vaFilter(vaId, isRequestNeeded);

        expect(component.entitiesFilter.va).toEqual(0);
        expect(component.entitiesFilter.language).toEqual(0);
        expect(setFormValueSpy).toHaveBeenCalledTimes(0);
        expect(loadlanguageFilterSpy).toHaveBeenCalledTimes(0);
        expect(getEntityListSpy).toHaveBeenCalledWith(component.PageNo, component.entitiesFilter.va, component.entitiesFilter.language, '');
    });

    it('vaFilter should initialize entitiesFilter object and should only call loadlanguageFilter once', () => {
        const setFormValueSpy = spyOn(component, 'setFormValue');
        const getEntityListSpy = spyOn(component, 'getEntityList');
        const loadlanguageFilterSpy = spyOn(component, 'loadlanguageFilter');
        const vaId = 1;
        const isRequestNeeded = false;

        component.vaFilter(vaId, isRequestNeeded);

        expect(setFormValueSpy).toHaveBeenCalledTimes(0);
        expect(loadlanguageFilterSpy).toHaveBeenCalledTimes(1);
        expect(getEntityListSpy).toHaveBeenCalledTimes(0);
    });

    it('vaFilter should initialize entitiesFilter object and should call 3 methods', () => {
        const setFormValueSpy = spyOn(component, 'setFormValue');
        const getEntityListSpy = spyOn(component, 'getEntityList');
        const loadlanguageFilterSpy = spyOn(component, 'loadlanguageFilter');
        const vaId = 1;
        const isRequestNeeded = true;

        component.vaFilter(vaId, isRequestNeeded);

        expect(component.entitiesFilter.va).toEqual(1);
        expect(component.entitiesFilter.language).toEqual(0);
        expect(setFormValueSpy).toHaveBeenCalledTimes(1);
        expect(loadlanguageFilterSpy).toHaveBeenCalledTimes(1);
        expect(getEntityListSpy).toHaveBeenCalledTimes(1);
    });

    it('loadlanguageFilter should call show and hide spinner', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const openModalApiErrorSpy = spyOn(component, 'openModalApiError');
        const spinnerShowSpy = spyOn(spinner, 'show');
        const spinnerHideSpy = spyOn(spinner, 'hide');

        const vaId = 1;

        component.loadlanguageFilter(vaId);

        expect(spinnerShowSpy).toHaveBeenCalledTimes(1);
        expect(component.languages).toEqual([]);
        expect(spinnerHideSpy).toHaveBeenCalledTimes(1);
        expect(openModalApiErrorSpy).toHaveBeenCalledTimes(0);
    });

    it('loadlanguageFilter should call show and hide spinner and call openModalApiError on error', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const openModalApiErrorSpy = spyOn(component, 'openModalApiError');
        const spinnerShowSpy = spyOn(spinner, 'show');
        const spinnerHideSpy = spyOn(spinner, 'hide');

        const vaId = 0;

        component.loadlanguageFilter(vaId);

        expect(spinnerShowSpy).toHaveBeenCalledTimes(1);
        expect(spinnerHideSpy).toHaveBeenCalledTimes(1);
        expect(openModalApiErrorSpy).toHaveBeenCalledTimes(1);
    });

    it('languageFilter should initialize entitiesFilter object and call getEntityList methods', () => {
        const getEntityListSpy = spyOn(component, 'getEntityList');

        const language = 1;

        component.languageFilter(language);

        expect(component.entitiesFilter.language).toEqual(language);
        expect(getEntityListSpy).toHaveBeenCalledWith(component.PageNo, component.entitiesFilter.va, component.entitiesFilter.language, '');
    });

    it('onSearchIntent should initialize oldSearchText and call getEntityList method', () => {
        const getEntityListSpy = spyOn(component, 'getEntityList');

        const event = {
            target: {
                value: 'value'
            }
        };

        component.onSearchIntent(event);

        expect(component.counter).toEqual(1);
        expect(component.oldSearchText).toEqual('value');
        expect(getEntityListSpy).toHaveBeenCalledWith(component.PageNo, component.entitiesFilter.va, component.entitiesFilter.language, 'value');
    });

    it('onScroll should increment counter and call tableDataGen method twice', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const tableDataGenSpy = spyOn(component, 'tableDataGen');
        component.counter = 1;

        component.onScroll();

        expect(component.counter).toEqual(2);
        expect(component.loaded).toBeTruthy();
        expect(tableDataGenSpy).toHaveBeenCalledTimes(2);
    });

    it('getEntityList should not initialize entityCount call tableDataGen method twice', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const tableDataGenSpy = spyOn(component, 'tableDataGen');
        const spinnerShowSpy = spyOn(spinner, 'show');
        const spinnerHideSpy = spyOn(spinner, 'hide');
        const pageNo = 0;
        const vaId = 1;
        const vaLang = 1;
        const serachString = 'searc me';

        component.getEntityList(pageNo, vaId, vaLang, serachString);

        expect(component.counter).toEqual(1);
        expect(component.loaded).toBeTruthy();
        expect(component.entityCount).toEqual(0);
        expect(spinnerShowSpy).toHaveBeenCalledTimes(1);
        expect(tableDataGenSpy).toHaveBeenCalledTimes(2);
        expect(spinnerHideSpy).toHaveBeenCalledTimes(1);
    });

    it('getEntityList should initialize entityCount call tableDataGen method twice', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const tableDataGenSpy = spyOn(component, 'tableDataGen');
        const spinnerShowSpy = spyOn(spinner, 'show');
        const spinnerHideSpy = spyOn(spinner, 'hide');
        const pageNo = 1;
        const vaId = 1;
        const vaLang = 1;
        const serachString = 'searc me';

        component.getEntityList(pageNo, vaId, vaLang, serachString);

        expect(component.counter).toEqual(1);
        expect(component.loaded).toBeTruthy();
        expect(component.entityCount).toEqual(1);
        expect(spinnerShowSpy).toHaveBeenCalledTimes(1);
        expect(tableDataGenSpy).toHaveBeenCalledTimes(2);
        expect(spinnerHideSpy).toHaveBeenCalledTimes(1);
    });

    it('tableDataGen should initialize entityListResponse array', () => {
        const entity = {
            entityId: 1,
            entityName: 'name1',
            entityDescription: 'desc1',
            virtualAgentPojo: {
                languages: [{
                    langEngId: 1,
                    langName: 'en-us'
                },
                {
                    langEngId: 2,
                    langName: 'en-uk'
                }]
            },
        }

        component.tableDataGen(entity);
        expect(component.entityListResponse.length).toEqual(2);
    });

    // it('openModalDelete should call deleteEntity after modal is closed', () => {
    //     const dialogModal = TestBed.get(MatDialog);
    //     console.log('dialogModal', dialogModal.open('',''));
    //     const deleteEntitySpy = spyOn(component, 'deleteEntity');
    //     const dialogOpenSpy = spyOn(dialogModal, 'open');
    //     const vaID = 1;
    //     const entityId = 1;

    //     component.openModalDelete(vaID, entityId);

    //     expect(dialogOpenSpy).toHaveBeenCalled();
    //     expect(deleteEntitySpy).toHaveBeenCalled();
    // });

    it('openModalApiError should open modal on error', () => {
        const dialogModal = TestBed.get(MatDialog);
        const dialogOpenSpy = spyOn(dialogModal, 'open');

        component.openModalApiError();

        expect(dialogOpenSpy).toHaveBeenCalled();
    });

    it('deleteEntity should call getEntityList method', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const getEntityListSpy = spyOn(component, 'getEntityList');
        const spinnerShowSpy = spyOn(spinner, 'show');
        const spinnerHideSpy = spyOn(spinner, 'hide');
        const vaId = 1;
        const entityId = 1;

        component.deleteEntity(vaId, entityId);

        expect(spinnerShowSpy).toHaveBeenCalled();
        expect(getEntityListSpy).toHaveBeenCalled();
        expect(spinnerHideSpy).toHaveBeenCalled();
    });

    it('deleteEntity should not call getEntityList method', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const getEntityListSpy = spyOn(component, 'getEntityList');
        const spinnerShowSpy = spyOn(spinner, 'show');
        const spinnerHideSpy = spyOn(spinner, 'hide');
        const vaId = 0;
        const entityId = 1;

        component.deleteEntity(vaId, entityId);

        expect(spinnerShowSpy).toHaveBeenCalled();
        expect(getEntityListSpy).toHaveBeenCalledTimes(0);
        expect(spinnerHideSpy).toHaveBeenCalled();
    });

    // it('check methods', () => {

    // });
});
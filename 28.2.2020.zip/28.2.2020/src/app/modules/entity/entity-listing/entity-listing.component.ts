import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { EntitiesService } from '../../../core/services/entity.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";
import { EntityResponseObjectList, Language, VirtualAgentPojo } from '../../../core/models/entityResponse';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig } from '@angular/material';
import { ModalComponent } from '../../../shared/components/modal/modal.component';
import { modalErrorConfig, modalDeleteConfig } from '../../../core/utils/const-message';


interface entitiesFilterPojo {
  va: number,
  language: number
}

@Component({
  selector: 'app-entity-listing',
  templateUrl: './entity-listing.component.html',
  styleUrls: ['./entity-listing.component.scss']
})
export class EntityListingComponent implements OnInit {

  entityListingForm: FormGroup;
  vaName: string;
  vaId: string;
  vaLang: string;
  vaLangId: string;

  vaLists: any = [];
  vaById: any = {};
  enittyLists: any = [];
  userId: number = 0;
  entitiesFilter: entitiesFilterPojo = {
    va: 0,
    language: 0
  }
  languages: any = [];

  counter: number = 1;
  PageNo: number = 1;
  entityCount: number = 0;
  showloader = false;
  loaded: boolean = false;
  searchValue: string = '';
  oldSearchText: string = '';

  entityListResponse: any = [];

  dialogConfig = new MatDialogConfig();

  tableSpinner = "tableSpinner";
  fullSpinner = "fullSpinner";

  constructor(private entitiesService: EntitiesService, private modalService: BsModalService, private router: Router, private activatedRoute: ActivatedRoute, private spinner: NgxSpinnerService, public dialog: MatDialog) {
    this.entityListingForm = new FormGroup({
      va: new FormControl(null, Validators.required),
      language: new FormControl(null, Validators.required),
    })
    this.userId = Number(localStorage.getItem('userId'));
  }

  ngOnInit() {
    this.spinner.show(this.fullSpinner);
    // this.activatedRoute.paramMap.subscribe(params => {
    //   console.log('params', params);
    //   this.vaName = params.get('name');
    //   this.vaId = params.get('id');
    //   this.vaLang = params.get('lang');
    //   this.vaLangId = params.get('langId');
    // });
    this.getdropdownValues();
  }

  getdropdownValues() {
    this.entitiesService.getVAdetailsByUserId(1).subscribe((res: any) => {
      this.vaLists = res['virtualAgents'];
      for (let i in this.vaLists) {
        this.vaById[this.vaLists[i].vaId] = this.vaLists[i];
      }
      setTimeout(() => {
        this.callEntityListByparam();
      }, 500);

    }), (err: any) => {
      console.error('Error In VA Listing dropdown');
      console.error(err);
      this.openModalApiError();
      this.spinner.hide(this.fullSpinner);
    };
  }

  setFormValue(key: Array<string | number> | string, value: Number) {
    this.entityListingForm.get(key).setValue(value);
  }

  callEntityListByparam() {
    this.spinner.hide(this.fullSpinner);
    if (this.vaId) {
      this.entitiesFilter.va = +this.vaId, this.entitiesFilter.language = +this.vaLangId;
      this.languages.push(this.vaById[this.entitiesFilter.va].languages);
      this.setFormValue('va', this.entitiesFilter.va);
      this.setFormValue('language', this.entitiesFilter.va);

      this.vaFilter(this.entitiesFilter.va, false);
      this.getEntityList(1, this.entitiesFilter.va, this.entitiesFilter.language, '');

    } else {
      this.entitiesFilter.va = 0, this.entitiesFilter.language = 0;
      this.setFormValue('va', this.entitiesFilter.va);
      this.setFormValue('language', this.entitiesFilter.va);
      this.getEntityList(1, this.entitiesFilter.va, this.entitiesFilter.language, '');
    }
  }

  vaFilter(vaId: string | number, isRequestNeeded: boolean) {
    //console.info('On va change --> ', vaId, isRequestNeeded);
    if (vaId == 0) {
      this.entitiesFilter.va = vaId, this.entitiesFilter.language = 0;
      this.languages = []
      this.entityListingForm.patchValue({ channel: 0, language: 0 });
      this.getEntityList(this.PageNo, this.entitiesFilter.va, this.entitiesFilter.language, '');
    } else {
      this.loadlanguageFilter(vaId);
    }

    if (isRequestNeeded) {
      this.entitiesFilter.va = Number(vaId), this.entitiesFilter.language = 0;
      this.setFormValue('language', this.entitiesFilter.language);
      this.getEntityList(this.PageNo, this.entitiesFilter.va, this.entitiesFilter.language, '');
    }
  }

  loadlanguageFilter(vaId: string | number) {
    this.spinner.show(this.fullSpinner);
    this.entitiesService.getLanguagessByVaId(Number(vaId)).subscribe((res: any) => {
      this.languages = res['languageEngineMaps'];
      this.spinner.hide(this.fullSpinner);
    }, (err: any) => { 
      console.error('Error In Language Listing dropdown');
      console.error(err);
      this.openModalApiError();
      this.spinner.hide(this.fullSpinner);
    });

  }

  languageFilter(language: string | number, ) {
    //console.log(' languageFilter ====> ', language);
    this.entitiesFilter.language = Number(language);
    this.getEntityList(this.PageNo, this.entitiesFilter.va, this.entitiesFilter.language, '');
  }

  onSearchIntent(event: any) {
    this.counter = 1;
    //console.log('====>', event, event.target.value);
    this.oldSearchText = event.target.value;
    this.getEntityList(this.PageNo, this.entitiesFilter.va, this.entitiesFilter.language, event.target.value);
  }

  onScroll() {
    this.counter += 1;
    this.showloader = true;
    //console.log(this.counter, this.entitiesFilter.va, this.entitiesFilter.language);
    this.entitiesService.getEntityList(this.counter, this.entitiesFilter.va, this.entitiesFilter.language, this.oldSearchText, this.userId)
      .subscribe((res: any[]) => {
        this.loaded = true;
        console.log('res ====>', this.counter, res);
        let entityResponseObjectList = res['entityResponseObjectList'];
        for (let i in entityResponseObjectList) {
          this.tableDataGen(entityResponseObjectList[i]);
        }
        this.showloader = false;
        console.log("1  scrolled data -------(-1-)---->", this.entityListResponse);
      });
  }

  getEntityList(pageNo: number, vaId: number, vaLang: number, serachString: string) {
    
    this.spinner.show(this.tableSpinner);
    this.counter = 1;
    this.entitiesService.getEntityList(pageNo, vaId, vaLang, serachString, this.userId).subscribe((res: any[]) => {
      this.loaded = true;
      console.log('res ====>', pageNo, res);
      if (pageNo == 1) { this.entityCount = res['count']; this.entityListResponse = [] }
      let entityResponseObjectList = res['entityResponseObjectList'];
      for (let i in entityResponseObjectList) {
        this.tableDataGen(entityResponseObjectList[i]);
      }
      console.log("intentListResponse --------->", this.entityListResponse);
      this.spinner.hide(this.tableSpinner);
    });
  }

  tableDataGen(entity: EntityResponseObjectList | any) {
    for (let j in entity.virtualAgentPojo.languages) {
      let pushdata = {
        'entityId': entity.entityId,
        'entityName': entity.entityName,
        'entityDescription': entity.entityDescription,
        'vaName': entity.virtualAgentPojo.vaName,
        'vaId': entity.virtualAgentPojo.vaId,
        'langEngId': entity.virtualAgentPojo.languages[j].langEngId,
        'langName': entity.virtualAgentPojo.languages[j].langName,
      };
      this.entityListResponse.push(pushdata);
    }
  }

  openModalDelete(vaId: any, entityId: any) {
    let dialogRef = this.dialog.open(ModalComponent, {
      disableClose: true,
      data: modalDeleteConfig
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.deleteEntity(vaId, entityId);
      }
    });
  }

  openModalApiError() {
    let dialogRef = this.dialog.open(ModalComponent, {
      disableClose: true,
      data: modalErrorConfig
    });
  }

  deleteEntity(vaId: number, entityId: number) {
    this.spinner.show(this.tableSpinner);
    this.entitiesService.deleteEntity(vaId, entityId).subscribe((res: any[]) => {
      console.info('Delete Entity List', res);
      if (res['count'] == 1) {
        this.searchValue = null;
        this.getEntityList(this.PageNo, this.entitiesFilter.va, this.entitiesFilter.language, '');
        this.spinner.hide(this.tableSpinner);
      } else {
        console.error('Error in delete Intent');
        this.spinner.hide(this.tableSpinner);
      }
    });
  }
}
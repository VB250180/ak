import { Component, OnInit } from '@angular/core';
import { EntityObj, EntityRefernceValuePojoList, EntitySynonymsValueList,Language,VaDropDown } from '../../../core/models/entity';
import * as cloneDeep from 'lodash/cloneDeep';
import { ItemsList } from '@ng-select/ng-select/lib/items-list';
import { CreateEntityService } from './create-entity.service';
import { format } from 'url';
import { EntitiesService } from 'src/app/core/services/entity.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';
declare var $: any;



@Component({
  selector: 'app-create-entity',
  templateUrl: './create-entity.component.html',
  styleUrls: ['./create-entity.component.scss']
})
export class CreateEntityComponent implements OnInit {
  model: any = {};
  entityObj = new EntityObj()
  entityRefernceValuePojoListObj = new EntityRefernceValuePojoList();
  entitySynonymsValueList = new Array<EntitySynonymsValueList>();
  vrmId; vaAgents; lang;
  entityObjNew;
  entityDupValue: Boolean;
  showUpdateBtn: Boolean = true;
  isActiveSaveBtn: Boolean = true;
  isEntityDisabled: Boolean = false;
  isAlphCheckEntityName:Boolean=false;
  BreakException = {};
  userId: number = 0;
  vaID = null;
  langId; flag: any;
  constructor(private route: ActivatedRoute, private _entitiesService: EntitiesService, private _createEntityService: CreateEntityService, private matDialog: MatDialog, private router: Router) {
    this.addNewArrayRefval();
    this.userId = 1;
  }
  // default empty array 
  addNewArrayRefval() {
    let entityRefernceValuePojoListObj = new EntityRefernceValuePojoList();
    this.entityObj.entityRefernceValuePojoList.push(entityRefernceValuePojoListObj);
  }
  // addNewArrayRefvalObjNew() {
  //   let entityRefernceValuePojoListObj = new EntityRefernceValuePojoList();
  //   this.entityObjNew.entityRefernceValuePojoList.push(entityRefernceValuePojoListObj);
  // }

  ngOnInit() {
    this.route.paramMap.subscribe((params: any) => {
      this.vaID = params.params.vaID;
      let entId = params.params.entId;
      this.langId = params.params.langId;
      if (this.vaID != undefined) {
        this.isEntityDisabled = true;
        this.getEntity(entId, this.langId);
        this.isActiveSaveBtn = false;
      }
    });
    this.virtualAgents();

    $(document).on("keypress", "input", function (e) {
      var startPos = e.currentTarget.selectionStart;
      if (e.which === 32 && startPos == 0)
        e.preventDefault();
    });

//     $("input").bind("keypress",function(e){
//     var patt = /([a-z][0-9][\.\_])*/i; /* this is the pattern u want to test */
//     var value = this.value + String.fromCharCode(e.keyCode);
//     var result = patt.test(value ); /* result = true or false */
//     /* here you can do anything now */
// });
  }

  getEntity(entId, langId) {
    this._createEntityService.getEntity(entId, langId)
      .subscribe((res: any) => {
        this.model.vrmId = this.vaID;
        this.entityObj = res.entityResponseObject;
        let entityRefernceValuePojoListObj = new EntityRefernceValuePojoList();
        this.entityObj.entityRefernceValuePojoList.push(entityRefernceValuePojoListObj);
        this.entityObjNew = cloneDeep(this.entityObj);
        

      })
  }
  // getListofVA
  virtualAgents() {
    this._entitiesService.getVAdetailsByUserId(this.userId)
      .subscribe((res: any) => {
        this.vaAgents = res.virtualAgents;
        if (this.vaID != undefined) {
          this.vaChange(this.vaID);
        }
      })
  }
  //on VA Change
  vaChange(e) {
    let vaId = e;
    this._entitiesService.getLanguagessByVaId(vaId)
      .subscribe((res: any) => {
        this.lang = res.languageEngineMaps;
        if (this.vaID != null) {
          setTimeout(() => {
            // var foundlang =  this.lang.filter(obj => obj.langEngId == this.langId);
            // this.compareLang(this.lang,foundlang);
            this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1].languageMasterPojo.langId = this.langId;
          }, 500);
        }
      })
    // var foundValue = this.vaAgents.filter(obj => obj.virtualAgent.vaId == vaId);
    // this.lang = foundValue[0].languages;


  }
  //default first synonyms value
  OnChangeSynonyms(value) {
    this.entityDupValue = false;
    this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1].entitySynonymsValueList = [];
    this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1].entitySynonymsValueList.push({ "entitySynonymsValue": value });
  }


  searchDuplicateVal(value) {
    if (this.entityObjNew != undefined) {
      var duplicateVal = this.entityObjNew.entityRefernceValuePojoList.filter(item => item.entityReferenceValue == value);
      (duplicateVal.length == 0) ? this.saveEntityData() : this.entityDupValue = true;
    } else {
      this.saveEntityData();
    }
  }

  specialCharPresent(entName){
          var alphaExp = /^[a-zA-Z]+$/;
              if((entName.charAt(0)).match(alphaExp)){
                this.isAlphCheckEntityName=false;
                this.funSpecialCharChk(entName);
               }else{
                  this.isAlphCheckEntityName=true;
                  return false;
                 }
  }

  funSpecialCharChk(entName) {
    var patt = /^[a-zA-Z0-9\-\_]*$/;
    if(patt.test(entName)){
      this.isAlphCheckEntityName=false;
    }
    else{
      this.isAlphCheckEntityName=true;
      return false;
}
  }
  entityAddValue(f) {      
    if (f.form.valid) {
      if( this.isAlphCheckEntityName==false){
      this.searchDuplicateVal(f.form.value.entityReferenceValue);
      }
    }
  }
  saveEntityData() {
    this.entityDupValue = false;
    this.addNewArrayRefval();
    this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1].languageMasterPojo.langId = this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 2].languageMasterPojo.langId;
    this.entityObjNew = cloneDeep(this.entityObj);
  }
  //saveEntity new data
  saveEntity() {
    if(this.entityObjNew.entityRefernceValuePojoList.length>1){
    this.entityObjNew.entityRefernceValuePojoList.pop();
    this._createEntityService.saveEntity(this.model.vrmId, this.entityObjNew)
      .subscribe((res: any) => {
        if(res.errorBody!=null){
          this.openModalErrorPopUp(res['errorBody'].summary);
        }
        else{
        this.entityObjNew = res.entityResponseObject;
        let entityRefernceValuePojoListObj = new EntityRefernceValuePojoList();
        this.entityObjNew.entityRefernceValuePojoList.push(entityRefernceValuePojoListObj);
        this.openModalPopUp(this.flag);
        }
      });
    }
    else{
      this.openModalPopUpUpdateErr("2");
    }
  };
  updateEntity() {
    if(this.entityObjNew.entityRefernceValuePojoList.length>1){
    this.entityObjNew.entityRefernceValuePojoList.pop();
    this._createEntityService.updateEntity(this.model.vrmId, this.entityObjNew)
      .subscribe((res: any) => {
        if(res.errorBody!=null){
          this.openModalErrorPopUp(res['errorBody'].summary);
        }
       else{
        this.entityObjNew = res.entityResponseObject;
        let entityRefernceValuePojoListObj = new EntityRefernceValuePojoList();
        this.entityObjNew.entityRefernceValuePojoList.push(entityRefernceValuePojoListObj);
        this.openModalPopUp("1");
        this.entityObjNew = res.entityResponseObject;
        }
      });
    }else{
      this.openModalPopUpUpdateErr("2");
    }
  };

  //edit Entity
  editIndex;
  editEntity(entityObj, i) {
    this.editIndex = i;
    this.showUpdateBtn = false;
    this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1] = entityObj;
    this.entityObjNew = cloneDeep(this.entityObjNew);
  }

  entityUpdateValue(f) {
    if (f.form.valid) {
      if( this.isAlphCheckEntityName==false){
      this.entityObj.entityRefernceValuePojoList[this.editIndex] = this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1];
      let entityRefernceValuePojoListObj = new EntityRefernceValuePojoList();
      this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1] = entityRefernceValuePojoListObj;
      this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1].languageMasterPojo.langId = this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 2].languageMasterPojo.langId;
      this.entityObjNew = cloneDeep(this.entityObj);
      this.showUpdateBtn = true;
      }
    }
  }


  deleteEntity(i,obj) {
    this.entityObjNew.entityRefernceValuePojoList.splice(i, 1);
    this.entityObj = cloneDeep(this.entityObjNew);
    this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1].languageMasterPojo.langId = obj.languageMasterPojo.langId;
    this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1].entityReferenceValue = null;
    this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1].entitySynonymsValueList = [];

    this.showUpdateBtn = true;
  }


  onCancel() {
    this.flag == 1 ? this.router.navigate(['/entity-listing']) : "";
  }
  openModalPopUp(flag) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = "800px";
    dialogConfig.data = {
      primaryText: 'You have successfully created a new Entity',
      secondaryText: `The Entered data is saved in the Entity List page, you can view all the created Entity together in the list page`,
      hasPrimaryBtn: true,
      primaryBtnText: 'Create another',
      hasSecondaryBtn: true,
      secondaryBtnText: 'Go to Entity Listing Page',
      suggestedText: `Please Contact Uniphore Customer Support to complete the Entity configuration.`,
      popUpType: 'save',
      hasCancelBtn: false
    };
    flag == 1 ? dialogConfig.data.primaryText = 'You have successfully updated a new Entity' : '';
    const modalDialog = this.matDialog.open(ModalComponent, dialogConfig);
    modalDialog.afterClosed().subscribe(data => {
      console.log('material data', data);
      if (data == 'secondary') {
        this.router.navigate(['/entity-listing'])
      }
      else {
        this.redirectTo('/create-entity');
        // this.router.navigate(['/create-entity'])
      }
    });
  }

  redirectTo(uri:string){
    this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>
    this.router.navigate([uri]));
 }

  openModalErrorPopUp(err) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = "800px";
    dialogConfig.data = {
      primaryText: err,
      hasPrimaryBtn: true,
      primaryBtnText: 'Ok',
      suggestedText: `Please Contact Uniphore Customer Support to complete the Entity configuration.`,
      popUpType: 'error',
      hasCancelBtn: true
    };
    const modalDialog = this.matDialog.open(ModalComponent, dialogConfig);
    modalDialog.afterClosed().subscribe(data => {
      console.log('material data err', data);
      if (data == true) {
        this.redirectTo('/create-entity');
      }
      else {
        this.router.navigate(['/entity-listing'])
      }
    });
  }


  openModalPopUpUpdateErr(flag) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = "500px";
    dialogConfig.data = {
      primaryText: 'Entity not saved !!!',
      secondaryText: `You need to enter atleast one entity value to save the data`,
      hasPrimaryBtn: true,
      primaryBtnText: 'OK',
      hasSecondaryBtn: true,
      // secondaryBtnText: 'Go to va Entity Listing Page',
      suggestedText: `Please Contact Uniphore Customer Support to complete the Entity configuration.`,
      popUpType: 'save',
      hasCancelBtn: false
    };
    const modalDialog = this.matDialog.open(ModalComponent, dialogConfig);
    modalDialog.afterClosed().subscribe(data => {
    });
  }
 // dropdownBindvalue
  compareVal(c1: VaDropDown, c2: VaDropDown){
    if(c2==c1){
      return c2;
    }
    // return c1 && c2 ? c1.vaId === c2.vaId : c1 === c2;
  }
  compareLang(l1: Language, l2: Language){
    if(l2==l1){
      return l2;
    }
    // return 11 && 11 ? l1.langEngId === l2.langEngId : l1 === l2;
  }

}

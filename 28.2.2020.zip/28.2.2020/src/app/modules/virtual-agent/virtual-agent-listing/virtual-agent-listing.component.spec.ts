import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VirtualAgentListingComponent } from './virtual-agent-listing.component';

describe('VirtualAgentListingComponent', () => {
  let component: VirtualAgentListingComponent;
  let fixture: ComponentFixture<VirtualAgentListingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VirtualAgentListingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VirtualAgentListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

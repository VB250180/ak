import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalComponent } from './modal.component';
import { MatDialogModule, MatDialog } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, Component } from '@angular/core';
import { OverlayContainer } from '@angular/cdk/overlay';



describe('ModalComponent', () => {
  let dialog: MatDialog;
  let overlayContainerElement: HTMLElement;
  let noop: ComponentFixture<NoopComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ DialogTestModule ],
      providers: [
        { provide: OverlayContainer, useFactory: () => {
          overlayContainerElement = document.createElement('div');
          return { getContainerElement: () => overlayContainerElement };
        }}
      ]
    });

    dialog = TestBed.get(MatDialog);
    noop = TestBed.createComponent(NoopComponent);
  });

  it('should display correct values', () => {
    const config = {
      data: {
        primaryText: 'Hello How are you',
        secondaryText: 'Im fine thank you',
        hasPrimaryBtn: true,
        primaryBtnText: 'Save',
        popUpType: 'info',
        hasCancelBtn: true
      }
    };
    console.log('overlay', overlayContainerElement);
    

    dialog.open(ModalComponent, config);
    noop.detectChanges();
    const primaryText = overlayContainerElement.querySelector('.primary-text-font');
    const secondarytext = overlayContainerElement.querySelector('.secondary-text-font');
    const cancellBtn = overlayContainerElement.querySelector('.cancel-btn');
    const primaryBtn = overlayContainerElement.querySelector('.primary-btn');

    console.log('primary', primaryText);
    console.log('secondary', secondarytext);
    console.log('cancellBtn', cancellBtn);
    console.log('primaryBtn', primaryBtn);


    expect(primaryText.textContent).toBe('Hello How are you');
    expect(secondarytext.textContent).toBe('Im fine thank you');
    expect(cancellBtn.textContent.trim()).toBe('Cancel');
    expect(primaryBtn.textContent.trim()).toBe('Save');
  });

  it('should not display cancel button', () => {
    const onPrimaryBtnClickedSpy = jasmine.createSpyObj('ModalComponent', ['onPrimaryBtnClicked']);
    const config = {
      data: {
        primaryText: 'Hello How are you',
        secondaryText: 'Im fine thank you',
        hasPrimaryBtn: true,
        primaryBtnText: 'Save',
        popUpType: 'info',
        hasCancelBtn: false
      }
    };
    dialog.open(ModalComponent, config);
  
    noop.detectChanges();
  
    const cancellBtn = overlayContainerElement.querySelector('.cancel-btn') as HTMLElement;
    const primaryBtn = overlayContainerElement.querySelector('.primary-btn') as HTMLElement;

    primaryBtn.click();
    noop.detectChanges();

    expect(cancellBtn).toBe(null);
    expect(primaryBtn.textContent.trim()).toBe('Save')
  });

  it('should not display cancel button', () => {
    const onPrimaryBtnClickedSpy = jasmine.createSpyObj('ModalComponent', ['onPrimaryBtnClicked']);
    const config = {
      data: {
        primaryText: 'Hello How are you',
        secondaryText: 'Im fine thank you',
        hasPrimaryBtn: false,
        primaryBtnText: 'Save',
        popUpType: 'info',
        hasCancelBtn: true
      }
    };
    dialog.open(ModalComponent, config);
  
    noop.detectChanges();
  
    const cancellBtn = overlayContainerElement.querySelector('.cancel-btn') as HTMLElement;
    const primaryBtn = overlayContainerElement.querySelector('.primary-btn') as HTMLElement;

    cancellBtn.click();
    noop.detectChanges();

    expect(primaryBtn).toBe(null);
    expect(cancellBtn.textContent.trim()).toBe('Cancel');
  });
});

@Component({
  template: ''
})
class NoopComponent {}


const TEST_DIRECTIVES = [
  ModalComponent,
  NoopComponent
];

@NgModule({
  imports: [MatDialogModule, NoopAnimationsModule],
  exports: TEST_DIRECTIVES,
  declarations: TEST_DIRECTIVES,
  entryComponents: [
    ModalComponent
  ],
})
class DialogTestModule { }
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-va-send-message',
  templateUrl: './va-send-message.component.html',
  styleUrls: ['./va-send-message.component.scss']
})
export class VaSendMessageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

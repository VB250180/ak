import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-selected-va',
  templateUrl: './selected-va.component.html',
  styleUrls: ['./selected-va.component.scss']
})
export class SelectedVaComponent implements OnInit {

  @Output() onEditClicked = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }

  onEditClick() {
    this.onEditClicked.emit(true);
  }

}

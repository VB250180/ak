import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-va-chat-window',
  templateUrl: './va-chat-window.component.html',
  styleUrls: ['./va-chat-window.component.scss']
})
export class VaChatWindowComponent implements OnInit {

  @Input() showEditView: boolean;

  constructor() { }

  ngOnInit() {
  }

}

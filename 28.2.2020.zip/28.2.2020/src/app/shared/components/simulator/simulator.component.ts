import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-simulator',
  templateUrl: './simulator.component.html',
  styleUrls: ['./simulator.component.scss']
})
export class SimulatorComponent implements OnInit {

  showPopUp = false;
  showEditView = false;

  editForm: FormGroup;

  constructor() { }

  ngOnInit() {
    this.editForm = new FormGroup({
      vaAgent: new FormControl(null, Validators.required),
      vaChannel: new FormControl(null, Validators.required),
      vaLanguage: new FormControl(null, Validators.required)
    });
  }

  togglePopUp() {
    this.showPopUp = !this.showPopUp
  }

  editClicked() {
    this.showEditView = true;
  }

  onEditCancelClicked() {
    this.showEditView = false;
  }

}

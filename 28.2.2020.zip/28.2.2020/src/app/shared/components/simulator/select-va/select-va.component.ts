import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-select-va',
  templateUrl: './select-va.component.html',
  styleUrls: ['./select-va.component.scss']
})
export class SelectVaComponent implements OnInit {

  showPopUp : any;


  editForm: FormGroup;
  @Output() cancelClicked = new EventEmitter();
  vaDetails = [{
    vaInitials: 'AA',
    vaName: 'Va Test 1',
    vaStatus: 'Live'
  },
  {
    vaInitials: 'BB',
    vaName: 'Va Test 2',
    vaStatus: 'Test'
  }];

  vaChannels = [{
    channelName: 'Channel 1'
  },
  {
    channelName: 'Channel 2'
  },
  {
    channelName: 'Channel 3'
  },
  {
    channelName: 'Channel 3'
  }];

  constructor() { }

  ngOnInit() {
    this.editForm = new FormGroup({
      vaAgent: new FormControl(null, Validators.required),
      vaChannel: new FormControl(null, Validators.required),
      vaLanguage: new FormControl(null, Validators.required)
    });
  }

  onCancelClicked() {
    this.cancelClicked.emit(true);
  }

  onChange(event) {
    console.log(event);
  }

  statusFilter(s,f){
    console.log(s,f);
  }
}

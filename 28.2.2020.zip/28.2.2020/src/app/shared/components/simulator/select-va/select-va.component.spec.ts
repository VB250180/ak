import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectVaComponent } from './select-va.component';

describe('SelectVaComponent', () => {
  let component: SelectVaComponent;
  let fixture: ComponentFixture<SelectVaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectVaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectVaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

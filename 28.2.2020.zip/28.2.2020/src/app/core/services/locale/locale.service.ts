import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import en from '../../../../assets/i18n/en.json';

@Injectable({
  providedIn: 'root'
})
export class LocaleService {
  login: any;
  appAdmin: any;
  loginPage:any;
  forgotPasswordPage:any;
  resetPasswordPage:any;
  resetPasswordSuccessPage:any;

  constructor(private http: HttpClient) {
    this.loadBrowserLanguge('en')
   }

  loadBrowserLanguge(lang) {

    if (lang == 'en') {
      this.loginPage = en.login.loginPage;
      this.forgotPasswordPage = en.login.forgotPasswordPage;
      this.resetPasswordPage = en.login.resetPasswordPage;
      this.resetPasswordSuccessPage = en.login.resetPasswordSuccessPage;

      this.appAdmin = en.appAdmin;
    }

  }


}

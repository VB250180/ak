import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment as env } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class EntitiesService {

  constructor(private http: HttpClient) { }

  public getVAdetailsByUserId(userId:number) : Observable<any> {
    return this.http.get<any>(env.apiUrl + '/user/'+userId+'/virtualAgentsByUser/');
  }

  public getLanguagessByVaId(vaId:number) : Observable<any> {
    return this.http.get<any>(env.apiUrl + '/virtualAgent/'+vaId+'/languages');
  }

  public getEntityList(pageNo:number, vaId:number, vaLang:number,serachString:string,userId:number) : Observable<any> {
        return this.http.get<any>(env.apiUrl + '/virtualAgent/'+vaId+'/language/'+vaLang+'/page/'+pageNo+'/entity/{entityName}/user/'+userId+'/entities/?entityName='+serachString ); 

  }

  public deleteEntity(vaId:number,entityId:number){
    return this.http.delete<any>(env.apiUrl + '/virtualAgent/'+vaId+'/entity/'+entityId+'/entities/');
  }

}

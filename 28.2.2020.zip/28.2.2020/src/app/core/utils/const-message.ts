export const modalErrorConfig = {
    primaryText: 'Something went wrong',
    secondaryText: `We're having trouble completing your request, Please try again`,
    secondaryBtnText: 'Close',
    popUpType: 'Error',
    hasCancelBtn: true
};

export const modalDeleteConfig = {
    primaryText: 'Confirm',
    secondaryText: 'Are you sure want to delete?',
    hasPrimaryBtn: true,
    primaryBtnText: 'Yes',
    secondaryBtnText: 'No',
    popUpType: 'delete',
    hasCancelBtn: true
};
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from '../components/home/home.component';
import { CallSummaryComponent } from '../components/call-summary/call-summary.component';
import { AssistedTrainingComponent } from '../components/assisted-training/assisted-training.component';
import { CreateIntentComponent } from 'src/components/create-intent/create-intent.component';
import { LandingPageComponent } from '../components/landing-page/landing-page.component';
import { AgentListComponent } from '../components/agent-list/agent-list.component';
import { IntentListingComponent } from 'src/components/intent-listing/intent-listing.component';
import { TrainingPhrasesComponent } from 'src/components/create-intent/training-phrases/training-phrases.component';
import { VirtualAgentListingComponent } from './modules/virtual-agent/virtual-agent-listing/virtual-agent-listing.component';
import { VirtualAgentCreationComponent } from './modules/virtual-agent/virtual-agent-creation/virtual-agent-creation.component';
import { EntityListingComponent } from 'src/app/modules/entity/entity-listing/entity-listing.component';
import { CreateEntityComponent } from './modules/entity/create-entity/create-entity.component';
import { LoginComponent } from '../app/modules/login/login.component';
import { ConversationPacksComponent } from './modules/conversation-packs/conversation-packs.component';

const routes: Routes = [
  { path: '', redirectTo: 'agent-list', pathMatch: 'full' },
  { path: 'call-summary-configuration', component: HomeComponent },
  { path: 'call-summary', component: CallSummaryComponent },
  { path: 'assisted-training/:id/:name/:desc/:channel/:lang/:chId/:langId', component: AssistedTrainingComponent },
  { path: 'create-intent/:vaID/:intId/:langId/:chId/:flag', component: CreateIntentComponent },
  // { path: 'create-intent/:vaID/:intId/:langId/:chId', component: CreateIntentComponent },
  { path: 'create-intent', component: CreateIntentComponent },
  { path: 'landing-page', component: LandingPageComponent },
  { path: 'agent-list', component: AgentListComponent },
  { path: 'intent-listing', component: IntentListingComponent },
  { path: 'intent-listing/:id/:name/:desc/:channel/:lang/:chId/:langId', component: IntentListingComponent },
  { path: 'training-phrases', component: TrainingPhrasesComponent },
  { path: 'create-entity', component: CreateEntityComponent },
  { path: 'create-entity/:vaID/:entId/:langId', component: CreateEntityComponent },
  { path: 'va-listing' , component:VirtualAgentListingComponent},
  { path: 'va-creation/:vaId/:flag' , component:VirtualAgentCreationComponent},
  { path: 'va-creation' , component:VirtualAgentCreationComponent},
  { path: 'entity-listing', component: EntityListingComponent },
  { path: 'login' , component: LoginComponent},
  { path: 'conversation-packs' , component: ConversationPacksComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }


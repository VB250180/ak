export const environment = {
  //apiUrl: 'http://10.7.138.249:8082', //Tetsing
  //apiUrl: 'http://localhost:9000', //localhost
  //apiUrl: 'http://192.168.12.63:8082', //63
  apiUrl: 'http://172.16.15.10:9000',//ctrlS-172-10
  //apiUrl: 'http://10.7.138.226:8081', //Praveen
  production: true,
  userId:1,
};

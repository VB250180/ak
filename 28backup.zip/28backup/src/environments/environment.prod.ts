export const environment = {
  apiUrl:'http://10.7.138.195:8082',
  production: true
};

import { Component, NgModule, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, FormsModule, Validators } from '@angular/forms';
import { NgSelectModule, NgOption } from '@ng-select/ng-select';
import { AssistedTrainingService } from './assisted-training.service';
import { NgxSpinnerService } from "ngx-spinner";
import { BsDropdownConfig } from 'ngx-bootstrap/dropdown';

import { first } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import * as moment from 'moment';
import { DatePipe } from '@angular/common';
import { formatDate } from '@angular/common';


@Component({
  selector: 'app-assisted-training',
  templateUrl: './assisted-training.component.html',
  styleUrls: ['./assisted-training.component.scss'],
  providers: [{ provide: BsDropdownConfig, useValue: { autoClose: false } }]
})
export class AssistedTrainingComponent implements OnInit {

  public items = [
    { name: 'John', otherProperty: 'Foo' },
    { name: 'Joe', otherProperty: 'Bar' }
  ];

  cities2 = [
    { id: 1, name: 'Coverage Details' },
    { id: 2, name: 'Out Of Pocket' },
    { id: 3, name: 'Out Of Order', disabled: true },
    { id: 4, name: 'Benefits Details' },
    { id: 5, name: 'Order Of Installment' }
  ];

  conversationList: any;
  alwaysShowCalendars: boolean;
  showRangeLabelOnInput: boolean;
  keepCalendarOpeningWithRange: boolean;
  editCategoryForm = [];
  // minDate: moment.Moment = moment().subtract(6, 'days');
  // maxDate: moment.Moment = moment().add(2, 'month');

  ranges: any = [moment().subtract(6, 'days'), moment()];
  selected = { start: moment().subtract(6, 'days'), end: moment() };


  modalRef: BsModalRef;
  config = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: "my-modal"
  };
  config2 = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: "my-modal2"
  };

  myDate = new Date();
  date: any;
  tempdate: any;
  unmapped_Id: any;
  selectedCity: any;
  selectedCityIds: string[];
  selectedCityName = 'Vilnius';
  selectedCityId: number;
  selectedUserIds: number[];


  AssistedTrainingForm: FormGroup;
  serviceValue: any;
  channelValues: any = [];
  languageValues: any = [];
  statusValue: any = [];
  status: any;
  filterValues: any;
  isLoaded: boolean = false;
  options: any = [];
  channels: any = [];
  languages: any = [];
  listDetails: any;
  scopeInputs: any = [];
  mappedInputs: any = [];
  outscopeInputs: any = [];
  allInputs: any = [];
  sessionId: any = [];
  scopeLength: any;
  mappedLength: any;
  outscopeLength: any;
  display: boolean = false;
  events: Event[] = [];
  mwidth: number;
  swidth: number;
  owidth: number;
  dateLimit: number;
  VA_id: any;
  language_id: any;
  sortByDesc: boolean = true;
  channelId: number;
  pageNumber: number = 1;


  constructor(private trainingService: AssistedTrainingService, private spinner: NgxSpinnerService, private modalService: BsModalService) {
    this.AssistedTrainingForm = new FormGroup({
      status: new FormControl(null, Validators.required),
      channel: new FormControl(null, Validators.required),
      language: new FormControl(null, Validators.required),
    });
    this.alwaysShowCalendars = true;
    this.dateLimit = 7;
  }


  ngOnInit() {
    this.spinner.show();
    this.trainingService.getInputs().subscribe((res: any[]) => {
      this.serviceValue = res['virtualAgents'];
      this.filterValues = this.serviceValue;
      console.log(res['virtualAgents']);
    },
      err => console.error(err));

    this.trainingService.getIntents(this.channelId, this.language_id, this.VA_id, this.date, this.tempdate, this.sortByDesc, this.pageNumber).subscribe((list: any[]) => {
      this.conversationList = list;
      console.log(this.conversationList);
    });


    setTimeout(() => {
      console.log(this.serviceValue);
      console.log(this.conversationList);
      this.dropdownValues();
      this.conversationListDetails();
      this.spinner.hide();
    }, 5000);

    //current date formater
    this.date = formatDate(new Date(), 'yyyy-MM-dd', 'en');
    console.log("Date is", this.date);
    // this.date =this.date.setDate(this.date.getDate() - 7);
    // console.log("Again Date is",this.date);
    this.tempdate = "2019-10-17";

  }

  dropdownValues() {
    this.isLoaded = true;
    // this.serviceValue.forEach(options => {
    //   this.options.push(options.virtualAgent);
    // });
    console.log(this.serviceValue)
    for (let i = 0; i < this.serviceValue.length; i++) {
      this.options.push(this.serviceValue[i].virtualAgent)
    }
  }

  rangeClicked(date, event) {
    console.log('date selected', date, event);
  }

  showMessage(message: any) {
    console.log(message);
  }

  statusFilter(status) {
    this.AssistedTrainingForm.setValue({
      status: this.AssistedTrainingForm.controls.status.value,
      channel: null,
      language: null
    });
    this.VA_id = status.id;
    console.log("VA id is", this.VA_id);
    this.channels = []; this.languages = [];
    for (let q = 0; q < this.serviceValue.length; q++) {
      if (this.serviceValue[q].virtualAgent.value == status.value) {
        for (let j = 0; j < this.serviceValue[q].channels.length; j++) {
          this.channels.push(this.serviceValue[q].channels[j]);
        }
        for (let j = 0; j < this.serviceValue[q].languages.length; j++) {
          this.languages.push(this.serviceValue[q].languages[j]);
        }
      }
    }

    if (this.channels.length == 1 && this.languages.length == 1) {
      this.AssistedTrainingForm.patchValue({
        channel: this.channels[0].value,
        language: this.languages[0].value,
      });
    }
    else if (this.channels.length == 1) {
      this.AssistedTrainingForm.patchValue({
        channel: this.channels[0].value,


      });
      this.channelId = this.channels[0].id;
      console.log("channel id is", this.channelId);
    }

  }

  channelFilter(VA) {

    for (let q = 0; q < this.serviceValue.length; q++) {
      if (this.serviceValue[q].virtualAgent.value == VA.value) {
        for (let j = 0; j < this.serviceValue[q].languages.length; j++) {
          this.languageValues.push(this.serviceValue[q].languages[j]);
        }
      }
    }

    if (this.languages.length == 1) {
      this.AssistedTrainingForm.patchValue({
        language: this.languages[0].value,
      });
    }
  }

  languageFilter(language) {
    console.log(language);
    this.display = false;
    this.language_id = language.id;
    console.log("language is", this.language_id);
  }

  conversationListDetails() {
    this.mwidth = this.conversationList.mappedCount;
    this.swidth = this.conversationList.inScopeCount;
    this.owidth = this.conversationList.outOfScopeCount;
    console.log(this.conversationList.inScopeCount, this.conversationList.mappedCount, this.conversationList.outOfScopeCount);

    this.allInputs = this.conversationList.conversationList;
    for (let k = 0; k < this.conversationList.conversationList.length; k++) {
      this.sessionId = this.conversationList.conversationList[k].sessionId;
      for (let j = 0; j < this.conversationList.conversationList[k].inScopePhrases.length; j++) {
        this.scopeInputs.push(this.conversationList.conversationList[k].inScopePhrases[j]);
      }
      for (let j = 0; j < this.conversationList.conversationList[k].mapppedPhrases.length; j++) {
        this.mappedInputs.push(this.conversationList.conversationList[k].mapppedPhrases[j]);
      }
      for (let j = 0; j < this.conversationList.conversationList[k].outOfScopePhrases.length; j++) {
        this.outscopeInputs.push(this.conversationList.conversationList[k].outOfScopePhrases[j]);
      } console.log(this.mappedInputs, this.conversationList.conversationList[0].mapppedPhrases[0])
    }
  }


  expandPanel(input) {
    this.display = true;
    console.log(input);
    this.scopeInputs = []; this.mappedInputs = []; this.outscopeInputs = [];

    this.allInputs = this.conversationList.conversationList;
    for (let k = 0; k < this.conversationList.conversationList.length; k++) {
      if (input === this.conversationList.conversationList[k].sessionId) {
        console.log(input, this.conversationList.conversationList[k].sessionId)
        for (let j = 0; j < this.conversationList.conversationList[k].inScopePhrases.length; j++) {
          this.scopeInputs.push(this.conversationList.conversationList[k].inScopePhrases[j]);
          this.scopeLength = this.scopeInputs.length;
        }
        for (let j = 0; j < this.conversationList.conversationList[k].mapppedPhrases.length; j++) {
          this.mappedInputs.push(this.conversationList.conversationList[k].mapppedPhrases[j]);
          this.mappedLength = this.mappedInputs.length;
        }
        for (let j = 0; j < this.conversationList.conversationList[k].outOfScopePhrases.length; j++) {
          this.outscopeInputs.push(this.conversationList.conversationList[k].outOfScopePhrases[j]);
          this.outscopeLength = this.outscopeInputs.length;
        }
      }
    }
  }

  deleteUnmappedUser() {
    this.trainingService.deleteUnmappedUserInputs(this.unmapped_Id)
      .subscribe(res => {
        this.modalRef.hide();
        this.unmapped_Id = null;
        // let indexOfItem = this.userPosts.indexOf(post);  
        //       this.userPosts.splice(indexOfItem, 1);  
        //       console.log(this.userPosts.length);  
      });
  }

  openModal(template: TemplateRef<any>, id) {
    let editCategoryForm2 = [];
    if (id == undefined) {
      // for (let key of this.editCategoryForm) {
      //   editCategoryForm2.push('vaId='+key);
      //   this.unmapped_Id=editCategoryForm2;
      //  }
      this.unmapped_Id = this.editCategoryForm;
    } else {
      this.unmapped_Id = id;
    }
    this.modalRef = this.modalService.show(template, this.config2);
  }

  openModals(template2: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template2, this.config);
  }
  onChange(index: number, data, isChecked: boolean) {
    debugger;
    if (isChecked) {
      this.editCategoryForm.push(data);
    } else {
      this.editCategoryForm.splice(this.editCategoryForm.indexOf(data), 1);
    }
  }
  getIntents() {

  }
}

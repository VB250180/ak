import { Component, OnInit } from '@angular/core';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import * as $ from 'jquery';
import { AlertPromise } from 'selenium-webdriver';

@Component({
  selector: 'app-intent-listing',
  templateUrl: './intent-listing.component.html',
  styleUrls: ['./intent-listing.component.scss']
})
export class IntentListingComponent implements OnInit {


  clicks: any = 0;
  lastClick: any;
  Emergencies: any = [];
  showSelected: boolean = true;
  channels:any=[];
  dataRow:any;

  
  data = [
    {
      id: 1,
      intent: "Check Loan status",
      language: "French",
      channel: [{IVR:0, Web:1, Msn:0, Slk:1}],
      va: "Samantha",
      bu:"claim status"
    },
    {
      id: 2,
      intent: "Check Loan status",
      language: "English",
      channel:  [{IVR:1, Web:1, Msn:1, Slk:1}],
      va: "Samantha",
      bu:"claim status"
    },
    {
      id: 3,
      intent: "Coverage Details",
      language: "Spainish",
      channel:[{IVR:0, Web:1, Msn:0, Slk:1}],
      va: "Jonathan",
      bu:"claim status"
    },
    {
      id: 4,
      intent: "Coverage Details",
      language: "Spainish",
      channel: [{IVR:1, Web:0, Msn:1, Slk:1}],
      va: "Debbi",
      bu:"claim status"
    },
    {
      id: 5,
      intent: "Coverage Details",
      language: "Spainish",
      channel: [{IVR:1, Web:1, Msn:1, Slk:0}],
      va: "Samantha",
      bu:"claim status"
    },
    {
      id: 6,
      intent: "Coverage Details",
      language: "Spainish",
      channel: [{IVR:1, Web:1, Msn:1, Slk:1}],
      va: "Samantha",
      bu:"claim status"
    },
    {
      id: 7,
      intent: "Coverage Details",
      language: "Spainish",
      channel: [{IVR:0, Web:1, Msn:0, Slk:1}],
      va: "Jonathan",
      bu:"claim status"
    }
  ];

  constructor() { }

  ngOnInit() {
  }

  // addEmergency(i) {

  //   var item = {
  //     "ContactName": "",
  //     "Phone": "",
  //     "relationship": "",
  //     "id": this.clicks,
  //   }
  //   this.Emergencies.push(item);
  //   console.log("current id is ", item.id);
  //   this.lastClick = this.clicks;
  //   this.clicks += 1;
  //   if (this.clicks > 1) {
  //     if (this.clicks > this.lastClick) {
  //       alert("Are you sure to add one more form");
  //     }

  //   }
  // }
  removeRow(datas, index){
    this.data.splice(index, 1);
}

}




import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { catchError, map, tap, delay,filter,scan } from 'rxjs/operators';
import { environment as env} from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CreateIntentService {

  constructor(private http:HttpClient) { }

  public saveCreateIntent(saveIntentForm){
    let roleId=1;
    return this.http.post(env.apiUrl+'/virtualAgent/'+roleId+'/intents',saveIntentForm);
  }
  public updateCreateIntent(intentId,saveIntentForm){
    let roleId=1;
    return this.http.put(env.apiUrl+'/virtualAgent/'+roleId+'/intents/'+intentId,saveIntentForm);
  }
  public getIntent(roleId,intentId){
    return this.http.get(env.apiUrl+'/virtualAgent/'+roleId+'/intents/'+intentId);
  }

}

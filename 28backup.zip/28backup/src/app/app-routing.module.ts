import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from '../components/home/home.component';
import { CallSummaryComponent } from '../components/call-summary/call-summary.component';
import { AssistedTrainingComponent } from '../components/assisted-training/assisted-training.component';
import { CreateIntentComponent } from 'src/components/create-intent/create-intent.component';
import { LandingPageComponent } from '../components/landing-page/landing-page.component';
import { AgentListComponent } from '../components/agent-list/agent-list.component';
import { IntentListingComponent } from 'src/components/intent-listing/intent-listing.component';

const routes: Routes = [
  { path: '', redirectTo:'assisted-training', pathMatch:'full'},
  { path: 'call-summary-configuration', component: HomeComponent },
  { path: 'call-summary', component: CallSummaryComponent },
  { path: 'assisted-training', component: AssistedTrainingComponent },
  { path: 'create-intent', component: CreateIntentComponent },
  { path: 'landing-page', component: LandingPageComponent },
  { path: 'agent-list', component: AgentListComponent },
  { path: 'assisted-training', component: AssistedTrainingComponent },
  { path: 'intent-listing' , component: IntentListingComponent}  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { TextSelectDirective } from "../app/shared/directives/text-select.directive";
import { NgModule } from '@angular/core';

//TextSelectDirective

@NgModule({
    declarations: [TextSelectDirective],
    exports:[TextSelectDirective]

})
export class SharedModule { }
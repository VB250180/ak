import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from '../components/home/home.component';
import { CallSummaryComponent } from '../components/call-summary/call-summary.component';
import { CreateIntentComponent } from 'src/components/create-intent/create-intent.component';
import { LandingPageComponent } from '../components/landing-page/landing-page.component';
import { AgentListComponent } from '../components/agent-list/agent-list.component';
import { IntentListingComponent } from 'src/components/intent-listing/intent-listing.component';
import { TrainingPhrasesComponent } from 'src/components/create-intent/training-phrases/training-phrases.component';

import { EntityListingComponent } from 'src/app/modules/entity/entity-listing/entity-listing.component';
import { CreateEntityComponent } from './modules/entity/create-entity/create-entity.component';
import { LoginComponent } from '../app/modules/login/login.component';
import { ConversationPacksComponent } from './modules/conversation-packs/conversation-packs.component';
import { AuthGuard } from './core/guards/auth.guard';
import { PasswordComponent } from './modules/password/password.component';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'call-summary-configuration', component: HomeComponent, canActivate: [AuthGuard] },
  { path: 'call-summary', component: CallSummaryComponent , canActivate: [AuthGuard]},
  
  // { path: 'assisted-training/:id/:name/:desc/:channel/:lang/:chId/:langId', component: AssistedTrainingComponent , canActivate: [AuthGuard]},
  { path: 'create-intent/:vaID/:intId/:langId/:chId/:flag', component: CreateIntentComponent, canActivate: [AuthGuard] },
  { path: 'create-intent', component: CreateIntentComponent, canActivate: [AuthGuard] },
  { path: 'landing-page', component: LandingPageComponent, canActivate: [AuthGuard] },
  { path: 'agent-list', component: AgentListComponent,canActivate: [AuthGuard]},
  { path: 'intent-listing', component: IntentListingComponent , canActivate: [AuthGuard]},
  { path: 'intent-listing/:id/:name/:desc/:channel/:lang/:chId/:langId', component: IntentListingComponent , canActivate: [AuthGuard]},
  { path: 'training-phrases', component: TrainingPhrasesComponent, canActivate: [AuthGuard] },
  { path: 'create-entity', component: CreateEntityComponent, canActivate: [AuthGuard] },
  { path: 'create-entity/:vaID/:entId/:langId', component: CreateEntityComponent, canActivate: [AuthGuard] },
  { path: 'va',
    loadChildren: () => import('../app/modules/virtual-agent/virtual-agent.module').then(m => m.VirtualAgentModule),
    canActivate: [AuthGuard]
  },
  { path: 'assisted',
    loadChildren: () => import('../app/modules/assisted-training/assisted-training.module').then(m => m.AssistedTrainingtModule),
    canActivate: [AuthGuard]
  },
  { path: 'entity-listing', component: EntityListingComponent, canActivate: [AuthGuard] },
  { path: 'login' , component: LoginComponent, canActivate: [AuthGuard]},
  { path: 'conversation-packs' , component: ConversationPacksComponent, canActivate: [AuthGuard]},
  { path: 'reset-password' , component: PasswordComponent},
  { path: 'conversational-metrics',
    loadChildren: () => import('../app/modules/conversational-metrics/conversational-metrics.module').then(m => m.ConversationalMetricsModule),
    canActivate: [AuthGuard]
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }


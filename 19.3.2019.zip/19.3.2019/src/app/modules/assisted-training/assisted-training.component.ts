import {
  Component,
  OnInit,
  TemplateRef,
  ViewChild,
} from "@angular/core";
import {
  FormControl,
  FormGroup,
  Validators,
  FormBuilder
} from "@angular/forms";

import { ActivatedRoute, Router } from '@angular/router'
import { MapModalComponent } from '../assisted-training/map-modal/map-modal.component';
import { AssistedTrainingService } from "./assisted-training.service";
import { NgxSpinnerService } from "ngx-spinner";
import { BsDropdownConfig } from "ngx-bootstrap/dropdown";
import { MatDialog } from '@angular/material/dialog';
import { BsModalService } from "ngx-bootstrap/modal";
import { BsModalRef } from "ngx-bootstrap/modal/bs-modal-ref.service";
import moment from "moment";
import { formatDate } from "@angular/common";
import { ToastrService } from 'ngx-toastr';
import { TextSelectEvent } from "../../shared/directives/text-select.directive";
import { SelectionRectangle } from "../../core/models/selectionRectangle";
import { IntentType, intentTypeList } from "../../core/models/intentType";
import { CreateIntentService } from '../../../components/create-intent/create-intent.service';
import { chooseColorClassByLastDigit, getObjById, isEmptyObj } from '../../core/utils/akeira-utils';
import * as cloneDeep from 'lodash/cloneDeep';
import { getCurrentUserId } from '../../core/utils/akeira-utils';

@Component({
  selector: "app-assisted-training",
  templateUrl: "./assisted-training.component.html",
  styleUrls: ["./assisted-training.component.scss"],
  providers: [{ provide: BsDropdownConfig, useValue: { autoClose: false } }],
})
export class AssistedTrainingComponent implements OnInit {
  // Added dummy value for  build
  // Start
  id;
  locale;
  start;
  // End
  conversationList: any;
  alwaysShowCalendars: boolean;
  showRangeLabelOnInput: boolean;
  keepCalendarOpeningWithRange: boolean;
  editCategoryForm = [];
  // minDate: moment.Moment = moment().subtract(6, 'days');
  // maxDate: moment.Moment = moment().add(2, 'month');

  ranges: any = [moment().subtract(6, "days"), moment()];
  selected = { start: moment().subtract(6, "days"), end: moment() };
  tomorrow: any;

  modalRef: BsModalRef;
  config = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: "my-modal"
  };
  config2 = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: "my-modal2"
  };
  myDate = new Date();
  date: any;
  tempdate: any;
  unmapped_Id: any;
  selectedCity: any;
  selectedIntentName: string[];
  unmapObjectIndex = new Map<string, any>();
  //unmap: any;
  clearId: any;
  clearSessionId: any;
  clearPhraseType: any;

  AssistedTrainingForm: FormGroup;
  serviceValue: any;
  statusValue: any = [];
  status: any;
  channel: any;
  language: any;
  filterValues: any;
  isLoaded: boolean = false;
  options: any = [];
  channels: any = [];
  languages: any = [];
  listDetails: any;
  scopeInputs: any = [];
  mappedInputs: any = [];
  outscopeInputs: any = [];
  allInputs: any = {};
  //allInputArray: any = [];
  sessionId: any = [];
  scopeLength: any;
  mappedLength: any;
  outscopeLength: any;
  display: boolean = false;
  events: Event[] = [];
  mwidth: number;
  m_length: number;
  swidth: number;
  s_length: number;
  owidth: number;
  o_length: number;
  totalInputs: number;
  dateLimit: number;
  VA_id: any;
  language_id: any;
  channel_Id: any;
  sortByDesc: boolean = true;
  channelId: number;
  pageNumber: number = 1;
  toDate: any;
  fromDate: any;
  Entities: any;
  response: any;
  intentListData: any = [];
  intentSlotList: any = [];
  intentSlotColorList: any = [];
  isIntentLive: true;
  IsHidden = true;
  ArrayList: any = [];
  searchText: string = '';
  textarea: any;
  selectionValue: boolean = false;
  log: any; selection: any;
  unmappedJson: any = [];
  //phraseSelected: boolean = true;
  selectedValue: any[] = []; selectedIntentId: any; intentSlotId: any = []; intentSlotValue: any = [];
  currentSelectedtxt: string = '';
  count: number = 0;
  counter: number = 1;
  pos: any;
  vaName: any;
  vaId: any;
  vaDesc: any;
  vaChan: any;
  vaLang: any;
  vaChanId: any;
  vaLangId: any;
  vaById: any = {};
  BreakException = {};
  intentType: IntentType[] = intentTypeList;
  showloader = false;
  selectedIntents = [];

  @ViewChild('templateWarning', { static: false }) templateRef: TemplateRef<any>;
  modalMsg: string = '';
  modalHeader: string = 'Info';

  modalRefInfo: BsModalRef;
  configModal = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: "my-modal2"
  };

  createFormGroup: FormGroup;
  innnerHTMLStr: any;
  flag: boolean = false;
  created: boolean;
  public hostRectangle: SelectionRectangle | null;
  private selectedText: string;
  public dropdownError: string;
  selectedPharseKey: string;
  posStart: number = -1;
  posEnd: number = -1;

  modalRefTrainInput: BsModalRef;
  trainInputconfig = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: "my-modaltraining"
  };
  toastrConfig = {
    timeOut: 3000
  };
  userId: number = 0;
  rangeClicked(start, e) { }
  ifbestResponseIntent: boolean = false;
  bestResponseSlots = [];

  constructor(
    private trainingService: AssistedTrainingService,
    private spinner: NgxSpinnerService,
    private modalService: BsModalService,
    private _Activatedroute: ActivatedRoute,
    private _router: Router,
    private fb: FormBuilder,
    private toastr: ToastrService,
    public createIntentService: CreateIntentService,
    public dialog: MatDialog
  ) {
    this.AssistedTrainingForm = new FormGroup({
      status: new FormControl(null, Validators.required),
      channel: new FormControl(null, Validators.required),
      language: new FormControl(null, Validators.required)
    });
    this.createFormGroup = this.fb.group({});
    this.createFormGroup.addControl('name', new FormControl('', [Validators.required]));
    this.createFormGroup.addControl('description', new FormControl('', [Validators.required]));
    this.createFormGroup.addControl('intentType', new FormControl('', [Validators.required]));

    // this.createFormGroup = new FormGroup({
    //   name: new FormControl(" ", [Validators.required]),
    //   description: new FormControl(" ", [Validators.required])
    // });

    this.userId = getCurrentUserId();

    this.alwaysShowCalendars = true;
    this.tomorrow = moment();
    this.dateLimit = 6;
    this.clearHostRectangle();
  }

  ngOnInit() {
    this.spinner.show();
    this.clearAssistedTrainingtags();
    this._Activatedroute.paramMap.subscribe(params => {
      console.log('assisted-training page params --->', params);
      this.vaName = params.get('name');
      this.vaId = params.get('id');
      this.vaDesc = params.get('desc');
      this.vaChan = params.get('channel');
      this.vaLang = params.get('lang');
      this.vaChanId = params.get('chId');
      this.vaLangId = params.get('langId');
      console.log('this.vaId', this.vaId);
    });

    //current date formater
    this.date = new Date();
    this.toDate = formatDate(this.date, "yyyy-MM-dd", "en");
    this.date.setDate(this.date.getDate() - 7);
    this.fromDate = formatDate(this.date, "yyyy-MM-dd", "en");
    console.log("date ranges are", this.fromDate, "--", this.toDate);
    this.getDropdownInput();
  }

  getDropdownInput() {
    //Get all dropdown value
    this.trainingService.getInputs(this.userId).subscribe((res: any[]) => {
      console.log('trainingService.getInputs --->', res);

      this.serviceValue = res['virtualAgentRoleMaps'];
      for (let i = 0; i < res['virtualAgentRoleMaps'].length; i++) {
        this.vaById[res['virtualAgentRoleMaps'][i].vrmId] = res['virtualAgentRoleMaps'][i];
      }

      // this.serviceValue = res["virtualAgents"];
      // for (let i = 0; i < res['virtualAgents'].length; i++) {
      //   this.vaById[res['virtualAgents'][i].virtualAgent.vaId] = res['virtualAgents'][i];
      // }
      this.setDropdownValues();
      //this.dropdownValues();
      this.searchIntentFunc();
    },
      err => { this.spinner.hide(); console.error('Error In trainingService.getInputs'); console.error(err); }
    );
  }


  setDropdownValues() {
    this.isLoaded = true;
    this.channels = []; this.languages = [];
    this.channels = this.vaById[this.vaId].channels;
    this.languages = this.vaById[this.vaId].languages;
    (this.vaById[this.vaId]['vrmIsLive'] === false) ? this.status = 'Test' : this.status = 'Live';
    this.channel = this.vaChan;
    this.AssistedTrainingForm.get('channel').setValue(this.vaChan);
    this.language = this.vaLang;
    this.AssistedTrainingForm.get('language').setValue(this.vaLang);
    this.channel_Id = this.vaChanId;
    this.language_id = this.vaLangId;
    this.VA_id = this.vaId

    this.serviceCallUnmappedInputs(this.channel_Id, this.fromDate, this.language_id, this.pageNumber, this.sortByDesc, this.toDate, this.VA_id, this.searchText);

    console.log(this.channel_Id, this.language_id, this.VA_id);
  }

  //Fetch search Intent 
  searchIntentFunc() {
    this.trainingService
      .searchIntent(this.VA_id, this.language_id)
      .subscribe((res: any[]) => {
        console.log("Search Entities Data", res);
        this.response = res;
        for (let k = 0; k < this.response.length; k++) {
          this.intentListData.push(res[k]["intent"]);
        }
        this.intentListData = [...this.intentListData];
      },
        err => { this.spinner.hide(); console.error(err); }
      );
  }

  //code to fetch service for left panel unmapped user inputs 
  serviceCallUnmappedInputs(chn, fromDate, langId, pageNo, sort, toDate, VA, text) {
    let serachtxt = text != undefined && text != 'undefined' ? text : '';
    this.clearAssistedTrainingtags();
    this.trainingService.getIntents(chn, fromDate, langId, pageNo, sort, toDate, VA, serachtxt).subscribe((list: any[]) => {
      console.log(list);
      this.allInputs = {};
      //this.allInputArray = [];
      this.conversationListDetails(list);
    }, err => {
      console.log(err);
      this.spinner.hide();
    });
  }
  //code to trigger event onselection of channel
  channelFilter() {
    this.spinner.show();
    this.clearAssistedTrainingtags();
    //console.log('-----> ', this.AssistedTrainingForm.get('channel').value);
    this.channel_Id = this.AssistedTrainingForm.get('channel').value;
    this.unmapObjectIndex.clear();
    this.serviceCallUnmappedInputs(this.channel_Id, this.fromDate, this.language_id, this.pageNumber, this.sortByDesc, this.toDate, this.VA_id, this.searchText);
  }
  //code to trigger event onselection of language
  languageFilter() {
    this.spinner.show();
    this.clearAssistedTrainingtags();
    //console.log('-----> ', this.AssistedTrainingForm.get('language').value);
    this.language_id = this.AssistedTrainingForm.get('language').value;
    this.unmapObjectIndex.clear();
    this.intentListData = [];
    this.trainingService.languageChange(this.channel_Id, this.fromDate, this.language_id, this.pageNumber, this.sortByDesc, this.toDate, this.VA_id, this.searchText)
      .subscribe((res: any[]) => {
        let searchIntent = res[0];
        let getIntents = res[1];

        console.log("Search Entities Data", searchIntent);
        this.response = res[0];
        for (let k = 0; k < this.response.length; k++) {
          this.intentListData.push(this.response[k]["intent"]);
        }
        this.intentListData = [...this.intentListData];
        console.log(getIntents, this.intentListData);
        this.allInputs = {};
        //this.allInputArray = [];
        this.conversationListDetails(getIntents);
      },
        err => { this.spinner.hide(); console.error(err); }
      );
  }

  onSearch(text: any) {
    this.spinner.show();
    this.counter = 1;
    this.searchText = text;
    this.clearAssistedTrainingtags();
    this.serviceCallUnmappedInputs(this.channel_Id, this.fromDate, this.language_id, 1, this.sortByDesc, this.toDate, this.VA_id, this.searchText);
    console.log(this.searchText, this.vaId, this.VA_id);
  }

  //code to triggger eventon date selection 
  choosedDate(e) {
    this.toDate = formatDate(this.selected.end['_d'], 'yyyy-MM-dd', 'en');
    this.fromDate = formatDate(this.selected.start['_d'], 'yyyy-MM-dd', 'en');
    console.log(e, this.toDate, this.fromDate, this.channels, this.channel_Id, this.fromDate, this.language_id, this.pageNumber, true, this.toDate, this.VA_id, this.AssistedTrainingForm.value.channel);
  }

  submitFilter(e) {
    console.log(e, this.toDate, this.fromDate, this.channels, this.channel_Id, this.fromDate, this.language_id, this.pageNumber, true, this.toDate, this.VA_id, this.AssistedTrainingForm.value.channel);
    console.log(this.channel_Id, this.language_id, this.VA_id);
    this.serviceCallUnmappedInputs(this.channel_Id, this.fromDate, this.language_id, this.pageNumber, true, this.toDate, this.VA_id, this.searchText);
  }

  cancelFilter(e) {
    console.log(e);
    console.log(this.channel_Id, this.language_id, this.VA_id);
    this.serviceCallUnmappedInputs(this.channel_Id, this.fromDate, this.language_id, this.pageNumber, true, this.toDate, this.VA_id, this.searchText);
  }

  cancelCreate() {
    this.createFormGroup.reset();
  }

  //code to populate values in left panel
  conversationListDetails(list) {
    //console.log(this.conversationList);
    this.m_length = list.mappedCount;
    this.s_length = list.inScopeCount;
    this.o_length = list.outOfScopeCount;
    this.totalInputs = list.mappedCount + list.inScopeCount + list.outOfScopeCount

    this.mwidth = Math.round((this.m_length / this.totalInputs) * 100);
    this.swidth = Math.round((this.s_length / this.totalInputs) * 100);
    this.owidth = Math.round((this.o_length / this.totalInputs) * 100);

    for (let k = 0; k < list.conversationList.length; k++) {
      //this.allInputs.push(this.conversationList.conversationList[k]);
      this.conversationListProcess(list.conversationList[k]['sessionId'], list.conversationList[k]);
    }
    console.log('this.allInputs --->', this.allInputs);
    //console.log('this.allInputArray --->', this.allInputArray);
    this.spinner.hide();
  }

  conversationListProcess(sessionId, conversationList) {
    this.scopeInputs = []; this.mappedInputs = []; this.outscopeInputs = [];
    for (let j = 0; j < conversationList.mapppedPhrases.length; j++) {
      let map = conversationList.mapppedPhrases[j];
      console.log('mapped phrases', map);
      map['sessionId'] = sessionId;
      map['isSelected'] = false;
      map['phraseType'] = 'mapppedPhrases';
      map["mappedData"] = this.mappedPhraseGenerator(
        conversationList.mapppedPhrases[j], conversationList.sessionId
      );
      this.mappedInputs.push(map);
      console.log(this.mappedInputs.length, conversationList.mapppedPhrases[j], conversationList.sessionId)
    }
    for (let j = 0; j < conversationList.outOfScopePhrases.length; j++) {
      let map = conversationList.outOfScopePhrases[j];
      map['intentslots'] = {};
      map['intentId'] = null;
      map['isSelected'] = false;
      map['phraseType'] = 'outscopePhrases';
      map['sessionId'] = sessionId;
      map["mappedData"] = {
        'displayValue': conversationList.outOfScopePhrases[j].value,
        'sessionId': conversationList.sessionId,
        'mappedHighlightData': this.genrateHighlightdata(conversationList.outOfScopePhrases[j].value, false, '')
      }
      this.outscopeInputs.push(map);
    }
    for (let j = 0; j < conversationList.inScopePhrases.length; j++) {
      let map = conversationList.inScopePhrases[j];
      map['intentslots'] = {};
      map['intentId'] = null;
      map['isSelected'] = false;
      map['phraseType'] = 'inScopePhrases';
      map['sessionId'] = sessionId;
      map["mappedData"] = {
        'displayValue': conversationList.inScopePhrases[j].value,
        'sessionId': conversationList.sessionId,
        'mappedHighlightData': this.genrateHighlightdata(conversationList.inScopePhrases[j].value, false, '')
      }
      this.scopeInputs.push(map);
    }
    let pushDt = {
      'mapppedPhrases': this.mappedInputs,
      'inScopePhrases': this.scopeInputs,
      'sessionId': conversationList.sessionId,
      'outscopePhrases': this.outscopeInputs
    }
    this.allInputs[conversationList.sessionId] = pushDt;
  }


  mappedPhraseGenerator(mapphrases, id) {
    let found = [],
      displayValue = mapphrases.value,
      rxp = /%([^%/]+)%/g,
      curMatch
    // intentSlotsValue = [];
    console.log(mapphrases);
    if (mapphrases.intentslots != null) {
      while ((curMatch = rxp.exec(mapphrases.value))) {

        console.log(curMatch[1])
        displayValue = displayValue.replace(curMatch[1], mapphrases.intentslots[curMatch[1]].value);
        console.log(curMatch[1], displayValue);
      }
      displayValue = displayValue.replace(/%/g, "");
      let mappedHighlightData = [];
      let displayData = {
        'displayValue': displayValue,
        'intentId': mapphrases.intentId,
        'sessionId': id,
        'mappedHighlightData': this.genrateHighlightdata(displayValue, true, mapphrases.intentslots),
        'intentslots': mapphrases.intentslots
      }

      console.log(displayData);
      return displayData;
    } else {
      let displayData = {
        'displayValue': mapphrases.value,
        'intentId': mapphrases.intentId,
        'sessionId': id,
        'mappedHighlightData': this.genrateHighlightdata(mapphrases.value, false, ''),
        'intentslots': {}
      }
      return displayData;
    }
  }

  genrateHighlightdata(txt: string, isMapped: boolean, intentslots) {
    let txtArray = txt.split(" "), renderJson = [];
    txtArray.forEach((e, i) => { renderJson.push({ 'index': i, 'value': e, 'isHighlight': false, 'key': ('pos' + i) }); });
    if (isMapped) {
      let outputColorArray = [].concat(...this.colorArrayGenrater(intentslots));
      console.log('outputColorArray', outputColorArray);
      for (let i in renderJson) {
        for (let j in outputColorArray) {
          if (renderJson[i]['key'] === outputColorArray[j]) {
            renderJson[i]['isHighlight'] = true;
            break;
          }
        }
      }
      console.log(renderJson);
    }
    return renderJson;
  }

  //code to trigger event accordion expansion
  expandPanel(input) {
    this.display = true;
    this.scopeInputs = []; this.mappedInputs = []; this.outscopeInputs = [];

    //this.allInputs = this.conversationList.conversationList;

    if (this.allInputs[input]) {
      for (let j = 0; j < this.allInputs[input].inScopePhrases.length; j++) {
        this.scopeInputs.push(this.allInputs[input].inScopePhrases[j]);
        this.scopeLength = this.scopeInputs.length;
      }
      for (let j = 0; j < this.allInputs[input].outscopePhrases.length; j++) {
        this.outscopeInputs.push(this.allInputs[input].outscopePhrases[j]);
        this.outscopeLength = this.outscopeInputs.length;
      }
      for (let j = 0; j < this.allInputs[input].mapppedPhrases.length; j++) {
        this.mappedInputs.push(this.allInputs[input].mapppedPhrases[j]);
        this.mappedLength = this.mappedInputs.length;
      }
      // for (let j = 0;j < this.allInputs[input].outOfScopePhrases.length; j++ ) {
      //   this.outscopeInputs.push(this.allInputs[input].outOfScopePhrases[j]);
      //   this.outscopeLength = this.outscopeInputs.length;
      // }
      console.log(this.scopeInputs.length, this.mappedInputs.length, this.outscopeInputs.length);
    }

  }

  clearAssistedTrainingtags() {
    this.unmapObjectIndex.clear(); this.selectedIntentName = []; this.selectedIntentId = '', this.intentSlotColorList = [];
  }

  //code to delete input
  deleteUnmappedUser() {
    this.spinner.show();
    this.trainingService
      .deleteUnmappedUserInputs(this.unmapped_Id)
      .subscribe(res => {
        this.modalRef.hide();
        this.unmapped_Id = null;
        this.serviceCallUnmappedInputs(this.channel_Id, this.fromDate, this.language_id, this.pageNumber, this.sortByDesc, this.toDate, this.VA_id, this.searchText);
      },
        err => { this.spinner.hide(); console.error(err); }
      );
  }

  openModalClear(template: TemplateRef<any>, id, session, phraseType) {
    this.clearSessionId = session;
    this.clearId = id;
    this.clearPhraseType = phraseType;
    this.modalRef = this.modalService.show(template, this.config2);
  }

  //modal popup on click of map intent
  openDialog(): void {
    if (this.unmapObjectIndex.size > 0 && this.selectedIntentId != undefined && this.selectedIntentId != '') {
      const dialogRef = this.dialog.open(MapModalComponent, {
        data: 'open dialog'
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result == true) {
          this.saveUnmappedUserInputsRequest();
        }
      });
    } else {
      this.modalHeader = "Warning !!";
      this.modalMsg = "Select one intent for mapping";
      this.modalRefInfo = this.modalService.show(this.templateRef, this.configModal);
    }
  }

  openModal(template: TemplateRef<any>, id) {
    let editCategoryForm2 = [];
    if (id == undefined) {
      // for (let key of this.editCategoryForm) {
      //   editCategoryForm2.push('vaId='+key);
      //   this.unmapped_Id=editCategoryForm2;
      //  }
      this.unmapped_Id = this.editCategoryForm;
    } else {
      this.unmapped_Id = id;
    }
    this.modalRef = this.modalService.show(template, this.config2);
  }


  openModals(template2: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template2, this.config);
  }

  openModalTrainInput(templatetrain: TemplateRef<any>) {
    this.modalRefTrainInput = this.modalService.show(templatetrain, this.trainInputconfig);
  }

  trainInputEvent() {
    this.createIntentService.addTrainingPhraseDialogFlow(this.vaLangId, this.vaId)
      .subscribe(res => console.log(res),
        (error: any) => {
          console.log(error);
          let responsetxt = error.error.text;
          console.log("responsetxt ", responsetxt);
          // if (responsetxt == 'Trained') {
          //   this.toastr.success('', "Training is Scheduled", this.toastrConfig);
          //}
          if (responsetxt == 'Training in Progress') {
            this.toastr.warning('', "Training in Progress", this.toastrConfig);
          }
          // else {
          //   this.toastr.error('', "Error While scheduling! Try agian later", this.toastrConfig);
          // }
        });
    //this.toastr.success('', "Training is Scheduled", this.toastrConfig);
    this.modalRefTrainInput.hide();
  }

  showContent(value, checkboxId) {
    //this.phraseSelected = false;

    console.log('intentListData --> ', this.intentListData, value.intentId);
    if (this.selectedIntentId === value.intentId) {
      console.log('Intent already thr');
    } else {
      this.clearunmapIntentSlotsData();
      this.displaySlotsList();
      this.selectedIntentName = []; this.selectedIntentId = '';
      if (value.intentId != null) {
        try {
          console.log('-- ', value.intentId);
          this.intentListData.forEach(e => {
            if (e.id === value.intentId) {
              this.selectedIntentName = e.value;
              this.selectedIntentId = e.id;
              throw this.BreakException;
            }
          });
        } catch (e) {
          this.displaySlotsList();
          if (e !== this.BreakException) throw e;
        }
      } else {
        this.intentSlotColorList = [];
      }
    }
    this.setupPhraseData(value, checkboxId);
  }

  clearunmapIntentSlotsData() {
    if (this.unmapObjectIndex.size > 0) {
      for (let key of this.unmapObjectIndex.keys()) {
        this.unmapObjectIndex.get(key).intentslots = {};
        this.unmapObjectIndex.get(key).value = this.unmapObjectIndex.get(key).mappedData.displayValue;
        this.coloringPhrase(this.unmapObjectIndex.get(key));
      }
    }
  }

  setupPhraseData(value, checkboxId) {
    if (!this.unmapObjectIndex.has(checkboxId)) {
      let phraseObj = JSON.parse(JSON.stringify(value));
      console.log('----phraseObj---> ', phraseObj, '---> ', isEmptyObj(phraseObj));
      isEmptyObj(phraseObj['intentslots']) ? '' : phraseObj['value'] = this.coloringPhrase(phraseObj);
      this.unmapObjectIndex.set(checkboxId, phraseObj);
      this.showBestResponseTab(checkboxId,false);
    } else {
      this.unmapObjectIndex.delete(checkboxId);
    }
    console.log('showContent --> ', checkboxId, this.unmapObjectIndex, this.unmapObjectIndex.size);
  }

  //code to create new Intent
  createNewIntent() {
    this.created = true;
    this.spinner.show();
    var body = {
      intentDescription: this.createFormGroup.value.description,
      intentName: this.createFormGroup.value.name,
      isIntentLive: false,
      intentType: this.createFormGroup.value.intentType
    };
    console.log(body);
    this.trainingService.createIntent(body, this.VA_id).subscribe(res => {
      console.log(res);
      if (res['intent'] != null) {
        this.showPopup("Info", "Intent is created successfully");
      } else {
        this.showPopup("Error", res['errorBody'].summary);
      }
      this.searchIntentFunc();
      this.spinner.hide();
      //this.toastr.success('', "Intent is created successfully")
    }, err => {
      this.showPopup("Error", "Intent is not created");
      this.spinner.hide();
      //this.toastr.error('', "Intent is not created")
    });
    this.createFormGroup.reset();
  }

  checkEmpty(txt: string) {
    return (this.selectedIntentId != undefined && this.selectedIntentId != '') ? true : false;
  }

  public renderRectangles(event: TextSelectEvent, key: string): void {

    console.group("Text Select Event");
    console.log("Event:", event);
    console.log("Text:", event.text);
    console.log("start:", event.posStart);
    console.log("end:", event.posEnd);
    console.log("Viewport Rectangle:", event.viewportRectangle);
    console.log("Host Rectangle:", event.hostRectangle);
    console.groupEnd();

    // If a new selection has been created, the viewport and host rectangles will
    // exist. Or, if a selection is being removed, the rectangles will be null.
    if (event.hostRectangle) {
      this.hostRectangle = event.viewportRectangle;
      this.selectedPharseKey = key;
      this.selectedText = event.text;
      this.posStart = event.posStart;
      this.posEnd = event.posEnd;
      this.posStart = this.checkForFirstSpace() ? this.posStart = (this.posStart + 1) : this.posStart;
      this.showIntentSlotsDropdown();
    } else {
      this.clearHostRectangle();
    }
  }

  clearHostRectangle = () => {
    this.hostRectangle = null;
    this.selectedText = "";
    this.selectedPharseKey = "";
  }

  checkForFirstSpace = () => this.selectedText.search(/^\S.*$/) === -1;

  showIntentSlotsDropdown() {
    let currentWords = this.selectedText.replace(/^\s+/, '').replace(/\s+$/, '');
    if (this.checkEmpty(this.selectedIntentId) && this.checkEmpty(currentWords)) {
      let displayedtext;
      let regex;
      let isCurrectWords;
      if (this.unmapObjectIndex.get(this.selectedPharseKey) !== undefined) {
        displayedtext = this.unmapObjectIndex.get(this.selectedPharseKey).mappedData.displayValue; //TODO BG
        regex = new RegExp("\\b(" + currentWords + ")\\b");
        isCurrectWords = displayedtext.search(regex);
      }
      console.log('$$$$ ', displayedtext, '---', currentWords, '---', isCurrectWords);
      this.currentSelectedtxt = currentWords;
      if (isCurrectWords > -1) {
        this.openSlotsDropdown();
      } else {
        this.dropdownError = 'Select proper words';
        this.intentSlotList = [];
      }
    } else {
      this.clearHostRectangle();
    }
  }

  openSlotsDropdown() {
    this.dropdownError = 'Choose an Intent slot';
    this.intentSlotList = [];
    this.pushIntentSlots(this.intentSlotList);
    if (this.selectedIntentName.length == 0) {
      this.intentSlotList = [];
    }
  }

  pushIntentSlots(slotsList) {
    for (let k = 0; k < this.response.length; k++) {
      if (this.response[k]['intent'].value == this.selectedIntentName) {
        for (let i = 0; i < this.response[k]['intentSlots'].length; i++) {
          let slot = this.response[k]['intentSlots'][i];
          slot['color'] = chooseColorClassByLastDigit(i);
          slotsList.push(slot);
        }
      }
    }
    console.log(slotsList);
  }

  displaySlotsList() {
    this.intentSlotColorList = [];
    this.pushIntentSlots(this.intentSlotColorList);
  }

  // saveUnmappedUserBtn() {
  //   //this.unmapObjectIndex.get(this.selectedPharseKey)
  //   if (this.unmapObjectIndex.size > 0 && this.selectedIntentId != undefined && this.selectedIntentId != '') {
  //     this.saveUnmappedUserInputsRequest();
  //   } else {
  //     this.modalHeader = "Warning !!";
  //     this.modalMsg = "Select atleat one user input";
  //     this.modalRefInfo = this.modalService.show(this.templateRef, this.configModal);
  //   }
  // }

  saveUnmappedUserInputsRequest() {
    this.spinner.show();
    let q = cloneDeep(this.unmapObjectIndex);
    console.log('q ------> ', q, this.unmapObjectIndex);
    let sendData = [];
    for (let key of q.keys()) {
      console.log("On save datat key ----> ", q.get(key));
      q.get(key)['intentId'] = this.selectedIntentId;              //Lokesh Raj John
      //delete q.get(key)['mappedData'];
      sendData.push(q.get(key));
    }

    console.log('sendData -->', q);

    this.trainingService.saveUnmappedInputs(sendData).subscribe(res => {
      console.log(res, sendData);
      if (res['errorBody'] != null) {
        this.showPopup("Error", res['errorBody'].summary);
      } else {
        this.clearAssistedTrainingtags();
        this.showPopup("Info", "Intent is mapped successfully");
        this.serviceCallUnmappedInputs(this.channel_Id, this.fromDate, this.language_id, this.pageNumber, this.sortByDesc, this.toDate, this.VA_id, this.searchText);
      }
    }, err => {
      this.showPopup("Error", "Intent is not mapped ,Internal Error");
      console.error(err);
      this.spinner.hide();
    });

    this.selectedValue = []; this.selectedIntentName = []; this.selectedIntents = [];
  }

  getPOSTIONoftxt(txtary: any, mappedHighlightData: any) {
    console.log(txtary, mappedHighlightData);
    let posAry = [];
    let pos = 'pos' + this.posStart++;
    posAry.push(pos);
    while (this.posStart <= this.posEnd) {
      let i = this.posStart++
      posAry.push('pos' + i);
      pos += '~pos' + i;
    }
    let posdata = { 'posAry': posAry, 'pos': pos }
    return posdata;
  }

  getIntentSlotValue(x) {
    console.log('========> ', x, this.currentSelectedtxt, this.selectedPharseKey);
    let phraseObj = this.unmapObjectIndex.get(this.selectedPharseKey);
    console.log('========> phraseObj ', phraseObj);
    let txtary = this.currentSelectedtxt.split(" ");
    let posData = this.getPOSTIONoftxt(txtary, phraseObj.mappedData.mappedHighlightData);
    console.log("getPOSTIONoftxt -->", posData.pos);

    for (var i in posData.posAry) {
      var regex = new RegExp("\\b(" + posData.posAry[i] + ")\\b");
      for (var key in phraseObj['intentslots']) {
        if (key.search(regex) >= 0) {
          delete phraseObj['intentslots'][key];
          break;
        }
      }
    }

    phraseObj['intentId'] = this.selectedIntentId;
    phraseObj['intentslots'][posData.pos] = {
      "intentSlot": {
        "id": x.id,
        "value": x.value
      },
      "value": this.currentSelectedtxt
    }
    phraseObj['value'] = phraseObj['mappedData']['displayValue'];
    phraseObj['value'] = this.coloringPhrase(phraseObj);

    this.unmapObjectIndex.set(this.selectedPharseKey, phraseObj);
    console.log("this.unmapObjectIndex ", this.unmapObjectIndex);

    // Clearing all selection text and data 
    document.getSelection().removeAllRanges();
    this.clearHostRectangle();
  }
  coloringPhrase(o) {
    let outputColorArray = [].concat(...this.colorArrayGenrater(o['intentslots']));
    console.log('outputColorArray ------------> ', outputColorArray);
    return this.colorDisplayTextAndGenrateInnerPhase(o, outputColorArray);
  }

  colorArrayGenrater(intentslots) {
    let colorArray = []
    for (var key of Object.keys(intentslots)) {
      console.log(key, key.length, " -> " + JSON.stringify(intentslots[key]))
      colorArray.push(key.split('~'));
    }
    return colorArray;
  }

  getColorStylebyIntentID = (id: number) => {
    let c = getObjById(this.intentSlotColorList, id);
    console.log('---> ', id, c);
    return c[0]['color'];
  }

  colorDisplayTextAndGenrateInnerPhase(o, outputColorArray) {
    let innerPhase = '', dontAdd: boolean = false, rxp = /%[ /]%/g;
    let mappedHighlightData = o['mappedData']['mappedHighlightData']
    for (let i in o['mappedData']['mappedHighlightData']) {
      mappedHighlightData[i]['isHighlight'] = false;
      for (let j in outputColorArray) {
        console.log(mappedHighlightData[i]['key'], outputColorArray[j])
        if (mappedHighlightData[i]['key'] === outputColorArray[j]) {
          console.log('----intentslots------> ', o['intentslots'][outputColorArray[j]]['intentSlot']);
          mappedHighlightData[i]['isHighlight'] = true;
          mappedHighlightData[i]['colorClass'] = this.getColorStylebyIntentID(o['intentslots'][outputColorArray[j]]['intentSlot']['id']);
          innerPhase += '%' + mappedHighlightData[i]['key'] + '% ';
          dontAdd = false;
          break;
        } else {
          dontAdd = true;
        }
      }
      dontAdd ? innerPhase += mappedHighlightData[i]['value'] + ' ' : '';
    }
    //.replace(rxp, '~') moved out of bug -- BG
    innerPhase = innerPhase.replace(/^\s+/, '').replace(/\s+$/, '');
    innerPhase == '' ? innerPhase = o['mappedData']['displayValue'] : '';
    return innerPhase;
  }

  preventClose(event: MouseEvent) {
    event.stopImmediatePropagation();
  }

  intentChanged(value) {
    console.log('selectedInten --> ', value, this.unmapObjectIndex);
    this.selectedIntentName = value.value;
    this.selectedIntentId = value.id;
    this.clearunmapIntentSlotsData();
    console.log('unmap status', this.unmapObjectIndex);
    this.displaySlotsList();
  }

  showPopup(title: string, msg: string) {
    this.modalHeader = title;
    this.modalMsg = msg;
    this.modalRefInfo = this.modalService.show(this.templateRef, this.configModal);
  }

  onScroll() {
    console.log("scroll --->");
    this.showloader = true;
    this.counter += 1;
    this.trainingService.getIntents(this.channel_Id, this.fromDate, this.language_id, this.counter, this.sortByDesc, this.toDate, this.VA_id, this.searchText).subscribe((res: any[]) => {
      let conversationSession = res['conversationList'];
      for (let k = 0; k < conversationSession.length; k++) {
        this.conversationListProcess(conversationSession[k]['sessionId'], conversationSession[k]);
      }
      this.showloader = false;
    },
      err => { this.spinner.hide(); console.error(err); }
    );
  }

  clearPhaseData() {
    let checkboxId = 'c-m-' + this.clearSessionId + '-' + this.clearId;
    //let arrayindex = this.unmapObjectIndex.get(checkboxId);
    //arrayindex > -1 ? this.unmapArray.splice(arrayindex, 1) : '';
    this.unmapObjectIndex.delete(checkboxId);
    this.allInputs[this.clearSessionId][this.clearPhraseType].forEach(e => {
      e.id = this.clearId ? e['isSelected'] = false : '';
    });
    this.modalRef.hide();
  }

  clearIntentSlot(id, session, phraseType) {
    let checkboxId = 'c-m-' + session + '-' + id;
    let phraseObj = this.unmapObjectIndex.get(checkboxId);
    console.log('dt', phraseObj);
    phraseObj['intentslots'] = {};
    phraseObj['value'] = phraseObj['mappedData']['displayValue'];
    phraseObj['value'] = this.coloringPhrase(phraseObj);
    this.unmapObjectIndex.set(checkboxId, phraseObj);
    console.log('rfv --->', this.unmapObjectIndex.get(checkboxId));
  }

  ideaIntent(id, session, phraseType) {
    let checkboxId = 'c-m-' + session + '-' + id;
    this.showBestResponseTab(checkboxId,true);
  }

  showBestResponseTab(id,isIdea) {
    if (this.unmapObjectIndex.size === 1 || isIdea) {
      let phraseObj = this.unmapObjectIndex.get(id);
      if (phraseObj['nextBestPredictions'].length > 0) {
        console.log('nextBestPredictions ', phraseObj['nextBestPredictions']);
        this.checkIfIntentThr(phraseObj['nextBestPredictions']);
        this.bestResponseSlots.length > 0 ? this.ifbestResponseIntent = true : '';
      } else {
        this.bestResponseSlots = [];
        this.ifbestResponseIntent = false;
      }
    } else {
      this.bestResponseSlots = [];
      this.ifbestResponseIntent = false;
    }
  }

  checkIfIntentThr(p) {
    for (let x in p) {
      for (let v in this.intentListData) {
        if (this.intentListData[v]['value'].toLowerCase() === p[x]['intentName'].toLowerCase()) {
          this.bestResponseSlots.push(p[x]);
        }
      }
    }
  }

  setIntent(slot) {
    console.log('Slot choosen ', slot);
    this.clearunmapIntentSlotsData();
    this.displaySlotsList();
    this.selectedIntentName = []; this.selectedIntentId = '';
    try {
      this.intentListData.forEach(e => {
        console.log(e.value.toLowerCase() === slot.intentName.toLowerCase(), e.value.toLowerCase() , slot.intentName.toLowerCase());
        if (e.value.toLowerCase() === slot.intentName.toLowerCase()) {
          this.selectedIntentName = e.value;
          this.selectedIntentId = e.id;
          throw this.BreakException;
        }
      });
    } catch (e) {
      this.displaySlotsList();
      if (e !== this.BreakException) throw e;
    }
  }

}

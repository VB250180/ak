import { RouterModule, Routes } from '@angular/router';
import { AssistedTrainingComponent } from './assisted-training.component';
import { NgModule } from '@angular/core';

const routes: Routes = [
  { path: 'training/:id/:name/:desc/:channel/:lang/:chId/:langId', component: AssistedTrainingComponent }
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AssistedTrainingRoutingModule { }
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-best-response',
  templateUrl: './best-response.component.html',
  styleUrls: ['./best-response.component.scss']
})
export class BestResponseComponent implements OnInit {
  @Input() slotName;
  @Input() index;
  slots: any;

  constructor() { }

  ngOnInit() {
    this.slotName.confidence = Math.round(this.slotName.confidence)
    this.slots = this.slotName;
    //console.log('live',this.slots,this.slotName);
  }
}

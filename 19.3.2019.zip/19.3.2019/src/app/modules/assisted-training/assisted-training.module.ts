import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AssistedTrainingRoutingModule } from './assisted-training-routing.module';
import { AssistedTrainingComponent } from './assisted-training.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { NgSelectModule } from '@ng-select/ng-select';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import {SharedModule} from '../../shared.module';
import { BestResponseComponent } from './bestResponse/best-response.component';

@NgModule({
    imports: [
        CommonModule,
        AssistedTrainingRoutingModule,
        FormsModule,
        ReactiveFormsModule,
        NgxSpinnerModule,
        AccordionModule,
        InfiniteScrollModule,
        NgMultiSelectDropDownModule.forRoot(),
        NgxDaterangepickerMd.forRoot(),
        NgSelectModule,
        ScrollingModule,
        BsDropdownModule,
        SharedModule
    ],
    declarations: [AssistedTrainingComponent, BestResponseComponent]
})
export class AssistedTrainingtModule { }
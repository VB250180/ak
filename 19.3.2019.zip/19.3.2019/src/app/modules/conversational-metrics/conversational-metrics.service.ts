import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
// import { catchError, map, tap, delay,filter,scan } from 'rxjs/operators';
import { environment as env } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ConversationalMetricsService {

  constructor(private http: HttpClient) { };

  public getliveData(mode,va,channel, language ): Observable<any> {
  
    return this.http.get<any>(env.nodeapiUrl + '/api/realmetrics?period=' + mode + '&va=' + va + "&channel=" +channel +'&language='+language +'&view='+ 'graph');
    // return this.http.get('../../assets/va.json');
  }

}



import { Component, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { ConversationalMetricsService } from '../conversational-metrics.service';
import { getCurrentUserId } from '../../../../app/core/utils/akeira-utils';
import { IntentService } from '../../../../components/intent-listing/intent.service';
import { FormControl, FormGroup, ReactiveFormsModule, FormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";


@Component({
  selector: 'app-metrics',
  templateUrl: './live-metrics.component.html',
  styleUrls: ['./live-metrics.component.scss']
})
export class LiveMetricsComponent {
  intentFilter: any = {
    va: 0,
    channel: 0,
    language: 0
  }
  userId: number = 0;
  channel: any = [];
  language: any = [];
  channelList: Array<any>;
  languageList: Array<any>;
  IntentListingForm: FormGroup;
  channels: any = [];
  languages: any = [];
  PageNo: number = 1;
  vaById: any = {};
  vaLists: any = [];
  loaded: boolean = false;
  counter: number = 1;
  len: number;
  intentListResponse: any = [];
  vaName: any;
  vaId: any;
  vaDesc: any;
  vaChan: any;
  vaLang: any;
  vaChanId: any;
  vaLangId: any;
  todayTab: boolean = false;
  weekTab: boolean = false;
  monthTab: boolean = true;
  customTab: boolean = false;
  liveSessions : any;
  liveAccuracy : any;
  averageSession : any;

  totalProgress : any;
  progress : any;
  public doughnutChart1Options: any = {
    cutoutPercentage: 90,
    elements: {
      arc: {
        borderWidth:0
      }
    },
    tooltips: {
      enabled: false
    }
  };

  public pieChart2Colors = [
    {
      backgroundColor: ['#57AB57', '#ccc'],
    },
  ];

  top10Intents =[];

  verticalbar_view: any[] = [1200, 200];

  showXAxis = true;
  showYAxis = true;
  gradient = false;
  showLegend = false;
  showXAxisLabel = true;
  xAxisLabel = 'Intents';
  showYAxisLabel = true;
  yAxisLabel = 'Count';

  colorScheme = {
    domain: ['#5AA454', '#A10A28', '#C7B42C', '#5AA454', '#A10A28', '#C7B42C', '#5AA454', '#A10A28', '#C7B42C', '#C7B42C', '#AAAAAA']
  };

  constructor(private intentService: IntentService, private reportService: ConversationalMetricsService, private router: Router, private activatedRoute: ActivatedRoute, private spinner: NgxSpinnerService) {
    this.userId = getCurrentUserId();
    this.IntentListingForm = new FormGroup({
      va: new FormControl(null, Validators.required),
      channel: new FormControl(null, Validators.required),
      language: new FormControl(null, Validators.required),

    })

  }

  onSelect(t){}

  ngOnInit() {
    // this.spinner.show();
    this.activatedRoute.paramMap.subscribe(params => {
      console.log('params', params);
      this.vaName = params.get('name');
      this.vaId = params.get('id');
      this.vaDesc = params.get('desc');
      this.vaChan = params.get('channel');
      this.vaLang = params.get('lang');
      this.vaChanId = params.get('chId');
      this.vaLangId = params.get('langId');
    });
    this.getdropdownValues();
    this.aTab('MTD')
    this.getReportData('live',0,0,0);
    console.log(this.intentFilter)

  }

  getReportData(modeval, vadata,chnldata,langdata) {
     this.spinner.show();
    console.log(this.intentFilter)
    let va = vadata;
    let chnl = chnldata;
    let lang = langdata;
    let mode = modeval;
    

    this.reportService.getliveData(mode,va, chnl, lang).subscribe((res: any) => {
      this.spinner.hide();
      console.log(res)
      this.liveSessions = res['data']['livesessioncount'];
      this.liveAccuracy = res['data']['liveaccuracyoercent'];
      this.averageSession = res['data']['averagesessionTime'];
    this.top10Intents = res['data']['topintents'];
    },
      err => console.error(err));

  }

  getdropdownValues() {
    this.intentService.getInputs(this.userId).subscribe((res: any) => {
      this.vaLists = res.virtualAgentRoleMaps;
      for (let i = 0; i < res['virtualAgentRoleMaps'].length; i++) {
        this.vaById[res['virtualAgentRoleMaps'][i].vrmId] = res['virtualAgentRoleMaps'][i];
      }
      console.log(this.vaById);
      setTimeout(() => {
        this.callIntentListByparam();
      }, 1000);

    }, (err: any) => { console.error('Error In Intent Listinbg dropdown'); console.error(err) });
  }

  callIntentListByparam() {
    this.spinner.hide();
    if (this.vaId) {
      this.intentFilter.va = +this.vaId, this.intentFilter.channel = +this.vaChanId, this.intentFilter.language = +this.vaLangId;
      this.channels.push(this.vaById[this.intentFilter.va].channels);
      console.log("channels",this.channels);
      this.languages.push(this.vaById[this.intentFilter.va].languages);
      console.log("channels",this.languages)
      this.statusFilter(this.intentFilter.va, false);


    } else {
      console.log("--------------> ")
      this.intentFilter.va = 0, this.intentFilter.channel = 0, this.intentFilter.language = 0;
    }
  }

  statusFilter(status: string | number, isRequestNeeded: boolean) {
    console.log('On va change --> ', status, isRequestNeeded);
    console.log(this.intentFilter);
    if (status == 0) {
      this.intentFilter.va = status, this.intentFilter.channel = 0, this.intentFilter.language = 0;
      this.languages = [], this.channels = [];
      this.IntentListingForm.patchValue({ channel: 0, language: 0 });

    } else {
      this.languages = this.vaById[status].languages;
      this.channels = this.vaById[status].channels;
    }

    if (isRequestNeeded) {
      this.intentFilter.va = status, this.intentFilter.channel = 0, this.intentFilter.language = 0;
      this.IntentListingForm.patchValue({
        channel: this.intentFilter.channel,
        language: this.intentFilter.language,
      });

    }
    this.getReportData('live',this.intentFilter.va,this.intentFilter.channel,this.intentFilter.language);
  }

  channelFilter(channel: { id: any; }) {
    console.log('channelFilter ====> ', channel);
    this.intentFilter.channel = channel;
    this.getReportData('live',this.intentFilter.va,this.intentFilter.channel,this.intentFilter.language);

  }

  languageFilter(language: { id: any; }) {
    console.log(' languageFilter ====> ', language);
    this.intentFilter.language = language;
    this.getReportData('live',this.intentFilter.va,this.intentFilter.channel,this.intentFilter.language);
  }

  aTab(data) {
    console.log(data)
    if (data == 'Today') {
      this.todayTab = true;
      this.weekTab = false;
      this.monthTab = false;
      this.customTab = false;
    }
    else if (data == 'WTD') {
      this.todayTab = false;
      this.weekTab = true;
      this.monthTab = false;
      this.customTab = false;
    }

    else if (data == 'MTD') {
      this.todayTab = false;
      this.weekTab = false;
      this.monthTab = true;
      this.customTab = false;
    }

    else if (data == 'customDate') {
      this.todayTab = false;
      this.weekTab = false;
      this.monthTab = false;
      this.customTab = true;
    }


  }





}
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LiveMetricsComponent } from './live-metrics/live-metrics.component';
const routes: Routes = [
  { path: 'live-metrics', component: LiveMetricsComponent },
  
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConversationalMetricsRoutingModule { }
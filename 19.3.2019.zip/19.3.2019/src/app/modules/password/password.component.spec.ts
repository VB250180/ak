import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PasswordComponent } from './password.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, Component, TemplateRef } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable, BehaviorSubject } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialogConfig, MatDialog, MatDialogModule } from '@angular/material';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';

class passwordServiceStub{
  constructor(){}

  public resetPassword({skandha,skandha1,skandha2}) {
    if (name === 'skandha') {
      return Observable.of({
        loginPojo: {
          userId: 0,
          username: "skandha",
          email: "string",
          phoneNumber: "string",
          jwToken: "string",
          password: skandha,
          newPassword: skandha1,
          confirmPassword: skandha2,
          roleId: 0,
          roleName: "string"
        }, errorBody: null
      })
    } else {
      return Observable.of({
        loginPojo: null,
        errorBody: {
          code: "1405",
          summary: "Please use new password which wasn't used earlier"
        }
      })
    }
  }

}

fdescribe('PasswordComponent', () => {
  let component: PasswordComponent;
  let fixture: ComponentFixture<PasswordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PasswordComponent ],
      imports: [FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
        RouterTestingModule,
        MatDialogModule,
      ],
      providers: [
        { provide: AuthenticationService, useClass: passwordServiceStub }],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call ngOninint', () => {
    component.ngOnInit();
  });

  it('should call createResetPasswordForm', () => {
    component.createResetPasswordForm();
  });

  
  it('should call close reset form', () => {
    component.resetClose();
  });

  
  it('should call close reset success', () => {
    component.resetpasswordonsuccess = false;
    component.ResetSucess();
  });

  it('on click of cancel ,testcase', () => {
    component.Cancel();
  });

  it('on method logout call after successful reset of password' , () =>{
   const router = TestBed.get(Router);
   const spy = spyOn(router, 'navigate');

   component.logout();
   expect(spy).toHaveBeenCalledWith(['/login']); 
  });
});

import { BehaviorSubject } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment as env } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ConversationPacksService {

  cpData = new BehaviorSubject<any>({});

  constructor(private http: HttpClient) { }

  getConvesationPacks(data) {
    console.log('data', data);
    let params = new HttpParams();
    params = params.append('channelId', data.channels);
    params = params.append('langId', data.languages);
    params = params.append('pageNumber', data.pageNo);
    // params = params.append('cpName', data.cpName);
    let response1;
    return this.http.get(env.apiUrl + '/conversationalPackListing', {params: params});
  }

  getSubscription() {
    return this.cpData.asObservable();
  }
}

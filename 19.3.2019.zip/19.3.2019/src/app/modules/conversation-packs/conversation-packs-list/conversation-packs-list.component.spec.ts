import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConversationPacksListComponent } from './conversation-packs-list.component';

describe('ConversationPacksListComponent', () => {
  let component: ConversationPacksListComponent;
  let fixture: ComponentFixture<ConversationPacksListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConversationPacksListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConversationPacksListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

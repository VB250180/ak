import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ConversationPacksService } from '../conversation-packs.service';

@Component({
  selector: 'app-conversation-packs-list',
  templateUrl: './conversation-packs-list.component.html',
  styleUrls: ['./conversation-packs-list.component.scss']
})
export class ConversationPacksListComponent implements OnInit {

  conversationPackSearchForm: FormGroup;
  @Input() conversationPacksList;
  @Input() vaDetails;
  @Output() scrolledToEnd = new EventEmitter();
  @Output() conversationPackSelected = new EventEmitter();
  pageNo = 0;
  constructor(private conversationPacksService: ConversationPacksService) { }

  iii = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];

  ngOnInit() {
    this.conversationPackSearchForm = new FormGroup({
      search: new FormControl('')
    });
  }

  onScroll() {
    console.log('on scroll triggered.....');
    this.pageNo += 1;
    const data ={
      channels: Object.values(this.vaDetails.vaChannels),
      languages: Object.values(this.vaDetails.vaLanguages),
      cpName: this.vaDetails,
      pageNo: this.pageNo
    };
    this.scrolledToEnd.emit(this.pageNo);
  }

  onConversationPackSelected(conversationPack) {
    console.log('pack selected', conversationPack);
    this.conversationPackSelected.emit(conversationPack['intents']);
  }

}

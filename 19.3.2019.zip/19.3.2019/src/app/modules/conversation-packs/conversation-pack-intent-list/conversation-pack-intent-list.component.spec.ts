import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConversationPackIntentListComponent } from './conversation-pack-intent-list.component';

describe('ConversationPackIntentListComponent', () => {
  let component: ConversationPackIntentListComponent;
  let fixture: ComponentFixture<ConversationPackIntentListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConversationPackIntentListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConversationPackIntentListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

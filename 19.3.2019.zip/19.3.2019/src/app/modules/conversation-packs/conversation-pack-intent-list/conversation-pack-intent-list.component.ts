import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';
import { MatDialogConfig, MatDialog } from '@angular/material';

@Component({
  selector: 'app-conversation-pack-intent-list',
  templateUrl: './conversation-pack-intent-list.component.html',
  styleUrls: ['./conversation-pack-intent-list.component.scss']
})
export class ConversationPackIntentListComponent implements OnInit {

  conversationPackSearchForm: FormGroup;
  intentListForm: FormGroup;
  showImportSelectedBtn = false;
  selectedVA;
  intentListResponse = [];
  @Input() intentList;
  iii = [1, 2];


  constructor(private matDialog: MatDialog) { }

  ngOnInit() {
    console.log('intentList', this.intentList);
    this.conversationPackSearchForm = new FormGroup({
      search: new FormControl('')
    });
    this.intentListForm = new FormGroup({
      selectAll: new FormControl(null)
    });
    
    this.tableDataGen();
  }

  tableDataGen() {
    let count = 0;
    for (let i = 0; i < this.intentList.length; i++) {
      let intent = this.intentList[i];
      for (let j = 0; j < intent.languages.length; j++) {
        let lang = intent.languages[j];
        let pushdata = {
          id: count++,
          intentId: intent.cp_intentId,
          intentName: intent.intentName,
          // 'vaId': intent.virtualAgent.vaId,
          // 'vaName': intent.virtualAgent.vaName,
          // 'vaIsLive': intent.virtualAgent.vaIsLive,
          // 'vaAvatarName': intent.virtualAgent.vaAvatarName,
          // 'businessUnit': intent.businessUnit,
          // 'langEngId': lang.langEngId,
          langName: lang.language.langName,
          channels: lang.channels,
          channelsStatus: '',
          icmIds: []
        };

        this.intentListResponse.push(pushdata);
      }

    }
    console.log('intentListResponse', this.intentListResponse);

    this.intentListResponse.forEach(intent => {
      this.intentListForm.addControl(intent.id, new FormControl());
    });
  }

  onSelectAllClicked(event) {
    if (event.target.checked) {
      this.showImportSelectedBtn = true;
      Object.keys(this.intentListForm.controls).forEach(control => {
        this.intentListForm.get(control).setValue(true);
      });
    } else {
      this.showImportSelectedBtn = false;
      Object.keys(this.intentListForm.controls).forEach(control => {
        this.intentListForm.get(control).setValue(false);
      });
    }
    console.log('event', this.intentListForm.controls, event.target.value);
  }

  onSelectOrDeSelect(event, controlName) {
    console.log(controlName);
    if (event.target.checked) {
      this.intentListForm.controls[controlName].setValue(true);
      this.showImportSelectedBtn = true;
      let flag = false;
      Object.keys(this.intentListForm.controls).forEach(control => {
        // console.log('control',control, this.intentListForm.get(control).value);
        if (this.intentListForm.get(control).value || control == 'selectAll') {
          this.showImportSelectedBtn = true;
        } else {
          flag = true;
        }
      });
      if (!flag) {
        this.intentListForm.controls['selectAll'].setValue(true);

      }
    } else {
      let flag = false;
      this.intentListForm.controls[controlName].setValue(false);
      this.intentListForm.controls['selectAll'].setValue(false);
      Object.keys(this.intentListForm.controls).forEach(control => {
        if (this.intentListForm.get(control).value) {
          this.showImportSelectedBtn = true;
          flag = true;
        }
      });
      if (!flag) {
        this.showImportSelectedBtn = false;
      }
    }

    console.log('checkbox', this.intentListForm.controls,    this.intentList );
    // Object.keys(this.intentListForm.controls).forEach(control => {
    //   if (this.intentListForm.get(control).value == true) {
    //     var res = control.substring(6);
    //     console.log('checkbox ++', this.intentListForm.get(control).value,control,res);
    //   }
    // });
  }

  importSelected(){
    console.log('import selected');
    const dialogConfigImport = new MatDialogConfig();
    dialogConfigImport.disableClose = true;
    dialogConfigImport.width = "800px";
    dialogConfigImport.data = {
      showDuplicatedText: "These are the intents that you have chosen to import duplicated",
      hasPrimaryBtn: true,
      primaryBtnText: 'Done',
      popUpType: 'importduplicated',
      hasCancelBtn: true,
      secondaryBtnText: 'Cancel',
      importedDetails:[1,2]
      //suggestedText:'Intent1 , Intent2, Intent3'
    }

    const modalDialog = this.matDialog.open(ModalComponent, dialogConfigImport);
      modalDialog.afterClosed().subscribe(data => {
        console.log('import',data);
        data == true ? this.openOtherModal() : ''
      });
  }

  openOtherModal(){
    const dialogConfigImport = new MatDialogConfig();
    dialogConfigImport.disableClose = true;
    dialogConfigImport.width = "800px";
    dialogConfigImport.data = {
      primaryText: "Please wait while we import your intents",
      hasPrimaryBtn: true,
      primaryBtnText: 'Ok',
      popUpType: 'import',
      //hasCancelBtn: true,
      //secondaryBtnText: 'Cancel',
    }

    const modalDialog = this.matDialog.open(ModalComponent, dialogConfigImport);
      modalDialog.afterClosed().subscribe(data => {
        console.log('import',data);
      //  data == true ? this.openOtherModal() : ''
      });
  }

}

import { TestBed } from '@angular/core/testing';

import { ConversationPacksService } from './conversation-packs.service';

describe('ConversationPacksService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ConversationPacksService = TestBed.get(ConversationPacksService);
    expect(service).toBeTruthy();
  });
});

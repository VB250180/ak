import { VirtualDetailsService } from './../../../shared/services/va-details/virtual-agent-details.service';
import { Component, OnInit, Output, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
    selector: 'app-conversation-header',
    templateUrl: './conversation-packs-header.component.html',
    styleUrls: ['./conversation-packs-header.component.scss']
})
export class ConversationPacksHeaderComponent implements OnInit {

    conversationPacksForm: FormGroup;
    isVASelected = false;
    @Output() initialSettingsDone = new EventEmitter();
    selectedVAAgent;
    channels = [];
    languages = [];


    channelDropdownSettings = {
        singleSelection: false,
        idField: 'channelId',
        textField: 'channelName',
        enableCheckAll: true,
        selectAllText: 'All',
        unSelectAllText: 'Unselect All',
        allowSearchFilter: false,
        limitSelection: -1,
        clearSearchFilter: true,
        maxHeight: 197,
        itemsShowLimit: 1,
        // noDataAvailablePlaceholderText: 'No data available',
        // closeDropDownOnSelection: true,
        showSelectedItemsAtTop: false,
        defaultOpen: false
    };

    langDropdownSettings = {
        singleSelection: false,
        idField: 'langEngId',
        textField: 'langName',
        enableCheckAll: true,
        selectAllText: 'All',
        unSelectAllText: 'Unselect All',
        allowSearchFilter: false,
        limitSelection: -1,
        clearSearchFilter: true,
        maxHeight: 197,
        itemsShowLimit: 1,
        // noDataAvailablePlaceholderText: 'No data available',
        // closeDropDownOnSelection: true,
        showSelectedItemsAtTop: false,
        defaultOpen: false
    };

    vaDetails = [];

    constructor(private virtualDetailsService: VirtualDetailsService,
        private cd: ChangeDetectorRef) { }

    ngOnInit(): void {
        this.conversationPacksForm = new FormGroup({
            vaAgent: new FormControl('', Validators.required),
            vaChannels: new FormControl('', Validators.required),
            vaLanguages: new FormControl('', Validators.required)
        });
        this.virtualDetailsService.requiredDataLoaded.subscribe(data => {
            if (data) {
                this.virtualDetailsService.getVirtualAgents().forEach(item => {
                    console.log('item', item);
                    item['vaInitials'] = item['vrmName'].substring(0, 1).toUpperCase();
                    this.vaDetails.push(item);
                });
            }
            console.log(this.vaDetails);
            this.cd.detectChanges();
        })

        this.conversationPacksForm.controls['vaAgent'].setValue(null);
        this.conversationPacksForm.controls['vaChannels'].disable();
        this.conversationPacksForm.controls['vaLanguages'].disable();
    }

    onVAAgentSelected(event) {
        console.log(event);
        this.selectedVAAgent = event;
        this.isVASelected = true;
        this.channels = this.virtualDetailsService.getChannelsByVrmId(this.selectedVAAgent.vrmId);
        this.languages = this.virtualDetailsService.getLanguagesByVrmId(this.selectedVAAgent.vrmId);
        console.log('channels', this.channels);
        console.log('langs', this.languages);
        console.log('sadsa', this.conversationPacksForm.controls['vaChannels'].value);
        if (this.conversationPacksForm.controls['vaAgent'].valid) {
            this.conversationPacksForm.controls['vaChannels'].enable();
            this.conversationPacksForm.controls['vaLanguages'].enable();
            this.conversationPacksForm.controls['vaChannels'].reset();
            this.conversationPacksForm.controls['vaLanguages'].reset();
            this.initialSettingsDone.emit(false);
        }
    }

    onSelectAll(event, controlName) {
        console.log(controlName)
        this.conversationPacksForm.controls[controlName].setValue(event);
        console.log('sadsa', this.conversationPacksForm.controls['vaAgent'].value);
        console.log('sadsa', this.conversationPacksForm.controls['vaChannels'].value);
        console.log('sadsa', this.conversationPacksForm.controls['vaLanguages'].value);
        console.log('valid', this.conversationPacksForm.valid);
        if (this.conversationPacksForm.valid) {
            const vaDetails = {
                vaAgent: this.conversationPacksForm.controls['vaAgent'].value,
                vaChannels: this.conversationPacksForm.controls['vaChannels'].value,
                vaLanguages: this.conversationPacksForm.controls['vaLanguages'].value,
            };
            this.initialSettingsDone.emit(vaDetails);
        } else {
            this.initialSettingsDone.emit(false);
        }
    }

    onChannelAndLanguageSelected() {
        console.log('sadsa', this.conversationPacksForm.controls['vaAgent'].value);
        console.log('sadsa', this.conversationPacksForm.controls['vaChannels'].value);
        console.log('sadsa', this.conversationPacksForm.controls['vaLanguages'].value);
        console.log('valid', this.conversationPacksForm.valid);
        if (this.conversationPacksForm.valid) {
            const vaDetails = {
                vaAgent: this.conversationPacksForm.controls['vaAgent'].value,
                vaChannels: this.conversationPacksForm.controls['vaChannels'].value,
                vaLanguages: this.conversationPacksForm.controls['vaLanguages'].value,
            };
            this.initialSettingsDone.emit(vaDetails);
        } else {
            this.initialSettingsDone.emit(false);
        }
    }

}
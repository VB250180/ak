import { VirtualDetailsService } from './../../shared/services/va-details/virtual-agent-details.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Component, OnInit, ViewChild, ElementRef, AfterViewChecked } from '@angular/core';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';
import { ConversationPacksService } from './conversation-packs.service';

@Component({
  selector: 'app-conversation-packs',
  templateUrl: './conversation-packs.component.html',
  styleUrls: ['./conversation-packs.component.scss']
})
export class ConversationPacksComponent implements OnInit {

  showIntentList = false;
  selectedVAAgent;
  conversationPackSearchForm: FormGroup;
  isVASelected = false;
  initialSettingsDone = false;
  selectedVirtualAgent;
  conversationPacksList = [];
  vaDetails;
  pageNo = 1;
  conversationPacksIntentList = [];

  dropdownSettings = {
    singleSelection: false,
    idField: 'name',
    textField: 'name',
    enableCheckAll: true,
    selectAllText: 'All',
    unSelectAllText: 'Unselect All',
    allowSearchFilter: false,
    limitSelection: -1,
    clearSearchFilter: true,
    maxHeight: 197,
    itemsShowLimit: 1,
    // noDataAvailablePlaceholderText: 'No data available',
    // closeDropDownOnSelection: true,
    showSelectedItemsAtTop: false,
    defaultOpen: false
  };

  iii = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
  conversationPacksForm: FormGroup;

  constructor(private matDialog: MatDialog,
    private conversationPacksService: ConversationPacksService,
    private virtualDetailsService: VirtualDetailsService) { }

  ngOnInit() {
    this.conversationPacksForm = new FormGroup({
      vaAgent: new FormControl('', Validators.required),
      vaChannels: new FormControl('', Validators.required),
      vaLanguages: new FormControl('', Validators.required)
    });
    this.conversationPackSearchForm = new FormGroup({
      search: new FormControl('')
    });
    this.conversationPacksForm.controls['vaChannels'].disable();
    this.conversationPacksForm.controls['vaLanguages'].disable();
    this.getConversationPacks();
  }

  onInitialSettingChanged(event) {
    if (event) {
      this.initialSettingsDone = true;
      this.selectedVirtualAgent = event;
      console.log(event);
      this.getConversationPacks();
    } else {
      this.initialSettingsDone = false;
      this.selectedVirtualAgent = undefined;
      console.log(event);
    }
  }

  getConversationPacks() {
    console.log('please come here bro..', this.selectedVirtualAgent);
    let channelList = [];
    let langList = [];
    // this.selectedVirtualAgent.vaChannels.forEach(channel => {
    //   channelList.push(channel.channelId);
    // });
    // this.selectedVirtualAgent.vaLanguages.forEach(lang => {
    //   langList.push(lang.langEngId);
    // });
    const data = {
      // channels: channelList,
      // languages: langList,
      channels: [1, 2, 3],
      languages: [1, 2],
      pageNo: 1,// this.pageNo
    };
    this.conversationPacksService.getConvesationPacks(data).subscribe(response => {
      console.log('hello', response);
      this.conversationPacksList = [...this.conversationPacksList, ...response['conversationPacks']];
      console.log('this.', this.conversationPacksList);
    });
  }

  onScroll(pageNo) {
    console.log(pageNo, 'pageNo');
    this.pageNo = pageNo;
    // this.conversationPacksService.getConvesationPacks(data).subscribe(response => {
    //   console.log('hello', response);
    //   this.conversationPacksList = [...this.conversationPacksList, ...response['conversationPacks']];
    //   console.log('this.', this.conversationPacksList);
    // });
    // this.conversationPacksList = [...this.conversationPacksList, ...this.conversationPacksList];
    this.getConversationPacks();
    console.log(this.conversationPacksList);
  }

  onConversationPackSelected(intents) {
    console.log('intent selected', intents);
    this.showIntentList = true;
    this.conversationPacksIntentList = intents;
  }

  importSelected() {
    console.log('import selected');
    const dialogConfigImport = new MatDialogConfig();
    dialogConfigImport.disableClose = true;
    dialogConfigImport.width = "800px";
    dialogConfigImport.data = {
      primaryText: "These are the intents that you have chosen to import",
      hasPrimaryBtn: true,
      primaryBtnText: 'Ok',
      popUpType: 'save',
      hasCancelBtn: true,
      secondaryBtnText: 'Cancel',
      suggestedText: 'Intent1 , Intent2, Intent3'
    }

    const modalDialog = this.matDialog.open(ModalComponent, dialogConfigImport);
    modalDialog.afterClosed().subscribe(data => {
      console.log('import', data);
      data == true ? this.openOtherModal() : ''
    });
  }

  openOtherModal() {
    const dialogConfigImport = new MatDialogConfig();
    dialogConfigImport.disableClose = true;
    dialogConfigImport.width = "800px";
    dialogConfigImport.data = {
      primaryText: "Please wait while we import your intents",
      hasPrimaryBtn: true,
      primaryBtnText: 'Ok',
      // popUpType: 'save',
      // hasCancelBtn: true,
      // secondaryBtnText: 'Cancel',
    }

    const modalDialog = this.matDialog.open(ModalComponent, dialogConfigImport);
    modalDialog.afterClosed().subscribe(data => {
      console.log('import', data);
      //  data == true ? this.openOtherModal() : ''
    });
  }

}

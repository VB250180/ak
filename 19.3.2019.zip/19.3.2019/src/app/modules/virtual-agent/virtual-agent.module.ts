import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VirtualAgentRoutingModule } from './virtual-agent-routing.module';
import { VirtualAgentListingComponent } from './virtual-agent-listing/virtual-agent-listing.component';
import { VirtualAgentCreationComponent } from './virtual-agent-creation/virtual-agent-creation.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';

@NgModule({
  imports: [
    CommonModule,
    VirtualAgentRoutingModule,
    NgxSpinnerModule,
    AccordionModule.forRoot(),
    ScrollingModule,
    InfiniteScrollModule,
    ReactiveFormsModule,
    FormsModule,
    NgMultiSelectDropDownModule.forRoot()
  ],
  declarations: [VirtualAgentListingComponent, VirtualAgentCreationComponent]
})
export class VirtualAgentModule { }
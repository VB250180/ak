import { VirtualAgentService } from 'src/app/core/services/virtual-agent/virtual-agent.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VirtualAgentListingComponent } from './virtual-agent-listing.component';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

class ActivatedRouteStub {
  paramsObj = {
    name: 'name',
    id: '1',
    desc: 'desc',
    channel: 'chnl',
    lang: 'en-uk',
    chId: 'chId',
    langId: '1',
    get: (property) => {
      return this.paramsObj[property];
    }
  }
  public paramMap = new BehaviorSubject(this.paramsObj);
}

class RouterStub {
  public navigate(path: []) { }
}

class VirtualAgentServiceStub {
  getVirtualAgents(pageNum,userId,agent){
    if (pageNum == 1 || pageNum == 2) {
      return Observable.of({
        virtualAgent: null,
        virtualAgents: [
          {
            vaId: 2,
            vaName: "Policy Issuance",
            vaIsLive: null,
            isNluConfigured: null,
            vaAvatarName: "Akeira2.0 av",
            vaDescription: "Policy issuance",
            businessUnit: null,
            languages: [
              {
                langEngId: 1,
                langName: "English",
                channels: null
              }
            ],
            channels: [
              {
                channelId: 2,
                channelName: "IVR"
              }
            ],
            businessUnitData: {
              catId: 1,
              categoryName: "Member Services",
              nluEngine: null,
              organization: {
                orgId: 1,
                organizationName: "Health Insurance Inc"
              }
            },
            userName: null
          },
          {
            vaId: 3,
            vaName: "Policy Issuance",
            vaIsLive: null,
            isNluConfigured: null,
            vaAvatarName: "Akeira2.0 av",
            vaDescription: "Policy issuance",
            businessUnit: null,
            languages: [
              {
                langEngId: 1,
                langName: "English",
                channels: null
              }
            ],
            channels: [
              {
                channelId: 2,
                channelName: "IVR"
              }
            ],
            businessUnitData: {
              catId: 1,
              categoryName: "Member Services",
              nluEngine: null,
              organization: {
                orgId: 1,
                organizationName: "Health Insurance Inc"
              }
            },
            userName: null
          }
        ],
        intent: null,
        intents: null,
        conversation: null,
        trainingPhrases: null,
        virtualAgentDashboardResponseObject: null,
        virtualAgentTrendResponseObject: null,
        systemSlotKeys: null,
        count: 16,
        languages: null,
        languageEngineMaps: null,
        channels: null,
        intentLanguageChannelMaps: null,
        intentSlots: null,
        entities: null,
        sessionData: null,
        organizationData: null,
        categoryData: null,
        userData: null,
        entityResponseObject: null,
        entityResponseObjectList: null,
        errorBody: null
      });
    } else if(pageNum == 3) {
      console.log('coming here');
      return Observable.of({
        virtualAgents: null
      });
    } else {
      return throwError('error');
    }
  }
}

class NgxSpinnerServiceStub {

}

describe('VirtualAgentListingComponent', () => {
  let component: VirtualAgentListingComponent;
  let fixture: ComponentFixture<VirtualAgentListingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: Router, useClass: RouterStub },
        { provide: ActivatedRoute, useClass: ActivatedRouteStub },
        { provide: VirtualAgentService, useClass: VirtualAgentServiceStub },
        { provide: NgxSpinnerService, useClass: NgxSpinnerServiceStub }
      ],
      declarations: [VirtualAgentListingComponent],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VirtualAgentListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('ngOnInit should initialize virtualAgents and agentsLength based on response returned', () => {
    component.pageNo = 1;
    component.userId = 1;
    component.searchText = '';

    component.ngOnInit();

    expect(component.virtualAgents.length).toEqual(2);
    expect(component.agentsLength).toEqual(2);
    expect(component.searchText).toEqual('');
  });

  it('ngOnInit should not initialize virtualAgents and agentsLength response returned is null', () => {
    component.pageNo = 3;
    component.userId = 1;
    component.searchText = undefined;
    component.agentsLength = 0;

    component.ngOnInit();

    expect(component.virtualAgents.length).toEqual(0);
    expect(component.agentsLength).toBe(0);
    expect(component.searchText).toEqual('');
  });

  it('selectedRow should call navigate to a different page', () => {
    const router = TestBed.get(Router);
    const routerSpy = spyOn(router, 'navigate');

    component.selectedRow({});

    expect(routerSpy).toHaveBeenCalled();
  });

  it('onScroll should initialize virtualAgents and agentsLength based on response returned', () => {
    component.counter = 0;
    component.userId = 1;
    component.searchText = '';

    component.onScroll();

    expect(component.counter).toEqual(1);
    expect(component.virtualAgents.length).toEqual(4);
    expect(component.agentsLength).toEqual(4);
    expect(component.searchText).toEqual('');
  });

  it('onScroll should not initialize virtualAgents and agentsLength response returned has error', () => {
    component.counter = -1;
    component.userId = 1;
    component.searchText = undefined;
    component.agentsLength = 0;
    component.virtualAgents = [];

    component.onScroll();

    expect(component.counter).toEqual(0);
    expect(component.virtualAgents.length).toEqual(0);
    expect(component.agentsLength).toBe(0);
    expect(component.searchText).toEqual('');
  });

  it('onSearchIntent should initialize virtualAgents', () => {
    component.pageNo = 3;
    component.userId = 1;
    component.searchText = undefined;
    component.agentsLength = 0;

    component.onSearchIntent('');

    expect(component.virtualAgents.length).toEqual(2);
    expect(component.searchText).toEqual('');
  });
});

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { VirtualAgentListingComponent } from './virtual-agent-listing/virtual-agent-listing.component';
import { VirtualAgentCreationComponent } from './virtual-agent-creation/virtual-agent-creation.component';

const routes: Routes = [
  { path: 'va-listing', component: VirtualAgentListingComponent },
  { path: 'va-creation/:vaId/:flag', component: VirtualAgentCreationComponent },
  { path: 'va-creation', component: VirtualAgentCreationComponent },
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VirtualAgentRoutingModule { }
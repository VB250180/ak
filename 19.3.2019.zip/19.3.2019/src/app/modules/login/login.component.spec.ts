import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, Component, TemplateRef } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable, BehaviorSubject } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginComponent } from './login.component';
import { MatDialogConfig, MatDialog, MatDialogModule } from '@angular/material';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';


class loginServiceStub {
  constructor() { }

  public forgotPassword(name) {
    if (name === 'skandha') {
      return Observable.of({
        loginPojo: {
          userId: 0,
          username: "vriksh",
          email: "string",
          phoneNumber: "string",
          jwToken: "string",
          password: "string",
          newPassword: "string",
          confirmPassword: "string",
          roleId: 0,
          roleName: "string"
        }, errorBody: null
      })
    } else {
      return Observable.of({
        loginPojo: null,
        errorBody: {
          code: "1405",
          summary: "entry field invalid"
        }
      })
    }
  }

  public login({ username, password }) {
    if (username === 'skandha' && password === 'skandhapass') {
      return Observable.of({
        loginPojo: {
          userId: 23,
          username: "skandha",
          email: "bhuvan@uniphore.com",
          phoneNumber: "9876540963",
          jwToken: "Password Reset",
          password: null,
          newPassword: null,
          confirmPassword: null,
          roleId: 1,
          roleName: "VARoleAdmin"
        }, errorBody: null
      })
    } else {
      return Observable.of({
        loginPojo: null,
        errorBody: {
          code: "1405",
          summary: "invlid credentials"
        }
      })
    }


  }
}

fdescribe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LoginComponent],
      imports: [FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
        RouterTestingModule,
        MatDialogModule,
      ],
      providers: [
        { provide: AuthenticationService, useClass: loginServiceStub }],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check on initialization on oninit method', () => {
    const createform = spyOn(component, 'createForm');
    const resetform = spyOn(component, 'createResetPasswordForm');

    component.ngOnInit();

    expect(createform).toHaveBeenCalled();
    expect(resetform).toHaveBeenCalled();
    expect(component.returnUrl).toEqual('/login');

    // expect(component.BusinessUnits).toEqual([{ catId: 1, categoryName: 'Claims' }]);
  });

  it('should check createForm', () => {
    component.loginformGroup.controls['username'].setValue('admin');
    component.loginformGroup.controls['password'].setValue('adminpass');

    component.createForm();
    expect(component.loginformGroup.controls['username'].value).toBe('');
    expect(component.loginformGroup.controls['password'].value).toBe('');
  });

  it('should check createresetForm', () => {
    component.resetpassword.controls['newpass'].setValue('pass');
    component.resetpassword.controls['confirmpass'].setValue('pass');

    component.createResetPasswordForm();
    expect(component.resetpassword.value.newpass).toEqual(component.resetpassword.value.newpass);
  });

  it('should show forgotPasswrodForm', () => {
    component.forgotpasswordformGroup.patchValue({
      username: ''
    });
    component.forgotPasswrodForm();
    expect(component.forgotpasswordformGroup.value).toEqual({username:''});
  });

  it('should show an error msg if form is invalid', () => {
    component.loginformGroup.patchValue({username:''})
    component.getError('value');

    expect(component.loginformGroup.get('username').hasError('required'))
  });

  it('should call method to login', () => {
    component.loading = true;
    component.onSubmit({username:'skandha', password:'skandhapass'},event);

  });

  it('should call method to show popup message', () => {
    component.openModal();
  //  expect(component.errorMsg).toEqual('Please enter a valid username and password');
  });

  it('should call method to show error message', () => {
    component.showErrMsg();
    expect(component.errorMsg).toEqual('Please enter a valid username and password');
  });

  // it('should open a popup', () => {
  //   const modal = TestBed.get(MatDialog);
  //   const spy = spyOn(modal, 'MatDialogConfig');
    
  //   component.openModal();
  //   expect(spy).toHaveBeenCalled();
  // });

  it('call a method to forgot password', () => {
    component.loginFormDisplay = false;
    component.loginFormResetEmial = true;
    component.forgetPass();
    expect(component.loginformGroup.value).toEqual({ username: null, password: null })
  });

  it('call a method to close login popup', () => {
    component.loginClose();
    expect(component.loginFormDisplay).toBeTruthy();
    expect(component.loginFormResetEmial).toBeFalsy();
  });

  it('call a method to forgot password', () => {
    component.loginFormDisplay = true;
    component.loginFormResetEmial = false;
    component.forgotClose();
    expect(component.forgotpasswordformGroup.value).toEqual({ username: null });
  });

  it('method to send reset link', () => {
    component.forgotpasswordformGroup.controls['username'].setValue('skandha');
    component.sendResetLink();

    expect(component.errorMsgName).toEqual('If account exists, an email will be sent with further instructions');
    expect(component.btnReset).toEqual('Ok');
    expect(component.forgotpasswordformGroup.value).toEqual({ username: null });

  });

  it('method to send reset link on err', () => {
    component.forgotpasswordformGroup.controls['username'].setValue('wrong name');
    component.sendResetLink();

    expect(component.errorMsgName).toEqual('If account exists, an email will be sent with further instructions');
    expect(component.btnReset).toEqual('Ok');
    expect(component.forgetPasswordSuccessForm).toBeTruthy;
    expect(component.loginFormResetEmial).toBeFalsy;

  });

  it('method to close forgot/reset password', () => {
    component.resetClose();

    expect(component.loginFormDisplay).toBeTruthy;
    expect(component.loginFormResetEmial).toBeFalsy;
    expect(component.forgetPasswordForm).toBeFalsy;

  });


  it('method to call reset success', () => {
    component.ResetSucess();

    expect(component.forgetPasswordForm).toBeFalsy;
    expect(component.forgetPasswordSuccessForm).toBeTruthy;

  });

  it('method to redirect form', () => {
    component.btnReset = 'Ok';
    const spy = spyOn(component, 'redirectToLoginForm');

    component.redirectToForm();

    expect(spy).toHaveBeenCalled();
    expect(component.forgotpasswordformGroup.value).toEqual({ username: null });

  });


  //   it('call a method to login after entering credentials', ()=>{
  //     const router = TestBed.get(Router);
  //     const spy = spyOn(router, 'navigate');

  //     component.submitted = true;
  //     component.loading = true;
  //     const event= new EventTarget();


  //     component.onSubmit({username:'skandha', password:'skandhapass'},event);

  //     expect(spy).toHaveBeenCalledWith(['/reset-password']);  });

});

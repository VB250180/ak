import { FilterPipe } from './filter.pipe';


describe('FilterPipe', () => {
  let filterPipe: FilterPipe;

  // synchronous beforeEach
  beforeEach(() => {
    filterPipe = new FilterPipe();
  });

  it('should be instanciated', () => {
    expect(filterPipe).toBeDefined();
  });

  // it('should return array item', () => {
  //   const items = [];
  //   items.push({ id: 1, name: 'Hans' });

  //   const filtered = filterPipe.transform(items, 'name', " ","includes");
  //   expect(filtered).toEqual(items);
  // });

  it('should return empty array if no items given', () => {
    const items = null;
    const filtered = filterPipe.transform(items, 'name', 'Hans',"includes");
    expect(filtered.length).toBe(0);
    expect(filtered).toEqual([]);
  });

  it('should return items if no field is given', () => {
    const items = [];
    items.push({ id: 1, name: 'Hans' });

    const filtered = filterPipe.transform(items, 'name', 'Hans',"includes");

    expect(filtered).toEqual(items);
  });

  it('should return items if no value is given', () => {
    const items = [];
    items.push({ id: 1, name: 'Hans' });

    const filtered = filterPipe.transform(items, 'name', 'Hans',"includes");

    expect(filtered).toEqual(items);
  });
// equal operator check

it('should check given string is equal', () => {
  const filtered = filterPipe.filter("a", "a","equal");
  expect(filtered).toBeTruthy();
});

it('should check given string is equal', () => {
  const filtered = filterPipe.filter("a", "ab","not-equal");
  expect(filtered).toBeTruthy();
});

});


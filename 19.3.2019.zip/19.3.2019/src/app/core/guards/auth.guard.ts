
import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, CanDeactivate } from '@angular/router';

import { AuthenticationService } from '../authentication/authentication.service';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
    constructor(
        private router: Router,
        private authenticationService: AuthenticationService,
        private matDialog: MatDialog
    ) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        const currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser) {
            console.log(currentUser);
            if (route['url'][0].path === 'login') {
                this.router.navigate(['/agent-list']);
                return false;
            }
            // check if route is restricted by role
            // if (route.data.roles && route.data.roles.indexOf(currentUser.role) === -1) {
            //     // role not authorised so redirect to home page
            //     //this.router.navigate(['/']);
            //     return false;
            // }

            // authorised so return true
            return true;
        } else if (route['url'][0].path === 'login') {
            return true;
        } else {
            // not logged in so redirect to login page with the return url
            const dialogConfigReset = new MatDialogConfig();
            dialogConfigReset.disableClose = true;
            dialogConfigReset.width = "800px";
            dialogConfigReset.data = {
                primaryText: "Session Timed Out, Please login to continue",
                hasPrimaryBtn: true,
                primaryBtnText: 'Ok',
                popUpType: 'warn',
                hasCancelBtn: true
            }

            const modalDialog = this.matDialog.open(ModalComponent, dialogConfigReset);
            modalDialog.afterClosed().subscribe(data => {
                this.router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
                return false;
            });

        }
    }
}


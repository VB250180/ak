import { Renderer2 } from '@angular/core';

export const lastDigitOfNumber = (no: number) => no % 10;
export const chooseColorClassByLastDigit = (no: number) => 'slot-c-' + lastDigitOfNumber(no);

export const getRandomRolor = () => {
    let letters = '012345'.split(''), color = '#';
    color += letters[Math.round(Math.random() * 5)];
    letters = '0123456789ABCDEF'.split('');
    for (let i = 0; i < 5; i++) {
        color += letters[Math.round(Math.random() * 15)];
    }
    return color;
}

//Object utils
export const getObjById = (x: [], id: any) => x.filter(function (o: any) { return o.id === id; });
export const isEmptyObj = (x: object) => {
    if (x != null && x != undefined) {
        return Object.keys(x).length === 0;
    } else {
        return true;
    }
}

export const filterByKeyValue = (arr: [], key: string, value: string | boolean | number) => arr.filter(i => i[key] === value);
export const filterByNluConfigured = (arr: []) => filterByKeyValue(arr, 'isNluConfigured', true);

export const getFromLocalStorage = (key: string) => {
    return localStorage.getItem(key);
}


//String utils
export const stringify = (x: object) => JSON.stringify(x);

export const getCurrentUserId = () => {
    // try { return Number(JSON.parse(getFromLocalStorage('currentUser')).userId);}
    // catch (error) {console.error('Error ',error); console.info('Error -- No Login user ');return null; }

    const user = JSON.parse(getFromLocalStorage('currentUser'));
    if (user !== null) {
        return Number(user.userId);
    } else {
        console.info('Error -- No Login user '); return null;
    }
}

export const getCurrentUserName = () => (JSON.parse(getFromLocalStorage('currentUser')).username);



// <div class="getInfo-rch-crd-container shadow p-3  bg-white rounded">
//     <div class="input-group mb-3 input-group-sm">
//         <div class="input-group-prepend">
//           <span class="input-group-text"><i class="fa fa-picture-o" aria-hidden="true"></i></span>
//        </div>
//        <input type="text" class="form-control" placeholder="~ Image Slot ~">
//      </div>

//      <div class="input-group mb-3 input-group-sm">
//        <input type="text" class="form-control" placeholder="~ Image description slot ~">
//      </div>
//      <label class="input-group mb-3 input-group-sm slot-label"><img src="../../../../assets/icons/more_icons/tooltip.svg">&nbsp;Add upto 5 fields as label</label>
//       <div class="input-group mb-3 input-group-sm" >
//         <input type="text"  class="form-control" placeholder="Label">
//         <input type="text"  class="form-control" placeholder="Value">
//         <span  class="col-1 removeWrap"><i class="fa fa-trash plusicon"></i></span>
//       </div>

//       <div class="input-group mb-3 input-group-sm" >
//         <input type="text"  class="form-control" placeholder="Label">
//         <input type="text"  class="form-control" placeholder="Value">
//       </div>

//       <div class="rich-crd-container add-slot-label">
//         <div class="add-rich-crd-pad add-slot-label">
//             <p class="add-rich-card-from-t rectangle-add-slot "><i  class="fa fa-plus createicon add-slot"></i>&nbsp;Add more Slots & Label</p>
//         </div>
//     </div>
// </div>

//Renderer2
// <div class="input-group mb-3 input-group-sm">
//  <div class="input-group-prepend">
//      <span class="input-group-text"><i class="fa fa-picture-o" ></i></span>
//  </div>
//  <input type="text" class="form-control" placeholder="~ Image Slot ~">
// </div>

export const createElement = (r, e) => r.createElement(e);
export const createText = (r, e) => r.createText(e);
export const addAttribute = (r, e, t, c) => r.setAttribute(e, t, c);
export const appendChild = (r, m, c) => r.appendChild(m, c);
export const removeChild = (r, p, c) => r.removeChild(p, c);

export const rendererImageInput = (r, nativeElement, placeholder, value) => {
    let divL1 = createElement(r, "div"); addAttribute(r, divL1, 'class', 'input-group mb-3 input-group-sm');
    let divL2 = createElement(r, "div"); addAttribute(r, divL2, 'class', 'input-group-prepend');
    let spanL3 = createElement(r, "span"); addAttribute(r, spanL3, 'class', 'input-group-text');
    let iL4 = createElement(r, "i"); addAttribute(r, iL4, 'class', 'fa fa-picture-o');

    let inputL2 = createElement(r, "input"); addAttribute(r, inputL2, 'class', 'form-control');
    addAttribute(r, inputL2, 'placeholder', placeholder); addAttribute(r, inputL2, 'value', value);

    appendChild(r, spanL3, iL4); appendChild(r, divL2, spanL3); appendChild(r, divL1, divL2); appendChild(r, divL1, inputL2);
    appendChild(r, nativeElement, divL1);
    return inputL2;
}

//  <div class="input-group mb-3 input-group-sm">
//    <input type="text" class="form-control" placeholder="~ Image description slot ~">
//  </div>

export const rendererInput = (r, nativeElement, placeholder, value) => {
    let divL1 = createElement(r, "div"); addAttribute(r, divL1, 'class', 'input-group mb-3 input-group-sm');
    let inputL2 = createElement(r, "input"); addAttribute(r, inputL2, 'class', 'form-control');
    addAttribute(r, inputL2, 'placeholder', placeholder);
    addAttribute(r, inputL2, 'value', value);

    appendChild(r, divL1, inputL2); appendChild(r, nativeElement, divL1);
    return inputL2;
}
//<label class="input-group mb-3 input-group-sm slot-label"><img src="../../../../assets/icons/more_icons/tooltip.svg">&nbsp;Add upto 5 fields as label</label>

export const rendererLabelAlert = (r, nativeElement, no) => {
    let label = createElement(r, "label"); addAttribute(r, label, 'class', 'input-group mb-3 input-group-sm slot-label');
    let txt = createText(r, " Add upto" + no + " fields as label");
    let image = createElement(r, "img"); addAttribute(r, image, 'src', "../../../../assets/icons/more_icons/tooltip.svg");
    appendChild(r, label, image); appendChild(r, label, txt);
    appendChild(r, nativeElement, label);
    //return label;
}

// <div class="input-group mb-3 input-group-sm" >
//   <input type="text"  class="form-control" placeholder="Label">
//   <input type="text"  class="form-control" placeholder="Value">
//   <span  class="col-1 removeWrap"><i class="fa fa-trash plusicon"></i></span>
// </div>

export const rendererLabelSlot = (r, nativeElement, v, isFirst) => {
    let delBtn;
    let divL1 = createElement(r, "div"); addAttribute(r, divL1, 'class', 'input-group mb-3 input-group-sm');
    let inputL2label = createElement(r, "input"); addAttribute(r, inputL2label, 'class', 'form-control');
    addAttribute(r, inputL2label, 'placeholder', "Label");
    // addAttribute(r,inputL2label, 'value', v['label']);

    let inputL2Slot = createElement(r, "input"); addAttribute(r, inputL2Slot, 'class', 'form-control');
    addAttribute(r, inputL2Slot, 'placeholder', "Value");
    // addAttribute(r,inputL2Slot, 'value', v['value']);
    appendChild(r, divL1, inputL2label); appendChild(r, divL1, inputL2Slot);
    if (!isFirst) {
        let spanL1 = createElement(r, "span"); addAttribute(r, spanL1, 'class', 'col-1 removeWrap');
        let iL1 = createElement(r, "i"); addAttribute(r, iL1, 'class', 'fa fa-trash plusicon');
        appendChild(r, spanL1, iL1); appendChild(r, divL1, spanL1);
        r.listen(spanL1, 'click', (evt) => {
            removeChild(r, nativeElement, divL1);
        });
    }
    appendChild(r, nativeElement, divL1);

    return [inputL2label, inputL2Slot, delBtn];
}
//<div class="rich-crd-container add-slot-label">
//   <div class="add-rich-crd-pad add-slot-label">
//      <p class="add-rich-card-from-t rectangle-add-slot "><i  class="fa fa-plus createicon add-slot"></i>&nbsp;Add more Slots & Label</p>
//   </div>
//</div>

export const rendererButton = (r, nativeElement) => {
    let divL1 = createElement(r, "div"); addAttribute(r, divL1, 'class', 'rich-crd-container add-slot-label');
    let divL2 = createElement(r, "div"); addAttribute(r, divL2, 'class', 'add-rich-crd-pad add-slot-label');
    let pL3 = createElement(r, "p"); addAttribute(r, pL3, 'class', 'add-rich-card-from-t rectangle-add-slot');
    appendChild(r, pL3, createText(r, "Add more Slots & Label"));
    let iL4 = createElement(r, "i"); addAttribute(r, iL4, 'class', 'fa fa-plus createicon add-slot');
    appendChild(r, iL4, pL3); appendChild(r, divL2, pL3); appendChild(r, divL1, divL2);
    appendChild(r, nativeElement, divL1);
    return divL1;
}

export const rendererLabelSlotByLimit = (r, nativeElement, limit, valueJson) => {
    rendererLabelAlert(r, nativeElement, limit);
    let i = rendererLabelSlot(r, nativeElement, valueJson[0], true);
    let b = rendererButton(r, nativeElement);

    return {
        'inputLabelSlotAry': i,
        'btn': b
    };
}

// const richCrdEditId = document.getElementById("richCrdGetInfo" + i);
// let imageSlotRes = rendererImageInput(this.renderer, richCrdEditId, "~Image Slot~", "");
// let inp = rendererInput(this.renderer, richCrdEditId, "~Image description slot ~", "");
// let labslot = rendererLabelSlotByLimit(this.renderer, richCrdEditId, 5, [""]);

export const findByEditFieldType = (renderer , nativeElement, manipulateHtml) => {
    console.log(manipulateHtml);
    let editField = manipulateHtml['editField'];
    console.log('editField ', editField);
    let returnType;
    switch (editField['type']) {
        case 'input':
            returnType = rendererInput(renderer, nativeElement, editField['placeholder'], '');
            break;
        case 'inputLabelSlot':
            returnType = ''
            break;
        case 'inputImage':
            returnType = ''
            break;
    }
    return returnType;
}

// vino
export const findSynonymsSlotCharLimit = (sysnValue) => {
    var sysLimit = sysnValue.filter(item => item.entitySynonymsValue.length > 51);
    if (sysLimit.length == 0) {
        return true;
    } else {
        return false;
    }
}





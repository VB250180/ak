import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VaChatWindowComponent } from './va-chat-window.component';
import { By } from '@angular/platform-browser';

describe('VaChatWindowComponent', () => {
  let component: VaChatWindowComponent;
  let fixture: ComponentFixture<VaChatWindowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VaChatWindowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VaChatWindowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('ngAfterViewChecked should create', () => {
    const scrollToBottomSpy = spyOn(component, 'scrollToBottom');

    component.ngAfterViewChecked();

    expect(scrollToBottomSpy).toHaveBeenCalled();
  });

  it('scrollToBottom should set scrollTop to scrollHeight value', () => {
    const scrollToBottomSpy = spyOn(component, 'scrollToBottom');
    const container = fixture.debugElement.query(By.css('.add-scroll'));
    // container.nativeElement.scrollHeight = '50vh';

    component.scrollToBottom();

    expect(container.nativeElement.scrollHeight).toBeDefined();
  });
});

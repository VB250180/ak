import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-selected-va',
  templateUrl: './selected-va.component.html',
  styleUrls: ['./selected-va.component.scss']
})
export class SelectedVaComponent implements OnInit {

  @Input() selectionDetails;
  @Input() requiredDataLoaded: boolean;
  @Output() editClicked = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }

  onEditClick() {
    if (this.requiredDataLoaded) {
      this.editClicked.emit(true);
    }
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectedVaComponent } from './selected-va.component';

describe('SelectedVaComponent', () => {
  let component: SelectedVaComponent;
  let fixture: ComponentFixture<SelectedVaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectedVaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectedVaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('onEditClick should emit an event if requiredDataLoaded is true', () => {
    const editClickedSpy = spyOn(component.editClicked, 'emit');
    component.requiredDataLoaded = true;

    component.onEditClick();

    expect(editClickedSpy).toHaveBeenCalled();
  });

  it('onEditClick should not emit an event if requiredDataLoaded is false', () => {
    const editClickedSpy = spyOn(component.editClicked, 'emit');
    component.requiredDataLoaded = false;

    component.onEditClick();

    expect(editClickedSpy).toHaveBeenCalledTimes(0);
  });
});

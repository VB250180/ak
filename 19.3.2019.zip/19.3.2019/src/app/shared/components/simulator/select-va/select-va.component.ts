import { VirtualDetailsService } from './../../../services/va-details/virtual-agent-details.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-select-va',
  templateUrl: './select-va.component.html',
  styleUrls: ['./select-va.component.scss']
})
export class SelectVaComponent implements OnInit {

  editForm: FormGroup;
  @Input() selectionDetails;
  @Output() cancelClicked = new EventEmitter();
  @Output() doneClicked = new EventEmitter();
  vaDetails = [];
  vaChannels = [];
  vaLanguages = [];

  constructor(private virtualDetailsService: VirtualDetailsService) { }

  ngOnInit() {
    this.editForm = new FormGroup({
      vaAgent: new FormControl(null, Validators.required),
      vaChannel: new FormControl(null, Validators.required),
      vaLanguage: new FormControl(null, Validators.required)
    });
    this.virtualDetailsService.getVirtualAgents().forEach(item => {
      console.log('item', item);
      if (!item.vrmIsLive) {
        item['vaInitials'] = item['vrmName'].substring(0, 1).toUpperCase();
        this.vaDetails.push(item);
      }
    });
    if (this.selectionDetails !== undefined) {
      this.editForm.controls['vaAgent'].setValue(this.selectionDetails.vrmAgentDetails);
      this.editForm.controls['vaChannel'].setValue(this.selectionDetails.vrmAgentChannelDetails);
      this.editForm.controls['vaLanguage'].setValue(this.selectionDetails.vrmAgentLanguageDetails);
      this.vaChannels = this.virtualDetailsService.getChannelsByVrmId(this.editForm.controls['vaAgent'].value.vrmId);
      this.vaLanguages = this.virtualDetailsService.getLanguagesByVrmId(this.editForm.controls['vaAgent'].value.vrmId);
    } else {
      this.editForm.controls['vaChannel'].disable();
      this.editForm.controls['vaLanguage'].disable();
    }
  }

  onCancelClicked() {
    this.cancelClicked.emit(true);
  }

  onVrmAgentChange(event) {
    if (this.editForm.controls['vaAgent'].status === 'VALID') {
      this.editForm.controls['vaChannel'].reset();
      this.editForm.controls['vaLanguage'].reset();
      this.editForm.controls['vaChannel'].enable();
      this.editForm.controls['vaLanguage'].enable();
      this.vaChannels = this.virtualDetailsService.getChannelsByVrmId(this.editForm.controls['vaAgent'].value.vrmId);
      this.vaLanguages = this.virtualDetailsService.getLanguagesByVrmId(this.editForm.controls['vaAgent'].value.vrmId);
    }
  }

  onDoneClicked() {
    const selectionDetails = {
      vrmAgentDetails: this.editForm.controls['vaAgent'].value,
      vrmAgentChannelDetails: this.editForm.controls['vaChannel'].value,
      vrmAgentLanguageDetails: this.editForm.controls['vaLanguage'].value
    };
    this.doneClicked.emit(selectionDetails);
  }
}

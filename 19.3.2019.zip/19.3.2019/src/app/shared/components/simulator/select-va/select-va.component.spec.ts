import { NgSelectModule } from '@ng-select/ng-select';
import { VirtualDetailsService } from 'src/app/shared/services/va-details/virtual-agent-details.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectVaComponent } from './select-va.component';
import { Observable } from 'rxjs';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

class VirtualDetailsServiceStub {
  public getVirtualAgents() {
    return [{
      vrmId: 25,
      vrmName: "Akeira",
      vrmIsLive: true,
      isNluConfigured: false,
      vrmAvatarName: "Samantha",
      vrmDescription: "va desc",
      vrmBU: "Member Services"
    },
    {
      vrmId: 26,
      vrmName: "Akeira",
      vrmIsLive: true,
      isNluConfigured: false,
      vrmAvatarName: "Samantha",
      vrmDescription: "va desc",
      vrmBU: "Member Services"
    }];
  }

  public getChannelsByVrmId(vrmId) {
    return [{
      virtualAgentRoleChannelMapId: 34,
      channelId: 1,
      channelName: "WEB",
      key: "uni@123"
    }, {
      virtualAgentRoleChannelMapId: 35,
      channelId: 1,
      channelName: "WEB",
      key: "uni@123"
    }];
  }

  public getLanguagesByVrmId(vrmId) {
    return [{
      langEngId: 1,
      langName: "English",
      channels: null
    },
    {
      langEngId: 2,
      langName: "French",
      channels: null
    }];
  }
}

describe('SelectVaComponent', () => {
  let component: SelectVaComponent;
  let fixture: ComponentFixture<SelectVaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: VirtualDetailsService, useClass: VirtualDetailsServiceStub }
      ],
      declarations: [SelectVaComponent],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        NgSelectModule
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]

    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectVaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('ngOnInit should disable the vaChannel and vaLanguage formControls', () => {
    component.selectionDetails = undefined;
    component.vaDetails = [];

    component.ngOnInit();

    expect(component.vaDetails.length).toEqual(2);
    expect(component.editForm.controls['vaChannel'].valid).toBeFalsy();
    expect(component.editForm.controls['vaLanguage'].valid).toBeFalsy();
  });

  it('ngOnInit should disable the vaChannel and vaLanguage FormContrls', () => {
    component.selectionDetails = {
      vrmAgentDetails: {
        vrmId: 25,
        vrmName: "Akeira",
        vrmIsLive: true,
        isNluConfigured: false,
        vrmAvatarName: "Samantha",
        vrmDescription: "va desc",
        vrmBU: "Member Services"
      },
      vrmAgentChannelDetails: {
        virtualAgentRoleChannelMapId: 34,
        channelId: 1,
        channelName: "WEB",
        key: "uni@123"
      },
      vrmAgentLanguageDetails: 'English'
    };
    component.vaDetails = [];

    component.ngOnInit();

    expect(component.vaDetails.length).toEqual(2);
    expect(component.vaChannels.length).toEqual(2);
    expect(component.vaLanguages.length).toEqual(2);
    expect(component.editForm.controls['vaChannel'].valid).toBeTruthy();
    expect(component.editForm.controls['vaLanguage'].valid).toBeTruthy();
  });

  it('onCancelClicked should emit an event', () => {
    const cancelClickedSpy = spyOn(component.cancelClicked, 'emit');

    component.onCancelClicked();

    expect(cancelClickedSpy).toHaveBeenCalledWith(true);
  });

  it('onDoneClicked should emit an event', () => {
    const doneClickedSpy = spyOn(component.doneClicked, 'emit');
    component.editForm.controls['vaAgent'].setValue('agent');
    component.editForm.controls['vaChannel'].setValue('channel');
    component.editForm.controls['vaLanguage'].setValue('language');
    const selectionDetails = {
      vrmAgentDetails: 'agent',
      vrmAgentChannelDetails: 'channel',
      vrmAgentLanguageDetails: 'language'
    }

    component.onDoneClicked();

    expect(doneClickedSpy).toHaveBeenCalledWith(selectionDetails);
  });

  it('onVrmAgentChange should reset vaChannel and vaLanguage FormContrls', () => {
    component.editForm.controls['vaAgent'].setValue('agent');
    component.editForm.controls['vaChannel'].setValue('channel');
    component.editForm.controls['vaLanguage'].setValue('language');

    component.onVrmAgentChange('');

    expect(component.editForm.controls['vaChannel'].valid).toBeFalsy();
    expect(component.editForm.controls['vaLanguage'].valid).toBeFalsy();
  });

  it('onVrmAgentChange should not reset vaChannel and vaLanguage FormContrls', () => {
    component.editForm.controls['vaAgent'].setValue('');
    component.editForm.controls['vaChannel'].setValue('channel');
    component.editForm.controls['vaLanguage'].setValue('language');

    component.onVrmAgentChange('');

    expect(component.editForm.controls['vaChannel'].valid).toBeFalsy();
    expect(component.editForm.controls['vaLanguage'].valid).toBeFalsy();
  });
});

// import { Router } from '@angular/router';
// import { Location } from '@angular/common';
import { Component, OnInit, OnChanges, Input } from '@angular/core';
import { version } from '../../../package.json';
import { Router, ActivatedRoute } from '@angular/router';
import {environment as env} from '../../environments/environment';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { MustMatch } from 'src/app/modules/login/login.component';
import { LocaleService } from 'src/app/core/services/locale/locale.service';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';
import { getCurrentUserName } from 'src/app/core/utils/akeira-utils';
// import { ReportsService } from '../../reports/reports.service';
// import { Subscription } from 'rxjs';
declare var $:any;
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  public userId : string;
  resetpassword: FormGroup;

  simulatorBaseUrl: string;
  hide = true;
  loginLocale: any;
  forgotpassLocale: any;
  resetpassLocale: any;
  resetsuccesslocale: any;

  loginFormDisplay = true;
  forgetPasswordForm = false;
  loginFormResetEmial = false;
  forgetPasswordSuccessForm = false;
  loginformGroup: FormGroup;

  upperVal = /(.*[A-Z].*)/;
  charVal = /[@#$%^&+=]/;
  submitted: boolean;
  loading: boolean;
  error: '';
  returnUrl: string;
  errorMsg: string;
  userName:any;

  path = '';
  @Input() x = 0;
  @Input() y = 0;
  // showContent: any;
  public version: string = version;
  resetpass: boolean = true;
  resetPasswordSuccessful = false;
  constructor(private fb: FormBuilder, private router: Router,private matDialog: MatDialog,
    private locale: LocaleService, private route: ActivatedRoute, private authenticationService: AuthenticationService) {
    this.loginLocale = this.locale.loginPage;
    this.forgotpassLocale = this.locale.forgotPasswordPage;
    this.resetpassLocale = this.locale.resetPasswordPage;
    this.resetsuccesslocale = this.locale.resetPasswordSuccessPage;
  }

  ngOnInit(): void { 

   getCurrentUserName() != null ? this.userName = getCurrentUserName() : this.userName = '';

    $(document).ready(function() {
      $('.parent').hover(function() {
        $('.sub-nav').toggleClass('visible');
      });
    });

    $(document).ready(function() {
      $('.parent2').hover(function() {
        $('.sub-nav2').toggleClass('visible');
      });
    });

    if(!localStorage.getItem('currentUser')){
      this.logout();
    }
  }

  onresetPasswordForm(){
    console.log('reset');
    this.resetpass = true;
  }

  logout(){
    this.authenticationService.logout();
  }
  
  forgetPass() {
    this.loginFormDisplay = false;
    this.loginFormResetEmial = true;
  }
  loginClose() {
    this.loginFormDisplay = true;
    this.loginFormResetEmial = false;
  }

  resetPassword() {
    this.loginFormDisplay = false;
    this.loginFormResetEmial = false;
    this.forgetPasswordForm = true;
  }
  resetPasswordMethod() {
    this.resetpass = false;
    this.router.navigate(['/reset-password']);
  }

  onresetSuccess(){
    this.resetPasswordSuccessful = true;
    const dialogConfigReset = new MatDialogConfig();
    dialogConfigReset.disableClose = true;
    dialogConfigReset.width = "800px";
    dialogConfigReset.data = {
      primaryText: "Your new password has been created successfully",
      hasPrimaryBtn: true,
      primaryBtnText: 'Ok',
      popUpType: 'info',
      hasCancelBtn: true
    }
    const modalDialog = this.matDialog.open(ModalComponent, dialogConfigReset);
    modalDialog.afterClosed().subscribe(data => {
      console.log(data);
    });

  }

  ResetSucess() {
    this.forgetPasswordForm = false;
    this.forgetPasswordSuccessForm = true;
  }
  rediectToLoginForm() {
    this.loginFormDisplay = true;
    this.forgetPasswordSuccessForm = false;
  }
}

import { LoginComponent } from './../../../app/modules/login/login.component';
import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { TrainingPhrasesComponent } from './training-phrases.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, Component, TemplateRef } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { BsModalService, BsModalRef } from "ngx-bootstrap/modal";
import { BsDropdownConfig } from "ngx-bootstrap/dropdown";
import { ToastrService, ToastrModule } from 'ngx-toastr';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { CreateIntentService } from '../create-intent.service';
import { of, BehaviorSubject, Observable, throwError } from 'rxjs';
import { TextSelectEvent } from 'src/app/shared/directives/text-select.directive';
import { ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

class ActivatedRouteStub {
    paramsObj = {
        params: {
            name: 'name',
            id: 1,
            desc: 'desc',
            channel: 'channel',
            lang: 'en-uk',
            chId: 'chId',
            langId: 'lanID'
        }
    };
    public paramMap = new BehaviorSubject(this.paramsObj);
}

class BsModalRefStub {
    public hide() { }

    public show() { }
}

class BsModalServiceStub {
    public show() { }
}

class CreateIntentServiceStub {
    public requestaddTrainingPhraseAndintentSlots(intentId, langId, pageNo, text): Observable<any[]> {
        if (intentId == 1) {
            return Observable.of([{
                trainingPhrases: [
                    {
                        trainingPhraseId: 130,
                        trainingPhraseText: "Book a flight ticket from Singaporee to %pos0%",
                        intentSlotMapPojos: [
                            {
                                position: "pos0",
                                value: "newzealand",
                                intentSlot: {
                                    intentSlotId: 1,
                                    intentSlotName: "fromPlace",
                                    intentSlotDescription: "from city",
                                    entity: {
                                        entityId: 1,
                                        entityName: "fromPlace"
                                    }
                                }
                            }
                        ],
                        trainingPhraseStage: "notTrained"
                    },
                    {
                        trainingPhraseId: 132,
                        trainingPhraseText: "i want to book a movie ticket from %pos0%",
                        intentSlotMapPojos: [
                            {
                                position: "pos0",
                                value: "Bengaluru",
                                intentSlot: {
                                    intentSlotId: 1,
                                    intentSlotName: "fromPlace",
                                    intentSlotDescription: "from city",
                                    entity: {
                                        entityId: 1,
                                        entityName: "fromPlace"
                                    }
                                }
                            }
                        ],
                        trainingPhraseStage: "notTrained"
                    },
                    {
                        trainingPhraseId: 135,
                        trainingPhraseText: "agile methodology in akeira 2.0 product %pos1%",
                        intentSlotMapPojos: [
                            {
                                position: "pos1",
                                value: "development",
                                intentSlot: {
                                    intentSlotId: 7,
                                    intentSlotName: "To city",
                                    intentSlotDescription: "city",
                                    entity: {
                                        entityId: 1,
                                        entityName: "fromPlace"
                                    }
                                }
                            },
                            {
                                position: "pos0",
                                value: "list",
                                intentSlot: {
                                    intentSlotId: 7,
                                    intentSlotName: "To city",
                                    intentSlotDescription: "city",
                                    entity: {
                                        entityId: 1,
                                        entityName: "fromPlace"
                                    }
                                }
                            }
                        ],
                        trainingPhraseStage: "notTrained"
                    }]
            }, {
                intentSlots: [
                    {
                        intentSlotId: 7,
                        intentSlotName: "To city",
                        intentSlotDescription: "city",
                        entity: {
                            entityId: 1,
                            entityName: "fromPlace"
                        }
                    },
                    {
                        intentSlotId: 6,
                        intentSlotName: "City from",
                        intentSlotDescription: "from city",
                        entity: {
                            entityId: 1,
                            entityName: "fromPlace"
                        }
                    },
                    {
                        intentSlotId: 1,
                        intentSlotName: "fromPlace",
                        intentSlotDescription: "from city",
                        entity: {
                            entityId: 1,
                            entityName: "fromPlace"
                        }
                    },
                    {
                        intentSlotId: 2,
                        intentSlotName: "toPlace",
                        intentSlotDescription: "to city",
                        entity: {
                            entityId: 2,
                            entityName: "toPlace"
                        }
                    }
                ]
            }]);
        } else if (intentId == 0) {
            return Observable.of([{
                trainingPhrases: []
            },
            {
                intentSlots: []
            }]);
        } else {
            return throwError({});
        }
    }

    public addTrainingPhrase(intentId, langId, pageNo, text) {
        if (intentId == 1) {
            return Observable.of({
                trainingPhrases: [
                    {
                        trainingPhraseId: 130,
                        trainingPhraseText: "Book a flight ticket from Singaporee to %pos0%",
                        intentSlotMapPojos: [
                            {
                                position: "pos0",
                                value: "newzealand",
                                intentSlot: {
                                    intentSlotId: 1,
                                    intentSlotName: "fromPlace",
                                    intentSlotDescription: "from city",
                                    entity: {
                                        entityId: 1,
                                        entityName: "fromPlace"
                                    }
                                }
                            }
                        ],
                        trainingPhraseStage: "notTrained"
                    },
                    {
                        trainingPhraseId: 132,
                        trainingPhraseText: "i want to book a movie ticket from %pos0%",
                        intentSlotMapPojos: [
                            {
                                position: "pos0",
                                value: "Bengaluru",
                                intentSlot: {
                                    intentSlotId: 1,
                                    intentSlotName: "fromPlace",
                                    intentSlotDescription: "from city",
                                    entity: {
                                        entityId: 1,
                                        entityName: "fromPlace"
                                    }
                                }
                            }
                        ],
                        trainingPhraseStage: "notTrained"
                    },
                    {
                        trainingPhraseId: 135,
                        trainingPhraseText: "agile methodology in akeira 2.0 product %pos1%",
                        intentSlotMapPojos: [
                            {
                                position: "pos1",
                                value: "development",
                                intentSlot: {
                                    intentSlotId: 7,
                                    intentSlotName: "To city",
                                    intentSlotDescription: "city",
                                    entity: {
                                        entityId: 1,
                                        entityName: "fromPlace"
                                    }
                                }
                            },
                            {
                                position: "pos0",
                                value: "list",
                                intentSlot: {
                                    intentSlotId: 7,
                                    intentSlotName: "To city",
                                    intentSlotDescription: "city",
                                    entity: {
                                        entityId: 1,
                                        entityName: "fromPlace"
                                    }
                                }
                            }
                        ],
                        trainingPhraseStage: "notTrained"
                    }]
            });
        } else if (intentId == 0) {
            return Observable.of({
                trainingPhrases: []
            });
        } else {
            return throwError({});
        }
    }

    public deleteTrainingPhrase(intentId, langId, phraseId, text) {
        return Observable.of({});
    }

    public addPhraseDetails(intentId, langId, addArray) {
        if (intentId == 1) {
            return Observable.of({
                errorBody: null
            });
        } else if (intentId == 2) {
            return Observable.of({
                errorBody: {}
            });
        } else {
            return throwError('ERROR');
        }

    }
}

class NgxSpinnerServiceStub {
    public show() { }

    public hide() { }
}

describe('AssistedTrainingComponent', () => {
    let intentService;
    let component: TrainingPhrasesComponent;
    let fixture: ComponentFixture<TrainingPhrasesComponent>;
    let template: TemplateRef<any>;
    let template2: TemplateRef<any>;
    let template1: TemplateRef<any>;
    let event: TextSelectEvent;


    let assistedTrainingInputs = {
        "virtualAgents": [
            {
                "virtualAgent": {
                    "vaId": 2,
                    "vaName": "webBot",
                    "vaIsLive": false,
                    "vaAvatarName": "UMRBOT",
                    "vaDescription": "web"
                },
                "languages": [
                    {
                        "id": 1,
                        "value": "English"
                    },
                    {
                        "id": 2,
                        "value": "French"
                    }
                ],
                "channels": [
                    {
                        "id": 1,
                        "value": "WEB"
                    }
                ]
            }
        ]
    };

    let intentList = {
        "mappedCount": 0,
        "inScopeCount": 0,
        "outOfScopeCount": 4,
        "conversationList": [
            {
                "sessionId": 1,
                "mapppedPhrases": [],
                "inScopePhrases": [],
                "outOfScopePhrases": [
                    {
                        "id": 1,
                        "value": "need information"
                    }
                ]
            },
            {
                "sessionId": 2,
                "mapppedPhrases": [],
                "inScopePhrases": [],
                "outOfScopePhrases": [
                    {
                        "id": 7,
                        "value": "first class ticket from mumbai"
                    },
                    {
                        "id": 4,
                        "value": "ticket book pannanum"
                    },
                    {
                        "id": 3,
                        "value": "sollunga"
                    }
                ]
            }
        ]
    };

    let intentSlots = [
        {
            "intent": {
                "id": 4,
                "value": "praveen intent"
            },
            "intentSlots": []
        },
        {
            "intent": {
                "id": 6,
                "value": "Booking Cancellation"
            },
            "intentSlots": []
        }
    ];

    let createIntentData = {
        "intent": {
            "intentId": 41,
            "intentName": "Test",
            "intentDescription": "Test",
            "virtualAgent": null,
            "businessUnit": null,
            "languages": [
                {
                    "langEngId": 1,
                    "langName": "English",
                    "channels": [
                        {
                            "icmId": 65,
                            "channelId": 1,
                            "channelName": "WEB",
                            "intentConfigStage": 0,
                            "isLive": false
                        }
                    ]
                },
                {
                    "langEngId": 2,
                    "langName": "French",
                    "channels": [
                        {
                            "icmId": 66,
                            "channelId": 1,
                            "channelName": "WEB",
                            "intentConfigStage": 0,
                            "isLive": false
                        }
                    ]
                }
            ]
        }
    }

    let intentSlotValues =
    {
        "virtualAgent": null,
        "virtualAgents": null,
        "intent": null,
        "intents": null,
        "conversation": null,
        "trainingPhrases": null,
        "virtualAgentDashboardResponseObject": null,
        "virtualAgentTrendResponseObject": null,
        "systemSlotKeys": null,
        "count": null,
        "languages": null,
        "channels": null,
        "intentLanguageChannelMaps": null,
        "intentSlots": [
            {
                "intentSlotId": 7,
                "intentSlotName": "To city",
                "intentSlotDescription": "city",
                "entity": {
                    "entityId": 1,
                    "entityName": "fromPlace"
                }
            },
            {
                "intentSlotId": 6,
                "intentSlotName": "City from",
                "intentSlotDescription": "from city",
                "entity": {
                    "entityId": 1,
                    "entityName": "fromPlace"
                }
            },
            {
                "intentSlotId": 1,
                "intentSlotName": "fromPlace",
                "intentSlotDescription": "from city",
                "entity": {
                    "entityId": 1,
                    "entityName": "fromPlace"
                }
            },
            {
                "intentSlotId": 2,
                "intentSlotName": "toPlace",
                "intentSlotDescription": "to city",
                "entity": {
                    "entityId": 2,
                    "entityName": "toPlace"
                }
            }
        ],
        "entities": null,
        "errorBody": null
    };

    let phrases = {
        "virtualAgent": null,
        "virtualAgents": null,
        "intent": null,
        "intents": null,
        "conversation": null,
        "trainingPhrases": [
            {
                "trainingPhraseId": 130,
                "trainingPhraseText": "Book a flight ticket from Singaporee to %pos0%",
                "intentSlotMapPojos": [
                    {
                        "position": "pos0",
                        "value": "newzealand",
                        "intentSlot": {
                            "intentSlotId": 1,
                            "intentSlotName": "fromPlace",
                            "intentSlotDescription": "from city",
                            "entity": {
                                "entityId": 1,
                                "entityName": "fromPlace"
                            }
                        }
                    }
                ],
                "trainingPhraseStage": "notTrained"
            },
            {
                "trainingPhraseId": 132,
                "trainingPhraseText": "i want to book a movie ticket from %pos0%",
                "intentSlotMapPojos": [
                    {
                        "position": "pos0",
                        "value": "Bengaluru",
                        "intentSlot": {
                            "intentSlotId": 1,
                            "intentSlotName": "fromPlace",
                            "intentSlotDescription": "from city",
                            "entity": {
                                "entityId": 1,
                                "entityName": "fromPlace"
                            }
                        }
                    }
                ],
                "trainingPhraseStage": "notTrained"
            },
            {
                "trainingPhraseId": 135,
                "trainingPhraseText": "agile methodology in akeira 2.0 product %pos1%",
                "intentSlotMapPojos": [
                    {
                        "position": "pos1",
                        "value": "development",
                        "intentSlot": {
                            "intentSlotId": 7,
                            "intentSlotName": "To city",
                            "intentSlotDescription": "city",
                            "entity": {
                                "entityId": 1,
                                "entityName": "fromPlace"
                            }
                        }
                    },
                    {
                        "position": "pos0",
                        "value": "list",
                        "intentSlot": {
                            "intentSlotId": 7,
                            "intentSlotName": "To city",
                            "intentSlotDescription": "city",
                            "entity": {
                                "entityId": 1,
                                "entityName": "fromPlace"
                            }
                        }
                    }
                ],
                "trainingPhraseStage": "notTrained"
            }],
        "virtualAgentDashboardResponseObject": null,
        "virtualAgentTrendResponseObject": null,
        "systemSlotKeys": null,
        "count": null,
        "languages": null,
        "channels": null,
        "intentLanguageChannelMaps": null,
        "intentSlots": null,
        "entities": null,
        "errorBody": null
    }

    let addPhrases =
    {
        "virtualAgent": null,
        "virtualAgents": null,
        "intent": null,
        "intents": null,
        "conversation": null,
        "trainingPhrases": [
            {
                "trainingPhraseId": 148,
                "trainingPhraseText": "Book flight ticket from Bengaluru",
                "intentSlotMapPojos": [
                    {
                        "position": "pos0",
                        "value": "Bengaluru",
                        "intentSlot": {
                            "intentSlotId": 1,
                            "intentSlotName": "From place",
                            "intentSlotDescription": null,
                            "entity": null
                        }
                    }
                ],
                "trainingPhraseStage": "notTrained"
            }
        ],
        "virtualAgentDashboardResponseObject": null,
        "virtualAgentTrendResponseObject": null,
        "systemSlotKeys": null,
        "count": null,
        "languages": null,
        "channels": null,
        "intentLanguageChannelMaps": null,
        "intentSlots": null,
        "entities": null,
        "errorBody": null
    }

    let mappedDetails = {
        id: 3,
        intentId: 655,
        intentslots: null,
        value: "sollunga",
        mappedData: { displayValue: "sollunga", intentId: 655, sessionId: 2, mappedHighlightData: [], intentslots: { index: 0, value: "sollunga", isHighlight: false, key: "pos0" } }
    }

    let deletedResponse = {
        channels: null,
        conversation: null,
        count: 1,
        entities: null,
        errorBody: null,
        intent: null,
        intentLanguageChannelMaps: null,
        intentSlots: null,
        intents: null,
        languages: null,
        systemSlotKeys: null,
        trainingPhrases: null,
        virtualAgent: null,
        virtualAgentDashboardResponseObject: null,
        virtualAgentTrendResponseObject: null,
        virtualAgents: null
    }

    let editedText = {
        trainingPhraseId: 632, trainingPhraseText: "add new phrases", intentSlotMapPojos: [], trainingPhraseStage: "notTrained", trainingPhraseDisplay: "add new phrases",
        mappedHighlightData: [{ index: 0, value: "add", isHighlight: false, key: "pos0" },
        { index: 1, value: "new", isHighlight: false, key: "pos1" },
        { index: 2, value: "phrases", isHighlight: false, key: "pos2" }]
    }

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: ActivatedRoute, useClass: ActivatedRouteStub },
                { provide: CreateIntentService, useClass: CreateIntentServiceStub },
                { provide: NgxSpinnerService, useClass: NgxSpinnerServiceStub },
                { provide: BsModalService, useClass: BsModalServiceStub },
                { provide: BsModalRef, useClass: BsModalRefStub },
                { provide: BsDropdownConfig }
            ],
            declarations: [TrainingPhrasesComponent],
            imports: [FormsModule,
                ReactiveFormsModule,
                BrowserAnimationsModule,
                HttpClientTestingModule,
                ToastrModule.forRoot(),
                BsDropdownModule.forRoot(),
                RouterTestingModule],
            schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
        })
            .compileComponents();
    }));

    beforeEach(inject([CreateIntentService], s => {
        let intentService = s;
        fixture = TestBed.createComponent(TrainingPhrasesComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    }));

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('ngOnInit should call fetchPageData method', () => {
        const fetchPageDataSpy = spyOn(component, 'fetchPageData');
        component.flag = 0;

        component.ngOnInit();

        expect(fetchPageDataSpy).toHaveBeenCalled();
    });

    it('refreshTrainingPhrase should call fetchPageData method', () => {
        const fetchPageDataSpy = spyOn(component, 'fetchPageData');
        const langId = 1;
        const chId = 1;

        component.refreshTrainingPhrase(langId, chId);

        expect(component.langId).toEqual(langId);
        expect(component.chId).toEqual(chId);
        expect(fetchPageDataSpy).toHaveBeenCalled();
    });

    it('ngOnChanges should call fetchPageData method', () => {
        const fetchPageDataSpy = spyOn(component, 'fetchPageData');
        component.arr = [1, 2, 3];
        component.searchText = '';

        component.ngOnChanges();

        expect(component.newData).toEqual([1, 2, 3]);
        expect(fetchPageDataSpy).toHaveBeenCalled();
    });

    it('ngOnChanges should not call fetchPageData method', () => {
        const fetchPageDataSpy = spyOn(component, 'fetchPageData');
        component.arr = [1, 2, 3];
        component.searchText = undefined;

        component.ngOnChanges();

        expect(component.newData).toEqual([1, 2, 3]);
        expect(fetchPageDataSpy).toHaveBeenCalledTimes(0);
    });

    it('fetchPageData should call displayTrainingPhrases method', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const spinnerShowSpy = spyOn(spinner, 'show');
        const spinnerHideSpy = spyOn(spinner, 'hide');
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        const intentId = 1;
        const langId = 1;
        const pageNum = 1;
        const searchText = '';
        component.slotsToDisplay = [];

        component.fetchPageData(intentId, langId, pageNum, searchText);

        expect(displayTrainingPhrasesSpy).toHaveBeenCalled();
        expect(component.searchText).toEqual('');
        expect(component.slotsToDisplay.length).toEqual(4);
        expect(spinnerShowSpy).toHaveBeenCalledBefore(spinnerHideSpy);
        expect(spinnerHideSpy).toHaveBeenCalled();
    });

    it('fetchPageData should call displayTrainingPhrases method and slotsToDisplay length should be zero', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const spinnerShowSpy = spyOn(spinner, 'show');
        const spinnerHideSpy = spyOn(spinner, 'hide');
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        const intentId = 0;
        const langId = 1;
        const pageNum = 1;
        const searchText = undefined;
        component.searchText = '';
        component.slotsToDisplay = [];

        component.fetchPageData(intentId, langId, pageNum, searchText);

        expect(displayTrainingPhrasesSpy).toHaveBeenCalled();
        expect(component.searchText).toEqual('');
        expect(component.slotsToDisplay.length).toEqual(0);
        expect(spinnerShowSpy).toHaveBeenCalledBefore(spinnerHideSpy);
        expect(spinnerHideSpy).toHaveBeenCalled();
    });

    it('fetchPageData should not call displayTrainingPhrases method', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const spinnerShowSpy = spyOn(spinner, 'show');
        const spinnerHideSpy = spyOn(spinner, 'hide');
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        const intentId = -1;
        const langId = 1;
        const pageNum = 1;
        const searchText = 'Hello';
        component.searchText = 'Hello';
        component.slotsToDisplay = [];

        component.fetchPageData(intentId, langId, pageNum, searchText);

        expect(displayTrainingPhrasesSpy).toHaveBeenCalledTimes(0);
        expect(component.searchText).toEqual('Hello');
        expect(component.slotsToDisplay.length).toEqual(0);
        expect(spinnerShowSpy).toHaveBeenCalledBefore(spinnerHideSpy);
        expect(spinnerHideSpy).toHaveBeenCalled();
    });

    it('addPhrases should call displayTrainingPhrases method and set status to true', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const spinnerHideSpy = spyOn(spinner, 'hide');
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        const intentId = 1;
        const langId = 1;
        const pageNum = 1;
        const searchText = undefined;
        component.searchText = 'Hello';

        component.addPhrases(intentId, langId, pageNum, searchText);

        expect(displayTrainingPhrasesSpy).toHaveBeenCalled();
        expect(component.status).toBeTruthy();
        expect(component.searchText).toEqual('Hello');
        expect(spinnerHideSpy).toHaveBeenCalled();
    });

    it('addPhrases should call displayTrainingPhrases method and set status to false', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const spinnerHideSpy = spyOn(spinner, 'hide');
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        const intentId = 0;
        const langId = 1;
        const pageNum = 1;
        const searchText = undefined;

        component.addPhrases(intentId, langId, pageNum, searchText);

        expect(displayTrainingPhrasesSpy).toHaveBeenCalled();
        expect(component.status).toBeFalsy();
        expect(component.searchText).toEqual('');
        expect(spinnerHideSpy).toHaveBeenCalled();
    });

    it('addPhrases should not call displayTrainingPhrases method', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const spinnerHideSpy = spyOn(spinner, 'hide');
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        const intentId = -1;
        const langId = 1;
        const pageNum = 1;
        const searchText = 'Hello';

        component.addPhrases(intentId, langId, pageNum, searchText);

        expect(displayTrainingPhrasesSpy).toHaveBeenCalledTimes(0);
        expect(component.searchText).toEqual('');
        expect(spinnerHideSpy).toHaveBeenCalled();
    });

    it('functionClick should set isHidden to true', () => {
        component.IsHidden = false;

        component.functionClick({});

        expect(component.IsHidden).toBeTruthy();
    });

    it('openModalDelete should open modal', () => {
        const modal = TestBed.get(BsModalService);
        const modalShowSpy = spyOn(modal, 'show');
        // component.modalService = modal;

        component.openModalDelete(template, 1, 2, false, 4);

        expect(modalShowSpy).toHaveBeenCalled();
    });

    it('deleteTrainingPhraseCall should call addPhrases method', () => {
        const addPhrasesSpy = spyOn(component, 'addPhrases');
        const modal = TestBed.get(BsModalRef);
        const modalShowSpy = spyOn(modal, 'hide');
        component.modalRef = modal;

        component.deleteTrainingPhraseCall();

        expect(modalShowSpy).toHaveBeenCalled();
        expect(addPhrasesSpy).toHaveBeenCalled();
    });

    it('deleteTrainingPhrase should not call deleteTrainingPhraseCall method and remove a num from addArray', () => {
        const deleteTrainingPhraseCallSpy = spyOn(component, 'deleteTrainingPhraseCall');
        const cancelAddSpy = spyOn(component, 'cancelAdd');
        const modal = TestBed.get(BsModalRef);
        const modalShowSpy = spyOn(modal, 'hide');
        component.modalRef = modal;
        component.isdelFromAddArray = true;
        component.idToDelete = 0;
        component.delIndex = 1;
        component.addArray = [1, 2];

        component.deleteTrainingPhrase();

        expect(modalShowSpy).toHaveBeenCalled();
        expect(component.addArray).toEqual([1]);
        expect(deleteTrainingPhraseCallSpy).toHaveBeenCalledTimes(0);
        expect(cancelAddSpy).toHaveBeenCalledTimes(1);
    });

    it('deleteTrainingPhrase should call deleteTrainingPhraseCall method and remove a num from addArray', () => {
        const deleteTrainingPhraseCallSpy = spyOn(component, 'deleteTrainingPhraseCall');
        const cancelAddSpy = spyOn(component, 'cancelAdd');
        const modal = TestBed.get(BsModalRef);
        const modalShowSpy = spyOn(modal, 'hide');
        component.modalRef = modal;
        component.isdelFromAddArray = true;
        component.idToDelete = 1;
        component.delIndex = 1;
        component.addArray = [1, 2];
        component.searchText = undefined;

        component.deleteTrainingPhrase();

        expect(modalShowSpy).toHaveBeenCalled();
        expect(component.searchText).toEqual('');
        expect(component.addArray).toEqual([1]);
        expect(deleteTrainingPhraseCallSpy).toHaveBeenCalled();
        expect(cancelAddSpy).toHaveBeenCalledTimes(1);
    });

    it('deleteTrainingPhrase should call deleteTrainingPhraseCall', () => {
        const deleteTrainingPhraseCallSpy = spyOn(component, 'deleteTrainingPhraseCall');
        const cancelAddSpy = spyOn(component, 'cancelAdd');
        const modal = TestBed.get(BsModalRef);
        const modalShowSpy = spyOn(modal, 'hide');
        component.modalRef = modal;
        component.isdelFromAddArray = false;
        component.searchText = undefined;

        component.deleteTrainingPhrase();

        expect(modalShowSpy).toHaveBeenCalled();
        expect(component.searchText).toEqual('');
        expect(deleteTrainingPhraseCallSpy).toHaveBeenCalled();
        expect(cancelAddSpy).toHaveBeenCalledTimes(1);
    });

    it('removeSelectedValue should remove given value from intentSlotMapPojos array', () => {
        const coloringPhraseSpy = spyOn(component, 'coloringPhrase');
        const updateValueToTableSpy = spyOn(component, 'updateValueToTable');
        component.intentSlotMapPojos = [{ value: 1 }, { value: 2 }];
        const value = 2;

        component.removeSelectedValue(value);

        expect(component.intentSlotMapPojos).toEqual([{ value: 1 }]);
        expect(coloringPhraseSpy).toHaveBeenCalled();
        expect(updateValueToTableSpy).toHaveBeenCalled();
    });

    it('checkEmpty should return true', () => {
        const value = 'Hello';

        const result = component.checkEmpty(value);

        expect(result).toBeTruthy();
    });

    it('checkEmpty should return false', () => {
        const value = '';

        const result = component.checkEmpty(value);

        expect(result).toBeFalsy();
    });

    it('checkIfEditWordandDisplayWord should return true', () => {
        const newTxt = 'Hello';
        const oldTxt = 'Hi'

        const result = component.checkIfEditWordandDisplayWord(newTxt, oldTxt);

        expect(result).toBeTruthy();
    });

    it('checkIfEditWordandDisplayWord should return false', () => {
        const newTxt = 'Hello';
        const oldTxt = 'Hello'

        const result = component.checkIfEditWordandDisplayWord(newTxt, oldTxt);

        expect(result).toBeFalsy();
    });

    it('onChangebtn should call genrateHighlightdata and updateValueToTable methods', () => {
        const genrateHighlightdataSpy = spyOn(component, 'genrateHighlightdata');
        const updateValueToTableSpy = spyOn(component, 'updateValueToTable');
        const txt = 'Hello';

        component.onChangebtn(txt);

        expect(genrateHighlightdataSpy).toHaveBeenCalled();
        expect(updateValueToTableSpy).toHaveBeenCalled();
        expect(component.disableAddbtm).toBeFalsy();
    });

    it('onChangebtn should not call genrateHighlightdata and updateValueToTable methods', () => {
        const genrateHighlightdataSpy = spyOn(component, 'genrateHighlightdata');
        const updateValueToTableSpy = spyOn(component, 'updateValueToTable');
        const txt = '';

        component.onChangebtn(txt);

        expect(genrateHighlightdataSpy).toHaveBeenCalledTimes(0);
        expect(updateValueToTableSpy).toHaveBeenCalledTimes(0);
    });

    it('editPhrase should not call genrateHighlightdata and updateValueToTable methods', () => {
        const cancelAddSpy = spyOn(component, 'cancelAdd');
        const updateValueToTableSpy = spyOn(component, 'updateValueToTable');
        const data = {};
        const index = 1;
        const isAddArray = false;
        component.intentSlotMapPojos = [];
        component.valueToEdit = 'value';

        component.editPhrase(data, index, isAddArray);

        expect(cancelAddSpy).toHaveBeenCalled();
        expect(component.addForm.controls['addtext'].value).toEqual('value');
        expect(updateValueToTableSpy).toHaveBeenCalled();
    });

    it('checkCanEdit should call editPhrase and modal should not open', () => {
        const editPhraseSpy = spyOn(component, 'editPhrase');
        const modalShowSpy = spyOn(TestBed.get(BsModalService), 'show');
        const data = {};
        const index = 1;
        const isAddArray = false;
        component.intentSlotMapPojos = [];
        component.checkEdited = '';

        component.checkCanEdit(data, index, isAddArray);

        expect(editPhraseSpy).toHaveBeenCalled();
        expect(modalShowSpy).toHaveBeenCalledTimes(0);
    });

    it('checkCanEdit should not call editPhrase and modal should open', () => {
        const modalService = TestBed.get(BsModalService);
        const editPhraseSpy = spyOn(component, 'editPhrase');
        const modalShowSpy = spyOn(modalService, 'show');
        const data = {};
        const index = 1;
        const isAddArray = false;
        component.intentSlotMapPojos = [];
        component.checkEdited = 'check';

        component.checkCanEdit(data, index, isAddArray);

        expect(editPhraseSpy).toHaveBeenCalledTimes(0);
        expect(modalShowSpy).toHaveBeenCalled();
    });

    it('editPhraseYes should call editPhrase and close the modal', () => {
        const modalRef = TestBed.get(BsModalRef);
        const editPhraseSpy = spyOn(component, 'editPhrase');
        const modalHideSpy = spyOn(modalRef, 'hide');
        component.modalRef = modalRef;

        component.editPhraseYes();

        expect(editPhraseSpy).toHaveBeenCalled();
        expect(modalHideSpy).toHaveBeenCalled();
    });

    it('editPhraseNo should call close the modal', () => {
        const modalRef = TestBed.get(BsModalRef);
        const modalHideSpy = spyOn(modalRef, 'hide');
        component.modalRef = modalRef;

        component.editPhraseNo();

        expect(modalHideSpy).toHaveBeenCalled();
    });

    it('cancelAdd should re-initialize variables to empty', () => {
        component.idToEdit = 1;
        component.valueToEdit = 'Hi';
        component.checkEdited = [1, 2, 3];
        component.arrayIndex = 1;
        component.fromAddarray = false;
        component.mappedHighlightData = [2, 3, 4];
        component.intentSlotMapPojos = [3, 4, 5];
        component.trainingPhraseText = 'training';
        component.disableAddbtm = false;
        component.intentSlots = [{ selectedValue: 'selected' }];
        component.addForm.setValue({
            'addtext': 'value'
        });

        component.cancelAdd();

        expect(component.idToEdit).toEqual(0);
        expect(component.valueToEdit).toEqual('');
        expect(component.checkEdited).toEqual([]);
        expect(component.arrayIndex).toEqual(null);
        expect(component.fromAddarray).toBeTruthy();
        expect(component.mappedHighlightData).toEqual([]);
        expect(component.intentSlotMapPojos).toEqual([]);
        expect(component.trainingPhraseText).toEqual('');
        expect(component.disableAddbtm).toBeTruthy();
        expect(component.intentSlots[0].selectedValue).toEqual('');
        expect(component.addForm.controls['addtext'].value).toEqual(null);
    });

    it('saveAddedTrainingPhrases should call displayTrainingPhrases and addPhrases on API success', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const modalShowSpy = spyOn(TestBed.get(BsModalService), 'show');
        const spinnerShowSpy = spyOn(spinner, 'show');
        const spinnerHideSpy = spyOn(spinner, 'hide');
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        const addPhrasesSpy = spyOn(component, 'addPhrases');
        component.intentId = 1;
        component.addArray = [
            { dummyData: '1', trainingPhraseDisplay: 'trainingPhraseDisplay' },
            { dummyData: '2', trainingPhraseDisplay: 'trainingPhraseDisplay' }
        ];

        component.saveAddedTrainingPhrases();

        expect(spinnerShowSpy).toHaveBeenCalledBefore(spinnerHideSpy);
        expect(spinnerHideSpy).toHaveBeenCalled();
        expect(component.modalHeader).toEqual('Info');
        expect(component.modalMsg).toEqual('Phrases added successfully');
        expect(modalShowSpy).toHaveBeenCalled();
        expect(displayTrainingPhrasesSpy).toHaveBeenCalled();
        expect(addPhrasesSpy).toHaveBeenCalled();
        expect(component.addArray).toEqual([]);
        expect(component.addForm.controls['addtext'].value).toEqual(null);
        expect(component.checkEdited).toEqual([]);
    });

    it('saveAddedTrainingPhrases should not call displayTrainingPhrases and addPhrases when API respone has error and open Info modal', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const modalShowSpy = spyOn(TestBed.get(BsModalService), 'show');
        const spinnerShowSpy = spyOn(spinner, 'show');
        const spinnerHideSpy = spyOn(spinner, 'hide');
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        const addPhrasesSpy = spyOn(component, 'addPhrases');
        component.intentId = 2;
        component.addArray = [
            { dummyData: '1', trainingPhraseDisplay: 'trainingPhraseDisplay' },
            { dummyData: '2', trainingPhraseDisplay: 'trainingPhraseDisplay' }
        ];

        component.saveAddedTrainingPhrases();

        expect(spinnerShowSpy).toHaveBeenCalledBefore(spinnerHideSpy);
        expect(spinnerHideSpy).toHaveBeenCalled();
        expect(component.modalHeader).toEqual('Warning');
        expect(component.modalMsg).toEqual('Error when adding phrases');
        expect(modalShowSpy).toHaveBeenCalled();
        expect(displayTrainingPhrasesSpy).toHaveBeenCalledTimes(0);
        expect(addPhrasesSpy).toHaveBeenCalledTimes(0);
        expect(component.addArray).toEqual([]);
        expect(component.addForm.controls['addtext'].value).toEqual(null);
        expect(component.checkEdited).toEqual([]);
    });

    it('saveAddedTrainingPhrases should not call displayTrainingPhrases and addPhrases when API fails or throws an error and open Warning modal', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const modalShowSpy = spyOn(TestBed.get(BsModalService), 'show');
        const spinnerShowSpy = spyOn(spinner, 'show');
        const spinnerHideSpy = spyOn(spinner, 'hide');
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        const addPhrasesSpy = spyOn(component, 'addPhrases');
        component.intentId = 0;
        component.addArray = [
            { dummyData: '1', trainingPhraseDisplay: 'trainingPhraseDisplay' },
            { dummyData: '2', trainingPhraseDisplay: 'trainingPhraseDisplay' }
        ];

        component.saveAddedTrainingPhrases();

        expect(spinnerShowSpy).toHaveBeenCalledTimes(0);
        expect(spinnerHideSpy).toHaveBeenCalledTimes(0);
        expect(component.modalHeader).toEqual('Warning');
        expect(component.modalMsg).toEqual('Internal error');
        expect(modalShowSpy).toHaveBeenCalled();
        expect(displayTrainingPhrasesSpy).toHaveBeenCalledTimes(0);
        expect(addPhrasesSpy).toHaveBeenCalledTimes(0);
        expect(component.addArray).toEqual([]);
        expect(component.addForm.controls['addtext'].value).toEqual(null);
        expect(component.checkEdited).toEqual([]);
    });

    it('onScroll should increment counter call displayTrainingPhrases on API success', () => {
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        component.intentId = 1;
        component.counter = 1;

        component.onScroll();

        expect(component.counter).toEqual(2);
        expect(displayTrainingPhrasesSpy).toHaveBeenCalled();
    });

    it('onScroll should increment counter not call displayTrainingPhrases on API failure', () => {
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        component.intentId = 2;
        component.counter = 1;

        component.onScroll();

        expect(component.counter).toEqual(2);
        expect(displayTrainingPhrasesSpy).toHaveBeenCalledTimes(0);
    });

    it('onScroll should initialize searchText to argument passed and call displayTrainingPhrases on API success', () => {
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        component.intentId = 1;
        const text = 'Hi';

        component.onSearch(text);

        expect(component.searchText).toEqual(text);
        expect(displayTrainingPhrasesSpy).toHaveBeenCalled();
    });

    it('openInfoModal should open modal', () => {
        const modalShowSpy = spyOn(TestBed.get(BsModalService), 'show');

        component.openInfoModal(template);

        expect(modalShowSpy).toHaveBeenCalled();
    });

    it('renderRectangles should call showIntentSlotsDropdown and set posStart to 0', () => {
        const showIntentSlotsDropdownSpy = spyOn(component, 'showIntentSlotsDropdown');
        const event = {
            text: 'Text With Space',
            posStart: 0,
            posEnd: 2,
            viewportRectangle: null,
            hostRectangle: {
                left: 0,
                top: 0,
                width: 0,
                height: 0
            }
        }
        component.renderRectangles(event);

        expect(component.posStart).toEqual(0);
        expect(showIntentSlotsDropdownSpy).toHaveBeenCalled();
    });

    it('renderRectangles should call showIntentSlotsDropdown and set posStart to 1', () => {
        const showIntentSlotsDropdownSpy = spyOn(component, 'showIntentSlotsDropdown');
        const event = {
            text: ' Text With First Space',
            posStart: 0,
            posEnd: 2,
            viewportRectangle: null,
            hostRectangle: {
                left: 0,
                top: 0,
                width: 0,
                height: 0
            }
        };
        component.renderRectangles(event);

        expect(component.posStart).toEqual(1);
        expect(showIntentSlotsDropdownSpy).toHaveBeenCalled();
    });

    it('renderRectangles should not call showIntentSlotsDropdown', () => {
        const showIntentSlotsDropdownSpy = spyOn(component, 'showIntentSlotsDropdown');
        const event = {
            text: ' Text With First Space',
            posStart: 0,
            posEnd: 2,
            viewportRectangle: null,
            hostRectangle: null
        };
        component.renderRectangles(event);

        expect(showIntentSlotsDropdownSpy).toHaveBeenCalledTimes(0);
        expect(component.hostRectangle).toEqual(null);
    });

    it('showIntentSlotsDropdown should not call openSlotsDropdown', () => {
        const openSlotsDropdownSpy = spyOn(component, 'openSlotsDropdown');
        const event = {
            text: ' Text With First Space',
            posStart: 0,
            posEnd: 2,
            viewportRectangle: null,
            hostRectangle: {
                left: 0,
                top: 0,
                width: 0,
                height: 0
            }
        };
        component.valueToEdit = ' Text how are you';
        component.intentSlots = [{ id: 1 }];

        component.renderRectangles(event);
        component.showIntentSlotsDropdown();

        expect(openSlotsDropdownSpy).toHaveBeenCalledTimes(0);
        expect(component.dropdownError).toEqual('Select proper words');
        expect(component.intentSlotList).toEqual([]);
    });

    it('showIntentSlotsDropdown should call openSlotsDropdown', () => {
        const openSlotsDropdownSpy = spyOn(component, 'openSlotsDropdown');
        const event = {
            text: ' Text',
            posStart: 0,
            posEnd: 2,
            viewportRectangle: null,
            hostRectangle: {
                left: 0,
                top: 0,
                width: 0,
                height: 0
            }
        };
        component.valueToEdit = ' Text how are you';
        component.intentSlots = [{ id: 1 }];

        component.renderRectangles(event);
        component.showIntentSlotsDropdown();

        expect(openSlotsDropdownSpy).toHaveBeenCalled();
    });

    it('showIntentSlotsDropdown should not call openSlotsDropdown and set hostRectangle to null', () => {
        const openSlotsDropdownSpy = spyOn(component, 'openSlotsDropdown');
        component.intentSlots = [];
        const event = {
            text: ' Text',
            posStart: 0,
            posEnd: 2,
            viewportRectangle: null,
            hostRectangle: {
                left: 0,
                top: 0,
                width: 0,
                height: 0
            }
        };

        component.renderRectangles(event);
        component.showIntentSlotsDropdown();

        expect(openSlotsDropdownSpy).toHaveBeenCalledTimes(0);
    });

    it('openSlotsDropdown should set intentSlotList length to 2', () => {
        component.intentSlots = [{ id: 1 }, { id: 2 }];

        component.openSlotsDropdown();

        expect(component.dropdownError).toEqual('Choose an Intent slot');
        expect(component.intentSlotList.length).toEqual(2);
    });

    it('getIntentSlotValue should call getPOSTIONoftxt and updateValueToTable', () => {
        const getPOSTIONoftxtSpy = spyOn(component, 'getPOSTIONoftxt');
        const updateValueToTableSpy = spyOn(component, 'updateValueToTable');

        component.getIntentSlotValue('');

        expect(getPOSTIONoftxtSpy).toHaveBeenCalled();
        expect(updateValueToTableSpy).toHaveBeenCalled();
        expect(component.hostRectangle).toEqual(null);
    });

});

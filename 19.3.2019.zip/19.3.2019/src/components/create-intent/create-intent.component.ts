import { Component, OnInit, ViewChild, EventEmitter, Output, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, Form, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { CreateIntentLeftComponent } from './create-intent-left/create-intent-left.component';
import { CreateIntentService } from './create-intent.service';
import { TrainingPhrasesComponent } from './training-phrases/training-phrases.component';
import { CreateIntentRightComponent } from './create-intent-right/create-intent-right.component';
import { ToastrService } from 'ngx-toastr';
import { BsModalService } from "ngx-bootstrap/modal";
import { BsModalRef } from "ngx-bootstrap/modal/bs-modal-ref.service";
import { IntentType, intentTypeList } from "../../app/core/models/intentType";
import { filterByNluConfigured } from '../../app/core/utils/akeira-utils';
import { DebounceClickDirective } from 'src/app/shared/directives/prevent-double-click.directive';
import * as cloneDeep from 'lodash/cloneDeep';
import { ItemsList } from '@ng-select/ng-select/lib/items-list';
declare var $: any;

@Component({
  selector: 'app-create-intent',
  templateUrl: './create-intent.component.html',
  styleUrls: ['./create-intent.component.scss'],
  preserveWhitespaces: false
})
export class CreateIntentComponent implements OnInit {
  showNextBtn: boolean = false;
  isValidFormSubmitted = null;
  intentStatus: any;
  intentResName;
  parentMessage; parentMessageIntentId; 
  @ViewChild("leftPanel", { static: false }) componentLeftPanel: CreateIntentLeftComponent;
  @ViewChild("trainingPhrase", { static: false }) trainingPhraseComponent: TrainingPhrasesComponent;
  @ViewChild("rightPanel", { static: false }) componentRightPanel: CreateIntentRightComponent;

  modalRef: BsModalRef;
  config = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: "my-modaltraining"
  };

  modalRefTrainInput: BsModalRef;
  trainInputconfig = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: "my-modaltraining"
  };
  toastrConfig = {
    timeOut: 3000
  };


  value: any; chId: any; langId: any;
  i; savebtn: boolean;
  intentId; vaRoleId;
  arr: any = [];
  channel: any;
  language: any;
  channels = [];
  languages = [];
  showIntent: boolean;
  showConversation: boolean;
  showAddPhrases: boolean;
  vaRoleDisable;
  enableNext: boolean = false;
  enableCurrentField: boolean = false; conversation: any = []; intentInfoStatus: boolean = false;
  intentDetails: any = []; intentChannels: any = []; checkAddArray: boolean = true; enableConversation: boolean;
  conversationFlowStatus: boolean = false; trainingPhraseStatus: boolean = false;
  trainingPhraseForm: FormGroup;
  intentType: IntentType[] = intentTypeList;
  styles = {
    'border': '1px solid rgb(247, 228, 228)',
    'border-radius': '14px',
    'background': '',
    'color': ''
  };

  constructor(private router: Router, private route: ActivatedRoute, private modalService: BsModalService, private fb: FormBuilder, public createIntentService: CreateIntentService, private toastr: ToastrService) {

    this.trainingPhraseForm = new FormGroup({
      channel: new FormControl(null, Validators.required),
      language: new FormControl(null, Validators.required)
    });

  }

  saveIntentForm: FormGroup;

  public getData(value) {
    this.fetchValuefromLeftPanel(value);
  }
  public getDataGet(value) {
    this.fetchValuefromLeftPanelGet(value);
  }
  public getDataFinalRes(value) {
    this.fetchValuefromLeftPanelFinalRes(value);
  }

  ngOnInit() {
    this.getSystemSlotDropdowns();
    this.intentStatus = "Create Intent"
    this.intentResName = "";
    $(document).on("keypress", "input", function (e) {
      var startPos = e.currentTarget.selectionStart;
      if (e.which === 32 && startPos == 0)
        e.preventDefault();
    });

    $(document).on("keypress", "textarea", function (e) {
      var startPos = e.currentTarget.selectionStart;
      if (e.which === 32 && startPos == 0)
        e.preventDefault();
    });

    this.i = 0;
    this.saveIntentForm = this.fb.group({
      intentName: ['', [Validators.required, this.noWhitespaceValidator, Validators.minLength(2), Validators.maxLength(50)]],
      intentDescription: ['', [Validators.required, this.noWhitespaceValidator, Validators.minLength(2), Validators.maxLength(200)]],
      virtualAgent: ["", [Validators.required]],
      intentType: ["", [Validators.required]]
    });


    this.route.paramMap.subscribe((params: any) => {
      console.log('params -->', params);
      this.intentId = params.params.intId;
      this.vaRoleId = params.params.vaID;
      this.chId = params.params.chId;
      this.langId = params.params.langId;
      console.log(this.chId, this.langId, this.vaRoleId);
      this.intentType = intentTypeList
      this.intentTab();
      this.virtualAgents();

    });

  }

  setStyles() {
    (this.intentInfoStatus == true) ? this.customStylesone() : this.customStylestwo();
    return this.styles;
  }

  setConversationStyles() {
    (this.conversationFlowStatus == true) ? this.customStylesone() : this.customStylestwo();
    return this.styles;
  }

  setPhraseStyles() {
    (this.trainingPhraseStatus == true) ? this.customStylesone() : this.customStylestwo();
    return this.styles;
  }

  customStylesone() {
    this.styles.background = 'rgb(210, 255, 234)',
      this.styles.color = '#4BCB8D';
  }

  customStylestwo() {
    this.styles.background = 'rgb(255, 220, 199)',
      this.styles.color = '#ff6a13';
  }

  receiveData($event) {
    this.checkAddArray = $event;
    console.log(this.checkAddArray);
  }

  getStatusRes($event) {
    this.trainingPhraseStatus = $event;
    console.log(this.trainingPhraseStatus, $event);

  }

  //code to trigger event onselection of language
  languageFilter(language) {
    // this.displayDropdownValues(language)
    this.langId = this.language.langEngId;
    this.channels = language.channels;
    if (this.showConversation === true) {
      this.refreshConversationTemp(this.langId, this.chId);
    }
    else if (this.showAddPhrases === true) {
      this.refreshTrainingPhrases(this.langId, this.chId);
    }

  }
  //code to trigger event onselection of channel
  channelFilter(channelNam) {
      this.componentLeftPanel.isChckChannelWeb(channelNam);
    let channel:any= this.channels.filter(item=>(item.channelName==channelNam));
    this.chId = channel[0].channelId;
    if (this.showConversation === true) {
      this.refreshConversationTemp(this.langId, this.chId);
    }
    else if (this.showAddPhrases === true) {
      this.refreshTrainingPhrases(this.langId, this.chId);
    }
  }

  refreshConversationTemp(langId, chID) {
    this.componentLeftPanel.getConversationList(this.intentId, langId, chID);
  }

  refreshTrainingPhrases(langId, chID) {
    this.trainingPhraseComponent.refreshTrainingPhrase(langId, chID);
  }

  openModalTrainInput(templatetrain: TemplateRef<any>) {
    console.log('train input');
    //this.modalRef = this.modalService.show(templatetrain, this.config);
    this.modalRefTrainInput = this.modalService.show(templatetrain, this.trainInputconfig);
  }
  trainInputEvent() {
    this.createIntentService.addTrainingPhraseDialogFlow(this.langId, this.vaRoleId)
      .subscribe(res => console.log(res),
        (error: any) => {
          console.log(error);
          let responsetxt = error.error.text;
          console.log("responsetxt ", responsetxt);
          // if (responsetxt == 'Trained') {
          //   this.toastr.success('', "Training is Scheduled", this.toastrConfig);
          //}
          if (responsetxt == 'Training in Progress') {
            this.toastr.warning('', "Training in Progress", this.toastrConfig);
          }
          // else {
          //   this.toastr.error('', "Error While scheduling! Try agian later", this.toastrConfig);
          // }
        });
    //this.toastr.success('', "Training is Scheduled", this.toastrConfig);
    this.modalRefTrainInput.hide();
  }

  public noWhitespaceValidator(control: FormControl) {
    const isWhitespace = (control.value || '').trim().length === 0;
    const isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true };
  }
  vaAgents;

  callGetIntentsEditData() {
    if (this.vaRoleId != undefined && this.vaRoleId != null) {
      this.vaRoleDisable = true;
      this.enableNext = true;
      this.getIntentsEdit(this.vaRoleId, this.intentId);
    }
  }

  virtualAgents() {
    this.createIntentService.getVAdetailsByUserId(1)
      .subscribe((response: any) => {
        console.log('response --', response);
        this.vaAgents = filterByNluConfigured(response.virtualAgents);
        this.callGetIntentsEditData();
      })
  }
  getIntentsEdit(roleID, intentID) {
    this.createIntentService.getIntent(roleID, intentID)
      .subscribe((response: any) => {
        this.intentStatus = ""
        this.intentResName = response.intent.intentName;
        this.saveIntentForm.controls['intentName'].setValue(response.intent.intentName);
        this.saveIntentForm.controls['intentDescription'].setValue(response.intent.intentDescription);
        this.saveIntentForm.controls['intentType'].setValue(response.intent.intentType);
        this.saveIntentForm.controls['virtualAgent'].setValue(this.vaRoleId);
        this.intentDetails = response.intent.languages;
        this.displayDropdownValues(this.intentDetails);

        if ((this.saveIntentForm.controls['intentName'].value.length > 1) || ((this.saveIntentForm.controls['intentDescription'].value.length > 1) && (this.saveIntentForm.controls['virtualAgent'].value.length > 1))) {
          this.intentInfoStatus = true;
          console.log('display intent', this.intentInfoStatus, response, this.saveIntentForm.controls['intentName'].value.length);
        }

      });
  }

  displayDropdownValues(intentDetails) {
    console.log('intent',intentDetails);
    this.languages = intentDetails;
    let langObj = this.languages.find(item => item.langEngId == this.langId);
    this.channels = langObj.channels;
    this.language = langObj.langName;
    let channelObj = langObj.channels.find(item => item.channelId == this.chId);
    this.channel = channelObj.channelName;
    // this.channel=2;

  }

  getSelectedText() {
    if (window.getSelection) {
      var selectedText = window.getSelection();
      console.log(selectedText);
    }
  }

  intentTab() {
    this.showIntent = true;
    this.showConversation = false;
    this.showAddPhrases = false;
    if(this.intentId!=undefined){
    this.createIntentService.getIntentConversionList(this.intentId, this.langId, this.chId)
      .subscribe((res: any) => {
        console.log(res);
        this.conversation = res.conversation;
        if (this.conversation != null) {
          let sendFinalResponseArray = this.conversation.conversationStages;
          sendFinalResponseArray.forEach(e => {
            if (e.finalResponse != null) {
              ((e.finalResponse.finalResponseText != null) && (e.finalResponse.finalResponseText.length > 0)) ? (this.conversationFlowStatus = true) : (this.conversationFlowStatus = false);
            }
          });
        }
      });

    let pageNum = 1, searchText = '';
    this.createIntentService.addTrainingPhrase(this.intentId, this.langId, pageNum, searchText).subscribe(responseList => {
      if (responseList['trainingPhrases'] != null) {
        (responseList['trainingPhrases'].length > 0) ? (this.trainingPhraseStatus = true) : (this.trainingPhraseStatus = false);
      }
    });
  }
  }


  conversationTab() {
    console.log("In conversationTab --->");
    if (this.enableNext) {
      this.parentMessage = this.saveIntentForm.value.virtualAgent;
      this.parentMessageIntentId = this.intentId;
      this.showIntent = false;
      this.showConversation = true;
      this.showAddPhrases = false;
    } else {
      this.toastr.warning('', "Intent is not saved");
      return;
    }
    this.arr = [this.intentId, this.langId, this.chId, this.saveIntentForm.controls['virtualAgent'].value];
    console.log(this.arr, this.saveIntentForm.controls['virtualAgent'].value);
  }

  addTab() {
    console.log("In addtab --->");
    this.showIntent = false;
    this.showConversation = false;
    this.showAddPhrases = true;
    this.arr = [this.intentId, this.langId, this.chId, this.saveIntentForm.controls['virtualAgent'].value];
    console.log(this.arr);
  }

  saveasDraft() {
    if (this.showIntent === true) {
      this.saveDraftIntent();
    }
    else if (this.showConversation === true) {
      this.saveDraftConversationTemp();
    }
    else {
      this.saveDraftTrainingPhrases();
    }
  }

  saveDraftIntent() {
    console.log(this.saveIntentForm);
    this.savebtn = true;
    let saveIntent = {
      "intentDescription": this.saveIntentForm.value.intentDescription,
      "intentName": this.saveIntentForm.value.intentName,
      "intentType": this.saveIntentForm.value.intentType,

    }

    if (!this.saveIntentForm.valid) {
      return true;
    }
    if (this.intentId == null || undefined) {
      this.createIntentService.saveCreateIntent(this.saveIntentForm.value.virtualAgent, saveIntent)
        .subscribe((res: any) => {
          if (res.intent != null) {
            if (res.intent.intentName != null) {
              this.toastr.success('', res.intent.intentName + " Intent Created Successfully");
              this.intentResName = res.intent.intentName;
              this.createIntentService.changeMessage("");
              this.enableNext = true;
              this.vaRoleDisable = true;
              this.intentId = res.intent.intentId;
              this.vaRoleId = this.saveIntentForm.value.virtualAgent;
              if (res.intent.languages != undefined) {
                this.langId = res.intent.languages[0].langEngId;
                this.chId = res.intent.languages[0].channels[0].channelId;
              }
              if ((this.saveIntentForm.controls['intentName'].value.length > 1) || ((this.saveIntentForm.controls['intentDescription'].value.length > 1) && (this.saveIntentForm.controls['virtualAgent'].value.length > 1))) {
                this.intentInfoStatus = true;
              }
              this.displayDropdownValues(res.intent.languages);
              console.log('chn,lang', this.langId, this.chId, res, this.saveIntentForm);
            }
          } else {
            this.toastr.success('', res.errorBody.summary);
          }
        });
    } else {
      this.createIntentService.updateCreateIntent(this.saveIntentForm.value.virtualAgent, this.intentId, saveIntent)
        .subscribe(res => {
          this.toastr.success('', " Intent updated Successfully");
        });
    }
    console.log('intent creation params', this.intentId, this.langId, this.chId, this.vaRoleId);
  }


  saveDraftTrainingPhrases() {
    this.trainingPhraseComponent.saveAddedTrainingPhrases();
  }


  getDataR(e) {
    if (e.sendMessage != null) {
      if (e.sendMessage.messageText != null) {
        this.componentLeftPanel.addMsg(e.sendMessage.messageText);
      }
    } else {
      this.componentLeftPanel.getGetInfo(e);
    }
  }

  fetchValuefromLeftPanelGet(e) {
    this.componentRightPanel.bindTempDataGet(e, this.intentId, this.langId, this.chId);
  }
  fetchValuefromLeftPanel(e) {
    this.componentRightPanel.bindTempData(e, this.intentId, this.langId, this.chId);
  }
  fetchValuefromLeftPanelFinalRes(e) {
    this.componentRightPanel.bindTempDataFinalRes(e, this.intentId, this.langId, this.chId);
  }

  isFinalResPresent = []; finalResNewArray = null;

  positionSystmSlt;

  systemslots;
  getSystemSlotDropdowns() {
    this.createIntentService.getSystemSlotDropdown().subscribe((Res: any) => {
      console.log(Res);
      this.systemslots = Res.systemSlotKeys;
    });
  };

  
  saveDraftConversationTemp() {
    let finalReTxt = { "finalResponse": this.componentLeftPanel.finalResponse, "sequenceNumber": 0 };
    (this.componentRightPanel.conversationListRight.conversationStages.length == 0) ? this.componentRightPanel.conversationListRight.conversationStages.push(finalReTxt) : '';
    this.componentRightPanel.conversationListRight.conversationStages.forEach((el, idx) => {
      if (el.finalResponse != null) {
        this.componentLeftPanel.finalResponse.finalResponseId = el.finalResponse.finalResponseId;
        el.finalResponse = this.componentLeftPanel.finalResponse;
        this.isFinalResPresent.push(el);
      }
    });

    if (this.componentLeftPanel.finalResponse.finalResponseText != "") {
      (this.isFinalResPresent.length == 0) ? this.componentRightPanel.conversationListRight.conversationStages.push(finalReTxt) : '';
    }


    this.componentRightPanel.conversationListRight.conversationStages.forEach((el, idx) => {
      if ((el.finalResponse != null) && (el.finalResponse != undefined)) {
        if (el.finalResponse.finalResponseText != "") {
          this.finalResNewArray = el;
          this.componentRightPanel.conversationListRight.conversationStages.splice(idx, 1);
        } else {
          this.componentRightPanel.conversationListRight.conversationStages.splice(idx, 1);
        }
      }
    });

    if (this.finalResNewArray != null) {
      (this.finalResNewArray.finalResponse.finalResponseText == "") ? this.componentRightPanel.conversationListRight.conversationStages : this.componentRightPanel.conversationListRight.conversationStages.push(this.finalResNewArray);
      this.finalResNewArray = null;
    }

    this.componentRightPanel.conversationListRight.conversationStages.forEach((el, idx) => {
      el.sequenceNumber = idx + 1;
    });


    let saveFinalConv=cloneDeep(this.componentRightPanel.conversationListRight);
    saveFinalConv.conversationStages.forEach((el, idx) => {
        if(el.getInfo!=null){
          el.getInfo.positionAndSlots=[];
       this.positionSystmSlt = 0;
       let curMatch;
       while (curMatch =( el.getInfo.promptQuestion.match(/<([^>/]+)>/))) {
         console.log(curMatch[1]);
         var extStr = curMatch[0];
         var extStrP = curMatch[1];
         el.getInfo.promptQuestion =el.getInfo.promptQuestion.replace(extStr, "%"+"pos" + this.positionSystmSlt +"%");
       if (this.systemslots.filter(item => item.systemSlotKeyName == extStrP).length){
         let sysObj= this.systemslots.filter(item => item.systemSlotKeyName == extStrP)
               let systemSlotName = { "position": "pos" + this.positionSystmSlt, systemSlot: { "systemSlotKeyName": extStrP,"systemSlotKeyId":sysObj[0].systemSlotKeyId } };
               el.getInfo.positionAndSlots.push(systemSlotName);
     }
     this.positionSystmSlt++;
     }
        }
    });

    this.createIntentService.saveConversations(saveFinalConv, this.intentId, this.langId, this.chId)
      .subscribe((Res: any) => {
        if ((Res.errorBody != undefined) && (Res.errorBody.summary == "internal error")) {
          this.toastr.warning('', "Data not Saved");
        } else {
          (finalReTxt.finalResponse.finalResponseText.length > 0) ? (this.conversationFlowStatus = true) : (this.conversationFlowStatus = false);
          console.log('final res text', finalReTxt);
          this.toastr.success('', "Saved Successfully");
          this.componentLeftPanel.getConversationList(this.intentId, this.langId, this.chId);
          this.componentRightPanel.getConversationList(this.intentId, this.langId, this.chId);
        }
      });
  }

}

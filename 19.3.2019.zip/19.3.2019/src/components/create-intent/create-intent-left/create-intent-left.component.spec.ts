import { async, ComponentFixture, TestBed,inject } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule,HttpTestingController } from '@angular/common/http/testing';
import { CreateIntentLeftComponent } from './create-intent-left.component';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import {   MatMenuModule, } from '@angular/material';
import { RouterModule } from '@angular/router';
import { APP_BASE_HREF } from '@angular/common';
import { ToastrModule } from 'ngx-toastr';
import { CreateIntentService } from '../create-intent.service';
import { of } from 'rxjs';
declare var $:any;

describe('CreateIntentLeftComponent', () => {
  let _createIntentService;
  let component: CreateIntentLeftComponent;
  let fixture: ComponentFixture<CreateIntentLeftComponent>;

  let systemSlotList={
    "systemSlotKeys": [
      {
        "systemSlotKeyId": 2,
        "systemSlotKeyName": "GroupID"
      },
      {
        "systemSlotKeyId": 1,
        "systemSlotKeyName": "MemberID"
      }
    ]
  };



  let entityList={
    "entities": [
      {
        "entityId": 5,
        "entityName": "Claim_Number"
      },
      {
        "entityId": 1,
        "entityName": "DOB"
      },
      {
        "entityId": 3,
        "entityName": "MTPIN"
      },
      {
        "entityId": 4,
        "entityName": "Phone Number"
      },
      {
        "entityId": 8,
        "entityName": "Policy_Type"
      },
      {
        "entityId": 2,
        "entityName": "SSN"
      },
      {
        "entityId": 7,
        "entityName": "sys.date"
      },
      {
        "entityId": 6,
        "entityName": "sys.number"
      }
    ]
  };
  let conversationList={
    "conversation": {
      "validationIntent": {
        "intentId": 61,
        "intentName": "ClaimS",
        "intentType": null,
        "intentDescription": "Claim status ",
        "virtualAgent": null,
        "businessUnit": null,
        "languages": null
      },
      "systemSlots": [
        {
          "systemSlotId": 42,
          "systemSlotKey": {
            "systemSlotKeyId": 1,
            "systemSlotKeyName": "MemberID"
          }
        },
        {
          "systemSlotId": 43,
          "systemSlotKey": {
            "systemSlotKeyId": 2,
            "systemSlotKeyName": "GroupID"
          }
        }
      ],
      "conversationStages": [
        {
          "sequenceNumber": 1,
          "conversationStageId": 129,
          "sendMessage": null,
          "getInfo": {
            "getInfoId": 38,
            "promptQuestion": "asdf",
            "promptValidationMessage": "asdf",
            "intentSlot": {
              "intentSlotId": 38,
              "intentSlotName": "asdf",
              "intentSlotDescription": "asdf",
              "entity": {
                "entityId": 8,
                "entityName": "Policy_Type"
              }
            }
          },
          "finalResponse": null
        },
        {
          "sequenceNumber": 2,
          "conversationStageId": 159,
          "sendMessage": {
            "messageId": 53,
            "messageText": "dsfgsdg"
          },
          "getInfo": null,
          "finalResponse": null
        },
        {
          "sequenceNumber": 3,
          "conversationStageId": 133,
          "sendMessage": {
            "messageId": 39,
            "messageText": "esarfas"
          },
          "getInfo": null,
          "finalResponse": null
        },
        {
          "sequenceNumber": 4,
          "conversationStageId": 134,
          "sendMessage": {
            "messageId": 40,
            "messageText": "dasfsda"
          },
          "getInfo": null,
          "finalResponse": null
        },
        {
          "sequenceNumber": 5,
          "conversationStageId": 130,
          "sendMessage": null,
          "getInfo": {
            "getInfoId": 39,
            "promptQuestion": "asdf",
            "promptValidationMessage": "asdf",
            "intentSlot": {
              "intentSlotId": 39,
              "intentSlotName": "sdafasd",
              "intentSlotDescription": "asdf",
              "entity": {
                "entityId": 3,
                "entityName": "MTPIN"
              }
            }

          },
          "finalResponse": null
        },
        {
          "sequenceNumber": 6,
          "conversationStageId": 132,
          "sendMessage": null,
          "getInfo": {
            "getInfoId": 40,
            "promptQuestion": "asf",
            "promptValidationMessage": "asf",
            "intentSlot": {
              "intentSlotId": 40,
              "intentSlotName": "new ",
              "intentSlotDescription": "asdf",
              "entity": {
                "entityId": 7,
                "entityName": "sys.date"
              }
            }
          },
          "finalResponse": null
        },
        {
          "sequenceNumber": 7,
          "conversationStageId": 171,
          "sendMessage": null,
          "getInfo": null,
          "finalResponse": {
            "finalResponseId": 67,
            "finalResponseText": "final claim status  %pos0% and  %pos1% intent",
            "positionAndSlots": [
              {
                "finalResponseSlotId": 709,
                "position": "pos1",
                "intentSlot": {
                  "intentSlotId": 40,
                  "intentSlotName": "new ",
                  "intentSlotDescription": "asdf",
                  "entity": {
                    "entityId": 7,
                    "entityName": "sys.date"
                  }
                },
                "responseSlot": null
              },
              {
                "finalResponseSlotId": 708,
                "position": "pos0",
                "intentSlot": null,
                "responseSlot": {
                  "responseSlotId": 39,
                  "responseSlotName": "data",
                  "responseSlotDescription": "dasf"
                }
              }
            ]
          }
        }
      ],
      "responseSlots": [
        {
          "responseSlotId": 39,
          "responseSlotName": "data",
          "responseSlotDescription": "dasf"
        }
      ]
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateIntentLeftComponent ],
      providers: [
        CreateIntentService,
        { provide: APP_BASE_HREF, useValue : '/' },],
      imports: [ 
        BrowserAnimationsModule,
        RouterTestingModule,
        HttpClientTestingModule,
        RouterModule.forRoot([]),
        AccordionModule.forRoot(),
        ToastrModule.forRoot(),
        FormsModule,
        ReactiveFormsModule,
        MatMenuModule,
        NgSelectModule,
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(inject([CreateIntentService], s => {
    _createIntentService=s;
    fixture = TestBed.createComponent(CreateIntentLeftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));


  it("should call getSystemSlotDropdown  and return list", async(() => {
    spyOn(_createIntentService, 'getSystemSlotDropdown').and.returnValue(of(systemSlotList))
    component.getSystemSlotDropdowns();
    spyOn(_createIntentService, 'getEntitys').and.returnValue(of(entityList))
    component.getEntitysDropdowns("2");
    }));

  it('should create', () => {
    expect(component).toBeTruthy();
  }); 

  // it("should call getIntentConversionList and return list", async(() => {
  //   spyOn(_createIntentService, 'getIntentConversionList').and.returnValue(of(conversationList.conversation))
  //   component.getConversationList(78,1,2);
  //   fixture.detectChanges();
  //   }));

  it('check methods left', () => {
    component.isValidationActive=false;
    component.selectedUserIds=[];
  let newGetInfoClearArray = [];
  let sendMessageNewArray =[];



    component.sendMsgIsActive(conversationList.conversation.conversationStages);
    component.changeVal(conversationList.conversation.validationIntent);
    component.onContextMenuAction1("action");
    component.getFinalResDropDown();
    component.getInfoDropDown();
    component.ngChangeGetInfoValMsg("airline",0);
    component.ngChangeGetInfoAskQuest("airline",0); 
    component.ngChangeGetInfoEntity("airline",0);
    component.ngChangeGetInfoDesc("airline",0);
    component.ngChangeGetInfoName("airline",0);
    component.compareSys({"systemSlotKeyId":1,"systemSlotKeyName":"akeria"},{"systemSlotKeyId":1,"systemSlotKeyName":"akeria"});
    component.compareEntity({"entityId":1,"entityName":"DOB"}, {"entityId":1,"entityName":"DOB"});
    component.compareVal({"intentId":1,"intentName":"Airline","intentDescription":"descr"},{"intentId":1,"intentName":"Airline","intentDescription":"descr"});
    component.showDuplicateErrorMsg();
    component.showDuplicateErrorMsgEntity();
    component.getConversationList(78,1,2);
    component.getIntentsDropdowns(1,78);
    // component.getConversationList(78,1,2);
  component.sendFinalResponse(conversationList.conversation);
  component.getFinalResSendMsgTxt();
  component.getInfoActive(conversationList.conversation.conversationStages);
  component.validationIsActive();
  component.checkValidationTab();
  component.validateAddBtn();
  component.validateCancelBtn();
  component.addMsg("validate date of birth");
  component.delMsg(0);
  component.editMsg(1,conversationList.conversation.conversationStages[1]);
  component.updateMsg("new message text");
  component.sendMsgFunc();
  component.sendMsgClearBtn();
  // component.getGetInfo(conversationList.conversation.conversationStages);
  // component.addInfoSlot();
  component.checkEmpty(null);
  component.addInfoSotConditionChk();
  component.showGetInfoErr();
  component.removeInfoSlot(0);
  component.getInfoBtn();
  component.duplicateGetInfo();
  component.getInfoDataPush();
  component.getInfoClearBtn();
  component.addResSlot();
  component.removeResSlot(0);
  component.SendTxtMsg();

    // component.getConversationList(78,1,2);
    // component.bindTempDataFinalRes(conversationList.conversation,78,1,2);
    // component.bindTempDataGet(conversationList.conversation,78,1,2);
    // component.bindTempData(conversationList.conversation,78,1,2)
  });

  it('should check method add info slot', () => {
    component.addInfoSlot();
  });
});

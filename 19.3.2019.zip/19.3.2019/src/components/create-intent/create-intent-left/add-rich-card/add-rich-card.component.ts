import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
// import { RichCardDialogComponent } from '../../rich-card-dialog/rich-card-dialog.component';
@Component({
  selector: 'app-add-rich-card',
  templateUrl: './add-rich-card.component.html',
  styleUrls: ['./add-rich-card.component.scss']
})
export class AddRichCardComponent implements OnInit {
  showRchCrdbtn:boolean=false;
  
constructor(public dialog: MatDialog) { }
dynamicArray: Array<any> = [];  
newDynamic: any = {}; 

 ngOnInit() {
  this.newDynamic = {label: "", value: ""};  
      this.dynamicArray.push(this.newDynamic); 
  }



  addSlotlabel(i){
    if(this.dynamicArray.length<5){
    this.newDynamic = {label: "", value: ""};  
    this.dynamicArray.push(this.newDynamic);  
    console.log(this.dynamicArray);  
    return true;  
    }
  }
  deleteRow(index) {  
    if(this.dynamicArray.length ==1) {  
        return false;  
    } else {  
        this.dynamicArray.splice(index, 1);  
        return true;  
    }  
}  

showAlert(dd){
  alert("kko")
}

}

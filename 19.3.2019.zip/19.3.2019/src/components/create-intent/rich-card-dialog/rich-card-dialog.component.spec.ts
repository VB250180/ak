import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RichCardDialogComponent } from './rich-card-dialog.component';

describe('RichCardDialogComponent', () => {
  let component: RichCardDialogComponent;
  let fixture: ComponentFixture<RichCardDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RichCardDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RichCardDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit, Output, EventEmitter, Input, ViewChild } from '@angular/core';
import { CreateIntentService } from '../create-intent.service';
// import { CreateIntentLeftComponent } from '../create-intent-left/create-intent-left.component';

@Component({
    selector: 'app-rich-card-dialog',
    templateUrl: './rich-card-dialog.component.html',
    styleUrls: ['./rich-card-dialog.component.scss']
})
export class RichCardDialogComponent implements OnInit {
    displayhtml;
constructor(public _createIntentService:CreateIntentService) { }
ngOnInit() {
    this.intentSlotRichCardTemplatesGetInfo();
    this.intentResponseRichCardTemplatesFinalRes();
}

intentSlotRichCardTemplatesGetInfo(){
    this._createIntentService.intentSlotRichCardTemplatesGetInfo()
    .subscribe((res:any)=>{
this.displayhtml =res.intentSlotRichCardTemplates;
    });
}

intentResponseRichCardTemplatesFinalRes(){
    this._createIntentService.intentSlotRichCardTemplatesGetInfo()
    .subscribe((res:any)=>{
this.displayhtml =res.intentSlotRichCardTemplates;
    });
}


    // testhtml: any = {

    //     "richCardTemplates": [

    //         {

    //             "templateId": 1,

    //             "templateName": "Rich Card 1",

    //             "templateHtml": "<div style='padding: 0;list-style: none;align-items: center;justify-content: center;'><div style='width:100%;text-align:center'><span style='padding: 5%;width: 100%;height: 100%;line-height: 50px;color: #000000;font-weight: 500;text-align: center;'>First Name</span></div><div style='width:100%;text-align:center'><span style='padding: 0%;width: 100%;height: 100%;line-height: 50px;color: #999999;font-weight: 500;text-align: center;'>Relation Ship</span></div></div>",

    //             "manipulateHtml": {

    //                 "elementKey": [

    //                     "staticTxtBold",

    //                     "staticTxtLight"

    //                 ],

    //                 "html": "<div style='padding: 0;margin: 13%;list-style: none;display: flex;align-items: center;justify-content: center;'><div style='width:100%;text-align:center'>~staticTxtBold~</div><div style='width:100%;text-align:center'>~staticTxtLight~</div></div>",

    //                 "staticTxtBold": {

    //                     "remderHtml": "<span style='padding: 5%;width: 100%;height: 100%;line-height: 50px;color: #000000;font-weight: bold;text-align: center;'>~value~</span>",

    //                     "limit": 1,

    //                     "key": [

    //                         "value"

    //                     ],

    //                     "editField": {

    //                         "type": "input",

    //                         "placeholder": "Enter a primary text or Choose a slot",

    //                         "maxlength": "",

    //                         "minlength": "",

    //                         "isSlotNeed": true,

    //                         "spellcheck": false

    //                     }

    //                 },

    //                 "staticTxtLight": {

    //                     "remderHtml": "<span style='padding: 5%;width: 100%;height: 100%;line-height: 50px;color: #999999;font-weight: bold;text-align: center;'>~value~</span>",

    //                     "limit": 1,

    //                     "key": [

    //                         "value"

    //                     ],

    //                     "editField": {

    //                         "type": "input",

    //                         "placeholder": "Enter a secondary text or Choose a slot",

    //                         "maxlength": "",

    //                         "minlength": "",

    //                         "isSlotNeed": true,

    //                         "spellcheck": false

    //                     }

    //                 }

    //             }

    //         },

    //         {

    //             "templateId": 2,

    //             "templateName": "Rich Card 2",

    //             "templateHtml": "<section style='height:100%;display:table;width:100%;'><div class='d-flex justify-content-between' style='padding: 7px;'><small class='mb-0-text-mut slot' style='color: #999999;padding-right: 36px;font-size: 12px;'>Slot1:</small><small class='mb-0 label'>Label 1</small></div><div class='d-flex justify-content-between' style='padding: 7px;'><small class='mb-0-text-mut slot' style='color: #999999;padding-right: 36px;font-size: 12px;'>Slot2:</small><small class='mb-0 label'>Label 2</small></div><div class='d-flex justify-content-between' style='padding: 7px;'><small class='mb-0-text-mut slot' style='color: #999999;padding-right: 36px;font-size: 12px;'>Slot3:</small><small class='mb-0 label'>Label 3</small></div></section>",

    //             "manipulateHtml": {

    //                 "elementKey": [

    //                     "slotLabelAry"

    //                 ],

    //                 "html": "<section style='height:100%;display:table;width:100%;'><div style=' display:table-cell;text-align:center;vertical-align: middle;padding: 1rem;color:#000000'>~slotLabelAry~</div></section>",

    //                 "slotLabelAry": {

    //                     "remderHtml": "<div style='float:left'>~labelVal~</div><div style='float: right'>~slotVal~</div><div style='clear:both'></div>",

    //                     "limit": 5,

    //                     "key": [

    //                         "labelVal",

    //                         "slotVal"

    //                     ],

    //                     "editField": {

    //                         "type": "inputLabelSlot",

    //                         "placeholderLabel": "Enter a text or Choose a slot",

    //                         "placeholderSlot": "Enter a text or Choose a slot",

    //                         "maxlength": "",

    //                         "minlength": "",

    //                         "isSlotNeed": true,

    //                         "spellcheck": false

    //                     }

    //                 }

    //             }

    //         },

    //         {

    //             "templateId": 3,

    //             "templateName": "Rich Card 3",

    //             "templateHtml": "<div style='border-radius:10px;overflow:hidden;'><img src='https://www.w3schools.com/css/img_5terre.jpg' alt='Cinque Terre' style='height:77px;width:100%' ><small style='padding:0px;text-align:center;font-weight:500; font-size: 11px;'>Slot for Image description</small></div>",

    //             "manipulateHtml": {

    //                 "elementKey": [

    //                     "imageURL",

    //                     "staticTxtBold"

    //                 ],

    //                 "html": "<div style='border-radius:10px;background:#f1f1f1;overflow:hidden;'>~imageURL~~staticTxtBold~</div>",

    //                 "imageURL": {

    //                     "remderHtml": "<img src='~url~' style='overflow: hidden;width:100%; height:50%;'/>",

    //                     "limit": 1,

    //                     "key": [

    //                         "url"

    //                     ],

    //                     "editField": {

    //                         "type": "inputImage",

    //                         "placeholder": "Image slots",

    //                         "maxlength": "",

    //                         "minlength": "",

    //                         "isSlotNeed": true,

    //                         "spellcheck": false

    //                     }

    //                 },

    //                 "staticTxtBold": {

    //                     "remderHtml": "<div style='padding:15px;text-align:center;'>~value~</div>",

    //                     "limit": 1,

    //                     "key": [

    //                         "value"

    //                     ],

    //                     "editField": {

    //                         "type": "input",

    //                         "placeholder": "Enter a primary text or Choose a slot",

    //                         "maxlength": "",

    //                         "minlength": "",

    //                         "isSlotNeed": true,

    //                         "spellcheck": false

    //                     }

    //                 }

    //             }

    //         },

    //         {

    //             "templateId": 4,

    //             "templateName": "Rich Card 4",

    //             "templateHtml": "<div style='border-radius:10px;overflow:hidden;'><img src='https://www.w3schools.com/css/img_5terre.jpg' alt='Cinque Terre' style='height:45px;width:100%' ><small style='padding:0px;text-align:center;font-weight:500; font-size: 11px;'>Slot for Image description</small><div class='d-flex justify-content-between' style='padding: 0px 7px;'><small class='mb-0-text-mut slot' style='color: #999999;padding-right: 36px;font-size: 12px;'>Slot1:</small><small class='mb-0 label'>Label 1</small></div><div class='d-flex justify-content-between' style='padding:0px 7px;'><small class='mb-0-text-mut slot' style='color: #999999;padding-right: 36px;font-size: 12px;'>Slot2:</small><small class='mb-0 label'>Label 2</small></div></div>",

    //             "manipulateHtml": {

    //                 "elementKey": ["imageURL", "staticTxtBold", "slotLabelAry"],

    //                 "html": "<div style='border-radius: 10px;background: #f1f1f1;'>~imageURL~~staticTxtBold~<section style=' display: table;width: 100%;'> <div style=' text-align: center; vertical-align: middle; padding: 1rem;color:#000000'>~slotLabelAry~</section></div>",

    //                 "imageURL": {

    //                     "remderHtml": "<img src='~url~' style='overflow: hidden;width:100%; height:50%;'/>",

    //                     "limit": 1,

    //                     "key": [

    //                         "url"

    //                     ],

    //                     "editField": {

    //                         "type": "inputImage",

    //                         "placeholder": "Image slots",

    //                         "maxlength": "",

    //                         "minlength": "",

    //                         "isSlotNeed": true,

    //                         "spellcheck": false

    //                     }

    //                 },

    //                 "staticTxtBold": {

    //                     "remderHtml": "<div style='padding:15px;text-align:center;'>~value~</div>",

    //                     "limit": 1,

    //                     "key": [

    //                         "value"

    //                     ],

    //                     "editField": {

    //                         "type": "input",

    //                         "placeholder": "Enter a primary text or Choose a slot",

    //                         "maxlength": "",

    //                         "minlength": "",

    //                         "isSlotNeed": true,

    //                         "spellcheck": false

    //                     }

    //                 },

    //                 "slotLabelAry": {

    //                     "remderHtml": "<div style='float:left'>~labelVal~</div><div style='float: right'>~slotVal~</div><div style='clear:both'></div>",

    //                     "limit": 5,

    //                     "key": [

    //                         "labelVal",

    //                         "slotVal"

    //                     ],

    //                     "editField": {

    //                         "type": "inputLabelSlot",

    //                         "placeholderLabel": "Enter a text or Choose a slot",

    //                         "placeholderSlot": "Enter a text or Choose a slot",

    //                         "maxlength": "",

    //                         "minlength": "",

    //                         "isSlotNeed": true,

    //                         "spellcheck": false

    //                     }

    //                 }

    //             }

    //         }

    //     ]

    // }
    // @ViewChild(AddRichCardComponent, {static: false}) hello: AddRichCardComponent;

    // @ViewChild("AddRichCardComponent", { static: false }) AddRichCardComponent: AddRichCardComponent;
    // constructor(private comp:CreateIntentLeftComponent) { }




}

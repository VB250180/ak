import { Component,  NgModule, OnInit,  TemplateRef  } from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule, FormsModule, Validators} from '@angular/forms';
import {NgSelectModule, NgOption} from '@ng-select/ng-select';

import { AssistedTrainingService } from './assisted-training.service';
import { NgxSpinnerService } from "ngx-spinner";
import { BsDropdownConfig } from 'ngx-bootstrap/dropdown';

import { first } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import * as moment from 'moment';


@Component({
  selector: 'app-assisted-training',
  templateUrl: './assisted-training.component.html',
  styleUrls: ['./assisted-training.component.scss'],
  providers: [{ provide: BsDropdownConfig, useValue: { autoClose: false } }]
})
export class AssistedTrainingComponent implements OnInit {
  cities2 = [
    { id: 1, name: 'Coverage Details' },
    { id: 2, name: 'Out Of Pocket' },
    { id: 3, name: 'Out Of Order', disabled: true },
    { id: 4, name: 'Benefits Details' },
    { id: 5, name: 'Order Of Installment' }
  ];

  alwaysShowCalendars: boolean;
  showRangeLabelOnInput: boolean;
  keepCalendarOpeningWithRange: boolean;
  
  minDate: moment.Moment = moment().subtract(6, 'days');
  maxDate: moment.Moment = moment().add(2, 'month');

  ranges: any = [moment().subtract(6, 'days'), moment()];
  selected = {start: moment().subtract(6, 'days'), end: moment() };


  modalRef: BsModalRef;
  config = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: "my-modal"
  };

  unmapped_Id:any;
  selectedCity: any;
  selectedCityIds: string[];
  selectedCityName = 'Vilnius';
  selectedCityId: number;
  selectedUserIds: number[];


  AssistedTrainingForm: FormGroup;
  serviceValue: any;
  channelValues: any = [];
  languageValues: any = [];
  statusValue: any = [];
  status: any;
  filterValues: any;
  isLoaded: boolean = false;
  options: any = [];
  channels: any = [];
  languages: any = [];
  conversationList: any;
  listDetails: any;
  scopeInputs: any = [];
  mappedInputs: any = [];
  outscopeInputs: any = [];
  allInputs: any = [];
  sessionId: any = [];
  scopeLength: any;
  mappedLength: any;
  outscopeLength: any;
  display: boolean = false;
  events: Event[] = [];
  mwidth : number;
  swidth : number;
  owidth : number;
  dateLimit: number;


  constructor(private trainingService: AssistedTrainingService, private spinner: NgxSpinnerService,private modalService: BsModalService) {
    this.AssistedTrainingForm = new FormGroup({
      status: new FormControl(null, Validators.required),
      channel: new FormControl(null, Validators.required),
      language: new FormControl(null, Validators.required),
    });
    this.alwaysShowCalendars = true;
    this.dateLimit = 7;
  }

  ngOnInit() {
    this.spinner.show();
    this.trainingService.getInputs().subscribe((res: any[]) => {
      this.serviceValue = res['virtualAgents'];
      this.filterValues = this.serviceValue;
      console.log(res['virtualAgents']);
    },
      err => console.error(err));

    this.trainingService.getConversationList().subscribe((list: any[]) => {
      this.conversationList = list;
    });


    setTimeout(() => {
      console.log(this.serviceValue);
      console.log(this.conversationList);
      this.dropdownValues();
      this.conversationListDetails();
      this.spinner.hide();
    }, 1000);

  }

  dropdownValues() {
    this.isLoaded = true;
    this.serviceValue.forEach(options => {
      this.options.push(options.virtualAgent);
    });
  }

  rangeClicked(date, event){
    console.log('date selected',date ,  event);
  }

  


  statusFilter(status) {
    this.AssistedTrainingForm.setValue({
      status: this.AssistedTrainingForm.controls.status.value,
      channel: null,
      language: null
    });

    this.channels = []; this.languages = [];
    for (let q = 0; q < this.serviceValue.length; q++) {
      if (this.serviceValue[q].virtualAgent.value == status.value) {
        for (let j = 0; j < this.serviceValue[q].channels.length; j++) {
          this.channels.push(this.serviceValue[q].channels[j]);
        }
        for (let j = 0; j < this.serviceValue[q].languages.length; j++) {
          this.languages.push(this.serviceValue[q].languages[j]);
        }
      }
    }

    if (this.channels.length == 1 && this.languages.length == 1) {
      this.AssistedTrainingForm.patchValue({
        channel: this.channels[0].value,
        language: this.languages[0].value,
      });
    }
    else if (this.channels.length == 1) {
      this.AssistedTrainingForm.patchValue({
        channel: this.channels[0].value,
      });
    }

  }

  channelFilter(VA) {

    for (let q = 0; q < this.serviceValue.length; q++) {
      if (this.serviceValue[q].virtualAgent.value == VA.value) {
        for (let j = 0; j < this.serviceValue[q].languages.length; j++) {
          this.languageValues.push(this.serviceValue[q].languages[j]);
        }
      }
    }

    if (this.languages.length == 1) {
      this.AssistedTrainingForm.patchValue({
        language: this.languages[0].value,
      });
    }
  }

  languageFilter(language) {
    console.log(language);
    this.display = false;
  }

  conversationListDetails() {
   this.mwidth = this.conversationList.mappedCount;
   this.swidth = this.conversationList.inScopeCount  ;
   this.owidth = this.conversationList.outOfScopeCount;
    console.log(this.conversationList.inScopeCount,this.conversationList.mappedCount,this.conversationList.outOfScopeCount);

    this.allInputs = this.conversationList.conversationList;
    for (let k = 0; k < this.conversationList.conversationList.length; k++) {
      this.sessionId = this.conversationList.conversationList[k].sessionId;
      for (let j = 0; j < this.conversationList.conversationList[k].inScopePhrases.length; j++) {
        this.scopeInputs.push(this.conversationList.conversationList[k].inScopePhrases[j]);
      }
      for (let j = 0; j < this.conversationList.conversationList[k].mapppedPhrases.length; j++) {
        this.mappedInputs.push(this.conversationList.conversationList[k].mapppedPhrases[j]);
      }
      for (let j = 0; j < this.conversationList.conversationList[k].outOfScopePhrases.length; j++) {
        this.outscopeInputs.push(this.conversationList.conversationList[k].outOfScopePhrases[j]);
      } console.log(this.mappedInputs, this.conversationList.conversationList[0].mapppedPhrases[0])
    }
  }


  expandPanel(input) {
    this.display = true;
    console.log(input);
    this.scopeInputs = []; this.mappedInputs = []; this.outscopeInputs = [];

    this.allInputs = this.conversationList.conversationList;
    for (let k = 0; k < this.conversationList.conversationList.length; k++) {
      if (input === this.conversationList.conversationList[k].sessionId) {
        console.log(input, this.conversationList.conversationList[k].sessionId)
        for (let j = 0; j < this.conversationList.conversationList[k].inScopePhrases.length; j++) {
          this.scopeInputs.push(this.conversationList.conversationList[k].inScopePhrases[j]);
          this.scopeLength = this.scopeInputs.length;
        }
        for (let j = 0; j < this.conversationList.conversationList[k].mapppedPhrases.length; j++) {
          this.mappedInputs.push(this.conversationList.conversationList[k].mapppedPhrases[j]);
          this.mappedLength = this.mappedInputs.length;
        }
        for (let j = 0; j < this.conversationList.conversationList[k].outOfScopePhrases.length; j++) {
          this.outscopeInputs.push(this.conversationList.conversationList[k].outOfScopePhrases[j]);
          this.outscopeLength = this.outscopeInputs.length;
        }
      }
    }
  }

  // deleteUnmappedUser() {  
  //   this.trainingService.deleteUnmappedUserInputs(this.unmapped_Id)
  //   .subscribe(res =>{
  //        this.modalRef.hide();
  //        this.unmapped_Id=null;
  //     // let indexOfItem = this.userPosts.indexOf(post);  
  //   //       this.userPosts.splice(indexOfItem, 1);  
  //   //       console.log(this.userPosts.length);  
  //   });

  //   }
  openModal(template: TemplateRef<any>,id) {
    this.unmapped_Id=id;
    this.modalRef = this.modalService.show(template);
  }


  openModals(template2: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template2, this.config);
}
}

import { Component, OnInit } from '@angular/core';
import { Validation } from './model/create-intent';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-create-intent',
  templateUrl: './create-intent.component.html',
  styleUrls: ['./create-intent.component.scss']
})
export class CreateIntentComponent implements OnInit {
  // createIntent= new CreateIntent();
  validation= new Validation();
  channels : any = [{id:1, value:"IVR"},{id:2, value:"Web"},{id:1, value:"Mobile"}];
  languages : any = [{id:1, value:"English"},{id:2, value:"Spanish"},{id:1, value:"English(US)"}];
  agents : any = [{id:1, value:"VA_one"},{id:2, value:"VA_two"},{id:1, value:"VA_three"}];
  units : any = [{id:1, value:"Health care"}];

  channel : any;
  language : any;
  agent:any;
  unit:any;

  selected:any;
  
  showIntent : boolean = true;
  showConversation : boolean = false;
  showAddPhrases : boolean = false;

  constructor() { }

  ngOnInit() {
  }

  intentTab(){
    this.showIntent = true;
    this.showConversation = false;
    this.showAddPhrases = false;
  }

  conversationTab(){
    this.showIntent = false;
    this.showConversation = true;
    this.showAddPhrases = false;
  }

  addTab(){
    this.showIntent = false;
    this.showConversation = false;
    this.showAddPhrases = true;
  }
  sample(createIntent){
    debugger;
    // this.createIntent.validation;
    this.validation;
    // this.createIntent.validation.channel;
  }
}

import { Component, OnInit } from '@angular/core';
import { ChartType, ChartDataSets, ChartOptions } from 'chart.js';
import { MultiDataSet, Label, Color, BaseChartDirective } from 'ng2-charts';
// import * as pluginAnnotations from 'chartjs-plugin-annotation';

@Component({
  selector: 'app-agent-list',
  templateUrl: './agent-list.component.html',
  styleUrls: ['./agent-list.component.scss']
})
export class AgentListComponent implements OnInit {
  public doughnutChart1Labels: Label[] = ['', ''];
  public doughnutChart1Data: MultiDataSet = [
    [75, 25]
  ];
  public doughnutChart1Options: any = {
    cutoutPercentage: 90,
    elements: {
      arc: {
        borderWidth: 0
      }
    }
  };

  public pieChart1Colors = [
    {
      backgroundColor: ['#57E0D8', 'rgba(87, 224, 216, 0.1)'],
    },
  ];

  public pieChart2Colors = [
    {
      backgroundColor: ['#B1A3F9', 'rgba(177, 163, 249, 0.1)'],
    },
  ];

  public doughnutChartType: ChartType = 'pie';
  public pieChartLegend = false;


  public lineChartData: ChartDataSets[] = [
    { data: [5, 10, 7, 12, 14, 11, 15], label: 'Series A' }
  ];

  public lineChartLabels: Label[] = ['', '', '', '', '', '', ''];

  public lineChartOptions: (ChartOptions) = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      xAxes: [{
        gridLines: {
          display: false,
          drawBorder: false
        },
      }],
      yAxes: [{
        gridLines: {
          display: false,
          drawBorder: false
        },
        ticks: {
          beginAtZero: true,
          callback: function(value, index, values) {
              return '';
          },
        }
      }]
    },
    // annotation: {
    //   annotations: [
    //     {
    //       type: 'line',
    //       mode: 'vertical',
    //       scaleID: 'x-axis-0',
    //       value: 'March',
    //       borderColor: 'orange',
    //       borderWidth: 2,
    //       label: {
    //         enabled: true,
    //         fontColor: 'orange',
    //         content: 'LineAnno'
    //       }
    //     },
    //   ],
    // },
  };
  public lineChartColors: Color[] = [
    {
      backgroundColor: 'rgba(87, 224, 216, 0.1)',
      // background: linear-gradient(180deg, #57E0D8 0%, rgba(87,224,216,0) 100%),
      borderColor: '#57E0D8',
      pointBackgroundColor: '#57E0D8',
      pointBorderColor: '#57E0D8',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: '#57E0D8'
    }
  ];
  public lineChartLegend = false;
  public lineChartType = 'line';
  // public lineChartPlugins = [pluginAnnotations];


  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, Form, Validators } from '@angular/forms';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';


@Component({
  selector: 'app-create-intent',
  templateUrl: './create-intent.component.html',
  styleUrls: ['./create-intent.component.scss']
})
export class CreateIntentComponent implements OnInit {

  channels : any = [{id:1, value:"IVR"},{id:2, value:"Web"},{id:1, value:"Mobile"}];
  languages : any = [{id:1, value:"English"},{id:2, value:"Spanish"},{id:1, value:"English(US)"}];
  agents : any = [{id:1, value:"VA_one"},{id:2, value:"VA_two"},{id:1, value:"VA_three"}];
  units : any = [{id:1, value:"Health care"}];
  entities : any = [{id:1,value:"Date of Birth"},{id:2,value:"OTP"},{id:3,value:"Departure Date"}]
  systemslots : any =[{id:1,value:"Member Id(unique)"},{id:2,value:"Account number"}] 

  channel : any;
  language : any;
  agent:any;
  unit:any;
  msg:any;
  msgValue:any;
  msgenteredValue:any;

  selected:any;
  
  showIntent : boolean = true;
  showConversation : boolean = false;
  showAddPhrases : boolean = false;
  audioupload : boolean = true;
  showCreateSlot : boolean = false;

  constructor(private fb: FormBuilder) { }

  validationForm : FormGroup;
  sendMessageForm : FormGroup;
  getInfoForm : FormGroup;
  finalResponseForm : FormGroup;

  ngOnInit() {
    this.validationForm = this.fb.group({
      slot_values: this.fb.array([this.fb.group({slot:''})])
    }),
    this.sendMessageForm = this.fb.group({
      msg : ['',Validators.required] 
    })
this.items;

  }

  get slotValues() {
    return this.validationForm.get('slot_values') as FormArray;
  }

  addSlotValue() {
    this.slotValues.push(this.fb.group({slot:''}));
  }

  deleteSlotValue(index) {
    this.slotValues.removeAt(index);
  }

  slotSelected(slot,id){
    console.log(slot.target.value,id);
    if(slot.target.value){
      console.log(slot)
      this.addSlotValue();
    }
  }

  msgentered(msg){
    this.msgenteredValue = msg;
  }

  addMsg(){
    this.msgValue = this.msgenteredValue;
    this.sendMessageForm.patchValue({
      msg : ''
    })
  }

  delMsg(){
    this.msgValue = '';
  }

  addIntentSlot(){
   this.showCreateSlot = true;
  }

  intentTab(){
    this.showIntent = true;
    this.showConversation = false;
    this.showAddPhrases = false;
  }

  conversationTab(){
    this.showIntent = false;
    this.showConversation = true;
    this.showAddPhrases = false;
  }

  addTab(){
    this.showIntent = false;
    this.showConversation = false;
    this.showAddPhrases = true;
  }

  uploadAudio(){
    this.audioupload=!this.audioupload;
    console.log('upload');
  }




  items =[ {
       validation: 
         [{label:"Validation Intent:",value:"Date of Birth" }],
         systemSlot:[
           {label:"System Slot:",value:"Member ID"},
           {label:"System Slot:",value:"Group ID"}
         ],
         sendMsg:[
          {label:"Send Message:",value:"sure let me get you that information"},
          {label:"Send Message:",value:"sure let me get you that information"}
        ],
        getInfo:[
          {label:"Get Info:",value:"date of birth",description:"Date when user took medical service",Question:"When did you take the service",validationMsg:"sorry i couldn't find a claim"}
        ]
   }] ;
         
    //  value: 'I can be dragged', disabled: false},
    // {value: 'I cannot be dragged', disabled: true},
    // {value: 'I can also be dragged', disabled: false}
        
newArray=[];
  drop(event: CdkDragDrop<string[]>) {
    debugger;
// this.newArray.push(this.items);
    moveItemInArray(this.items, event.previousIndex, event.currentIndex);
  }


}

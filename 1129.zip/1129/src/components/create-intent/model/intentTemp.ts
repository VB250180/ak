export class ConversationTemp {
    validationIntent?: any;
    systemSlots: SystemSlot[];
    constructor() {
        this.validationIntent={
            intentName:""
        };
       this.systemSlots = new Array<SystemSlot>();
    }
}
export class SystemSlot {
    systemSlotId: number;
    systemSlotKey: {
        systemSlotKeyId: number;
        systemSlotKeyName: string;
    };
}

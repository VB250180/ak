import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateIntentRightComponent } from './create-intent-right.component';
import { HttpClientTestingModule,HttpTestingController } from '@angular/common/http/testing';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { RouterModule } from '@angular/router';
describe('CreateIntentRightComponent', () => {
  let component: CreateIntentRightComponent;
  let fixture: ComponentFixture<CreateIntentRightComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateIntentRightComponent ],
      imports: [ 
        HttpClientTestingModule,
        RouterModule.forRoot([]),
        DragDropModule,
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateIntentRightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

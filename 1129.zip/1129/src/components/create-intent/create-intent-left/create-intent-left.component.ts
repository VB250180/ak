import { Component, OnInit, ViewChild, Output, EventEmitter, Input } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, Form, Validators, SelectControlValueAccessor } from '@angular/forms';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { Conversation, ConversationStage, GetInfo,IntentSlot, SendMessage, intentsDropD, systemSlotDropD, SystemSlot, Entity } from '../model/intent';
import { CreateIntentService } from '../create-intent.service';
import { ActivatedRoute } from '@angular/router';
import { analyzeAndValidateNgModules } from '@angular/compiler';
declare var $: any;
import { NgSelectModule, NgOption } from '@ng-select/ng-select';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-create-intent-left',
  templateUrl: './create-intent-left.component.html',
  styleUrls: ['./create-intent-left.component.scss']
})
export class CreateIntentLeftComponent implements OnInit {
  @Output() public getLeftPanelData = new EventEmitter<any>();
  @Input() childMessage: string;
  isValidationActive: boolean = false;
  isSendMsgActive: boolean = false;
  newSystemSlotArray = new Array<any>();
  selectedUserIds = [];
  activPostIndex = 0;
  conversation = new Conversation();
  sendMessageNewArray: any = [];
  newTempGetInfoArr:any=[];
  getInfoNewArray: any = [];
  systemSlot = new SystemSlot();
  intentSlot=new IntentSlot();
  getInfo = new GetInfo();
  valEntity: intentsDropD;
  entitys: Entity;
  systemslots: systemSlotDropD[];
  intentId; chId; langId; vaRoleId;
  BreakException = {};
  // getInfoArray = {
  //   conversationStageId: null,
  //   finalResponse: null,
  //   getInfo: this.getInfo,
  //   sendMessage: null,
  //   sequenceNumber: null
  // }

  constructor(private route: ActivatedRoute, public createIntentService: CreateIntentService, private toastr: ToastrService) {
    this.route.paramMap.subscribe((params: any) => {
      this.intentId = params.params.intId;
      this.vaRoleId = params.params.vaID;
      this.chId = params.params.chId;
      this.langId = params.params.langId;
      if (this.intentId != undefined) {
        this.getConversationList(this.intentId, this.langId, this.chId);
        this.getIntentsDropdowns(this.vaRoleId);
      }

      //  this.getIntentsEdit(roleId,this.intentId);
    });
  }





  addCustomUser = (term) => ({ systemSlotKeyId: term, systemSlotKeyName: term });

  newArray = []
  getConversationList(intentId, langId, chId) {
    this.createIntentService.getIntentConversionList(intentId, langId, chId)
      .subscribe((res: any) => {
        this.conversation = res.conversation;
        // this.selectedUserIds=this.conversation.systemSlots;
        this.valEntityDropDown = this.conversation.validationIntent;
        this.conversation.systemSlots.forEach((e, i) => {
          this.newArray.push(e.systemSlotKey);
        });

        this.selectedUserIds = this.newArray;
        this.sendMsgIsActive(this.conversation.conversationStages);
        console.log(this.conversation.conversationStages)
        this.validationIsActive();
        this.newArray = [];
        // this.addSlotValue();
      })
  }
  // isOpen: boolean;
  sendMsgIsActive(sendMsgArr) {
    let hasData: number = 0;
    sendMsgArr.forEach((e, i) => { (e.sendMessage != null || undefined) ? hasData += 1 : ''; });
    this.isSendMsgActive = hasData > 0 ? true : false;
  }
  validationIsActive() {
    this.checkValidationTab() ? this.isValidationActive = true : this.isValidationActive = false;
  }

  checkValidationTab() {
    return ((this.valEntityDropDown != undefined) && (this.selectedUserIds.length > 0)) ? true : false;
  }

  ngOnInit() {
    this.getIntentsDropdowns(this.childMessage);
    // this.addSlotValue();
    this.getSystemSlotDropdowns();
    this.getEntitysDropdowns();


    this.createIntentService.currentMessage.subscribe(message => this.message = message)

  }

  newMessage() {
  this.getInfoNewArray;
    this.createIntentService.changeMessage( this.getInfoNewArray)
  }
  // isfOpen(){
  //   this.isOpen=true;
  // }
  // isfOpens(){
  //   this.isOpen=false;
  // }


  // ValidationBlock
  valEntityDropDown;
  changeVal(valEntity) {
    this.valEntityDropDown = valEntity;
  }
  // changeSystemSlot(sysSlot, i) {
  //   debugger
  //   if (this.conversation.systemSlots.length < this.systemslots.length) {
  //     this.addSlotValue()
  //   }
  // }
  // addSlotValue() {
  //   let systemSlot = { systemSlotId: 0, systemSlotKey: { systemSlotKeyId: 0, systemSlotKeyName: "dfasf" } }
  //   this.conversation.systemSlots.push(systemSlot);
  // }
  // deleteSlotValue(index) {
  //   this.conversation.systemSlots.splice(index, 1);
  //   return true;
  // }

  // validateValidationTab(valEntityDropDown, systemslot) {
  //   return false;
  // }
  valSys;
  systemSlotKeyName;

  validateAddBtn() {
    if (this.checkValidationTab()) {
      this.conversation.validationIntent = this.valEntityDropDown;
      this.selectedUserIds.forEach((e, i) => {
        let systemSlot = { systemSlotId: null, systemSlotKey: { systemSlotKeyId: e.systemSlotKeyId, systemSlotKeyName: e.systemSlotKeyName } };
        this.newSystemSlotArray.push(systemSlot);
      });
      this.conversation.systemSlots = this.newSystemSlotArray;
      this.newSystemSlotArray = new Array<any>();
      this.getLeftPanelData.emit(this.conversation);
    } else {
      this.toastr.warning('', "Choose validation Intent and System slot's");
    }
    this.validationIsActive();
  }
  validateCancelBtn() {
    this.conversation.validationIntent = null;
    this.newSystemSlotArray = new Array<any>();
    this.selectedUserIds = this.newSystemSlotArray;
    this.conversation.systemSlots = this.selectedUserIds;
    this.validationIsActive();
  }

  // sendMessageBlock
  sendMsg; msg; changeEditIcon;

  addMsg(msgRef) {
    if (msgRef == "" || undefined) {
      return true;
    }
    this.msg = "";
    this.sendMsg = {
      sendMessage: {
        "messageText": msgRef
      }
    }
    this.conversation.conversationStages.push(this.sendMsg)
    // this.sendMessageNewArray.push(this.sendMsg);
    var myDataM = this.conversation.conversationStages;
    let newConversationSendMsgArray = [...new Map(myDataM.map(obj => [JSON.stringify(obj), obj])).values()];
    this.conversation.conversationStages = [];
    this.conversation.conversationStages = newConversationSendMsgArray;
    this.sendMsgFunc();
  }
  delMsg(i) {
    //  if(i==0){
    //    this.isSendMsgActive=false;
    //  }
    this.conversation.conversationStages.splice(i, 1);
    this.sendMsgFunc();
  }
  editMsg(i, data) {
    this.sendMessageNewArray = [];
    this.msg = data.sendMessage.messageText;
    this.sendMessageNewArray.push(data);
    this.changeEditIcon = true;
  }
  updateMsg(msgReg) {
    if (msgReg == "") {
      this.sendMessageNewArray = [];
      this.changeEditIcon = false;
      this.sendMessageNewArray = [];
    }
    this.sendMessageNewArray.forEach((e, i) => {
      this.conversation.conversationStages.forEach((el, i) => {
        if (e.conversationStageId == el.conversationStageId) {
          e.sendMessage.messageText = msgReg;
          this.msg = "";
          this.sendMessageNewArray = [];
          this.changeEditIcon = false;
          this.sendMessageNewArray = [];
        }
      });
    });
    this.sendMsgFunc()
  }
  sendMsgFunc() {
    this.sendMsgIsActive(this.conversation.conversationStages);
    this.sendMessageNewArray.forEach(e => {
      this.conversation.conversationStages.push(e);
    });
    this.sendMessageNewArray = [];
    var myData = this.conversation.conversationStages;
    this.conversation.conversationStages = [...new Map(myData.map(obj => [JSON.stringify(obj), obj])).values()];
    this.getLeftPanelData.emit(this.conversation);
  }
  newClearArray = [];
  sendMsgClearBtn() {
    this.conversation.conversationStages.forEach((e, i) => {
      (e.sendMessage != null || undefined) ? '' : this.newClearArray.push(e);
      this.conversation.conversationStages = [];
      this.conversation.conversationStages = this.newClearArray;
      this.newClearArray = [];
    });
    this.sendMsgFunc();
    this.sendMsgIsActive(this.conversation.conversationStages);
  }
  // getInfoBlock
  prevAddInfoSlot: Boolean = false;

  getGetInfo(e) {
    this.getInfoNewArray.push(e);
    var myData = this.getInfoNewArray;
    this.getInfoNewArray = [...new Map(myData.map(obj => [JSON.stringify(obj), obj])).values()];
    this.getInfoNewArray.forEach((e, i) => {
      if (e.getInfo.intentSlot.intentSlotName == undefined) {
        this.getInfoNewArray.splice(i, 1)
      } else {
      };
    });
  }
   

  addInfoSlot() {
    let anyGetInfoError:boolean = false;
    this.getInfoNewArray.length == 0? anyGetInfoError = true: '';
    

    // this.getInfoNewArray.forEach(e => {
    //   if (e.getInfo == null) {
    //     this.prevAddInfoSlot = false;
    //   }
    //   if (e.getInfo.intentSlot.intentSlotName == undefined) {
    //     this.prevAddInfoSlot = true;
    //   } else {
    //     this.prevAddInfoSlot = false;
    //   };
    // });

   

    // if (this.prevAddInfoSlot == false) {
    //   let getInfoArray = {
    //     conversationStageId: null,
    //     finalResponse: null,
    //     getInfo: this.getInfo,
    //     sendMessage: null,
    //     sequenceNumber: null
    //   }
    //   this.getInfoNewArray.push(getInfoArray);
    // }
    // this.getInfo = new GetInfo();
    // return true;
    try {
    this.getInfoNewArray.forEach(e => {
      let g = e.getInfo, i = g.intentSlot;
      if (i.entity != undefined) {
        if ((i.entity.entityName != undefined) && (this.checkEmpty(i.intentSlotName)) && (this.checkEmpty(i.intentSlotDescription)) && (this.checkEmpty(g.promptQuestion)) && (this.checkEmpty(g.promptValidationMessage))) {
          anyGetInfoError=true;
        } else {
          anyGetInfoError=false;
          // this.addInfoSotConditionChk();
          this.toastr.warning("Enter all Data");
          throw this.BreakException;
        }
      } else {
        anyGetInfoError=false;
        // this.addInfoSotConditionChk();
         this.toastr.warning("Enter all Data");
         throw this.BreakException;
      }

    });
  } catch (e) {
    if (e !== this.BreakException) throw e;
  }

    if(anyGetInfoError){
      this.getInfo = new GetInfo();
          let getInfoArray = {
                conversationStageId: null,
                finalResponse: null,
                getInfo: this.getInfo,
                sendMessage: null,
                sequenceNumber: null
              }
              debugger;
        this.getInfoNewArray.push(getInfoArray);
        this.newTempGetInfoArr.push(this.newGetArr);

        anyGetInfoError=false;
    }


  
}
checkEmpty(d){
  return d != null && d != '' ? true :false;
}
addInfoSotConditionChk(){

}

  showGetInfoErr() {
    this.toastr.warning("Add all fields")
  }


  removeInfoSlot(i) {
    this.getInfoNewArray.splice(i, 1);
  }
  message:string;
  getInfoFunc() {
    debugger;
    this.getInfoNewArray;
    this.newTempGetInfoArr.forEach((e, i) => {
  this.getInfoNewArray.forEach((el,idx) => {
    if(i==idx){
      debugger;
      el.getInfo.intentSlot.intentSlotName=e.name;
      el.getInfo.intentSlot.intentSlotDescription=e.desc;
          el.getInfo.intentSlot.entity= e.entity;
          el.getInfo.promptQuestion=e.quest;
          el.getInfo.promptValidationMessage=e.val;
    }

  });
    });
    // this.getInfoNewArray.forEach((e, i) => {
    //   if (e.getInfo.intentSlot.intentSlotName == undefined) {
    //     this.getInfoNewArray.splice(i, 1)
    //   } else {
    //     this.conversation.conversationStages.push(e);
    //   }
    // });
    // var myData = this.conversation.conversationStages;
    // this.conversation.conversationStages = [...new Map(myData.map(obj => [JSON.stringify(obj), obj])).values()];

    this.getLeftPanelData.emit(this.getInfoNewArray);

  }




  // ResponseSlot
  addResSlot() {
    let getResSlotArray = {
      responseSlotId: null,
      responseSlotName: "",
      responseSlotDescription: ""
    }
    this.conversation.responseSlots.push(getResSlotArray);
  }

  removeResSlot(i) {
    this.conversation.responseSlots.splice(i, 1);
  }

  getfinalRes() {
    this.getLeftPanelData.emit(this.conversation);
  }


  // dropdownBindvalue
  compareVal(c1: intentsDropD, c2: intentsDropD): boolean {
    return c1 && c2 ? c1.intentId === c2.intentId : c1 === c2;
  }
  compareSys(c1: systemSlotDropD, c2: systemSlotDropD): boolean {
    return c1 && c2 ? c1.systemSlotKeyId === c2.systemSlotKeyId : c1 === c2;
  }
  compareEntity(c1: Entity, c2: Entity): boolean {
    return c1 && c2 ? c1.entityId === c2.entityId : c1 === c2;
  }
  // dropDownValues
  getSystemSlotDropdowns() {
    this.createIntentService.getSystemSlotDropdown().subscribe((Res: any) => {
      this.systemslots = Res.systemSlotKeys;
    });
  };
  getIntentsDropdowns(vaRoleId) {
    this.createIntentService.getIntentsDropdown(vaRoleId).subscribe((Res: any) => {
      this.valEntity = Res.intents;
    });
  }
  getEntitysDropdowns() {
    this.createIntentService.getEntitys().subscribe((Res: any) => {
      this.entitys = Res.entities;
    });
  }
newGetArr= {name:null,desc:null,entity:null,quest:null,val:null};
  // sendMsg, getInfo, FinalResp Block disabled Function


  ngChangeGetInfoName(name,index){
    this.newTempGetInfoArr.forEach((el,idx) => {
      if(index==idx){
        el.name=name;
      }
    });
//     this.getInfoNewArray.forEach((el,idx) => {
//       if(index==idx){
//       el.getInfo.intentSlot.intentSlotName=name;
//       }
// });
  }
  ngChangeGetInfoDesc(name,index){
//     this.getInfoNewArray.forEach((el,idx) => {
//       if(index==idx){
//       el.getInfo.intentSlot.intentSlotDescription=name;
//       }
// });
this.newTempGetInfoArr.forEach((el,idx) => {
  if(index==idx){
    el.desc=name;
  }
});
  }
  ngChangeGetInfoEntity(entity,index){
//     this.getInfoNewArray.forEach((el,idx) => {
//       if(index==idx){
//       el.getInfo.intentSlot.entity=entity;
//       }
// });
this.newTempGetInfoArr.forEach((el,idx) => {
  if(index==idx){
    el.entity=entity;
  }
});
  }
  ngChangeGetInfoAskQuest(name,index){
//     this.getInfoNewArray.forEach((el,idx) => {
//       if(index==idx){
//      el.getInfo.promptQuestion=name;
//       }
// });
this.newTempGetInfoArr.forEach((el,idx) => {
  if(index==idx){
    el.quest=name;
  }
});
  }
  ngChangeGetInfoValMsg(name,index){
//     this.getInfoNewArray.forEach((el,idx) => {
//       if(index==idx){
//       el.getInfo.promptValidationMessage=name;
//       }
// });
this.newTempGetInfoArr.forEach((el,idx) => {
  if(index==idx){
    el.val=name;
  }
});
  }

}

import { TestBed, async, inject } from '@angular/core/testing';

import { CreateIntentService } from './create-intent.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import {HttpClientModule} from '@angular/common/http';
import { of } from 'rxjs';

describe('CreateIntentService', () => {
  let httpClientSpy: { get: jasmine.Spy, post: jasmine.Spy, put: jasmine.Spy };
  let intentService : CreateIntentService


  let intentSlotValues = 
    {
      "virtualAgent": null,
      "virtualAgents": null,
      "intent": null,
      "intents": null,
      "conversation": null,
      "trainingPhrases": null,
      "virtualAgentDashboardResponseObject": null,
      "virtualAgentTrendResponseObject": null,
      "systemSlotKeys": null,
      "count": null,
      "languages": null,
      "channels": null,
      "intentLanguageChannelMaps": null,
      "intentSlots": [
        {
          "intentSlotId": 7,
          "intentSlotName": "To city",
          "intentSlotDescription": "city",
          "entity": {
            "entityId": 1,
            "entityName": "fromPlace"
          }
        },
        {
          "intentSlotId": 6,
          "intentSlotName": "City from",
          "intentSlotDescription": "from city",
          "entity": {
            "entityId": 1,
            "entityName": "fromPlace"
          }
        },
        {
          "intentSlotId": 1,
          "intentSlotName": "fromPlace",
          "intentSlotDescription": "from city",
          "entity": {
            "entityId": 1,
            "entityName": "fromPlace"
          }
        },
        {
          "intentSlotId": 2,
          "intentSlotName": "toPlace",
          "intentSlotDescription": "to city",
          "entity": {
            "entityId": 2,
            "entityName": "toPlace"
          }
        }
      ],
      "entities": null,
      "errorBody": null
    };
   
  let phrases = {
  "virtualAgent": null,
  "virtualAgents": null,
  "intent": null,
  "intents": null,
  "conversation": null,
  "trainingPhrases": [
    {
      "trainingPhraseId": 130,
      "trainingPhraseText": "Book a flight ticket from Singaporee to %pos0%",
      "intentSlotMapPojos": [
        {
          "position": "pos0",
          "value": "newzealand",
          "intentSlot": {
            "intentSlotId": 1,
            "intentSlotName": "fromPlace",
            "intentSlotDescription": "from city",
            "entity": {
              "entityId": 1,
              "entityName": "fromPlace"
            }
          }
        }
      ],
      "trainingPhraseStage": "notTrained"
    },
    {
      "trainingPhraseId": 132,
      "trainingPhraseText": "i want to book a movie ticket from %pos0%",
      "intentSlotMapPojos": [
        {
          "position": "pos0",
          "value": "Bengaluru",
          "intentSlot": {
            "intentSlotId": 1,
            "intentSlotName": "fromPlace",
            "intentSlotDescription": "from city",
            "entity": {
              "entityId": 1,
              "entityName": "fromPlace"
            }
          }
        }
      ],
      "trainingPhraseStage": "notTrained"
    },
    {
      "trainingPhraseId": 135,
      "trainingPhraseText": "agile methodology in akeira 2.0 product %pos1%",
      "intentSlotMapPojos": [
        {
          "position": "pos1",
          "value": "development",
          "intentSlot": {
            "intentSlotId": 7,
            "intentSlotName": "To city",
            "intentSlotDescription": "city",
            "entity": {
              "entityId": 1,
              "entityName": "fromPlace"
            }
          }
        },
        {
          "position": "pos0",
          "value": "list",
          "intentSlot": {
            "intentSlotId": 7,
            "intentSlotName": "To city",
            "intentSlotDescription": "city",
            "entity": {
              "entityId": 1,
              "entityName": "fromPlace"
            }
          }
        }
      ],
      "trainingPhraseStage": "notTrained"
    }],
  "virtualAgentDashboardResponseObject": null,
  "virtualAgentTrendResponseObject": null,
  "systemSlotKeys": null,
  "count": null,
  "languages": null,
  "channels": null,
  "intentLanguageChannelMaps": null,
  "intentSlots": null,
  "entities": null,
  "errorBody": null
  }

  let addPhrases = {
    "virtualAgent": null,
    "virtualAgents": null,
    "intent": null,
    "intents": null,
    "conversation": null,
    "trainingPhrases": [
      {
        "trainingPhraseId": 148,
        "trainingPhraseText": "Book flight ticket from Bengaluru",
        "intentSlotMapPojos": [
          {
            "position": "pos0",
            "value": "Bengaluru",
            "intentSlot": {
              "intentSlotId": 1,
              "intentSlotName": "From place",
              "intentSlotDescription": null,
              "entity": null
            }
          }
        ],
        "trainingPhraseStage": "notTrained"
      }
    ],
    "virtualAgentDashboardResponseObject": null,
    "virtualAgentTrendResponseObject": null,
    "systemSlotKeys": null,
    "count": null,
    "languages": null,
    "channels": null,
    "intentLanguageChannelMaps": null,
    "intentSlots": null,
    "entities": null,
    "errorBody": null
  }

  let addPhrasesBody=[
    {
      "intentSlotMapPojos": [
        {
          "intentSlot": {
            "intentSlotId": 1,
            "intentSlotName": "From place"
          },
          "position": "pos0",
          "value": "Bengaluru"
        }
      ],
      "trainingPhraseId": 0,
      "trainingPhraseText": "Book flight ticket from Bengaluru"
    }
  ]
  

  beforeEach(() =>{ TestBed.configureTestingModule({
    imports: [HttpClientModule,HttpClientTestingModule],
    providers: [CreateIntentService,HttpClientModule]
  }),
  
  httpClientSpy = jasmine.createSpyObj('HttpClient', ['get', 'post', 'put']);
  intentService = new CreateIntentService(<any> httpClientSpy);

});

it(`should create`, async(inject([HttpTestingController, CreateIntentService],
  (httpClient: HttpTestingController , service: CreateIntentService) => {
    expect(httpClient).toBeTruthy();expect(service).toBeTruthy();
})));

  it('should be created', () => {
    const service: CreateIntentService = TestBed.get(CreateIntentService);
    expect(service).toBeTruthy();
  });

  it('check assisted training input', () => {
    httpClientSpy.get.and.returnValue(of(intentSlotValues));
  
    intentService.intentSlots(1,2).subscribe(
      res => {
        expect(res['intentSlots'].length).toBe(4);
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check phrases', () => {
    httpClientSpy.get.and.returnValue(of(phrases));
  
    intentService.addTrainingPhrase(1,2,1,'test').subscribe(
      res => {
        expect(res).toEqual(phrases);
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check adding phrases', () => {
    httpClientSpy.put.and.returnValue(of(addPhrases));
  
    intentService.addPhraseDetails(1,2,addPhrasesBody).subscribe(
      res => {
        expect(res).toEqual(addPhrases);
      },
      fail
    );
    expect(httpClientSpy.put.calls.count()).toBe(1, 'one call');
  });

  it('should have getEntitySerice List', () => {
    const service: CreateIntentService = TestBed.get(CreateIntentService);
    expect(service.getEntitys).toBeTruthy();
   });
   it('should have getIntentConversionList', () => {
    const service: CreateIntentService = TestBed.get(CreateIntentService);
    expect(service.getIntentConversionList).toBeTruthy();
   });
   it('should have getSystemSlotDropdown', () => {
    const service: CreateIntentService = TestBed.get(CreateIntentService);
    expect(service.getSystemSlotDropdown).toBeTruthy();
   });
   it('should have getIntentsDropdown', () => {
    const service: CreateIntentService = TestBed.get(CreateIntentService);
    expect(service.getIntentsDropdown).toBeTruthy();
   });
});

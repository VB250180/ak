import { Component, OnInit, ViewChild, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, Form, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { CreateIntentLeftComponent } from './create-intent-left/create-intent-left.component';
import { CreateIntentService } from './create-intent.service';
import { TrainingPhrasesComponent } from './training-phrases/training-phrases.component';
import { CreateIntentRightComponent } from './create-intent-right/create-intent-right.component';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-create-intent',
  templateUrl: './create-intent.component.html',
  styleUrls: ['./create-intent.component.scss'],
  preserveWhitespaces: false 
})
export class CreateIntentComponent implements OnInit {
  showNextBtn: boolean = false;
  isValidFormSubmitted = null;
  @ViewChild("leftPanel", { static: false }) componentLeftPanel: CreateIntentLeftComponent;
  @ViewChild("trainingPhrase", { static: false }) trainingPhraseComponent: TrainingPhrasesComponent;
  @ViewChild("rightPanel", { static: false }) componentRightPanel: CreateIntentRightComponent;

  value: any; chId: any; langId: any;
  i;
  intentId; vaRoleId;
  arr: any = [];
  channel: any;
  language: any;
  channels = [];
  languages = [];
  showIntent: boolean;
  showConversation: boolean;
  showAddPhrases: boolean;
  vaRoleDisable;
  enableNext: boolean = false;
  enableCurrentField: boolean = false;
  intentDetails: any = []; intentChannels: any = [];
  trainingPhraseForm: FormGroup;
  constructor(private router: Router, private route: ActivatedRoute, private fb: FormBuilder, public createIntentService: CreateIntentService, private toastr: ToastrService) {

    this.route.paramMap.subscribe((params: any) => {
      this.intentId = params.params.intId;
      this.vaRoleId = params.params.vaID;
      this.chId = params.params.chId;
      this.langId = params.params.langId;
      console.log(this.chId, this.langId, this.vaRoleId);
      if (this.vaRoleId != undefined) {
        this.vaRoleDisable = true;
        this.enableNext = true;
        this.getIntentsEdit(this.vaRoleId, this.intentId);
      }
    });

    this.trainingPhraseForm = new FormGroup({
      channel: new FormControl(null, Validators.required),
      language: new FormControl(null, Validators.required)
    });

  }

  saveIntentForm: FormGroup;

  public getData(value) {
    debugger;
    this.fetchValuefromLeftPanel(value);
  }

  ngOnInit() {
    this.i = 0;
    this.saveIntentForm = this.fb.group({
      intentName: ['',  [Validators.required,this.noWhitespaceValidator,Validators.minLength(2),Validators.maxLength(25)]],
      intentDescription: ['',  [Validators.required,this.noWhitespaceValidator,Validators.minLength(2),Validators.maxLength(30)]],
      isIntentLive: [true],
      virtualAgent:["",[Validators.required]]
    });
    // this.saveIntentForm.patchValue({
    //   agent: '',
    //   // language: '',
    //   businessUnit: ''
    // });

    this.intentTab();
    this.virtualAgents();
  }

    //code to trigger event onselection of language
    languageFilter(language) {
       this.langId=this.language.langEngId;
      this.channels=language.channels;
    }
  //code to trigger event onselection of channel
  channelFilter(channel) {
  this.chId=channel.channelId;
  }



  public noWhitespaceValidator(control: FormControl) {
    const isWhitespace = (control.value || '').trim().length === 0;
    const isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true };
}
  vaAgents;

  virtualAgents() {
    this.createIntentService.virtualAgent()
      .subscribe((response: any) => {
        this.vaAgents = response.virtualAgents;
      })
  }
  getIntentsEdit(roleID, intentID) {
    this.createIntentService.getIntent(roleID, intentID)
      .subscribe((response: any) => {
        this.saveIntentForm.controls['intentName'].setValue(response.intent.intentName);
        this.saveIntentForm.controls['intentDescription'].setValue(response.intent.intentDescription);
        this.saveIntentForm.controls['isIntentLive'].setValue(response.intent.isIntentLive);
        this.saveIntentForm.controls['virtualAgent'].setValue(this.vaRoleId);
        this.intentDetails = response.intent.languages;
        this.displayDropdownValues(this.intentDetails);

        console.log(response);
      });
  }

  displayDropdownValues(intentDetails) {
    // intentDetails.forEach(data => {
    //   this.languages.push({ id: data.langEngId, value: data.langName });
    //   data.channels.forEach(chn => {
    //     this.channels.push({ id: chn.channelId, value: chn.channelName });
    //     var result = this.channels.reduce((unique, o) => {
    //       if (!unique.some(obj => obj.id === o.id && obj.value === o.value)) {
    //         unique.push(o);
    //       }
    //       return unique;
    //     }, []);
    //     this.channels = result;
    //   });
    // });

    // this.languages.forEach(element => {
    //   if (element.id == this.langId) {
    //     this.language = element.value;
    //   }
    // });
    
    // this.channels.forEach(element => {
    //   if (element.id == this.chId) {
    //     this.channel = element.value;
    //   }
    // });
    this.languages=intentDetails;
    let langObj=  this.languages.find(item => item.langEngId == this.langId) ;
    this.language=langObj.langName;
    let channelObj=langObj.channels.find(item => item.channelId == this.chId);
    this.channel=channelObj.channelName;

  }

  getSelectedText() {
    if (window.getSelection) {
      var selectedText = window.getSelection();
      console.log(selectedText);
    }
  }

  intentTab() {
    this.showIntent = true;
    this.showConversation = false;
    this.showAddPhrases = false;
  }
  parentMessage;

  conversationTab() {
    if (this.enableNext) {
      this.parentMessage = this.saveIntentForm.value.virtualAgent
      this.showIntent = false;
      this.showConversation = true;
      this.showAddPhrases = false;
    } else {
      this.toastr.warning('', "Intent is not saved");
      return;
    }
    this.arr = [this.intentId, this.langId, this.chId, this.saveIntentForm.controls['virtualAgent'].value];
    console.log(this.arr, this.saveIntentForm.controls['virtualAgent'].value);
  }

  addTab() {
    this.showIntent = false;
    this.showConversation = false;
    this.showAddPhrases = true;
    this.arr = [this.intentId, this.langId, this.chId, this.saveIntentForm.controls['virtualAgent'].value];
    console.log(this.arr);
  }

  saveasDraft() {
    if (this.showIntent === true) {
      this.saveDraftIntent();
    }
    else if (this.showConversation === true) {
      this.saveDraftConversationTemp();
    }
    else {
      this.saveDraftTrainingPhrases();
    }
  }
 
  saveDraftIntent() {
    let saveIntent = {
      "intentDescription": this.saveIntentForm.value.intentDescription,
      "intentName": this.saveIntentForm.value.intentName
    }
    if (!this.saveIntentForm.valid) {
      return true;
    }
    if (this.intentId == null || undefined) {
      this.createIntentService.saveCreateIntent(this.saveIntentForm.value.virtualAgent, saveIntent)
        .subscribe((res: any) => {
          if (res.intent != null) {
            if (res.intent.intentName != null) {
              this.toastr.success('', res.intent.intentName + " Intent Created Successfully");
              this.enableNext = true;
              this.vaRoleDisable = true;
              this.intentId = res.intent.intentId;
              if (res.intent.languages != undefined) {
                // this.languages=res.intent.languages;
                this.langId = res.intent.languages[0].langEngId;
                this.chId = res.intent.languages[0].channels[0].channelId;
              }
              this.displayDropdownValues(res.intent.languages);
              console.log('chn,lang', this.langId,this.chId,res);
            }
          } else {
            this.toastr.success('', res.errorBody.summary);
          }

        });
    } else {
      this.createIntentService.updateCreateIntent(this.saveIntentForm.value.virtualAgent, this.intentId, saveIntent)
        .subscribe(res => {
          this.toastr.success('', " Intent updated Successfully");
        });
    }
    console.log('intent creation params', this.intentId, this.langId, this.chId, this.vaRoleId);
  }


  saveDraftTrainingPhrases() {
    this.trainingPhraseComponent.saveAddedTrainingPhrases();
  }

  
  getDataR(e){
    if(e.sendMessage!=null){
      if(e.sendMessage.messageText!=null){
        this.componentLeftPanel.addMsg(e.sendMessage.messageText);
      }
    } else {
      this.componentLeftPanel.getGetInfo(e);
    }
  }


  fetchValuefromLeftPanel(e) {
    debugger;
    this.componentRightPanel.bindTempData(e, this.intentId, this.langId, this.chId);
  }

  saveDraftConversationTemp() {
    this.componentLeftPanel.conversation.systemSlots.forEach((e, i) => {
      if (e.systemSlotKey.systemSlotKeyName == "") {
        this.componentLeftPanel.conversation.systemSlots.splice(i, 1)
      }
    });

    this.createIntentService.saveConversations(this.componentLeftPanel.conversation, this.intentId, this.langId, this.chId)
      .subscribe((Res: any) => {
        debugger;
        if((Res.errorBody!=undefined)&&(Res.errorBody.summary=="internal error")){
          this.toastr.warning('', "Data not Saved");
        }else{
          this.toastr.success('', "Saved Successfully");
        }
        console.log(this.intentId);
      })
  }

}

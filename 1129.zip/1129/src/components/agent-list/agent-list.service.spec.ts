import { TestBed, async, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AgentListService } from './agent-list.service';
import { HttpClientModule } from '@angular/common/http';
import { of } from 'rxjs';

describe('AgentListService', () => {
  let httpClientSpy: { get: jasmine.Spy };
  let agentListService: AgentListService;

  let channelAndLanguageList = {
    "virtualAgent":null,
    "virtualAgents":null,
    "intent":null,
    "intents":null,
    "conversation":null,
    "trainingPhrases":null,
    "virtualAgentDashboardResponseObject":null,
    "virtualAgentTrendResponseObject":null,
    "systemSlotKeys":null,
    "count":null,
    "languages": [
      {"langName":"French","langId":1},
      {"langName":"Spanish","langId":2}
    ],"channels": [
      {"channelId":1,"channelName":"WEB"},
      {"channelId":2,"channelName":"IVR"}
    ],
    "intentLanguageChannelMaps":null,
    "errorBody":null
  }

  let vaTrandData = {
    "virtualAgent": null,
    "virtualAgents": null,
    "intent": null,
    "intents": null,
    "conversation": null,
    "trainingPhrases": null,
    "virtualAgentDashboardResponseObject": null,
    "virtualAgentTrendResponseObject": 
    {
      "monthTrendList": [
        {"trenddate":"2019-10-05","trendvalue":0},
        {"trenddate":"2019-10-12","trendvalue":33},
        {"trenddate":"2019-10-19","trendvalue":0},
        {"trenddate":"2019-10-26","trendvalue":0}
      ],
      "weekTrendList": [
        {"trenddate":"2019-10-30","trendvalue":0},
        {"trenddate":"2019-10-31","trendvalue":0},
        {"trenddate":"2019-11-01","trendvalue":0},
        {"trenddate":"2019-11-02","trendvalue":0},
        {"trenddate":"2019-11-03","trendvalue":0},
        {"trenddate":"2019-11-04","trendvalue":0},
        {"trenddate":"2019-11-05","trendvalue":0}
      ]
    },
    "systemSlotKeys":null,
    "count":null,
    "languages":null,
    "channels":null,
    "errorBody":null
  }

  let vaListData = {
    "virtualAgentDashboardResponseObject": {
      "virtualAgentDashboardList": [
        {
          "vaAvatarName": "UMRBOT",
          "vaDescription": "web",
          "vaRoleName": "test",
          "vaTotalIntent": 0,
          "vaDraftIntent": 0,
          "vaDashChannelList": [
            {
              "vaChannel": "WEB",
              "vaDashLangList": [
                {
                  "vaLanguage": "English",
                  "vaUnmappedInputs": 0,
                  "vaCurrentMonthIntentAccuracy": 0,
                  "vaPreviousMonthIntentAccuracy": 0,
                  "vaCurrentWeekIntentAccuracy": 0,
                  "vaPreviousWeekIntentAccuracy": 0,
                  "vaCurrentMonthCallHandled": 0,
                  "vaPreviousMonthCallHandled": 0,
                  "vaCurrentWeekCallHandled": 0,
                  "vaPreviousWeekCallHandled": 0
                },
                {
                  "vaLanguage": "French",
                  "vaUnmappedInputs": 0,
                  "vaCurrentMonthIntentAccuracy": 0,
                  "vaPreviousMonthIntentAccuracy": 0,
                  "vaCurrentWeekIntentAccuracy": 0,
                  "vaPreviousWeekIntentAccuracy": 0,
                  "vaCurrentMonthCallHandled": 0,
                  "vaPreviousMonthCallHandled": 0,
                  "vaCurrentWeekCallHandled": 0,
                  "vaPreviousWeekCallHandled": 0
                }
              ]
            }
          ]
        },
        {
          "vaAvatarName": "UMRBOT",
          "vaDescription": "web",
          "vaRoleName": "live",
          "vaTotalIntent": 1,
          "vaDraftIntent": 0,
          "vaDashChannelList": [
            {
              "vaChannel": "WEB",
              "vaDashLangList": [
                {
                  "vaLanguage": "English",
                  "vaUnmappedInputs": 0,
                  "vaCurrentMonthIntentAccuracy": 0,
                  "vaPreviousMonthIntentAccuracy": 0,
                  "vaCurrentWeekIntentAccuracy": 0,
                  "vaPreviousWeekIntentAccuracy": 0,
                  "vaCurrentMonthCallHandled": 0,
                  "vaPreviousMonthCallHandled": 0,
                  "vaCurrentWeekCallHandled": 0,
                  "vaPreviousWeekCallHandled": 0
                },
                {
                  "vaLanguage": "French",
                  "vaUnmappedInputs": 0,
                  "vaCurrentMonthIntentAccuracy": 0,
                  "vaPreviousMonthIntentAccuracy": 0,
                  "vaCurrentWeekIntentAccuracy": 0,
                  "vaPreviousWeekIntentAccuracy": 0,
                  "vaCurrentMonthCallHandled": 0,
                  "vaPreviousMonthCallHandled": 0,
                  "vaCurrentWeekCallHandled": 0,
                  "vaPreviousWeekCallHandled": 0
                }
              ]
            }
          ]
        },
        {
          "vaAvatarName": "BOT",
          "vaDescription": "web",
          "vaRoleName": "test",
          "vaTotalIntent": 0,
          "vaDraftIntent": 0,
          "vaDashChannelList": [
            {
              "vaChannel": "IVR",
              "vaDashLangList": [
                {
                  "vaLanguage": "French",
                  "vaUnmappedInputs": 0,
                  "vaCurrentMonthIntentAccuracy": 0,
                  "vaPreviousMonthIntentAccuracy": 0,
                  "vaCurrentWeekIntentAccuracy": 0,
                  "vaPreviousWeekIntentAccuracy": 0,
                  "vaCurrentMonthCallHandled": 0,
                  "vaPreviousMonthCallHandled": 0,
                  "vaCurrentWeekCallHandled": 0,
                  "vaPreviousWeekCallHandled": 0
                },
                {
                  "vaLanguage": "English",
                  "vaUnmappedInputs": 0,
                  "vaCurrentMonthIntentAccuracy": 0,
                  "vaPreviousMonthIntentAccuracy": 0,
                  "vaCurrentWeekIntentAccuracy": 0,
                  "vaPreviousWeekIntentAccuracy": 0,
                  "vaCurrentMonthCallHandled": 0,
                  "vaPreviousMonthCallHandled": 0,
                  "vaCurrentWeekCallHandled": 0,
                  "vaPreviousWeekCallHandled": 0
                }
              ]
            }
          ]
        },
        {
          "vaAvatarName": "BOT",
          "vaDescription": "web",
          "vaRoleName": "live",
          "vaTotalIntent": 1,
          "vaDraftIntent": 0,
          "vaDashChannelList": [
            {
              "vaChannel": "IVR",
              "vaDashLangList": [
                {
                  "vaLanguage": "French",
                  "vaUnmappedInputs": 0,
                  "vaCurrentMonthIntentAccuracy": 0,
                  "vaPreviousMonthIntentAccuracy": 0,
                  "vaCurrentWeekIntentAccuracy": 0,
                  "vaPreviousWeekIntentAccuracy": 0,
                  "vaCurrentMonthCallHandled": 0,
                  "vaPreviousMonthCallHandled": 0,
                  "vaCurrentWeekCallHandled": 0,
                  "vaPreviousWeekCallHandled": 0
                },
                {
                  "vaLanguage": "English",
                  "vaUnmappedInputs": 0,
                  "vaCurrentMonthIntentAccuracy": 0,
                  "vaPreviousMonthIntentAccuracy": 0,
                  "vaCurrentWeekIntentAccuracy": 0,
                  "vaPreviousWeekIntentAccuracy": 0,
                  "vaCurrentMonthCallHandled": 0,
                  "vaPreviousMonthCallHandled": 0,
                  "vaCurrentWeekCallHandled": 0,
                  "vaPreviousWeekCallHandled": 0
                }
              ]
            }
          ]
        }
      ]
    }
  }

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule,HttpClientTestingModule],
      providers: [AgentListService]
    });
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get']);
    agentListService = new AgentListService(<any> httpClientSpy);
  });

  it(`should create`, async(inject([HttpTestingController, AgentListService],
    (httpClient: HttpTestingController , service: AgentListService) => {
      expect(httpClient).toBeTruthy();expect(service).toBeTruthy();
  })));

  it('check language and channel response', () => {
  
    httpClientSpy.get.and.returnValue(of(channelAndLanguageList));
  
    agentListService.getChannels().subscribe(
      res => {
        expect(res.languages.length).toBe(2);
        expect(res.channels.length).toBe(2);
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check trand response', () => {
  
    httpClientSpy.get.and.returnValue(of(vaTrandData));
  
    agentListService.getVATrandData(1,1,1).subscribe(
      res => {
        expect(res.virtualAgentTrendResponseObject.monthTrendList.length).toBe(4);
        expect(res.virtualAgentTrendResponseObject.weekTrendList.length).toBe(7);
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check va agent list response', () => {
  
    httpClientSpy.get.and.returnValue(of(vaListData));
  
    agentListService.getAgentList(1, 1).subscribe(
      res => {
        expect(res.virtualAgentDashboardResponseObject.virtualAgentDashboardList.length).toBe(4);
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });
});

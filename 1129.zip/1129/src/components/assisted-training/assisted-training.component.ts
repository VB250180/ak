import {
  Component,
  NgModule,
  OnInit,
  TemplateRef,
  ViewChild
} from "@angular/core";
import {
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  FormsModule,
  Validators,
  FormBuilder
} from "@angular/forms";

import { ActivatedRoute, Router } from '@angular/router'

import { NgSelectModule, NgOption } from "@ng-select/ng-select";
import { AssistedTrainingService } from "./assisted-training.service";
import { NgxSpinnerService } from "ngx-spinner";
import { BsDropdownConfig } from "ngx-bootstrap/dropdown";

import { first } from "rxjs/operators";
import { Observable } from "rxjs";
import { BsModalService } from "ngx-bootstrap/modal";
import { BsModalRef } from "ngx-bootstrap/modal/bs-modal-ref.service";
import * as moment from "moment";
import { DatePipe } from "@angular/common";
import { formatDate } from "@angular/common";
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: "app-assisted-training",
  templateUrl: "./assisted-training.component.html",
  styleUrls: ["./assisted-training.component.scss"],
  providers: [{ provide: BsDropdownConfig, useValue: { autoClose: false } }],
  host: {
    '(document:click)': 'functionClick($event)',
  }
})
export class AssistedTrainingComponent implements OnInit {
  // Added dummy value for  build
  // Start
  id;
  locale;
  rangeClicked(start, e) { }
  start;
  // End
  conversationList: any;
  alwaysShowCalendars: boolean;
  showRangeLabelOnInput: boolean;
  keepCalendarOpeningWithRange: boolean;
  editCategoryForm = [];
  // minDate: moment.Moment = moment().subtract(6, 'days');
  // maxDate: moment.Moment = moment().add(2, 'month');

  ranges: any = [moment().subtract(6, "days"), moment()];
  selected = { start: moment().subtract(6, "days"), end: moment() };

  modalRef: BsModalRef;
  config = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: "my-modal"
  };
  config2 = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: "my-modal2"
  };
  config3 = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: "my-modal3"
  };
  myDate = new Date();
  date: any;
  tempdate: any;
  unmapped_Id: any;
  selectedCity: any;
  selectedIntentName: string[];
  unmap: any;

  AssistedTrainingForm: FormGroup;
  serviceValue: any;
  statusValue: any = [];
  status: any;
  channel: any;
  language: any;
  filterValues: any;
  isLoaded: boolean = false;
  options: any = [];
  channels: any = [];
  languages: any = [];
  listDetails: any;
  scopeInputs: any = [];
  mappedInputs: any = [];
  outscopeInputs: any = [];
  allInputs: any = [];
  sessionId: any = [];
  scopeLength: any;
  mappedLength: any;
  outscopeLength: any;
  display: boolean = false;
  events: Event[] = [];
  mwidth: number;
  m_length: number;
  swidth: number;
  s_length: number;
  owidth: number;
  o_length: number;
  totalInputs: number;
  dateLimit: number;
  VA_id: any;
  language_id: any;
  channel_Id: any;
  sortByDesc: boolean = true;
  channelId: number;
  pageNumber: number = 1;
  toDate: any;
  fromDate: any;
  Entities: any;
  response: any;
  Array: any = [];
  isIntentLive: true;
  IsHidden = true;
  EntitiesList: any;
  ArrayList: any = [];
  searchText: any;
  textarea: any;
  selectionValue: boolean = false;
  log: any; selection: any;
  unmappedJson: any = [];
  selectedValue: any[] = []; selectedIntentId: any; intentSlotId: any = []; intentSlotValue: any = [];
  count: number = 0;
  pos: any;
  vaName: any; vaId: any; vaDesc: any;
  counter: number = 1;
  createFormGroup: FormGroup = this.fb.group({
    name: ['', [Validators.required]],
    description: ['', [Validators.required]],
  });



  constructor(
    private trainingService: AssistedTrainingService,
    private spinner: NgxSpinnerService,
    private modalService: BsModalService,
    private _Activatedroute: ActivatedRoute,
    private _router: Router,
    private fb: FormBuilder,
    private toastr: ToastrService
  ) {
    this.AssistedTrainingForm = new FormGroup({
      status: new FormControl(null, Validators.required),
      channel: new FormControl(null, Validators.required),
      language: new FormControl(null, Validators.required)
    });

    // this.createFormGroup = new FormGroup({
    //   name: new FormControl(" ", [Validators.required]),
    //   description: new FormControl(" ", [Validators.required])
    // });

    this.alwaysShowCalendars = true;
    this.dateLimit = 6;
  }

  ngOnInit() {
    this.spinner.show();
    this._Activatedroute.paramMap.subscribe(params => {
      console.log('params', params);
      this.vaName = params.get('name');
      this.vaId = params.get('id');
      this.vaDesc = params.get('desc');
      this.trainingService.getInputs().subscribe(
        (res: any[]) => {
          this.serviceValue = res["virtualAgents"];
          this.filterValues = this.serviceValue;
          console.log(res["virtualAgents"]);
          this.dropdownValues();
          this.searchIntentFunc();
        },
        err => console.error(err)
      );
    });


    // setTimeout(() => {

    //   //this.spinner.hide();
    // }, 2000);

    //current date formater
    this.date = new Date();
    this.toDate = formatDate(this.date, "yyyy-MM-dd", "en");
    this.date.setDate(this.date.getDate() - 7);
    this.fromDate = formatDate(this.date, "yyyy-MM-dd", "en");
    console.log("date ranges are", this.fromDate, "--", this.toDate);
  }

  onSearch(text) {
    this.searchText = text;
    this.serviceCallUnmappedInputs(
      this.channels[0].id,
      this.fromDate,
      this.languages[0].id,
      this.pageNumber,
      this.sortByDesc,
      this.toDate,
      this.VA_id,
      this.searchText
    );
    console.log(this.searchText, this.vaId, this.VA_id);
  }

  dropdownValues() {
    this.isLoaded = true;

    for (let q = 0; q < this.serviceValue.length; q++) {
      console.log('vaid', this.vaId, this.serviceValue[q].virtualAgent.vaId)

      if (this.serviceValue[q].virtualAgent.vaId == this.vaId) {
        console.log('vaid', this.vaId, this.serviceValue[q].virtualAgent.vaId)
        this.channels = []; this.languages = [];
        this.VA_id = this.serviceValue[q].virtualAgent.vaId

        for (let j = 0; j < this.serviceValue[q].channels.length; j++) {
          console.log(this.serviceValue[q].channels)
          this.channels.push(this.serviceValue[q].channels[j]);
        }
        for (let j = 0; j < this.serviceValue[q].languages.length; j++) {
          this.languages.push(this.serviceValue[q].languages[j]);
          console.log(this.languages)
        }

        if (this.serviceValue[q].virtualAgent.vaIsLive === false) {
          this.status = 'Test';
        }
        else {
          this.status = 'Live';
        }
      }
    }

    console.log(this.channels)

    this.channel = this.channels[0].value;
    this.language = this.languages[0].value;
    this.channel_Id = this.channels[0].id;
    this.language_id = this.languages[0].id;


    this.VA_id = this.vaId

    this.serviceCallUnmappedInputs(this.channel_Id, this.fromDate, this.language_id, this.pageNumber, this.sortByDesc, this.toDate, this.VA_id, this.searchText);
    //this.serviceCallUnmappedInputs(1, '2019-11-06', 1, this.pageNumber, this.sortByDesc, '2019-11-13', 2, '');
    //this.intentSlotsFunc(this.options[0].id, this.languages[0].id);
    // this.intentSlotsFunc(1 , 1);
    console.log(this.channel_Id, this.language_id, this.VA_id);
  }

  //code to triggger eventon date selection 
  choosedDate(e) {
    this.toDate = formatDate(this.selected.end['_d'], 'yyyy-MM-dd', 'en');
    this.fromDate = formatDate(this.selected.start['_d'], 'yyyy-MM-dd', 'en');
    console.log(e, this.toDate, this.fromDate, this.channels, this.channel_Id, this.fromDate, this.language_id, this.pageNumber, true, this.toDate, this.VA_id, this.AssistedTrainingForm.value.channel);
  }

  submitFilter(e) {
    console.log(e, this.toDate, this.fromDate, this.channels, this.channel_Id, this.fromDate, this.language_id, this.pageNumber, true, this.toDate, this.VA_id, this.AssistedTrainingForm.value.channel);
    console.log(this.channel_Id, this.language_id, this.VA_id);
    this.serviceCallUnmappedInputs(this.channel_Id, this.fromDate, this.language_id, this.pageNumber, true, this.toDate, this.VA_id, this.searchText);
  }

  cancelFilter(e) {
    console.log(e);
    console.log(this.channel_Id, this.language_id, this.VA_id);
    this.serviceCallUnmappedInputs(this.channel_Id, this.fromDate, this.language_id, this.pageNumber, true, this.toDate, this.VA_id, this.searchText);
  }

  cancelCreate() {
    this.createFormGroup.reset();
  }

  showMessage(message: any) {
    console.log(message);
  }

  //code to fetch service for left panel unmapped user inputs 
  serviceCallUnmappedInputs(chn, fromDate, langId, pageNo, sort, toDate, VA, text) {
    let serachtxt = text != undefined && text != 'undefined' ? text : '';
    this.trainingService.getIntents(chn, fromDate, langId, pageNo, sort, toDate, VA, serachtxt).subscribe((list: any[]) => {
      this.conversationList = list;
      console.log(list);
      this.conversationListDetails();
    }, err => {
      console.log(err);
    });
  }

  //code to trigger event onselection of agent
  statusFilter(status) {
    this.AssistedTrainingForm.setValue({
      status: status.vaAvatarName,
      channel: null,
      language: null
    });
    this.VA_id = status.vaId;
    this.channels = []; this.languages = [];
    for (let q = 0; q < this.serviceValue.length; q++) {
      if (this.serviceValue[q].virtualAgent.vaAvatarName == status.vaAvatarName) {
        for (let j = 0; j < this.serviceValue[q].channels.length; j++) {
          this.channels.push(this.serviceValue[q].channels[j]);
        }
        for (let j = 0; j < this.serviceValue[q].languages.length; j++) {
          this.languages.push(this.serviceValue[q].languages[j]);
        }
      }
    }
  }

  //code to trigger event onselection of channel
  channelFilter(channel) {
    this.spinner.show();

    setTimeout(() => {

      this.languages = [];
      for (let q = 0; q < this.serviceValue.length; q++) {
        if (this.serviceValue[q].virtualAgent.vaAvatarName == this.AssistedTrainingForm.value.status) {
          for (let j = 0; j < this.serviceValue[q].languages.length; j++) {
            this.languages.push(this.serviceValue[q].languages[j]);
          }
        }
      }

      if (this.languages.length == 1) {
        this.AssistedTrainingForm.patchValue({
          language: this.languages[0].value,
        });
        this.language_id = this.language.id;
        console.log(this.channel_Id, this.language_id, this.VA_id);
        this.serviceCallUnmappedInputs(this.channel_Id, this.fromDate, this.language_id, this.pageNumber, this.sortByDesc, this.toDate, this.VA_id, this.searchText);
      }
      console.log(this.channel_Id, this.language_id, this.VA_id);
      this.serviceCallUnmappedInputs(this.channel_Id, this.fromDate, this.language_id, this.pageNumber, this.sortByDesc, this.toDate, this.VA_id, this.searchText);

      this.channel_Id = this.channel.id;
      console.log(this.channel_Id, this.language_id);

      this.spinner.hide();
    }, 500);


  }

  //code to trigger event onselection of language
  languageFilter(language) {
    console.log('labf', language);

    this.spinner.show();

    setTimeout(() => {
      this.display = false;
      this.language_id = language.id;
      console.log(this.channel_Id, this.language_id);
      localStorage.setItem('language_id', this.language_id);
      if (this.channels.length > 0) {
        console.log(this.channel_Id, this.language_id, this.VA_id);
        this.serviceCallUnmappedInputs(this.channel_Id, this.fromDate, this.language_id, this.pageNumber, this.sortByDesc, this.toDate, this.VA_id, this.searchText);
      }
      this.spinner.hide();
    }, 500);

  }

  //code to populate values in left panel
  conversationListDetails() {
    console.log(this.conversationList);
    this.m_length = this.conversationList.mappedCount;
    this.s_length = this.conversationList.inScopeCount;
    this.o_length = this.conversationList.outOfScopeCount;
    this.totalInputs =
      this.conversationList.mappedCount +
      this.conversationList.inScopeCount


    this.mwidth = Math.round((this.m_length / this.totalInputs) * 100);
    this.swidth = Math.round((this.s_length / this.totalInputs) * 100);
    // this.owidth = Math.round((this.o_length / this.totalInputs) * 100);

    this.allInputs = this.conversationList.conversationList;
    for (let k = 0; k < this.conversationList.conversationList.length; k++) {
      this.sessionId = this.conversationList.conversationList[k].sessionId;
      for (
        let j = 0;
        j < this.conversationList.conversationList[k].inScopePhrases.length;
        j++
      ) {
        let map = this.conversationList.conversationList[k].inScopePhrases[j];
        map["mappedData"] = {
          'displayValue': this.conversationList.conversationList[k].inScopePhrases[j].value,
          'sessionId': this.conversationList.conversationList[k].sessionId
        }
        this.scopeInputs.push(map);
        this.scopeLength = this.scopeInputs.length;
      }
      for (
        let j = 0;
        j < this.conversationList.conversationList[k].mapppedPhrases.length;
        j++
      ) {
        let map = this.conversationList.conversationList[k].mapppedPhrases[j];
        console.log('mapped phrases', map);

        map["mappedData"] = this.mappedPhraseGenerator(
          this.conversationList.conversationList[k].mapppedPhrases[j], this.conversationList.conversationList[k].sessionId
        );
        this.mappedInputs.push(map);
        console.log(this.mappedInputs.length, this.conversationList.conversationList[k].sessionId)
        this.mappedLength = this.mappedInputs.length;
      }
      for (
        let j = 0;
        j < this.conversationList.conversationList[k].outOfScopePhrases.length;
        j++
      ) {
        let map = this.conversationList.conversationList[k].outOfScopePhrases[j];
        map["mappedData"] = {
          'displayValue': this.conversationList.conversationList[k].outOfScopePhrases[j].value,
          'sessionId': this.conversationList.conversationList[k].sessionId
        }
        this.outscopeInputs.push(map);
      }
    } console.log(this.mappedInputs, this.scopeInputs, this.outscopeInputs)
    this.spinner.hide();
  }

  mappedPhraseGenerator(mapphrases, id) {
    let found = [],
      displayValue = mapphrases.value,
      rxp = /%([^%/]+)%/g,
      curMatch
    // intentSlotsValue = [];


    while ((curMatch = rxp.exec(mapphrases.value))) {
      // found.push(curMatch[1]);
      console.log(curMatch[1])
      displayValue = displayValue.replace(
        curMatch[1],
        mapphrases.intentslots[curMatch[1]].value
      );
      console.log(curMatch[1], displayValue);
    }

    let displayData = {
      'displayValue': displayValue.replace(/%/g, ""),
      'intentId': mapphrases.intentId,
      'sessionId': id
      // 'intentData': intentSlotsValue
    }

    console.log(displayData);
    return displayData;
  }

  //code to trigger event accordion expansion
  expandPanel(input) {
    this.display = true;
    this.scopeInputs = [];
    this.mappedInputs = [];
    this.outscopeInputs = [];

    this.allInputs = this.conversationList.conversationList;
    for (let k = 0; k < this.conversationList.conversationList.length; k++) {
      if (input === this.conversationList.conversationList[k].sessionId) {
        for (
          let j = 0;
          j < this.conversationList.conversationList[k].inScopePhrases.length;
          j++
        ) {
          this.scopeInputs.push(
            this.conversationList.conversationList[k].inScopePhrases[j]
          );
          this.scopeLength = this.scopeInputs.length;
        }
        for (
          let j = 0;
          j < this.conversationList.conversationList[k].mapppedPhrases.length;
          j++
        ) {
          this.mappedInputs.push(
            this.conversationList.conversationList[k].mapppedPhrases[j]
          );
          this.mappedLength = this.mappedInputs.length;
        }
        for (
          let j = 0;
          j <
          this.conversationList.conversationList[k].outOfScopePhrases.length;
          j++
        ) {
          this.outscopeInputs.push(
            this.conversationList.conversationList[k].outOfScopePhrases[j]
          );
          this.outscopeLength = this.outscopeInputs.length;
        }
        console.log(
          this.scopeInputs.length,
          this.mappedInputs.length,
          this.outscopeInputs.length
        );
      }
    }
  }

  //code to delete input
  deleteUnmappedUser() {
    this.trainingService
      .deleteUnmappedUserInputs(this.unmapped_Id)
      .subscribe(res => {
        this.modalRef.hide();
        this.unmapped_Id = null;
        // this.getIntentss();
        this.dropdownValues();
        // let indexOfItem = this.userPosts.indexOf(post);
        //       this.userPosts.splice(indexOfItem, 1);
        //       console.log(this.userPosts.length);
      });
  }

  openModal(template: TemplateRef<any>, id) {
    let editCategoryForm2 = [];
    if (id == undefined) {
      // for (let key of this.editCategoryForm) {
      //   editCategoryForm2.push('vaId='+key);
      //   this.unmapped_Id=editCategoryForm2;
      //  }
      this.unmapped_Id = this.editCategoryForm;
    } else {
      this.unmapped_Id = id;
    }
    this.modalRef = this.modalService.show(template, this.config2);
  }

  openModals(template2: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template2, this.config);
  }

  openModalTrainInput(templatetrain: TemplateRef<any>) {
    console.log('train input');

    this.modalRef = this.modalService.show(templatetrain, this.config3);
  }

  showContent(value) {
    this.unmap = value;
    console.log(this.unmap.id, this.unmap.value);

    this.unmappedJson = {
      'id': this.unmap.id,
      'value': this.unmap.value,
      'intentId': value.intentId,
      'intentSlots': { ...this.unmap.intentslots }
    }

    this.Array.forEach(element => {
      if (element.id === value.intentId) {
        this.selectedIntentName = element.value;
        this.selectedIntentId = element.id;
        console.log(element.id, value);
      }
    });

    if (!this.unmap.intentId) {
      console.log(this.unmap)
      this.selectedIntentName = [];
    }
    console.log(this.unmappedJson);
  }

  onChange(index: number, data, isChecked: boolean) {
    debugger;
    if (isChecked) {
      this.editCategoryForm.push(data);
    } else {
      this.editCategoryForm.splice(this.editCategoryForm.indexOf(data), 1);
    }
  }

  searchIntentFunc() {
    this.trainingService
      .searchIntent(this.VA_id, this.language_id)
      .subscribe((res: any[]) => {
        console.log("Search Entities Data", res);
        this.response = res;
        for (let k = 0; k < this.response.length; k++) {
          this.Entities = res[k]["intent"];
          this.Array.push(this.Entities);
          console.log(this.Array);
        }
        this.Array = [...this.Array];
      });
  }


  onScroll(pageNum, chnId, langId, vaId, text) {
    this.counter += 1;
    console.log(this.counter, pageNum, chnId, langId, vaId, text);
    let searchText = text != undefined && text != 'undefined' ? text : '';

    this.trainingService.getIntents(chnId, this.fromDate, langId, pageNum, this.sortByDesc, this.toDate, vaId, searchText).subscribe((list: any[]) => {
      this.conversationList = list;
      console.log(list);
    }, err => {
      console.log(err);
    });
  }

  //code to create new Intent
  createNewIntent() {
    var body = {
      intentDescription: this.createFormGroup.value.description,
      intentName: this.createFormGroup.value.name,
      isIntentLive: false
    };
    console.log(this.VA_id);
    this.trainingService.createIntent(body, this.VA_id).subscribe(res => {
      console.log(res);
    });
    this.createFormGroup.reset();
  }


  onSelect(event) {
    console.log(this.unmap, this.selectedIntentName);
    event.preventDefault();

    this.IsHidden = !this.IsHidden;
    this.ArrayList = [];

    for (let k = 0; k < this.response.length; k++) {
      if (this.response[k]['intent'].value == this.selectedIntentName) {
        for (let i = 0; i < this.response[k]['intentSlots'].length; i++) {
          this.EntitiesList = this.response[k]['intentSlots'][i];
          this.ArrayList.push(this.response[k]['intentSlots'][i]);
        }
      }
    }

    if (this.selectedIntentName.length == 0) {
      this.ArrayList = [];
    }

    console.log(this.ArrayList);
  }

  functionClick($event) {
    if (!this.IsHidden) {
      this.IsHidden = !this.IsHidden;
    }
  }

  getSelectionText() {
    var selectedText: any;
    if (window.getSelection) { // all modern browsers and IE9+
      selectedText = window.getSelection().toString();
    }
    this.selectedValue.push(selectedText);

    return this.selectedValue;
  }

  intentSlotsFunc(VA_id, language_id) {
    console.log(VA_id, language_id);

    this.trainingService.intentSlots(VA_id, language_id)
      .subscribe((res: any[]) => {

        console.log('Entities Response', res);
        this.response = res;
        for (let k = 0; k < this.response.length; k++) {
          for (let i = 0; i < 5; i++) {
            this.EntitiesList = res[k]['intentSlots'][i];
            this.ArrayList.push(this.EntitiesList.value);
          }

          console.log('Entities List Data', this.ArrayList);
        }
      });
  }

  getIntentSlotValue(x) {
    console.log(x, this.selectedValue);
    this.intentSlotId.push(x.id);
    this.intentSlotValue.push(x.value);
  }

  intentChanged(value) {
    console.log(value, this.unmap);
    this.selectedIntentName = value.value;
    this.selectedIntentId = value.id;
  }

  saveUnmappedUserInputs() {
    console.log(this.selectedIntentId, this.selectedValue);
    let changedSlotValue = this.unmap.mappedData.displayValue;

    let dataToPass = [
      {
        "id": this.unmap.id,
        "intentId": this.selectedIntentId,
        "intentslots": {}
      }
    ]

    if (this.selectedValue.length > 0) {
      dataToPass[0]['value'] = changedSlotValue;
      for (let i = 0; i < this.selectedValue.length; i++) {
        let changedPos = dataToPass[0]['value'];
        let pos = `pos${i}`;
        // let posObj = {
        //   [`${pos}`]: 
        // };
        dataToPass[0].intentslots[pos] = {
          "intentSlot": {
            "id": this.intentSlotId[i],
            "value": this.intentSlotValue[i]
          },
          "value": this.selectedValue[i]
        };

        if (this.intentSlotId[i] == undefined) {
          delete dataToPass[0].intentslots[pos];
        }

        dataToPass[0]['value'] = changedPos.replace(this.selectedValue[i], `%pos${i}%`)
      }
    }

    this.trainingService.saveUnmappedInputs(dataToPass).subscribe(res => {
      console.log(res, dataToPass);
      this.toastr.success('', "Intent is mapped sucessfully");
    });

    this.serviceCallUnmappedInputs(this.channel_Id, this.fromDate, this.language_id, this.pageNumber, this.sortByDesc, this.toDate, this.VA_id, this.searchText);

    this.selectedValue = [];
  }
}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IntentListingComponent } from './intent-listing.component';
import { FilterPipe } from '../../app/filter.pipe';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';

describe('IntentListingComponent', () => {
  let component: IntentListingComponent;
  let fixture: ComponentFixture<IntentListingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IntentListingComponent ,FilterPipe],
      providers: [ FilterPipe ],
      schemas: [ NO_ERRORS_SCHEMA,CUSTOM_ELEMENTS_SCHEMA ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntentListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

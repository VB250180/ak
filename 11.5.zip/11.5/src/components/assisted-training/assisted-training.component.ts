import { Component, NgModule, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, FormsModule, Validators } from '@angular/forms';
import { NgSelectModule, NgOption } from '@ng-select/ng-select';
import { AssistedTrainingService } from './assisted-training.service';
import { NgxSpinnerService } from "ngx-spinner";
import { BsDropdownConfig } from 'ngx-bootstrap/dropdown';

import { first } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import * as moment from 'moment';
import { DatePipe } from '@angular/common';
import { formatDate } from '@angular/common';


@Component({
  selector: 'app-assisted-training',
  templateUrl: './assisted-training.component.html',
  styleUrls: ['./assisted-training.component.scss'],
  providers: [{ provide: BsDropdownConfig, useValue: { autoClose: false } }]
})
export class AssistedTrainingComponent implements OnInit {

  // Added dummy value for  build 
  // Start
  id;
  locale;
  rangeClicked(start,e){}
  start;
  // End

  cities2 = [
    { id: 1, name: 'Coverage Details' },
    { id: 2, name: 'Out Of Pocket' },
    { id: 3, name: 'Out Of Order', disabled: true },
    { id: 4, name: 'Benefits Details' },
    { id: 5, name: 'Order Of Installment' }
  ];

  conversationList: any;
  alwaysShowCalendars: boolean;
  showRangeLabelOnInput: boolean;
  keepCalendarOpeningWithRange: boolean;
  editCategoryForm = [];
  // minDate: moment.Moment = moment().subtract(6, 'days');
  // maxDate: moment.Moment = moment().add(2, 'month');

  ranges: any = [moment().subtract(6, 'days'), moment()];
  selected = { start: moment().subtract(6, 'days'), end: moment() };


  modalRef: BsModalRef;
  config = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: "my-modal"
  };
  config2 = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: "my-modal2"
  };

  myDate = new Date();
  date: any;
  tempdate: any;
  unmapped_Id: any;
  selectedCity: any;
  selectedIntentName: string[];
  unmap: any;


  AssistedTrainingForm: FormGroup;
  createFormGroup: FormGroup;
  serviceValue: any;
  statusValue: any = [];
  status: any; channel: any; language: any;
  filterValues: any;
  isLoaded: boolean = false;
  options: any = [];
  channels: any = [];
  languages: any = [];
  listDetails: any;
  scopeInputs: any = [];
  mappedInputs: any = [];
  outscopeInputs: any = [];
  allInputs: any = [];
  sessionId: any = [];
  scopeLength: any;
  mappedLength: any;
  outscopeLength: any;
  display: boolean = false;
  events: Event[] = [];
  mwidth: number; m_length: number;
  swidth: number; s_length: number
  owidth: number; o_length: number
  totalInputs: number;
  dateLimit: number;
  VA_id: any;
  language_id: any;
  channel_Id: any;
  sortByDesc: boolean = true;
  channelId: number;
  pageNumber: number = 1;
  toDate: any;
  fromDate: any;
  Entities: any;
  response: any;
  Array: any = [];
  isIntentLive: true;
  IsHidden = true;
  EntitiesList: any;
  ArrayList: any = [];

  constructor(private trainingService: AssistedTrainingService, private spinner: NgxSpinnerService, private modalService: BsModalService) {
    this.AssistedTrainingForm = new FormGroup({
      status: new FormControl(null, Validators.required),
      channel: new FormControl(null, Validators.required),
      language: new FormControl(null, Validators.required),
    });

    this.createFormGroup = new FormGroup({
      name: new FormControl(null, Validators.required),
      description: new FormControl(null, Validators.required),
    });
    this.alwaysShowCalendars = true;
    this.dateLimit = 6;
  }
  

  ngOnInit() {
    this.spinner.show();
    this.trainingService.getInputs().subscribe((res: any[]) => {
      this.serviceValue = res['virtualAgents'];
      this.filterValues = this.serviceValue;
      console.log(res['virtualAgents']);
    },
      err => console.error(err));

    setTimeout(() => {
      this.dropdownValues();
      this.searchEntitiesFunc();
      this.spinner.hide();
    }, 1500);

    //current date formater
    this.date = new Date();
    this.toDate = formatDate(this.date, 'yyyy-MM-dd', 'en');
    this.date.setDate(this.date.getDate() - 7);
    this.fromDate = formatDate(this.date, 'yyyy-MM-dd', 'en');
    console.log("date ranges are", this.fromDate, '--', this.toDate);

  }

  dropdownValues() {
    this.isLoaded = true;
    this.serviceValue.forEach(listDetails => {
      this.options.push(listDetails.virtualAgent);
    });
    this.status = this.options[0].value;


    for (let q = 0; q < this.serviceValue.length; q++) {
      if (this.serviceValue[q].virtualAgent.value == this.status) {
        for (let j = 0; j < this.serviceValue[q].channels.length; j++) {
          this.channels.push(this.serviceValue[q].channels[j]);
        }
        for (let j = 0; j < this.serviceValue[q].languages.length; j++) {
          this.languages.push(this.serviceValue[q].languages[j]);
        }
      }
    }
    this.channel = this.channels[0].value;
    this.language = this.languages[0].value;
    console.log(this.channel)


    //this.serviceCallUnmappedInputs(this.channels[0].id, this.fromDate, this.languages[0].id, this.pageNumber, this.sortByDesc, this.toDate,this.options[0].id);
    this.serviceCallUnmappedInputs(2, '2019-10-24', 1, this.pageNumber, this.sortByDesc, '2019-10-30', 1);
   //  this.intentSlotsFunc(this.options[0].id , this.languages[0].id);
   this.intentSlotsFunc(1 , 1);
  }

  //code to triggger eventon date selection 
  choosedDate(e) {
    this.toDate = formatDate(this.selected.end['_d'], 'yyyy-MM-dd', 'en');
    this.fromDate = formatDate(this.selected.start['_d'], 'yyyy-MM-dd', 'en');
    console.log(this.channels[0].id, this.fromDate, this.languages[0].id, this.pageNumber, true, this.toDate, this.options[0].id);
  }

  submitFilter(e) {
    console.log(e ,this.toDate,this.fromDate);
    this.serviceCallUnmappedInputs(this.channels[0].id, this.fromDate, this.languages[0].id, this.pageNumber, true, this.toDate, this.options[0].id);
  }

  cancelFilter(e) {
    console.log(e); 
    this.serviceCallUnmappedInputs(this.channels[0].id, this.fromDate, this.languages[0].id, this.pageNumber, true, this.toDate, this.options[0].id);   
  }

  showMessage(message: any) {
    console.log(message);
  }

  //code to fetch service for left panel unmapped user inputs 
  serviceCallUnmappedInputs(chn, fromDate, langId, pageNo, sort, toDate, VA) {
    this.trainingService.getIntents(chn, fromDate, langId, pageNo, sort, toDate, VA).subscribe((list: any[]) => {
      this.conversationList = list;
    },err=>{
      console.log(err);
    });

    setTimeout(() => {
      this.conversationListDetails();
    }, 800);
  }

  //code to trigger event onselection of agent
  statusFilter(status) {
    this.AssistedTrainingForm.setValue({
      status: status.value,
      channel: null,
      language: null
    });
    this.VA_id = status.id;
    this.channels = []; this.languages = [];
    for (let q = 0; q < this.serviceValue.length; q++) {
      if (this.serviceValue[q].virtualAgent.value == status.value) {
        for (let j = 0; j < this.serviceValue[q].channels.length; j++) {
          this.channels.push(this.serviceValue[q].channels[j]);
        }
        for (let j = 0; j < this.serviceValue[q].languages.length; j++) {
          this.languages.push(this.serviceValue[q].languages[j]);
        }
      }
    }

    if (this.channels.length == 1 && this.languages.length == 1) {
      this.AssistedTrainingForm.patchValue({
        channel: this.channels[0].value,
        language: this.languages[0].value,
      });
    }
    else if (this.channels.length == 1) {
      this.AssistedTrainingForm.patchValue({
        channel: this.channels[0].value,
      });
    }
  }

  //code to trigger event onselection of channel
  channelFilter(channel) {
    this.languages=[];
    for (let q = 0; q < this.serviceValue.length; q++) {
      if (this.serviceValue[q].virtualAgent.value == this.AssistedTrainingForm.value.status) {
        for (let j = 0; j < this.serviceValue[q].languages.length; j++) {
          console.log(this.serviceValue[q].languages[j]);
          this.languages.push(this.serviceValue[q].languages[j]);
        }
      }
    }

    if (this.languages.length == 1) {
      this.AssistedTrainingForm.patchValue({
        language: this.languages[0].value,
      });
      this.language_id = this.language.id;
    }

    this.channel_Id = this.channel.id;
  }

  //code to trigger event onselection of language
  languageFilter(language) {
    console.log('labf',language);
    this.display = false;
    this.language_id = language.id;
    this.serviceCallUnmappedInputs(this.channel_Id, this.fromDate, this.language_id, this.pageNumber, this.sortByDesc, this.toDate, this.VA_id);
  }

  //code to populate values in left panel
  conversationListDetails() {
    console.log(this.conversationList);
    this.m_length = this.conversationList.mappedCount;
    this.s_length = this.conversationList.inScopeCount;
    this.o_length = this.conversationList.outOfScopeCount;
    this.totalInputs = this.conversationList.mappedCount + this.conversationList.inScopeCount + this.conversationList.outOfScopeCount;

    this.mwidth = Math.round((this.m_length / this.totalInputs) * 100);
    this.swidth = Math.round((this.s_length / this.totalInputs) * 100);
    this.owidth = Math.round((this.o_length / this.totalInputs) * 100);

    this.allInputs = this.conversationList.conversationList;
    for (let k = 0; k < this.conversationList.conversationList.length; k++) {
      this.sessionId = this.conversationList.conversationList[k].sessionId;
      for (let j = 0; j < this.conversationList.conversationList[k].inScopePhrases.length; j++) {
        this.scopeInputs.push(this.conversationList.conversationList[k].inScopePhrases[j]);
      }
      for (let j = 0; j < this.conversationList.conversationList[k].mapppedPhrases.length; j++) {
        this.mappedInputs.push(this.conversationList.conversationList[k].mapppedPhrases[j]);
      }
      for (let j = 0; j < this.conversationList.conversationList[k].outOfScopePhrases.length; j++) {
        this.outscopeInputs.push(this.conversationList.conversationList[k].outOfScopePhrases[j]);
      } console.log(this.mappedInputs, this.conversationList.conversationList[0].mapppedPhrases[0])
    }
  }

  //code to trigger event accordion expansion
  expandPanel(input) {
    this.display = true;
    this.scopeInputs = []; this.mappedInputs = []; this.outscopeInputs = [];

    this.allInputs = this.conversationList.conversationList;
    for (let k = 0; k < this.conversationList.conversationList.length; k++) {
      if (input === this.conversationList.conversationList[k].sessionId) {

        for (let j = 0; j < this.conversationList.conversationList[k].inScopePhrases.length; j++) {
          this.scopeInputs.push(this.conversationList.conversationList[k].inScopePhrases[j]);
          this.scopeLength = this.scopeInputs.length;
        }
        for (let j = 0; j < this.conversationList.conversationList[k].mapppedPhrases.length; j++) {
          this.mappedInputs.push(this.conversationList.conversationList[k].mapppedPhrases[j]);
          this.mappedLength = this.mappedInputs.length;
        }
        for (let j = 0; j < this.conversationList.conversationList[k].outOfScopePhrases.length; j++) {
          this.outscopeInputs.push(this.conversationList.conversationList[k].outOfScopePhrases[j]);
          this.outscopeLength = this.outscopeInputs.length;
        }
      }
    }
  }

  //code to delete input
  deleteUnmappedUser() {
    this.trainingService.deleteUnmappedUserInputs(this.unmapped_Id)
      .subscribe(res => {
        this.modalRef.hide();
        this.unmapped_Id = null;
        // this.getIntentss();
        this.dropdownValues();
        // let indexOfItem = this.userPosts.indexOf(post);  
        //       this.userPosts.splice(indexOfItem, 1);  
        //       console.log(this.userPosts.length);  
      });
  }

  openModal(template: TemplateRef<any>, id) {
    let editCategoryForm2 = [];
    if (id == undefined) {
      // for (let key of this.editCategoryForm) {
      //   editCategoryForm2.push('vaId='+key);
      //   this.unmapped_Id=editCategoryForm2;
      //  }
      this.unmapped_Id = this.editCategoryForm;
    } else {
      this.unmapped_Id = id;
    }
    this.modalRef = this.modalService.show(template, this.config2);
  }

  openModals(template2: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template2, this.config);
  }

  showContent(value) {
    this.unmap = value;
    console.log(this.unmap);
  }

  
  onChange(index: number, data, isChecked: boolean) {
    debugger;
    if (isChecked) {
      this.editCategoryForm.push(data);
    } else {
      this.editCategoryForm.splice(this.editCategoryForm.indexOf(data), 1);
    }
  }
  
  searchEntitiesFunc() {
    this.trainingService.searchEntities(this.VA_id, this.language_id)
      .subscribe((res: any[]) => {
        console.log('Search Entities Data', res);
        this.response = res;
        for (let k = 0; k < this.response.length; k++) {
          this.Entities = res[k]['intent'];
          this.Array.push(this.Entities);

        }
        this.Array = [...this.Array];
      });
  }

  //code to create new Intent
  createNewIntent(){
    var body={
      "intentDescription":this.createFormGroup.value.description,
      "intentName": this.createFormGroup.value.name,
      "isIntentLive": true
    }
     console.log(this.VA_id);
    this.trainingService.createIntent(body,this.VA_id).subscribe(res=> {
      console.log(res);
        });
  }


  // saveIntentFunc(){
  //   this.trainingService.SaveIntent(this.unmap, this.selectedIntentName, this.VA_id, this.isIntentLive)
  //     .subscribe((res:any[]) => {
  //       console.log('save Data', res);

  //     });
  // }

  onSelect(event) {
    event.preventDefault();
    this.IsHidden = !this.IsHidden;
    this.intentSlotsFunc(1,1);
  }

  intentSlotsFunc(VA_id, language_id) {
    console.log(VA_id, language_id);
    
    this.trainingService.intentSlots(VA_id, language_id)
      .subscribe((res: any[]) => {
       
        console.log('Entities Response', res);
        this.response = res;
        for (let k = 0; k < this.response.length; k++) {
          for(let i = 0; i < 5;i++){

            this.EntitiesList = res[k]['entities'][i].value;
            
            this.ArrayList.push(this.EntitiesList);
          }
        
          console.log('Entities List Data', this.ArrayList);
        }
        
        //console.log('Entities List Data 222222', this.ArrayList);

      });
    }
  }

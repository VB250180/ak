import { Component, OnInit } from '@angular/core';
import { ChartType, ChartDataSets, ChartOptions } from 'chart.js';
import { MultiDataSet, Label, Color, BaseChartDirective } from 'ng2-charts';
//import { any } from 'node_modules1/codelyzer/util/function';
// import * as pluginAnnotations from 'chartjs-plugin-annotation';
// import { AssistedTrainingComponent } from '../assisted-training/assisted-training.component';

@Component({
  selector: 'app-agent-list',
  templateUrl: './agent-list.component.html',
  styleUrls: ['./agent-list.component.scss']
})
export class AgentListComponent implements OnInit {
  liveAgentList: Array<any> = [
    {
      "vaAvatarName": "UMRBOT",
      "vaDescription": "web",
      "vaRoleName": "test",
      "vaTotalIntent": 0,
      "vaDraftIntent": 0,
      "vaDashChannelList": [
        {
          "vaChannel": "WEB",
          "vaDashLangList": [
            {
              "vaLanguage": "English",
              "vaUnmappedInputs": 0,
              "vaCurrentMonthIntentAccuracy": 0,
              "vaPreviousMonthIntentAccuracy": 0,
              "vaCurrentWeekIntentAccuracy": 0,
              "vaPreviousWeekIntentAccuracy": 0,
              "vaCurrentMonthCallHandled": 0,
              "vaPreviousMonthCallHandled": 0,
              "vaCurrentWeekCallHandled": 0,
              "vaPreviousWeekCallHandled": 0
            },
            {
              "vaLanguage": "French",
              "vaUnmappedInputs": 0,
              "vaCurrentMonthIntentAccuracy": 0,
              "vaPreviousMonthIntentAccuracy": 0,
              "vaCurrentWeekIntentAccuracy": 0,
              "vaPreviousWeekIntentAccuracy": 0,
              "vaCurrentMonthCallHandled": 0,
              "vaPreviousMonthCallHandled": 0,
              "vaCurrentWeekCallHandled": 0,
              "vaPreviousWeekCallHandled": 0
            }
          ]
        }
      ]
    },
    {
      "vaAvatarName": "UMRBOT",
      "vaDescription": "web",
      "vaRoleName": "live",
      "vaTotalIntent": 1,
      "vaDraftIntent": 0,
      "vaDashChannelList": [
        {
          "vaChannel": "WEB",
          "vaDashLangList": [
            {
              "vaLanguage": "English",
              "vaUnmappedInputs": 0,
              "vaCurrentMonthIntentAccuracy": 0,
              "vaPreviousMonthIntentAccuracy": 0,
              "vaCurrentWeekIntentAccuracy": 0,
              "vaPreviousWeekIntentAccuracy": 0,
              "vaCurrentMonthCallHandled": 0,
              "vaPreviousMonthCallHandled": 0,
              "vaCurrentWeekCallHandled": 0,
              "vaPreviousWeekCallHandled": 0
            },
            {
              "vaLanguage": "French",
              "vaUnmappedInputs": 0,
              "vaCurrentMonthIntentAccuracy": 0,
              "vaPreviousMonthIntentAccuracy": 0,
              "vaCurrentWeekIntentAccuracy": 0,
              "vaPreviousWeekIntentAccuracy": 0,
              "vaCurrentMonthCallHandled": 0,
              "vaPreviousMonthCallHandled": 0,
              "vaCurrentWeekCallHandled": 0,
              "vaPreviousWeekCallHandled": 0
            }
          ]
        }
      ]
    },
    {
      "vaAvatarName": "BOT",
      "vaDescription": "web",
      "vaRoleName": "test",
      "vaTotalIntent": 0,
      "vaDraftIntent": 0,
      "vaDashChannelList": [
        {
          "vaChannel": "IVR",
          "vaDashLangList": [
            {
              "vaLanguage": "French",
              "vaUnmappedInputs": 0,
              "vaCurrentMonthIntentAccuracy": 0,
              "vaPreviousMonthIntentAccuracy": 0,
              "vaCurrentWeekIntentAccuracy": 0,
              "vaPreviousWeekIntentAccuracy": 0,
              "vaCurrentMonthCallHandled": 0,
              "vaPreviousMonthCallHandled": 0,
              "vaCurrentWeekCallHandled": 0,
              "vaPreviousWeekCallHandled": 0
            },
            {
              "vaLanguage": "English",
              "vaUnmappedInputs": 0,
              "vaCurrentMonthIntentAccuracy": 0,
              "vaPreviousMonthIntentAccuracy": 0,
              "vaCurrentWeekIntentAccuracy": 0,
              "vaPreviousWeekIntentAccuracy": 0,
              "vaCurrentMonthCallHandled": 0,
              "vaPreviousMonthCallHandled": 0,
              "vaCurrentWeekCallHandled": 0,
              "vaPreviousWeekCallHandled": 0
            }
          ]
        }
      ]
    },
    {
      "vaAvatarName": "BOT",
      "vaDescription": "web",
      "vaRoleName": "live",
      "vaTotalIntent": 1,
      "vaDraftIntent": 0,
      "vaDashChannelList": [
        {
          "vaChannel": "IVR",
          "vaDashLangList": [
            {
              "vaLanguage": "French",
              "vaUnmappedInputs": 0,
              "vaCurrentMonthIntentAccuracy": 0,
              "vaPreviousMonthIntentAccuracy": 0,
              "vaCurrentWeekIntentAccuracy": 0,
              "vaPreviousWeekIntentAccuracy": 0,
              "vaCurrentMonthCallHandled": 0,
              "vaPreviousMonthCallHandled": 0,
              "vaCurrentWeekCallHandled": 0,
              "vaPreviousWeekCallHandled": 0
            },
            {
              "vaLanguage": "English",
              "vaUnmappedInputs": 0,
              "vaCurrentMonthIntentAccuracy": 0,
              "vaPreviousMonthIntentAccuracy": 0,
              "vaCurrentWeekIntentAccuracy": 0,
              "vaPreviousWeekIntentAccuracy": 0,
              "vaCurrentMonthCallHandled": 0,
              "vaPreviousMonthCallHandled": 0,
              "vaCurrentWeekCallHandled": 0,
              "vaPreviousWeekCallHandled": 0
            }
          ]
        }
      ]
    }
  ];

  channelList: Array<any> = [
    {
      name: 'WEB',
      id: 1
    },
    {
      name: 'IVR',
      id: 2
    }
  ];

  languageList: Array<any> = [
    {
      name: 'French',
      id: 1
    },
    {
      name: 'Spanish',
      id: 2
    }
  ];

  agentFilter: any = {
    channel: '',
    language: ''
  }
  // selectedChannel: any = '';
  // selectedLangulage: any;









  public doughnutChart1Labels: Label[] = ['', ''];
  public doughnutChart1Data: MultiDataSet = [
    [75, 25]
  ];
  public doughnutChart1Options: any = {
    cutoutPercentage: 90,
    elements: {
      arc: {
        borderWidth: 0
      }
    }
  };

  public pieChart1Colors = [
    {
      backgroundColor: ['#57E0D8', 'rgba(87, 224, 216, 0.1)'],
    },
  ];

  public pieChart2Colors = [
    {
      backgroundColor: ['#B1A3F9', 'rgba(177, 163, 249, 0.1)'],
    },
  ];

  public doughnutChartType: ChartType = 'pie';
  public pieChartLegend = false;


  public lineChartData: ChartDataSets[] = [
    { data: [5, 10, 7, 12, 14, 11, 15], label: 'Series A', borderWidth: 1 }
  ];

  public lineChartLabels: Label[] = ['', '', '', '', '', '', ''];

  public lineChartOptions: (ChartOptions) = {
    responsive: true,
    maintainAspectRatio: false,
    // pointBorder: 0,
    // borderWidth: 1,
    elements: { point: { radius: 0 } } ,
    scales: {
      xAxes: [{
        gridLines: {
          display: false,
          drawBorder: false,
          tickMarkLength: 0
        },
      }],
      yAxes: [{
        gridLines: {
          display: false,
          drawBorder: false
        },
        ticks: {
          beginAtZero: true,
          callback: function(value, index, values) {
              return '';
          },
        }
      }]
    }
  };
  public lineChartColors: Color[] = [
    {
      backgroundColor: 'rgba(87, 224, 216, 0.1)',
      borderColor: '#57E0D8',
      pointBackgroundColor: '#57E0D8',
      pointBorderColor: '#57E0D8',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: '#57E0D8'
    }
  ];
  public lineChart2Colors: Color[] = [
    {
      backgroundColor: 'rgba(177, 163, 249, 0.1)',
      borderColor: '#B1A3F9',
      pointBackgroundColor: '#B1A3F9',
      pointBorderColor: '#B1A3F9',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: '#B1A3F9'
    }
  ];
  public lineChartLegend = false;
  public lineChartType = 'line';

  public showTrand = true;

  constructor() { }

  ngOnInit() {
  }

  toggleLiveAgentGraphs = (index) => {
    if(!this.liveAgentList[index].showTrand){
      this.liveAgentList[index].showTrand = true;
    } else{
      this.liveAgentList[index].showTrand = !this.liveAgentList[index].showTrand;
    }
  }

  changeLiveDataTime(val, index){
    this.liveAgentList[index].dataTime = val;
  }

}

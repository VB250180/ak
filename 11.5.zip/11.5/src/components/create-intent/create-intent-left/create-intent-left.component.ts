import { Component, OnInit, } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, Form, Validators,SelectControlValueAccessor  } from '@angular/forms';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import {  Conversation,ConversationStage} from '../model/intent';
import { CreateIntentService } from '../create-intent.service';
import { analyzeAndValidateNgModules } from '@angular/compiler';
// import { $ } from 'protractor';
declare var $:any;
@Component({
  selector: 'app-create-intent-left',
  templateUrl: './create-intent-left.component.html',
  styleUrls: ['./create-intent-left.component.scss']
})
export class CreateIntentLeftComponent implements OnInit {
  conversation = new Conversation();
  conversationStages:ConversationStage[]=[];
  ConversationStageSendGetFinal= new ConversationStage();
  conversationList:any;lastElement;  finalResSlot:any;

  slotPage; msgValue:any=[]; showValidation; showSendMsg; showGetInfo; showCreateInfo;showFinalRes;

  agents: any = [{ id: 1, value: "VA_one" }, { id: 2, value: "VA_two" }, { id: 1, value: "VA_three" }];


  // userForm: FormGroup;

  constructor(public fb: FormBuilder, public createIntentService:CreateIntentService) { }
  // conversationForm: FormGroup;
  systemslots;valEntity;
  getSystemSlotDropdowns(){
    this.createIntentService.getSystemSlotDropdown().subscribe((Res:any)=>{
      this.systemslots=Res.systemSlotKeys;
      this.systemslots=[{systemSlotKeyName:"userId",systemSlotKeyId:1 }]
      // this.slotPage = this.systemslots.length;
    });
  };
  getIntentsDropdowns(){
    this.createIntentService.getIntentsDropdown().subscribe((Res:any)=>{
      this.valEntity=Res.intents;
      this.valEntity=[{intentName:"vinodha",intentId:1 }]
    });
  }


  // func(){
  //   // this.conversationCreate;
  //   this.conversation;
  // }
  ngOnInit() {

    // this.conversationForm = this.fb.group({
    //   valEntity: [''],
    //   slotValues: this.fb.array([this.fb.group({ slot: '' })]),
    //   msg: [''],
    //   getInfoValues: this.fb.array([this.fb.group({ name: '', description: '', entity: '', question: '', validationMsg: '' })]),
    //   finalResdataValues: this.fb.array([this.fb.group({ name: '', description: '' })]),
    // });
    // this.showCreateInfo = false;

    this.getSystemSlotDropdowns();
    this.getIntentsDropdowns();
    this.getConversationList();


    
  }



ngAfterViewInit(){

}


getConversationList(){
  this.createIntentService.getIntentConversionList().subscribe((data:any) => {
    // this.conversationList=data.conversation;
    // this.conversation=this.conversationList;
    this.conversation={
        "validationIntent": "vinodha",
        "systemSlots": [
          {
            "systemSlotId": 42,
            "systemSlotKey": {
              "systemSlotKeyId": 1,
              "systemSlotKeyName": "userId"
            }
          },
          {
            "systemSlotId": 43,
            "systemSlotKey": {
              "systemSlotKeyId": 2,
              "systemSlotKeyName": "token"
            }
          }
        ],
        "conversationStages": [
          {
            "sequenceNumber": 1,
            "conversationStageId": 33,
            "sendMessage": {
              "messageId": 20,
              "messageText": "3 thanks for contacting us"
            },
            "getInfo": null,
            "finalResponse": null
          },
          {
            "sequenceNumber": 2,
            "conversationStageId": 34,
            "sendMessage": null,
            "getInfo": {
              "getInfoId": 10,
              "promptQuestion": "3provide the name of the airline",
              "promptValidationMessage": "3invalid airline",
              "intentSlot": {
                "intenSlotId": 10,
                "intentSlotName": "3Airline Name",
                "intentSlotDescription": "3Airline",
                "entity": {
                  "entityId": 1,
                  "entityName": "airline"
                }
              }
            },
            "finalResponse": null
          },
          {
            "sequenceNumber": 3,
            "conversationStageId": 35,
            "sendMessage": {
              "messageId": 21,
              "messageText": "3 kindly wait while we get the info"
            },
            "getInfo": null,
            "finalResponse": null
          },
          {
            "sequenceNumber": 2,
            "conversationStageId": 34,
            "sendMessage": null,
            "getInfo": {
              "getInfoId": 10,
              "promptQuestion": "3provide the name of the airline",
              "promptValidationMessage": "3invalid airline",
              "intentSlot": {
                "intenSlotId": 10,
                "intentSlotName": "3Airline Name",
                "intentSlotDescription": "3Airline",
                "entity": {
                  "entityId": 1,
                  "entityName": "airline"
                }
              }
            },
            "finalResponse": null
          },
          {
            "sequenceNumber": 4,
            "conversationStageId": 36,
            "sendMessage": null,
            "getInfo": null,
            "finalResponse": {
              "finalResponseId": 4,
              "finalResponseText": "3the price for %pos1% is $%pos2%",
              "positionAndSlots": [
                {
                  "finalResponseSlotId": 14,
                  "position": "pos2",
                  "intentSlot": null,
                  "responseSlot": {
                    "responseSlotId": 3,
                    "responseSlotName": "ticketAmount"
                  }
                },
                {
                  "finalResponseSlotId": 13,
                  "position": "pos2",
                  "intentSlot": null,
                  "responseSlot": {
                    "responseSlotId": 3,
                    "responseSlotName": "ticketAmount"
                  }
                }
              ]
            }
          }
        ]
      }
      // this.conversationList=this.conversation;
    // this.conversationStages= this.conversationList.conversationStages;
        this.conversationList=this.conversation;

    this.conversationStages=this.conversation.conversationStages;
    this.lastElement = this.conversationStages.pop();
    this.conversationStages.forEach(e => {
      this.finalResSlot=this.lastElement.finalResponse;
        this.finalResSlot.positionAndSlots.forEach(e => {
         if(e.intentSlot!=null){
         var replaceStr=e.intentSlot.entity.entityName;
         }else{
          var replaceStr=e.responseSlot.responseSlotName; 
         }
         var str1="<$ "+replaceStr+" >"; 
         this.finalResSlot.finalResponseText=this.finalResSlot.finalResponseText.replace(e.position, str1);
        }); 
      });
  });
}

// compareTech(t1: Technology, t2: Technology): boolean {
//   return t1 && t2 ? t1.techId === t2.techId : t1 === t2;
// } 

  drop(event: CdkDragDrop<{title: string, poster: string}[]>) {
    moveItemInArray( this.conversationStages, event.previousIndex, event.currentIndex);
  }

  // validation Block
  deleteSlotValue(index) {  
        this.conversation.systemSlots.splice(index, 1);  
        return true;  
} 

  // get slotValues() {
  //   return this.conversationForm.get('slotValues') as FormArray;
  // }
  // addSlotValue() {
  //   this.slotValues.push(this.fb.group({ slot: '' }));
  // }
  // deleteSlotValue(index) {
  //   if (this.slotValues.value.length > 1) {
  //     this.slotValues.removeAt(index);
  //     this.slotPage++;
  //   }
  // }
  // slotSelected(slot, idx) {
  //   if (this.slotPage != 1) {
  //     this.addSlotValue();
  //     this.slotPage = this.systemslots.length - 1;
  //   }
  // }

  // sendMsg Block
  sendMsg;
  addMsg(msg) {
    this.sendMsg={
      sendMessage:{
        "messageText":msg
      }
    }
this.conversation.conversationStages.push(this.sendMsg);

  }
  delMsg(i){
    this.conversation.conversationStages.splice(i,1);
  }
  // addMsg() {
  //   this.msgValue.push(this.conversationForm.value.msg);
  // }
  // delMsg() {
  //   this.msgValue = '';
  // }

  // getInfo Block
  // get getInfo() {
  //   return this.conversationForm.get('getInfoValues') as FormArray;
  // }
  // addInfoSlot() {
  //   if (this.showCreateInfo) {
  //     this.getInfo.push(this.fb.group({ name: '', description: '', entity: '', question: '', validationMsg: '' }));
  //   }
  //   this.showCreateInfo = true;
  // }
  // removeInfoSlot(i: number) {
  //   this.getInfo.removeAt(i);
  // }

  // finalRes Block
  // get finalRes() {
  //   return this.conversationForm.get('finalResdataValues') as FormArray;
  // }
  // addResSlot() {
  //   this.finalRes.push(this.fb.group({ name: '', description: '' }));
  // }
  // removeResSlot(i: number) {
  //   this.finalRes.removeAt(i);
  // }

  // RightPanel Block
  mapFunc() {
    this.showValidation = "true"
//   this.conversation.systemSlots=this.conversationCreate.systemSlots;
// this.conversation.validationIntent=this.conversationCreate.validationIntent;
  }
  sendMsgFunc() {
    // this.addMsg();
    this.showSendMsg = "true"
  }
  getInfoFunc() {
    this.showGetInfo = "true"
  }
  getfinalRes(){
  this.showFinalRes="true"
  };
  saveConversation(){
    this.createIntentService.saveConversations(this.conversation)
 .subscribe((res:any)=>{});
  }
//   saveDraft;
//   saveConversation(){
//     this.intent.validationIntent={"intentId":this.conversationForm.value.valEntity.id};
//     this.conversationForm.value.slotValues.forEach((element,index) => {
//       if(element.slot.systemSlotKeyId!=undefined){
//         this.intent.systemSlotKey={"systemSlotKey":{
//           "systemSlotKeyId":element.slot.systemSlotKeyId
//         }};
//         this.intent.systemSlots[index]= this.intent.systemSlotKey;
//       }
//    });
//  this.saveDraft=({"validationIntent":this.intent.validationIntent,"systemSlots": this.intent.systemSlots})

//  this.createIntentService.saveConversations(this.saveDraft)
//  .subscribe((res:any)=>{});
//    }


 
}

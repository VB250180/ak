import { Component, Inject } from '@angular/core';
import { NgModule, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { MustMatch } from 'src/app/modules/login/login.component';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig } from '@angular/material';
import { LocaleService } from 'src/app/core/services/locale/locale.service';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';
import { IfStmt } from '@angular/compiler';

@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.scss']
})

export class PasswordComponent implements OnInit {
  resetpassword: FormGroup;
  public userId: string;

  simulatorBaseUrl: string;
  hideoldpass = true;
  hidenewpass = true;
  hideconfirmpass = true;
  loginLocale: any;
  forgotpassLocale: any;
  resetpassLocale: any;
  resetsuccesslocale: any;

  loginFormDisplay = true;
  forgetPasswordForm = false;
  loginFormResetEmial = false;
  forgetPasswordSuccessForm = false;
  loginformGroup: FormGroup;

  upperVal = /(.*[A-Z].*)/;
  charVal = /[@#$%^&+=]/;
  submitted: boolean;
  loading: boolean;
  error: '';
  returnUrl: string;
  errorMsg: string;
  resetpasswordonsuccess: boolean = true;

  constructor(private fb: FormBuilder, private router: Router,
    private locale: LocaleService, private matDialog: MatDialog, private authenticationService: AuthenticationService) {
    this.loginLocale = this.locale.loginPage;
    this.forgotpassLocale = this.locale.forgotPasswordPage;
    this.resetpassLocale = this.locale.resetPasswordPage;
    this.resetsuccesslocale = this.locale.resetPasswordSuccessPage;
  }
  ngOnInit() {
    this.createResetPasswordForm();
  }
  createResetPasswordForm() {
    this.resetpassword = this.fb.group({
      'oldpass': ['', [Validators.required]],
      'newpass': ['', [Validators.required, Validators.minLength(8), Validators.pattern(/^(?=.{8,})(?=.*[A-Z])(?=.*[@#$%^&+=]).*$/)]],
      'confirmpass': ['', [Validators.required, Validators.minLength(8), Validators.pattern(/^(?=.{8,})(?=.*[A-Z])(?=.*[@#$%^&+=]).*$/)]],
    }, {
      validator: MustMatch('newpass', 'confirmpass')
    });
  }

  resetClose() {
    this.loginFormDisplay = true;
    this.loginFormResetEmial = false;
    this.forgetPasswordForm = false;
    //this.dialogRef.close(this.resetpassword.value)
  }


  //method when reset button clicked
  ResetSucess() {
    this.resetpasswordonsuccess = false;
    console.log('reset dat', this.resetpassword.value);

    const dialogConfigReset = new MatDialogConfig();
    dialogConfigReset.disableClose = true;
    dialogConfigReset.width = "800px";
    dialogConfigReset.data = {
      primaryText: "",
      hasPrimaryBtn: true,
      primaryBtnText: 'Ok',
      popUpType: 'warn',
      hasCancelBtn: true
    }

    this.authenticationService.resetPassword(this.resetpassword.value).subscribe(res => {
      console.log('reset dat form',res);
      // res.errorBody != null ? dialogConfigReset.data.primaryText = "Please enter correctly your old password" : dialogConfigReset.data.primaryText = "Your password has been reset successfully"

      if(res.loginPojo){
        dialogConfigReset.data.primaryText = "Your password has been reset successfully",
        dialogConfigReset.data.popUpType = "success"
      }
      else if(res.errorBody !== null){
        (res.errorBody.summary.indexOf('password') != -1) ?  dialogConfigReset.data.primaryText = "Please use new password which wasn't used earlier" :  dialogConfigReset.data.primaryText = "Please enter your valid old password" 
      }

      const modalDialog = this.matDialog.open(ModalComponent, dialogConfigReset);
      modalDialog.afterClosed().subscribe(data => {
        console.log(data, res.errorBody);
        res.errorBody !== null ? this.router.navigate(['/reset-password']) : this.logout();
        this.resetpasswordonsuccess = true;
      });
    })
  }

  
  Cancel() {
    this.router.navigateByUrl('/agent-list');
  }

  logout() {
    this.authenticationService.logout();
  }
}




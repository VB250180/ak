import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VirtualAgentCreationComponent } from './virtual-agent-creation.component';
import { VirtualAgentService } from '../../../core/services/virtual-agent/virtual-agent.service';

import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, Component, TemplateRef } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MatDialogModule, MatDialog } from '@angular/material';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { Observable, BehaviorSubject } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';


class VirtualServiceStub {
  constructor() { }

  public getVirtualAgent(vaId: 1){
    return Observable.of({
      virtualAgent: [
        {
          vaId: 3,
          vaName: "Policy Issuance",
          vaIsLive: true,
          isNluConfigured: false,
          vaAvatarName: "Akeira2.0 av",
          vaDescription: "Policy issuance",
          businessUnit: null,
          languages: null,
          channels: null,
          businessUnitData: null,
          userName: "VAadmin"
        }]
    })

  }

  public sendVaSaveResponse(id: 1, userId: 16, respoonse: any) {
    return Observable.of({
      virtualAgent: {
        vaId: 0,
        vaIsLive: true,
        businessUnit: "Member Services",
        vaAvatarName: "Akeira2.0",
        vaDescription: "Policy issuance",
        vaName: "Policy Issuance",
        channels: [{ id: 1, Name: 'Web' }],
        languages: [{ id: 1, Name: 'English' }]
      },
    });
  }

  public updateVaResponse(id: 1, response: any, userid: 16) {
    return Observable.of({
      virtualAgent: {
        vaId: 1,
        vaIsLive: true,
        businessUnit: "Member Services",
        vaAvatarName: "Akeira2.0",
        vaDescription: "Policy issuance",
        vaName: "Policy Issuance",
        channels: [{ id: 1, Name: 'Web' }],
        languages: [{ id: 1, Name: 'English' }]
      },
    });
  }

  public orgData() {
    return Observable.of({
      organizationData: [{ orgId: 1, organizationName: 'Uniphore' }]
    })
  }

  public busUnitData() {
    return Observable.of({
      categoryData: [{ catId: 16, categoryName: "Outbound", nluEngine: { engineId: 1, engineName: "DIALOG_FLOW" }, organization: null }]
    })
  }

  public langData() {
    return Observable.of({
      languageEngineMaps: [{ langEngId: 1, langName: "English", channels: null }]
    })
  }

  public chnData() {
    return Observable.of({
      channels: [{ channelId: 2, channelName: "IVR" }]
    })
  }

}

describe('VirtualAgentCreationComponent', () => {
  let component: VirtualAgentCreationComponent;
  let fixture: ComponentFixture<VirtualAgentCreationComponent>;


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [VirtualAgentCreationComponent],
      imports: [FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
        RouterTestingModule,
        MatDialogModule,
        NgMultiSelectDropDownModule
      ],
      providers: [
        { provide: VirtualAgentService, useClass: VirtualServiceStub },],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VirtualAgentCreationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check on initialization on oninit method', () => {
    component.flag = 1;
    component.ngOnInit();
    component.createAgentForm.patchValue({
      avatarName:'',
      agentName:'',
      agentDescription:'',
      agentBusinessUnit: '',
      agentOrganization:'',
      agentLanguages: [{ id: 1, lang: 'Eng' }],
      agentChannels: [{ id: 1, chn: 'IVr' }]
    });

    expect(component.Organizations).toEqual([{ orgId: 1, organizationName: 'Uniphore' }]);

    // expect(component.BusinessUnits).toEqual([{ catId: 1, categoryName: 'Claims' }]);
  });

  it('cancelCreate should reset createAgentForm', () => {
    component.flag = 0;
    component.createAgentForm.controls['avatarName'].setValue('name');
    component.createAgentForm.controls['agentName'].setValue('agentName');
    component.createAgentForm.controls['agentDescription'].setValue('description');
    component.createAgentForm.controls['agentBusinessUnit'].setValue('agentUnit');
    component.createAgentForm.controls['agentLanguages'].setValue([{ id: 1, lang: 'Eng' }]);
    component.createAgentForm.controls['agentChannels'].setValue([{ id: 1, lang: 'Web' }]);

    component.onCancel();

    expect(component.createAgentForm.controls['avatarName'].value).toBe(null);
    expect(component.createAgentForm.controls['agentName'].value).toBe(null);
    expect(component.createAgentForm.controls['agentDescription'].value).toBe(null);
    expect(component.createAgentForm.controls['agentBusinessUnit'].value).toBe(null);
    expect(component.createAgentForm.controls['agentLanguages'].value).toBe(null);
    expect(component.createAgentForm.controls['agentChannels'].value).toBe(null);

  });

  it('get organization dropdown values', () => {
    component.getOrgs();
    expect(component.Organizations).toEqual([{ orgId: 1, organizationName: 'Uniphore' }]);
  });

  it('get business dropdown values', () => {
    component.createAgentForm.patchValue({
      agentBusinessUnit: '',
      agentLanguages: [],
      agentChannels: []
    });
    let orgId = 1;
    component.orgChange(orgId);
    expect(component.BusinessUnits).toEqual([{ catId: 16, categoryName: "Outbound", nluEngine: { engineId: 1, engineName: "DIALOG_FLOW" }, organization: null }]);
  });

  it('get business language values', () => {
    component.createAgentForm.patchValue({
      agentLanguages: [],
      agentChannels: []
    });
    let catId = 1;
    component.businessUnitChange(catId);
    expect(component.languages).toEqual([{ langEngId: 1, langName: "English", channels: null }]);
  });

  it('get list of channels on selection of language/s', () => {
    component.createAgentForm.patchValue({
      agentChannels: []
    });
    const langSelected = { langEngId: 4, langName: "English-Indian" };
    component.onLanguageSelect(langSelected);
    expect(component.channels).toEqual([{ channelId: 2, channelName: "IVR" }])
  });

  it('on uncheck of languages that are selected', () => {
    const langdeselected = { langEngId: 4, langName: "English-Indian" };
    component.onLanguageDeSelect(langdeselected);
    expect(component.deselectedValues).toEqual([{ langEngId: 4, langName: "English-Indian" }]);
  });

  it('select of channels', () => {
    const chnSelected = { channelId: 2, channelName: "IVR" };
    component.channelsList = [];
    component.onChannelSelect(chnSelected);
    expect(component.channelsList).toEqual([{ channelId: 2, channelName: "IVR" }]);
  });

  it('click on save send response based on the flag' , () => {
    component.saveResponse = [
      {
        "businessUnit": 'outbound',
        "businessUnitData": {
          "catId": 1,
          "nluEngine": {
            "engineId": 0,
            "engineName": ""
          },
          "organization": {
            "orgId": 1,
            "organizationName": 'Uniphore'
          }
        },
        "userName":"",
        "channels": [{"channelId":2,"channelName":"IVR"}],
        "languages": [{"langEngId":1,"langName":"English","channels":null}],
        "vaAvatarName": "Akeira2.0 av",
        "vaDescription": "Policy issuance",
        "vaId": 0,
        "vaIsLive": true,
        "vaName": "Policy"
      }
    ];
    component.flag = 1;
    component.onSave();
    component.saveResponse[0].vaId = 1;
  });

  it('should call method cancel', () => {
    const router = TestBed.get(Router);
    const spy = spyOn(router, 'navigate');
    component.flag = 1;

    component.onCancel();
    expect(spy).toHaveBeenCalledWith(['/va-listing']);
  });

  it('should call method openModalErrorPopUp', ()=> {
    const dialog = TestBed.get(MatDialog);
    const spy = spyOn(dialog, 'MatDialogConfig');
    
    component.openModalErrorPopUp('internal error');
    expect(spy).toHaveBeenCalled();
  });

  });

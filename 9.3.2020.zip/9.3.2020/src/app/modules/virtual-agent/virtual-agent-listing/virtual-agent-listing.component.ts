import { Component, OnInit } from '@angular/core';
import { element } from 'protractor';
import { VirtualAgentService } from 'src/app/core/services/virtual-agent/virtual-agent.service';
import { ActivatedRoute, Router } from '@angular/router';
import { getCurrentUserId } from '../../../core/utils/akeira-utils';


@Component({
  selector: 'app-virtual-agent-listing',
  templateUrl: './virtual-agent-listing.component.html',
  styleUrls: ['./virtual-agent-listing.component.scss']
})
export class VirtualAgentListingComponent implements OnInit {
  virtualAgents: any = [];
  languages: any = [];
  pageNo: number = 1;
  userId: number;
  searchText: string;
  counter: number = 1;
  showloader = false;
  agentsLength:number

  constructor(private vaService: VirtualAgentService, private route: ActivatedRoute,
    private router: Router) { 
      this.userId = getCurrentUserId();
    }

  ngOnInit() {
    this.virtualAgents = [];
    (this.searchText === ('' || undefined)) ? this.searchText = '' : '';

    this.vaService.getVirtualAgents(this.pageNo, this.userId, this.searchText).subscribe(res => {
      console.log(res);
      if(res['virtualAgents'] != null){
        console.log(res['virtualAgents']);
        this.virtualAgents = res['virtualAgents'];
        this.agentsLength = this.virtualAgents.length;
      }
    })
  }

  selectedRow(details) {
    console.log(details);
    this.router.navigate(['/va-creation', details.vaId, 1])
  }

  onScroll() {
    this.counter += 1;
    let agentsLoaded: any = [];
    this.showloader = true;
    if (this.searchText === ('' || undefined)) {
      this.searchText = '';
    }
    console.log('this.counter', this.counter);
    this.vaService.getVirtualAgents(this.counter, this.userId, this.searchText).subscribe(res => {
      for (let i = 0; i < res['virtualAgents'].length; i++) {
        agentsLoaded = res['virtualAgents'][i];
        this.virtualAgents.push(agentsLoaded);
        this.agentsLength = this.virtualAgents.length;
      }
      this.showloader = false;
    },
      err => {
        console.error(err);
      });
  }

  onSearchIntent(agent) {
    console.log(agent)
    this.pageNo = 1;
    this.searchText = agent;
    this.vaService.getVirtualAgents(this.pageNo, this.userId, this.searchText).subscribe(res => {
      console.log(res);
      this.virtualAgents = res['virtualAgents'];
      this.agentsLength = this.virtualAgents.length;
    },
      err => {
        console.error(err);
      });
  }
}

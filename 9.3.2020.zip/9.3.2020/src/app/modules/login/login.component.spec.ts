import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, Component, TemplateRef } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable, BehaviorSubject } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginComponent } from './login.component';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';


class loginServiceStub {

}

fdescribe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LoginComponent],
      imports: [FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
        RouterTestingModule
      ],
      providers: [
        { provide: AuthenticationService, useClass: loginServiceStub}],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check on initialization on oninit method', () => {
    const createform = spyOn(component, 'createForm');
    const resetform = spyOn(component, 'createResetPasswordForm');

    component.ngOnInit();

    expect(createform).toHaveBeenCalled();
    expect(resetform).toHaveBeenCalled();
    expect(component.returnUrl).toEqual('/');

    // expect(component.BusinessUnits).toEqual([{ catId: 1, categoryName: 'Claims' }]);
  });

  it('should check createForm', () => {
    component.loginformGroup.controls['username'].setValue('admin');
    component.loginformGroup.controls['password'].setValue('adminpass');

      component.createForm();
      expect(component.loginformGroup.controls['username'].value).toBe('admin');
      expect(component.loginformGroup.controls['password'].value).toBe('adminpass');
  });

  it('should check createresetForm', () => {
    component.resetpassword.controls['newpass'].setValue('pass');
    component.resetpassword.controls['confirmpass'].setValue('pass');

      component.createResetPasswordForm();
      
      expect(component.resetpassword.value.newpass).toEqual(component.resetpassword.value.newpass);
  });


  });

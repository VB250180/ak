
import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormGroup, FormBuilder } from '@angular/forms';
// import { AppService } from '../../app.service';
import { Router, ActivatedRoute } from '@angular/router';
import { LocaleService } from '../../../app/core/services/locale/locale.service';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { first } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs';
import { User } from 'src/app/core/models/user/user.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  hide = true;
  loginLocale: any;
  forgotpassLocale: any;
  resetpassLocale: any;
  resetsuccesslocale: any;

  loginFormDisplay = true;
  forgetPasswordForm = false;
  loginFormResetEmial = false;
  forgetPasswordSuccessForm = false;
  loginformGroup: FormGroup;
  resetpassword: FormGroup;

  upperVal = /(.*[A-Z].*)/;
  charVal = /[@#$%^&+=]/;
  submitted: boolean;
  loading: boolean;
  error: '';
  returnUrl: string;
  errorMsg: string;
  forgotpasswordformGroup: FormGroup;

  private currentUserSubject: BehaviorSubject<User>;
  public currentUser: Observable<User>;

  constructor(private formBuilder: FormBuilder, private router: Router,
    private locale: LocaleService, private route: ActivatedRoute, private authenticationService: AuthenticationService) {
    this.loginLocale = this.locale.loginPage;
    this.forgotpassLocale = this.locale.forgotPasswordPage;
    this.resetpassLocale = this.locale.resetPasswordPage;
    this.resetsuccesslocale = this.locale.resetPasswordSuccessPage;


    // this.appservice.headerNavlinkfield(false);
    // this.appservice.showHeader(false);
    // this.appservice.showLoaderimg(false);

    if (this.authenticationService.currentUserValue) {
      this.router.navigate(['/']);
    }
  }

  ngOnInit() {
  
    this.returnUrl = '/';
    this.createForm();
    this.createResetPasswordForm();
    this.forgotPasswrodForm();
    // get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }

  createForm() {
    this.loginformGroup = this.formBuilder.group({
      'username': ['', Validators.required],
      'password': ['', Validators.required],
    });
  }

  createResetPasswordForm() {
    this.resetpassword = this.formBuilder.group({
      'newpass': ['', [Validators.required, Validators.minLength(8), Validators.pattern(/^(?=.{8,})(?=.*[A-Z])(?=.*[@#$%^&+=]).*$/)]],
      'confirmpass': ['', [Validators.required, Validators.minLength(8), Validators.pattern(/^(?=.{8,})(?=.*[A-Z])(?=.*[@#$%^&+=]).*$/)]],
    }, {
      validator: MustMatch('newpass', 'confirmpass')
    });
  }

  forgotPasswrodForm(){
    this.forgotpasswordformGroup = this.formBuilder.group({
      'username': ['', Validators.required],
    });
  }
  

  getError(el) {
    switch (el) {
      case 'user':
        if (this.loginformGroup.get('username').hasError('required')) {
          return 'Please Enter a Valid Username';
        }
        break;
      case 'pass':
        if (this.loginformGroup.get('password').hasError('required')) {
          return 'Please Enter a Valid Password';
        }
        break;
      default:
        return '';
    }
  }


  onSubmit(value,event) {
    event.preventDefault();
    this.submitted = true;
    // stop here if form is invalid
    if (this.loginformGroup.invalid) {
      return;
    }

    this.loading = true;
        this.authenticationService.login(value.username, value.password)
          .pipe(first())
          .subscribe(
              data => {
                console.log(data);
                // login successful if there's a jwt token in the response
                if (data && data.loginPojo != null) {
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
                    localStorage.setItem('currentUser', JSON.stringify(data.loginPojo));
                    this.authenticationService.currentUserSubject.next(data.loginPojo);

                    if(data.loginPojo.jwToken == "Password Reset"){
                      this.router.navigate(['/reset-password']);
                    }
                    else{
                      this.router.navigate(['/agent-list']);
                    }
                }
                else{
                  this.errorMsg = 'Please enter a valid username and password';
                  console.log('error',this.errorMsg);
                  this.authenticationService.currentUserSubject.next(null);
                }
                return data;
              },
              error => {
                this.error = error;
                this.loading = false;
              });
  }


  forgetPass() {
    this.loginFormDisplay = false;
    this.loginFormResetEmial = true;
  }

  loginClose() {
    this.loginFormDisplay = true;
    this.loginFormResetEmial = false;
  }

  forgotClose(){
    this.loginFormDisplay = true;
    this.loginFormResetEmial = false;
    }

  sendResetLink() {
    var username = this.forgotpasswordformGroup.value.username;
    console.log('username', this.forgotpasswordformGroup.value.username);
    this.authenticationService.forgotPassword(username).subscribe(res => {
    console.log('forgot passowrd',res);
    res['loginPojo'] != null ? this.router.navigate(['/login']) : '';

  //  this.router.navigateByUrl('/reset-password');
    });
    this.loginFormDisplay = false;
    this.loginFormResetEmial = false;
    this.forgetPasswordSuccessForm = true;
  }
  resetClose() {
    this.loginFormDisplay = true;
    this.loginFormResetEmial = false;
    this.forgetPasswordForm = false;
  }
  ResetSucess() {
    this.forgetPasswordForm = false;
    this.forgetPasswordSuccessForm = true;
  }
  rediectToLoginForm() {
    this.loginFormDisplay = true;
    this.forgetPasswordSuccessForm = false;
  }

}
// custom validator to check that two fields match
export function MustMatch(controlName: string, matchingControlName: string) {
  return (formGroup: FormGroup) => {
    const control = formGroup.controls[controlName];
    const matchingControl = formGroup.controls[matchingControlName];

    if (matchingControl.errors && !matchingControl.errors.mustMatch) {
      // return if another validator has already found an error on the matchingControl
      return;
    }

    // set error on matchingControl if validation fails
    if (control.value !== matchingControl.value) {
      matchingControl.setErrors({ mustMatch: true });
    } else {
      matchingControl.setErrors(null);
    }
  }
}

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VaSendMessageComponent } from './va-send-message.component';

describe('VaSendMessageComponent', () => {
  let component: VaSendMessageComponent;
  let fixture: ComponentFixture<VaSendMessageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [VaSendMessageComponent],
      imports: [
        FormsModule,
        ReactiveFormsModule
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VaSendMessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('ngOnInit should disable messageText FromControl', () => {
    component.initialSettingsDone = false;
    component.messageForm.controls['messageText'].setValue('Hi');

    component.ngOnInit();

    expect(component.messageForm.controls['messageText'].valid).toBeFalsy();
  });

  it('should create', () => {
    component.initialSettingsDone = true;

    component.ngOnInit();

    expect(component.messageForm.controls['messageText'].valid).toBeFalsy();
  });

  it('ngOnChanges should enable messageText FromControl', () => {
    component.initialSettingsDone = true;
    component.messageForm.controls['messageText'].setValue('Hi');

    component.ngOnChanges();

    expect(component.messageForm.controls['messageText'].valid).toBeTruthy();
  });

  it('ngOnChanges should disable messageText FromControl', () => {
    component.initialSettingsDone = false;
    component.messageForm.controls['messageText'].setValue('Hi');

    component.ngOnChanges();

    expect(component.messageForm.controls['messageText'].valid).toBeFalsy();
  });

  it('ngOnChanges should disable messageText FromControl', () => {
    component.initialSettingsDone = false;
    component.messageForm = undefined;

    component.ngOnChanges();

    expect(component).toBeTruthy();
  });

  it('should create', () => {
    component.initialSettingsDone = true;

    component.ngOnInit();

    expect(component.messageForm.controls['messageText'].valid).toBeFalsy();
  });

  it('sendMessage should emit event and reset form', () => {
    const sendMessageClickedSpy = spyOn(component.sendMessageClicked, 'emit');
    component.initialSettingsDone = true;
    component.messageForm.controls['messageText'].setValue('Hi');
    component.messageForm.controls['messageText'].enable();

    component.sendMessage();

    expect(sendMessageClickedSpy).toHaveBeenCalled();
    expect(component.messageForm.controls['messageText'].value).toEqual(null);
  });

  it('sendMessage should not emit event and should not reset form', () => {
    const sendMessageClickedSpy = spyOn(component.sendMessageClicked, 'emit');
    component.initialSettingsDone = true;
    component.messageForm.controls['messageText'].setValue('Hi');
    component.messageForm.controls['messageText'].disable();

    component.sendMessage();

    expect(sendMessageClickedSpy).toHaveBeenCalledTimes(0);
    expect(component.messageForm.controls['messageText'].value).toEqual('Hi');
  });
});

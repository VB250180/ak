export const modalErrorConfig = {
    primaryText: 'Something went wrong',
    secondaryText: `We're having trouble completing your request, Please try again`,
    secondaryBtnText: 'Close',
    popUpType: 'warn',
    hasCancelBtn: true
};

export const modalDeleteConfig = {
    primaryText: 'Confirm',
    secondaryText: 'Are you sure want to delete?',
    hasPrimaryBtn: true,
    primaryBtnText: 'Yes',
    secondaryBtnText: 'No',
    popUpType: 'delete',
    hasCancelBtn: true
};

export const modalFileErrorConfig = {
    primaryText: 'Invalid Format',
    secondaryText: 'Please add .txt & .csv files',
    secondaryBtnText: 'Close',
    popUpType: 'warn',
    hasCancelBtn: true
};

export const modalFileSizeConfig = {
    primaryText: 'File Size limit',
    secondaryText: 'Please upload file size less than 1MB',
    secondaryBtnText: 'Close',
    popUpType: 'warn',
    hasCancelBtn: true
};

export const modalEditTrained = {
    primaryText: 'Warning',
    secondaryText: 'Already Is in Edit',
    secondaryBtnText: 'Close',
    popUpType: 'warn',
    hasCancelBtn: true
}

export const modalEditConfig = {
    primaryText: 'Warning',
    secondaryText: 'Your unsaved data will be lost! Are you sure?',
    hasPrimaryBtn: true,
    primaryBtnText: 'Yes',
    secondaryBtnText: 'No',
    popUpType: 'warn',
    hasCancelBtn: true
}; 

export const modalResponseTrainedError = {
    primaryText: 'Warning',
    secondaryText: 'Error when adding phrases',
    secondaryBtnText: 'Close',
    popUpType: 'warn',
    hasCancelBtn: true
}
export const modalResponseTrainedSuccess = {
    primaryText: 'Info',
    secondaryText: 'Phrases added successfully',
    secondaryBtnText: 'Close',
    popUpType: 'info',
    hasCancelBtn: true
}
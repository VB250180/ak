
// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { BehaviorSubject, Observable } from 'rxjs';
// import { map } from 'rxjs/operators';

// import { environment } from '../../../environments/environment';
// import { User } from '../../core/models/user/user.model';


// @Injectable({ providedIn: 'root' })
// export class AuthenticationService {
//     public currentUserSubject: BehaviorSubject<User>;
//     public currentUser: Observable<User>;

//     constructor(private http: HttpClient) {
//     }

//     public get currentUserValue(): User {
//         console.log(this.currentUserSubject.value);
//         return this.currentUserSubject.value;
//     }

//     login(username: string, password: string) {
//         let formData = new FormData();
//         formData.append('username', username);
//         formData.append('password', password);
//         console.log('login',username, password,formData,`${environment.apiLogin}`)

//         let body ={
//             "username":username,
//             "password":password
//         }

//         return this.http.post<any>(`${environment.apiLogin}/login`, formData );
//     }

//     logout() {
//         // remove user from local storage to log user out
//         localStorage.removeItem('currentUser');
//         this.currentUserSubject.next(null);
//     }
// }
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { environment } from '../../../environments/environment';
import { User } from '../../core/models/user/user.model';
import { getCurrentUserName } from 'src/app/core/utils/akeira-utils';
import { getCurrentUserId } from 'src/app/core/utils/akeira-utils';
import { Router } from '@angular/router';


@Injectable({ providedIn: 'root' })
export class AuthenticationService {
    value: any;
    public currentUserSubject: BehaviorSubject<User>;
    public currentUser: Observable<User>;

    constructor(private http: HttpClient, private router:Router) {
        this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
        this.currentUser = this.currentUserSubject.asObservable();
    }

    public get currentUserValue(): User {
        return this.currentUserSubject.value;
    }

    login(username: string, password: string) {
        let body = {

            "confirmPassword": "string",
            "email": "string",
            "jwToken": "string",
            "newPassword": "string",
            "password": password,
            "phoneNumber": "string",
            "userId": 0,
            "username": username
        }

        return this.http.post<any>(environment.apiUrl + '/login', body);
    }

    resetPassword(form){
        var username = getCurrentUserName();
        var userid = getCurrentUserId();
        var newpassword = form.newpass;
        var oldpassword = form.oldpass
           let body = {
            "confirmPassword": form.confirmpass,
            "email": "string",
            "jwToken": "string",
            "newPassword": newpassword,
            "password": oldpassword,
            "phoneNumber": "string",
            "userId": userid,
            "username": username
           }

           console.log(body);
        return this.http.put<any>(environment.apiUrl + '/reset-password' , body);
    }

    forgotPassword(username){
        console.log(username);
        let body = {
            "confirmPassword": "",
            "email": "",
            "jwToken": "",
            "newPassword": "",
            "password": "",
            "phoneNumber": "",
            "userId": "",
            "username": username
           }
        return this.http.put(environment.apiUrl + '/forgot-password' , body);
    }

    logout() {
        console.log('vygvtfvc')
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
        this.currentUserSubject.next(null);
        this.router.navigate(['/login']);
    }
}


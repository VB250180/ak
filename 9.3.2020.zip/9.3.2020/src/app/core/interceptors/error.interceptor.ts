import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { AuthenticationService } from '../authentication/authentication.service';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
    constructor(private authenticationService: AuthenticationService,  private matDialog:MatDialog) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(request).pipe(catchError(err => {
            if ([401, 403].indexOf(err.status) !== -1) {
                // auto logout if 401 Unauthorized or 403 Forbidden response returned from api
               this.authenticationService.logout();
               // location.reload(true);
            }
            else {
                const dialogConfigReset = new MatDialogConfig();
                dialogConfigReset.disableClose = true;
                dialogConfigReset.width = "800px";
                dialogConfigReset.data = {
                  primaryText: "Server is facing an issue, Please contact Uniphore IT Support",
                  hasPrimaryBtn: true,
                  primaryBtnText: 'Ok',
                  popUpType: 'warn',
                  hasCancelBtn: true
                }
                
           const modalDialog = this.matDialog.open(ModalComponent, dialogConfigReset);
            modalDialog.afterClosed().subscribe(data => {
            console.log(data);
      });
            }
         
            const error = err.message || err.statusText;
            return throwError(error);
        }))
    }
}
import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpHeaders } from '@angular/common/http';
import { Observable, EMPTY } from 'rxjs';

import { environment } from '../../../environments/environment';
import { AuthenticationService } from '../authentication/authentication.service';
import { Router } from '@angular/router';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';

@Injectable()
export class JwtInterceptor implements HttpInterceptor {
  constructor(private authenticationService: AuthenticationService, private router: Router, private matDialog: MatDialog) { }
  authReq: any;

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // add auth header with jwt if user is logged in and request is to api url
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    const isLoggedIn = currentUser && currentUser.jwToken;
    const isApiUrl = request.url.startsWith(environment.apiUrl);
    console.log('router url', this.router.url);
    if (isLoggedIn && isApiUrl) {
      request = request.clone({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache,no-store',
          'Pragma': 'no-cache',
          'Authorization': `Bearer ${currentUser.jwToken}`
        })
      });
      console.log('api url header passe', request, this.authReq);
      return next.handle(request);
    }
    else if (this.router.url.startsWith('/login')) {
      console.log('api url header passe', request, this.authReq);
      return next.handle(request);
    }
    else {
      const dialogConfigReset = new MatDialogConfig();
      dialogConfigReset.disableClose = true;
      dialogConfigReset.width = "800px";
      dialogConfigReset.data = {
        primaryText: "Session Timed Out, Please login to continue",
        hasPrimaryBtn: true,
        primaryBtnText: 'Ok',
        popUpType: 'warn',
        hasCancelBtn: true
      }

      const modalDialog = this.matDialog.open(ModalComponent, dialogConfigReset);
      modalDialog.afterClosed().subscribe(data => {
        console.log(data);
        this.router.navigate(['/login']);
      });
    }
    return EMPTY;
  }
}
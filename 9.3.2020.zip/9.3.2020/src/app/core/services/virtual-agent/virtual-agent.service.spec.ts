import { TestBed } from '@angular/core/testing';

import { VirtualAgentService } from './virtual-agent.service';

describe('VirtualAgentService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: VirtualAgentService = TestBed.get(VirtualAgentService);
    expect(service).toBeTruthy();
  });
});

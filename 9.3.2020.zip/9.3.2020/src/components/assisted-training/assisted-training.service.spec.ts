import { TestBed, async, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AssistedTrainingService } from './assisted-training.service';
import { HttpClientModule } from '@angular/common/http';
import { of } from 'rxjs';

describe('AssistedTrainingService', () => {
  let httpClientSpy: { get: jasmine.Spy,put: jasmine.Spy, post: jasmine.Spy,delete: jasmine.Spy };
  let assistedTrainingService: AssistedTrainingService;

  let assistedTrainingInputs = {
    "virtualAgents": [
      {
        "virtualAgent": {
          "vaId": 1,
          "vaName": "webBot",
          "vaIsLive": false,
          "vaAvatarName": "UMRBOT",
          "vaDescription": "web"
        },
        "languages": [
          {
            "id": 1,
            "value": "English"
          },
          {
            "id": 2,
            "value": "French"
          }
        ],
        "channels": [
          {
            "id": 1,
            "value": "WEB"
          }
        ]
      }
    ]
  };

  let intentList = {
    "mappedCount": 0,
    "inScopeCount": 0,
    "outOfScopeCount": 4,
    "conversationList": [
      {
        "sessionId": 1,
        "mapppedPhrases": [],
        "inScopePhrases": [],
        "outOfScopePhrases": [
          {
            "id": 1,
            "value": "need information"
          }
        ]
      },
      {
        "sessionId": 2,
        "mapppedPhrases": [],
        "inScopePhrases": [],
        "outOfScopePhrases": [
          {
            "id": 7,
            "value": "first class ticket from mumbai"
          },
          {
            "id": 4,
            "value": "ticket book pannanum"
          },
          {
            "id": 3,
            "value": "sollunga"
          }
        ]
      }
    ]
  };

  let intentSlots = [
    {
      "intent": {
        "id": 4,
        "value": "praveen intent"
      },
      "intentSlots": []
    },
    {
      "intent": {
        "id": 6,
        "value": "Booking Cancellation"
      },
      "intentSlots": []
    }
  ];

  let createIntentData = {
    "intent": {
      "intentId": 41,
      "intentName": "Test",
      "intentDescription": "Test",
      "virtualAgent": null,
      "businessUnit": null,
      "languages": [
        {
          "langEngId": 1,
          "langName": "English",
          "channels": [
            {
              "icmId": 65,
              "channelId": 1,
              "channelName": "WEB",
              "intentConfigStage": 0,
              "isLive": false
            }
          ]
        },
        {
          "langEngId": 2,
          "langName": "French",
          "channels": [
            {
              "icmId": 66,
              "channelId": 1,
              "channelName": "WEB",
              "intentConfigStage": 0,
              "isLive": false
            }
          ]
        }
      ]
    }
  }

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule, HttpClientTestingModule],
      providers: [AssistedTrainingService],
    });
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get', 'put','post','delete']);
    assistedTrainingService = new AssistedTrainingService(<any>httpClientSpy);
  });

  // it(`should create`, async(inject([HttpTestingController, AssistedTrainingService],
  //   (httpClient: HttpTestingController, service: AssistedTrainingService) => {
  //     expect(httpClient).toBeTruthy(); expect(service).toBeTruthy();
  //   })));

  // it('check assisted training input', () => {
  //   httpClientSpy.get.and.returnValue(of(assistedTrainingInputs));

  //   assistedTrainingService.getInputs().subscribe(
  //     res => {
  //       expect(res['virtualAgents'].length).toBe(1);
  //     },
  //     fail
  //   );
  //   expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  // });

  it('check intent list', () => {
    httpClientSpy.get.and.returnValue(of(intentList));

    assistedTrainingService.getIntents(1, '2019-11-04', 2, 1, true, '2019-11-10', 2, '').subscribe(
      res => {
        expect(res['conversationList'].length).toBe(2);
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check intent slots', () => {
    httpClientSpy.get.and.returnValue(of(intentSlots));

    assistedTrainingService.intentSlots(1, 2).subscribe(
      res => {
        expect(res).toBe(intentSlots);
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check search intent', () => {
    httpClientSpy.get.and.returnValue(of(intentSlots));

    assistedTrainingService.searchIntent(1, 2).subscribe(
      res => {
        expect(res).toBe(intentSlots);
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check create intent', () => {
    httpClientSpy.post.and.returnValue(of(createIntentData));

    assistedTrainingService.createIntent({ intentDescription: "Test", intentName: "Test", isIntentLive: false }, "2").subscribe(
      res => {
        expect(res).toBe(createIntentData);
      },
      fail
    );
    expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
  });
  
  it('check delete unmapped user input', () => {
    httpClientSpy.delete.and.returnValue(of(1));

    assistedTrainingService.deleteUnmappedUserInputs(2).subscribe(
      res => {
        expect(res).toBe(1);
      },
      fail
    );
    expect(httpClientSpy.delete.calls.count()).toBe(1, 'one call');
  });

  it('check save unmapped user input', () => {
    httpClientSpy.put.and.returnValue(of(true));

    assistedTrainingService.saveUnmappedInputs([{id: 363, value: "hope you doing good", intentslots: {}, intentId: 654}]).subscribe(
      res => {
        expect(res).toBe(true);
      },
      fail
    );
    expect(httpClientSpy.put.calls.count()).toBe(1, 'one call');
  });

  it('check language change method', () => {
    httpClientSpy.get.and.returnValue(of([intentSlots,assistedTrainingInputs]));
  
    assistedTrainingService.languageChange(1,'20-01-2018',2,1,true,'20-02-2018',4,'').subscribe(
      (res:any) => {
        expect(res.length).toBe(2);
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(2, 'one call');
  });
});

import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { AlertPromise } from 'selenium-webdriver';
import { IntentService } from './intent.service';
import { FormControl, FormGroup, ReactiveFormsModule, FormsModule, Validators } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
// import { InfiniteScroll } from 'ngx-infinite-scroll';
import { InfiniteScrollDirective } from 'ngx-infinite-scroll';
import { NgxSpinnerService } from "ngx-spinner";
import { getCurrentUserId } from '../../app/core/utils/akeira-utils';

@Component({
  selector: 'app-intent-listing',
  templateUrl: './intent-listing.component.html',
  styleUrls: ['./intent-listing.component.scss']
})
export class IntentListingComponent implements OnInit {

  // Added dummy value for  build 
  // Start

  // searchValue02;
  // scrollDistance;
  // scrollUpDistance;
  // throttle;
  // onScrollDown() { };
  // End


  clicks: any = 0;
  lastClick: any;
  Emergencies: any = [];
  showSelected: boolean = true;
  channels: any = [];
  languages: any = [];
  dataRow: any;
  response: any = [];
  data: any = [];
  data2: any;
  lang: any = [];
  vaById: any = {};
  vaLists: any = [];
  status: any;
  IntentListingForm: FormGroup;
  VA_id: any;
  flag: number = 1;

  //channeList: any = [];
  delete_vaId: any;
  delete_intentId: any = [];
  vaIsLive: boolean;
  vaName: any;
  vaId: any;
  vaDesc: any;
  vaChan: any;
  vaLang: any;
  vaChanId: any;
  vaLangId: any;
  intentListResponse: any = [];
  PageNo: number = 1;
  loaded: boolean = false;
  counter: number = 1;
  len: number;
  showloader = false;
  toggledIcmIds = [];

  intentFilter: any = {
    va: 0,
    channel: 0,
    language: 0
  }
  userId: number = 0;
  channel: any = [];
  language: any = [];
  channelList: Array<any>;
  languageList: Array<any>;

  modalRef: BsModalRef;
  config = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: "my-modal2"
  };
  searchValue: string = '';
  @ViewChild('templateWarning', { static: false }) templateRef: TemplateRef<any>;

  modalRefInfo: BsModalRef;
  configModal = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: "my-modal2"
  };
  modalMsg: string = '';
  modalHeader: string = 'Info';
  oldSearchText: string = '';
  intentSelected: any;

  constructor(private intentService: IntentService, private modalService: BsModalService, private router: Router, private activatedRoute: ActivatedRoute, private spinner: NgxSpinnerService) {
    this.userId = getCurrentUserId();
    this.IntentListingForm = new FormGroup({
      va: new FormControl(null, Validators.required),
      channel: new FormControl(null, Validators.required),
      language: new FormControl(null, Validators.required),
    })
  }

  ngOnInit() {

    this.spinner.show();
    this.activatedRoute.paramMap.subscribe(params => {
      console.log('params', params);
      this.vaName = params.get('name');
      this.vaId = params.get('id');
      this.vaDesc = params.get('desc');
      this.vaChan = params.get('channel');
      this.vaLang = params.get('lang');
      this.vaChanId = params.get('chId');
      this.vaLangId = params.get('langId');
    });
    this.getdropdownValues();
  }

  getdropdownValues() {
    this.intentService.getInputs(this.userId).subscribe((res: any) => {
      this.vaLists = res.virtualAgentRoleMaps;
      for (let i = 0; i < res['virtualAgentRoleMaps'].length; i++) {
        this.vaById[res['virtualAgentRoleMaps'][i].vrmId] = res['virtualAgentRoleMaps'][i];
      }
      console.log(this.vaById);
      setTimeout(() => {
        this.callIntentListByparam();
      }, 1000);

    }, (err: any) => { console.error('Error In Intent Listinbg dropdown'); console.error(err) });
  }

  callIntentListByparam() {
    this.spinner.hide();
    if (this.vaId) {
      this.intentFilter.va = +this.vaId, this.intentFilter.channel = +this.vaChanId, this.intentFilter.language = +this.vaLangId;
      this.channels.push(this.vaById[this.intentFilter.va].channels);
      this.languages.push(this.vaById[this.intentFilter.va].languages);
      // this.IntentListingForm.patchValue({
      //   va: this.intentFilter.va,
      //   channel: this.intentFilter.channel,
      //   language: this.intentFilter.language,
      // });
      this.statusFilter(this.intentFilter.va, false);
      this.getIntentList(1, this.intentFilter.va, this.intentFilter.channel, this.intentFilter.language);

    } else {
      console.log("--------------> ")
      this.intentFilter.va = 0, this.intentFilter.channel = 0, this.intentFilter.language = 0;
      // this.IntentListingForm.patchValue({
      //   va: this.intentFilter.va,
      //   channel: this.intentFilter.channel,
      //   language: this.intentFilter.language,
      // });
      this.getIntentList(1, this.intentFilter.va, this.intentFilter.channel, this.intentFilter.language);
    }
  }

  onScroll() {
    this.counter += 1;
    this.showloader = true;
    console.log(this.counter, this.intentFilter.va, this.intentFilter.channel, this.intentFilter.language);
    this.intentService.intentListByName(this.userId,this.counter, this.intentFilter.va, this.intentFilter.channel, this.intentFilter.language, this.oldSearchText)
      .subscribe((res: any[]) => {
        this.loaded = true;
        console.log('All Intent scrolled data List', res);
        for (let i = 0; i < res['intents'].length; i++) {
          let intent = res['intents'][i];
          this.tableDataGen(intent);
        }
        this.showloader = false;
        console.log("1  scrolled data -------(-1-)---->", this.intentListResponse);
      });
  }

  statusFilter(status: string | number, isRequestNeeded: boolean) {
    console.log('On va change --> ', status, isRequestNeeded);
    if (status == 0) {
      this.intentFilter.va = status, this.intentFilter.channel = 0, this.intentFilter.language = 0;
      this.languages = [], this.channels = [];
      this.IntentListingForm.patchValue({ channel: 0, language: 0 });
      this.getIntentList(this.PageNo, this.intentFilter.va, this.intentFilter.channel, this.intentFilter.language);
    } else {
      this.languages = this.vaById[status].languages;
      this.channels = this.vaById[status].channels;
    }

    if (isRequestNeeded) {
      this.intentFilter.va = status, this.intentFilter.channel = 0, this.intentFilter.language = 0;
      this.IntentListingForm.patchValue({
        channel: this.intentFilter.channel,
        language: this.intentFilter.language,
      });
      this.getIntentList(this.PageNo, this.intentFilter.va, this.intentFilter.channel, this.intentFilter.language);
    }
  }

  channelFilter(channel: { id: any; }) {
    console.log('channelFilter ====> ', channel);
    this.intentFilter.channel = channel;
    this.getIntentList(this.PageNo, this.intentFilter.va, this.intentFilter.channel, this.intentFilter.language);
  }

  languageFilter(language: { id: any; }) {
    console.log(' languageFilter ====> ', language);
    this.intentFilter.language = language;
    this.getIntentList(this.PageNo, this.intentFilter.va, this.intentFilter.channel, this.intentFilter.language);
  }


  getIntentList(PageNo: number, vaId: any, vaChanId: any, vaLangId: any) {
    this.spinner.show();
    this.counter = 1;
    this.intentService.intentList(this.userId,PageNo, vaId, vaChanId, vaLangId)
      .subscribe((res: any[]) => {
        this.loaded = true; console.log('res ====>', PageNo, res);
        if (PageNo == 1) { this.len = res['count']; this.intentListResponse = [] }
        for (let i = 0; i < res['intents'].length; i++) {
          let intent = res['intents'][i];
          this.tableDataGen(intent);
        }
        console.log("intentListResponse --------->", this.intentListResponse);
        this.spinner.hide();
      });
  }

  tableDataGen(intent: { languages: any[]; intentId: any; intentName: any; virtualAgent: { vaId: any; vaName: any; vaIsLive: any; vaAvatarName: any; }; businessUnit: any; }) {
    for (let j = 0; j < intent.languages.length; j++) {
      let lang = intent.languages[j];
      let pushdata = {
        'intentId': intent.intentId,
        'intentName': intent.intentName,
        'vaId': intent.virtualAgent.vaId,
        'vaName': intent.virtualAgent.vaName,
        'vaIsLive': intent.virtualAgent.vaIsLive,
        'vaAvatarName': intent.virtualAgent.vaAvatarName,
        'businessUnit': intent.businessUnit,
        'langEngId': lang.langEngId,
        'langName': lang.langName,
        'channels': lang.channels,
        'channelsStatus': '',
        'icmIds': []
      };
      let toggleFlag: boolean = false;
      for (let ch = 0; ch < pushdata.channels.length; ch++) {
        let channel = pushdata.channels[ch];
        channel['informationStatus'] = ((1 & channel.intentConfigStage) == 1);
        channel['visualModelerStatus'] = ((2 & channel.intentConfigStage) == 2);
        channel['trainingPhaseStatus'] = ((4 & channel.intentConfigStage) == 4);
        channel.channelStatus = this.draftORLive(channel);
        if ((channel.intentConfigStage == 7) || channel.isLive) {
          toggleFlag = true;
          pushdata.icmIds.push(channel.icmId);
        }
        pushdata['channelsStatus'] = pushdata['channelsStatus'] != '' ? pushdata['channelsStatus'] + ', ' + this.draftORLive(channel) : this.draftORLive(channel) + '';
      }
      pushdata['showTogglebtn'] = toggleFlag;
      this.intentListResponse.push(pushdata);
    }
  }

  draftORLive(channel) {
    return channel.isLive ? 'Active' : 'Draft'
  }

  onSearchIntent(event: any) {
    this.counter = 1;
    console.log('====>', event, event.target.value);
    this.oldSearchText = event.target.value;
    this.spinner.show();

    this.intentService.intentListByName(this.userId,1, this.intentFilter.va, this.intentFilter.channel, this.intentFilter.language, event.target.value)
      .subscribe((res: any[]) => {
        this.loaded = true; console.log('onSearchIntent res ====>', res);
        this.len = res['count']; this.intentListResponse = [];
        for (let i = 0; i < res['intents'].length; i++) {
          let intent = res['intents'][i];
          this.tableDataGen(intent);
        }
        this.spinner.hide();

        console.log("onSearchIntent intentListResponse --------->", this.intentListResponse);
      });
  }

  openModal(template: TemplateRef<any>, vaId: any, intentId: any) {
    this.modalRef = this.modalService.show(template, this.config);
    this.delete_vaId = vaId;
    this.delete_intentId.push(intentId);
  }

  openInfoModal(templateWarning: TemplateRef<any>) {
    this.modalRefInfo = this.modalService.show(this.templateRef, this.configModal);
  }

  openToggleModal(template: TemplateRef<any>, intent) {
    this.intentSelected = intent;
    let modalOptions = {
      animated: true,
      keyboard: true,
      backdrop: false,
      ignoreBackdropClick: false,
      class: "modal_size"
    };
    this.modalRefInfo = this.modalService.show(template, modalOptions);
  }

  onchannelStatusChange(event, channel) {
    if (event.checked) {
      if (channel.isLive) {
        let index = this.toggledIcmIds.indexOf(channel.icmId);
        if (index > -1) {
          this.toggledIcmIds.splice(index, 1);
        }
      } else {
        this.toggledIcmIds.push(channel.icmId);
      }
    } else {
      if (!channel.isLive) {
        let index = this.toggledIcmIds.indexOf(channel.icmId);
        if (index > -1) {
          this.toggledIcmIds.splice(index, 1);
        }
      } else {
        this.toggledIcmIds.push(channel.icmId);
      }
    }
    console.log(this.toggledIcmIds);
  }

  deleteIntentsFunc() {
    this.spinner.show();
    this.intentService.deleteIntents(this.delete_vaId, this.delete_intentId).subscribe((res: any[]) => {
      console.log('Delete Intent List', res);
      if (res['intents'].length > 0) {
        this.modalRef.hide();
        this.searchValue = null;
        this.spinner.hide();
        this.getIntentList(this.PageNo, this.intentFilter.va, this.intentFilter.channel, this.intentFilter.language);
      } else {
        console.error('Error in delete Intent');
        this.spinner.hide();
      }
    });
  }

  refresh(): void {
    window.location.reload();
  }

  toggleIntentFunc() {
    if (this.toggledIcmIds.length > 0) {
      this.modalRefInfo.hide();
      this.spinner.show();
      let body = { 'icmIds': this.toggledIcmIds };
      console.log('--toggleIntentFunc--', this.toggledIcmIds, this.intentSelected.vaId);
      this.intentService.toggleIntent(body, this.toggledIcmIds, this.intentSelected.vaId).subscribe((res: any[]) => {
        console.log('toggleIntent List', res);
        this.toggledIcmIds = [];
        this.intentSelected = {};
        let intentLanguageChannelMaps = res['intentLanguageChannelMaps'];
        console.log('intentLanguageChannelMaps ----> ', intentLanguageChannelMaps);
        if (intentLanguageChannelMaps !== null) {
          this.spinner.hide();
          this.modalHeader = "Info";
          this.modalMsg = "Toggle Successfully";
          this.modalRefInfo = this.modalService.show(this.templateRef, this.configModal);
          this.getIntentList(this.PageNo, this.intentFilter.va, this.intentFilter.channel, this.intentFilter.language);
        } else {
          this.modalHeader = "Warning";
          this.modalMsg = "Error in Toggle";
          this.modalRefInfo = this.modalService.show(this.templateRef, this.configModal);
          this.spinner.hide();
        }
      });
    } else {
      this.modalRefInfo.hide();
      this.intentSelected = {};
    }
  }

  onToggleIntentModalCancel() {
    this.modalRefInfo.hide();
    this.toggledIcmIds = [];
    this.intentSelected = {};
  }

  cloneIntentFunc(intId: any, vaId: any) {
    let body = {};
    this.spinner.show();
    //console.log('--cloneIntentFunc--', vaId, intId);
    this.intentService.cloneIntent(body, intId, vaId).subscribe((res: any[]) => {
      //console.log('CloneIntent List', res);
      this.response = res['intent'];
      if (this.response !== null) {
        console.log("Done successfully -->", this.response);
        this.modalHeader = "Info";
        this.modalMsg = "Successfully Clone to Live";
        this.modalRefInfo = this.modalService.show(this.templateRef, this.configModal);
        this.spinner.hide();
      } else {
        console.log("Already Exists!!!");
        this.modalHeader = "Warning";
        this.modalMsg = "Already Intent exists in Live !!!";
        this.modalRefInfo = this.modalService.show(this.templateRef, this.configModal);
        this.spinner.hide();
      }
    }, err => console.error(err));
  }
}




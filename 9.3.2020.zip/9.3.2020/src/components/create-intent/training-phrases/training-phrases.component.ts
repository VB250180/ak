import { Component, OnInit,  Input,  OnChanges, Output, EventEmitter } from '@angular/core';
import { CreateIntentService } from '../create-intent.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { BsModalService } from "ngx-bootstrap/modal";
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { TextSelectEvent } from "../../../app/shared/directives/text-select.directive";
import { SelectionRectangle } from "../../../app/core/models/selectionRectangle";
import { MatDialog} from '@angular/material';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatChipInputEvent } from '@angular/material/chips';
import { ModalComponent } from '../../../app/shared/components/modal/modal.component';
import { modalFileErrorConfig, modalFileSizeConfig, modalEditConfig, modalEditTrained,modalResponseTrainedError,modalDeleteConfig,modalResponseTrainedSuccess } from '../../../app/core/utils/const-message';
import { chooseColorClassByLastDigit, getObjById, isEmptyObj } from '../../../app/core/utils/akeira-utils';

export interface SearchWord {
    name: string;
}


@Component({
    selector: 'app-training-phrases',
    templateUrl: './training-phrases.component.html',
    styleUrls: ['./training-phrases.component.scss'],
    host: {
        '(document:click)': 'functionClick($event)',
    }
})
export class TrainingPhrasesComponent implements OnInit, OnChanges {

    //Other Page data
    @Input() arr;

    //Pass To other page
    @Output() enableTrainEvent = new EventEmitter<boolean>();
    @Output() configurationStatus = new EventEmitter<boolean>();

    //TOP
    intentId: number;
    langId: number;
    vaRoleId: number;
    chId: number;
    flag: number;
    newData: any = [];
    IsHidden: boolean = true;


    //Left
    fileContent: any;
    orginalContent: any;
    manualPhrase: any = '';
    visible = true;
    selectable = true;
    removable = true;
    addOnBlur = true;
    readonly separatorKeysCodes: number[] = [ENTER, COMMA];
    srchword: SearchWord[] = [];
    upcontent: any;

    hostSelection_left: SelectionRectangle | null;
    viewportRectangle_left: SelectionRectangle | null;
    selectedText_left: string = '';
    posStart_left: any;
    posEnd_left: any;


    //Right
    showTabNewPhrase: boolean = false;

    //Right -- Section 1
    addPhraseArray: any = [];
    currentSelectedtxt: string = '';
    hostSelection_right: SelectionRectangle | null;
    viewportRectangle_right: SelectionRectangle | null;
    selectedText_right: string = '';
    posStart_right: any;
    posEnd_right: any;
    dropdownError: string;
    intentSlotList: any = [];
    selectedaddPhraseArrayKey: any;

    //Right-- Section 2
    searchTextRight: String;
    pageNum: number = 1;
    phrases: any = [];
    checkAddArray: boolean = true;
    isLoaded: boolean = false;

    intentSlots: any = [];
    slotsToDisplay: any = [];
    slotsToDisplayMap = new Map<string, any>();
    counter: number = 1;
    showSection2Loader: boolean = false;

    constructor(private route: ActivatedRoute, private intentService: CreateIntentService,
        private spinner: NgxSpinnerService, private modalService: BsModalService, private toastr: ToastrService,
        private matDialog: MatDialog, private router: Router, public dialog: MatDialog) {
        this.route.paramMap.subscribe((params: any) => {
            this.intentId = params.params.intId;
            this.langId = params.params.langId;
            this.flag = params.params.flag;
        });
    }

    functionClick($event) {
        if (!this.IsHidden) {
          this.IsHidden = !this.IsHidden;
        }
      }
    

    ngOnInit() {
        this.searchTextRight = '';
        console.log(this.flag, this.newData);

        if (!this.flag) {
            this.intentId = this.newData[0];
            this.langId = this.newData[1];
            this.chId = this.newData[2];
            this.vaRoleId = this.newData[3]
        }
        this.fetchPageData(this.intentId, this.langId, this.pageNum);
    }

    ngOnChanges() {
        console.log('ngOnChanges', this.intentId, this.langId, this.pageNum, this.searchTextRight);
        this.newData = this.arr;
        this.searchTextRight != undefined ? this.fetchPageData(this.intentId, this.langId, this.pageNum) : '';
    }

    refreshTrainingPhrase(langId, chID) {
        console.log("----From other page---->", langId, chID);
        this.langId = langId;
        this.chId = chID;
        this.fetchPageData(this.intentId, this.langId, this.pageNum);
    }

    makeStringEmpty = (s) => s === ('' || undefined) ? '' : '';

    fetchPageData(intentId: number, langId: number, pageNum: number) {
        this.spinner.show();
        this.searchTextRight = this.makeStringEmpty(this.searchTextRight);
        this.intentService.requestaddTrainingPhraseAndintentSlots(intentId, langId, pageNum, this.searchTextRight).subscribe(responseList => {
            console.log('addTrainingPhrase -->', responseList[0]);
            console.log('intentSlots -->', responseList[1]);

            //intentSlots response
            this.intentSlots = responseList[1]['intentSlots'];
            this.intentSlots.forEach((e, i) => {
                let colorClassName = this.getColorClassById(i);
                e['colorClass'] = colorClassName
                this.slotsToDisplayMap.set(e.intentSlotId, e)
                this.slotsToDisplay.push({
                    'color': colorClassName,
                    'value': e.intentSlotName,
                    'intentSlotId': e.intentSlotId,
                });
            });

            //addTrainingPhrase response
            (pageNum == 1) ? this.phrases = [] : '';
            let Convphrases = responseList[0]['trainingPhrases'];
            if (Convphrases.length > 0) {
                this.checkAddArray = false;
                this.enableTrainEvent.emit(this.checkAddArray);
            } else {
                this.checkAddArray = true;
                this.enableTrainEvent.emit(this.checkAddArray);
            }
            this.displayTrainingPhrases(Convphrases);
            this.spinner.hide();
        }, err => {
            this.spinner.hide();
            console.error('fetchPageData Error', err);
        });

    }

    addPhrases(intentId, langId, pageNum) {
        this.searchTextRight = this.makeStringEmpty(this.searchTextRight);
        this.intentService.addTrainingPhrase(intentId, langId, pageNum, this.searchTextRight).subscribe(res => {
            if (pageNum == 1) { this.phrases = [] }
            console.log(res);
            let Convphrases = res['trainingPhrases'];
            let status = (Convphrases.length > 0 ? true : false);
            this.configurationStatus.emit(status);
            this.displayTrainingPhrases(Convphrases);
            this.spinner.hide();
        }, err => {
            this.spinner.hide();
            console.log(err);
        });
    }

    onScroll() {
        this.counter += 1;
        this.searchTextRight = this.makeStringEmpty(this.searchTextRight);
        this.showSection2Loader = true;
        console.log('this.counter', this.counter);
        this.intentService.addTrainingPhrase(this.intentId, this.langId, this.counter, this.searchTextRight).subscribe(res => {
            let phrasesOnScroll = res['trainingPhrases'];
            this.displayTrainingPhrases(phrasesOnScroll);
            this.showSection2Loader = false;
        }, err => {
            console.error(err);
        });
    }

    getColorClassById(id) {
        return chooseColorClassByLastDigit(id);
    }

    displayTrainingPhrases(phrases) {
        phrases.length > 0 ? this.isLoaded = true : '';
        let posPhraseValues: any = [];
        for (let i = 0; i < phrases.length; i++) {
            let trainingPhrases = phrases[i];
            if ((phrases[i].intentSlotMapPojos !== null) && (phrases[i].intentSlotMapPojos.length > 0)) {

                let posPhrase: any,
                    rxp = /%([^%/]+)%/g, curMatch, postionArray: string[] = [];
                posPhrase = trainingPhrases.trainingPhraseText;
                for (let k = 0; k < trainingPhrases.intentSlotMapPojos.length; k++) {
                    postionArray.push(trainingPhrases.intentSlotMapPojos[k].position);
                    while ((curMatch = rxp.exec(posPhrase))) {
                        if (trainingPhrases.intentSlotMapPojos[k].position === curMatch[1]) {
                            posPhrase = (posPhrase.replace(
                                curMatch[1],
                                trainingPhrases.intentSlotMapPojos[k].value));
                            posPhraseValues = posPhrase.replace(/%/g, "");
                        }
                    }
                }
                trainingPhrases['trainingPhraseDisplay'] = posPhraseValues;
                trainingPhrases['mappedHighlightData'] = this.genrateHighlightdata(posPhraseValues, true, postionArray, trainingPhrases.intentSlotMapPojos);
                console.log('trainingPhrases -->', trainingPhrases);
            } else {
                trainingPhrases['trainingPhraseDisplay'] = trainingPhrases.trainingPhraseText;
                trainingPhrases['mappedHighlightData'] = this.genrateHighlightdata(trainingPhrases.trainingPhraseText, false, [], '');
                trainingPhrases['intentSlotMapPojos'] = [];
            }
            this.phrases.push(trainingPhrases);
        }
        console.log('update phrases --- ', this.phrases.length);
    }

    genrateHighlightdata(txt: string, isMapped: boolean, postionArray: string[], intentSlotMapPojos: any) {
        console.log('text', txt, isMapped, postionArray, intentSlotMapPojos);
        let txtArray = txt.split(" "), renderJson = [], colorArray = [];
        txtArray.forEach((e, i) => { renderJson.push({ 'index': i, 'value': e, 'isHighlight': false, 'key': ('pos' + i) }); });
        if (isMapped) {
            for (var key of postionArray) { colorArray.push(key.split('~')); }
            let outputColorArray = [].concat(...colorArray);
            for (let i in renderJson) {
                for (let j in outputColorArray) {
                    if (renderJson[i]['key'] === outputColorArray[j]) {
                        renderJson[i]['isHighlight'] = true;
                        renderJson[i]['colorClass'] = this.getColorCodeByPostion(renderJson[i]['key'], intentSlotMapPojos);
                        break;
                    }
                }
            }
        }
        return renderJson;
    }

    getColorCodeByPostion(pos, intentSlotMapPojosList) {
        let keyIntent = ''
        let regex = new RegExp("\\b(" + pos + ")\\b");
        for (let intent in intentSlotMapPojosList) {
            if (intentSlotMapPojosList[intent]['position'].search(regex) >= 0) {
                keyIntent = intentSlotMapPojosList[intent]['intentSlot']['intentSlotId'];
                break;
            }
        }
        console.log('########### ', this.slotsToDisplayMap, keyIntent);
        return this.slotsToDisplayMap.get(keyIntent)['colorClass'];
    }

    traniedPhraseEdit(index: number, phraseId: number) {
        let tempAry: any;
        tempAry = this.phrases[index];
        console.log(tempAry);
        if (this.checkIfNewPhraseHas(phraseId)) {
            //Add to new phrases list
            this.addPhraseArray.push(tempAry);
            this.showTabNewPhrase = true;
        } else {
            this.openModalAlreadyAdded();
        }
    }

    checkIfNewPhraseHas(phraseId) {
        for (let i in this.addPhraseArray) {
            if (this.addPhraseArray[i]['trainingPhraseId'] === phraseId) {
                return false;
            }
        }
        return true;
    }

    openModalAlreadyAdded() {
        this.dialog.open(ModalComponent, {
            disableClose: true,
            data: modalEditTrained
        });
    }

    openModalDelete(id: any, value: any, index: any) {
        let dialogRef = this.dialog.open(ModalComponent, {
            disableClose: true,
            data: modalDeleteConfig
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result) {
                this.deleteTrainingPhraseCall(id)
            }
        });
    }

    deleteTrainingPhraseCall(idToDelete) {
        this.intentService
            .deleteTrainingPhrase(this.intentId, this.langId, idToDelete)
            .subscribe(res => {
                console.log(res);
                this.addPhrases(this.intentId, this.langId, this.pageNum);
            });
    }

    onselectFile(data) {
        let allowedext = ["application/vnd.ms-excel", "text/plain"];
        let file = data[0];
        if (allowedext.includes(file.type)) {
            if (file.size < 1048576) {
                this.fileContent = "";
                this.orginalContent = "";
                let fileReader: FileReader = new FileReader();
                let that = this;
                fileReader.onloadend = function (x) {
                    that.fileContent = fileReader.result;
                    that.orginalContent = fileReader.result;
                }
                fileReader.readAsText(file);
            }
            else {
                this.openModalFilesizeLimit()
            }

        }
        else {
            this.openModalFileError()

        }
    }

    openModalFileError() {
        this.dialog.open(ModalComponent, {
            disableClose: true,
            data: modalFileErrorConfig
        });
    }

    openModalFilesizeLimit() {
        this.dialog.open(ModalComponent, {
            disableClose: true,
            data: modalFileSizeConfig
        });
    }

    serachWord(event: MatChipInputEvent): void {
        const input = event.input;
        const value = event.value;
        if ((value || '').trim()) {
            this.srchword.push({ name: value.trim() });
            if (this.srchword[0].name != undefined) {
                this.highlightSearchTxt();
            }
        }
        // Reset the input value
        if (input) {
            input.value = '';
        }
    }

    highlightSearchTxt() {
        let string: any;
        for (var i = 0; i < this.srchword.length; i++) {

            string = this.srchword[i].name;
            if (!string) {
                return this.fileContent;
            }
            var gf = this.fileContent.replace(new RegExp(string, "gi"), match => {
                console.log(match);
                return '<span class="training_phrse_sch_highlight">' + match + '</span>';
            });
            this.fileContent = gf;

        }
    }

    remove(data: SearchWord): void {
        const index = this.srchword.indexOf(data);
        if (index >= 0) {
            this.srchword.splice(index, 1);
            if (this.srchword.length > 0) {
                for (var i = 0; i < this.srchword.length; i++) {
                    let remov = this.srchword[i].name;
                    if (i == 0) {
                        this.upcontent = this.orginalContent
                    } else {
                        this.upcontent = this.fileContent
                    }
                    var gf = this.upcontent.replace(new RegExp(remov, "gi"), match => {
                        console.log(match);
                        return '<span class="training_phrse_sch_highlight">' + match + '</span>';
                    });
                    this.fileContent = gf;
                }
            }
            else {
                return this.fileContent = this.orginalContent;
            }
        }
    }

    public renderSelectionLeft(event: TextSelectEvent): void {
        console.group("Left Text Select Event <----");
        console.log("Event:", event);
        console.log("Text:", event.text);
        console.log("start:", event.posStart);
        console.log("end:", event.posEnd);
        console.log("Viewport Rectangle:", event.viewportRectangle);
        console.log("Host Rectangle:", event.hostRectangle);
        console.groupEnd();

        if (event.hostRectangle) {
            this.hostSelection_left = event.hostRectangle;
            this.viewportRectangle_left = event.viewportRectangle;
            this.selectedText_left = event.text;
            this.posStart_left = event.posStart;
            this.posEnd_left = event.posEnd;
        } else {
            this.hostSelection_left = null;
            this.viewportRectangle_left = null;
            this.selectedText_left = "";
        }
    }

    getcopiedData() {
        let cptxt = this.selectedText_left.replace(/\r/g, "").replace(/\n/g, "");
        this.hostSelection_left = null;
        this.viewportRectangle_left = null;
        this.addNewPhrase(cptxt, false);
        // Now that we've shared the text, let's clear the current selection.
        document.getSelection().removeAllRanges();
        this.hostSelection_left = null;
        this.viewportRectangle_left = null;
        this.selectedText_left = "";
    }

    addNewPhrase(txt, onEdit) {
        let addtxt = txt.replace(/^\s+/, '').replace(/\s+$/, '');
        console.log('addNewPhrase ---> ', txt, onEdit);

        this.enableTrainEvent.emit(this.checkAddArray);
        let newPhraseSlotDetails = {};
        if (onEdit) {

        } else {
            newPhraseSlotDetails = {
                "intentSlotMapPojos": [],
                "trainingPhraseId": 0,
                "trainingPhraseText": addtxt,
                "trainingPhraseDisplay": addtxt,
                "mappedHighlightData": this.genrateHighlightdata(addtxt, false, [], '')
            }
        }
        this.addPhraseArray.push(newPhraseSlotDetails);
        this.showTabNewPhrase = true;
        this.manualPhrase = '';
    }

    editAddPhrase(index: number) {
        this.manualPhrase = this.addPhraseArray[index].trainingPhraseDisplay;
        this.addPhraseArray.splice(index, 1);
    }

    openModalAddPhraseEdit(index: number) {
        if (this.manualPhrase != '') {
            let dialogRef = this.dialog.open(ModalComponent, {
                disableClose: true, data: modalEditConfig
            });
            dialogRef.afterClosed().subscribe(result => {
                result ? this.editAddPhrase(index) : '';
            });
        } else {
            this.editAddPhrase(index);
        }
    }

    openModalAddPhraseDelete(index: number) {
        let dialogRef = this.dialog.open(ModalComponent, {
            disableClose: true, data: modalDeleteConfig
        });
        dialogRef.afterClosed().subscribe(result => {
            this.addPhraseArray.splice(index, 1);
        });
    }

    public renderSelectionRight(event: TextSelectEvent, key: any): void {
        console.group("Right Text Select Event ---->");
        console.log("Event:", event);
        console.log("Text:", event.text);
        console.log("start:", event.posStart);
        console.log("end:", event.posEnd);
        console.log("Viewport Rectangle:", event.viewportRectangle);
        console.log("Host Rectangle:", event.hostRectangle);
        console.groupEnd();

        if (event.hostRectangle) {
            this.hostSelection_right = event.hostRectangle;
            this.viewportRectangle_right = event.viewportRectangle;
            this.selectedText_right = event.text;
            this.posStart_right = event.posStart;
            this.posEnd_right = event.posEnd;
            this.posStart_right = this.checkForFirstSpace(event.text) ? this.posStart_right = (this.posStart_right + 1) : this.posStart_right;
            this.showIntentSlotsDropdown(key);
        } else {
            this.clearRightSelection();
        }
    }
    checkForFirstSpace = (t) => t.search(/^\S.*$/) === -1;
    checkEmpty = (t) => t != null && t != '' ? true : false;

    clearRightSelection() {
        this.hostSelection_right = null;
        this.viewportRectangle_right = null;
        this.selectedText_right = "";
    }

    showIntentSlotsDropdown(key: any) {
        this.currentSelectedtxt = '';
        this.selectedaddPhraseArrayKey = key;
        let currentWords = this.selectedText_right.replace(/^\s+/, '').replace(/\s+$/, '');
        if (this.intentSlots.length > 0 && this.checkEmpty(currentWords)) {
            let displayedtext = this.addPhraseArray[key]['trainingPhraseDisplay'];
            let regex = new RegExp("\\b(" + currentWords + ")\\b");
            let isCurrectWords = displayedtext.search(regex);
            this.currentSelectedtxt = currentWords;
            if (isCurrectWords > -1) {
                this.openSlotsDropdown();
            } else {
                this.dropdownError = 'Select proper words';
                this.intentSlotList = [];
            }
        } else {
            this.clearRightSelection();
        }
    }

    openSlotsDropdown() {
        this.dropdownError = 'Choose an Intent slot';
        this.intentSlotList = [];
        this.slotsToDisplay.forEach(e => { this.intentSlotList.push(e); });
    }

    getIntentSlotValue(x) {
        console.log('selectedslot', x, this.selectedaddPhraseArrayKey);
        console.log('--obj-> ', this.addPhraseArray[this.selectedaddPhraseArrayKey]);
        let txtary = this.currentSelectedtxt.split(" ");
        let posData = this.getPOSTIONoftxt(txtary, this.addPhraseArray[this.selectedaddPhraseArrayKey]['mappedHighlightData']);
        console.log(posData);
        if (posData !== undefined) {
            for (let x = 0; x < posData.posAry.length; x++) {
                let regex = new RegExp("\\b(" + posData.posAry[x] + ")\\b");
                for (let i = 0; i < this.addPhraseArray[this.selectedaddPhraseArrayKey]['intentSlotMapPojos'].length; i++) {
                    console.log(i, this.addPhraseArray[this.selectedaddPhraseArrayKey]['intentSlotMapPojos'][i], regex);
                    if (this.addPhraseArray[this.selectedaddPhraseArrayKey]['intentSlotMapPojos'][i]['position'].search(regex) >= 0) {
                        this.addPhraseArray[this.selectedaddPhraseArrayKey]['intentSlotMapPojos'].splice(i, 1); break;
                    }
                }
            }
        }
        let intentSlotMapPojo = {
            "position": posData.pos,
            "value": this.currentSelectedtxt,
            "intentSlot": x,
        }
        this.addPhraseArray[this.selectedaddPhraseArrayKey]['intentSlotMapPojos'].push(intentSlotMapPojo);
        this.addPhraseArray[this.selectedaddPhraseArrayKey]['trainingPhraseText'] = this.coloringPhrase(this.addPhraseArray[this.selectedaddPhraseArrayKey]);

        // Now that we've shared the text, let's clear the current selection.
        document.getSelection().removeAllRanges();
        this.clearRightSelection();
    }

    getPOSTIONoftxt(txtary: any, mappedHighlightData: any) {
        let posAry = [];
        let pos = 'pos' + this.posStart_right++;
        posAry.push(pos);
        while (this.posStart_right <= this.posEnd_right) {
            let i = this.posStart_right++
            posAry.push('pos' + i);
            pos += '~pos' + i;
        }
        let posdata = { 'posAry': posAry, 'pos': pos }
        return posdata;
    }

    coloringPhrase(phrase) {
        let outputColorArray = [].concat(...this.colorArrayGenrater(phrase['intentSlotMapPojos']));
        return this.colorDisplayTextAndGenrateInnerPhase(phrase, outputColorArray);
    }

    colorArrayGenrater(intentSlotMapPojos) {
        let colorArray = [];
        for (let i = 0; i < intentSlotMapPojos.length; i++) {
            colorArray.push(intentSlotMapPojos[i]['position'].split('~'));
        }
        return colorArray;
    }

    colorDisplayTextAndGenrateInnerPhase(phrase, outputColorArray) {
        console.log(phrase, outputColorArray);
        let innerPhase = '', dontAdd: boolean = false, rxp = /%[ /]%/g;
        for (let i = 0; i < phrase['mappedHighlightData'].length; i++) {
            phrase['mappedHighlightData'][i]['isHighlight'] = false;
            for (let j in outputColorArray) {
                if (phrase['mappedHighlightData'][i]['key'] === outputColorArray[j]) {
                    phrase['mappedHighlightData'][i]['isHighlight'] = true;
                    phrase['mappedHighlightData'][i]['colorClass'] = this.getColorCodeByPostion(phrase['mappedHighlightData'][i]['key'], phrase['intentSlotMapPojos']);
                    innerPhase += '%' + phrase['mappedHighlightData'][i]['key'] + '% ';
                    dontAdd = false;
                    break;
                } else {
                    dontAdd = true;
                }
            }
            dontAdd ? innerPhase += phrase['mappedHighlightData'][i]['value'] + ' ' : '';
        }
        innerPhase = innerPhase.replace(rxp, '~').replace(/^\s+/, '').replace(/\s+$/, '');
        innerPhase == '' ? innerPhase = phrase['trainingPhraseDisplay'] : '';
        return innerPhase;
    }

    saveAddedTrainingPhrases() {
        this.spinner.show();
        this.flag = 1;
        for (let i = 0; i < this.addPhraseArray.length; i++) {
            delete this.addPhraseArray[i].trainingPhraseDisplay;
        }

        if (this.addPhraseArray.length > 0) {
            this.intentService.addPhraseDetails(this.intentId, this.langId, this.addPhraseArray).subscribe(res => {
                if (res['errorBody'] !== null) {
                    this.spinner.hide();
                    this.dialog.open(ModalComponent, {
                        disableClose: true, data: modalResponseTrainedError
                    });
                } else {
                    this.spinner.hide();
                    this.dialog.open(ModalComponent, {
                        disableClose: true, data: modalResponseTrainedSuccess
                    });
                    let convPhrases = res['trainingPhrases'];
                    this.displayTrainingPhrases(convPhrases);
                    this.addPhrases(this.intentId, this.langId, this.pageNum);
                }
            }, err => {
                this.dialog.open(ModalComponent, {
                    disableClose: true, data: modalResponseTrainedError
                });
            });
            this.addPhraseArray = [];
        }
    }
}
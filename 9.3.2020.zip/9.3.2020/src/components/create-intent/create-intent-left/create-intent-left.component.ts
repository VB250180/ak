import { Component, OnInit, ViewChild, Output, EventEmitter, Input } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, Form, Validators, SelectControlValueAccessor } from '@angular/forms';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { Conversation, ConversationStage, FinalResponse, GetInfo, IntentSlot, SendMessage, intentsDropD, systemSlotDropD, SystemSlot, Entity } from '../model/intent';
import { CreateIntentService } from '../create-intent.service';
import { ActivatedRoute } from '@angular/router';
import { analyzeAndValidateNgModules } from '@angular/compiler';
import { NgSelectModule, NgOption } from '@ng-select/ng-select';
import { ToastrService } from 'ngx-toastr';
import { MatMenuTrigger } from '@angular/material';
import { AddRichCardComponent } from './add-rich-card/add-rich-card.component';
import {MatDialog} from '@angular/material/dialog';

declare var $: any;


@Component({
  selector: 'app-create-intent-left',
  templateUrl: './create-intent-left.component.html',
  styleUrls: ['./create-intent-left.component.scss']

})
export class CreateIntentLeftComponent implements OnInit {
  @Output() public getLeftPanelData = new EventEmitter<any>();
  @Output() public getLeftPanelDataGet = new EventEmitter<any>();
  @Output() public getLeftPanelDataFinalRes = new EventEmitter<any>();
  @Input() childMessage: any;
  @Input() childMessageIntentId: any;
  isValidationActive: boolean = false;
  isSendMsgActive: boolean = false;
  isGetInfoActive: boolean = false;
  isFinalResActive: boolean = false;
  newSystemSlotArray = new Array<any>();
  selectedUserIds = [];
  activPostIndex = 0;
  conversation = new Conversation();
  sendMessageNewArray: any = [];
  newTempGetInfoArr: any = [];
  getInfoNewArray: any = [];
  systemSlot = new SystemSlot();
  intentSlot = new IntentSlot();
  finalResponse = new FinalResponse();
  getInfo = new GetInfo();
  valEntity: intentsDropD;
  entitys: Entity;
  systemslots: systemSlotDropD[];
  intentId; chId; langId; vaRoleId;
  BreakException = {};

  constructor(private route: ActivatedRoute, public createIntentService: CreateIntentService, private toastr: ToastrService,public dialog: MatDialog) {
    this.conversation.validationIntent = null;
    this.route.paramMap.subscribe((params: any) => {
      this.intentId = params.params.intId;
      this.vaRoleId = params.params.vaID;
      this.chId = params.params.chId;
      this.langId = params.params.langId;
      if (this.intentId != undefined) {
        this.getConversationList(this.intentId, this.langId, this.chId);
        this.getIntentsDropdowns(this.vaRoleId, this.intentId);
      }
    });
  }

  addCustomUser = (term) => ({ systemSlotKeyId: term, systemSlotKeyName: term });

  newArray = []
  getConversationList(intentId, langId, chId) {
    this.createIntentService.getIntentConversionList(intentId, langId, chId)
      .subscribe((res: any) => {
        this.conversation = res.conversation;
        this.valEntityDropDown = this.conversation.validationIntent;
        this.conversation.systemSlots.forEach((e, i) => {
          this.newArray.push(e.systemSlotKey);
        });
        this.selectedUserIds = this.newArray;
        console.log(this.selectedUserIds)
        this.sendMsgIsActive(this.conversation.conversationStages);
        this.getInfoActive(this.conversation.conversationStages);
        this.sendFinalResponse(this.conversation);
        this.validationIsActive();
        this.newArray = [];
      })
  }
  // isOpen: boolean;

  replaceStr; lastElement; finalResSlot: any; sendFinalResTxt;
  sendFinalResponse(conversation) {
    this.message = "";
    this.conversation.conversationStages.forEach((el, i) => {
      (el.finalResponse != null) ? this.getFinalResSendMsgTxt() : '';
    });
    this.getFinalAddBtn();
  }

  getFinalResSendMsgTxt() {
    let sendFinalResponseArray = this.conversation.conversationStages;
    sendFinalResponseArray.forEach(e => {
      if (e.finalResponse != null) {
        this.lastElement = e;
      }
    });
    console.log('last element response', this.lastElement);
    sendFinalResponseArray.forEach(e => {
      this.finalResSlot = this.lastElement.finalResponse;
      (this.finalResSlot.positionAndSlots.length == 0) ? this.message = this.finalResSlot.finalResponseText : '';
      this.finalResSlot.positionAndSlots.forEach(e => {
        if (e.intentSlot != null) {
          var replaceStr = e.intentSlot.intentSlotName;
        } else {
          var replaceStr = e.responseSlot.responseSlotName;
        }
        var str1 = "<" + replaceStr + ">";
        this.finalResSlot.finalResponseText = this.finalResSlot.finalResponseText.replace(e.position, str1);
        this.sendFinalResTxt = this.finalResSlot.finalResponseText;
        var res = this.sendFinalResTxt.replace(/%/g, "");
        this.message = res;
        console.log('response msg', this.message);
      });
    });
    this.getFinalAddBtn();
  }


  getInfoActive(getInfoArrT) {
    this.getInfoNewArray = [];
    getInfoArrT.forEach((el, i) => {
      if (el.getInfo != null) {
        this.getInfoNewArray.push(el);
        this.isGetInfoActive = true;
      }
    });
    let hasDataGet: number = 0;
    this.getInfoNewArray.forEach((e, i) => { (e.getInfo != null || undefined) ? hasDataGet += 1 : ''; });
    this.isGetInfoActive = hasDataGet > 0 ? true : false;
  }
  sendMsgIsActive(sendMsgArr) {
    let hasData: number = 0;
    sendMsgArr.forEach((e, i) => { (e.sendMessage != null || undefined) ? hasData += 1 : ''; });
    this.isSendMsgActive = hasData > 0 ? true : false;
  }
  validationIsActive() {
    this.checkValidationTab() ? this.isValidationActive = true : this.isValidationActive = false;
  }

  checkValidationTab() {
    return ((this.valEntityDropDown != undefined) && (this.selectedUserIds.length > 0)) ? true : false;
  }


  ngOnInit() {
    $(document).on("keypress", "input", function (e) {
      var startPos = e.currentTarget.selectionStart;
      if (e.which === 32 && startPos == 0)
        e.preventDefault();
    });
    $(document).on("keypress", "textarea", function (e) {
      var startPos = e.currentTarget.selectionStart;
      if (e.which === 32 && startPos == 0)
        e.preventDefault();
    });

    this.getIntentsDropdowns(this.childMessage, this.childMessageIntentId);
    this.getSystemSlotDropdowns();
    this.getEntitysDropdowns();
    this.createIntentService.currentMessage.subscribe(message => this.message = message);
  }

  // ValidationBlock
  valEntityDropDown;
  changeVal(valEntity) {
    this.valEntityDropDown = valEntity;
  }
  valSys;
  systemSlotKeyName;

  validateAddBtn() {
    if (this.checkValidationTab()) {
      this.conversation.validationIntent = this.valEntityDropDown;
      this.selectedUserIds.forEach((e, i) => {
        let systemSlot = { systemSlotId: null, systemSlotKey: { systemSlotKeyId: e.systemSlotKeyId, systemSlotKeyName: e.systemSlotKeyName } };
        this.newSystemSlotArray.push(systemSlot);
      });
      this.conversation.systemSlots = this.newSystemSlotArray;
      this.newSystemSlotArray = new Array<any>();
      this.getLeftPanelData.emit(this.conversation);
    } else {
      this.toastr.warning('', "Choose validation Intent and System slot's");
    }
    this.validationIsActive();
  }
  validateCancelBtn() {
    this.conversation.validationIntent = null;
    this.newSystemSlotArray = new Array<any>();
    this.selectedUserIds = this.newSystemSlotArray;
    this.conversation.systemSlots = this.selectedUserIds;
    this.validationIsActive();
    this.getLeftPanelData.emit(this.conversation);
  }

  // sendMessageBlock
  sendMsg; msg; changeEditIcon;

  addMsg(msgRef) {
    if (msgRef == "" || undefined) {
      return true;
    }
    this.msg = "";
    this.sendMsg = {
      sendMessage: {
        "messageText": msgRef
      },
      sequenceNumber: 0
    }
    this.conversation.conversationStages.push(this.sendMsg)
    var myDataM = this.conversation.conversationStages;
    let newConversationSendMsgArray = [...new Map(myDataM.map(obj => [JSON.stringify(obj), obj])).values()];
    this.conversation.conversationStages = [];
    this.conversation.conversationStages = newConversationSendMsgArray;
    this.sendMsgFunc();
  }
  delMsg(i) {
    this.conversation.conversationStages.splice(i, 1);
    this.sendMsgFunc();
  }
  editMsg(i, data) {
    this.sendMessageNewArray = [];
    this.msg = data.sendMessage.messageText;
    this.sendMessageNewArray.push(data);
    this.changeEditIcon = true;
  }
  updateMsg(msgReg) {
    if (msgReg == "") {
      this.sendMessageNewArray = [];
      this.changeEditIcon = false;
      this.sendMessageNewArray = [];
    }
    this.sendMessageNewArray.forEach((e, i) => {
      this.conversation.conversationStages.forEach((el, i) => {
        if (e.conversationStageId == el.conversationStageId) {
          e.sendMessage.messageText = msgReg;
          this.msg = "";
          this.sendMessageNewArray = [];
          this.changeEditIcon = false;
          this.sendMessageNewArray = [];
        }
      });
    });
    this.sendMsgFunc()
  }
  sendMsgFunc() {
    this.sendMsgIsActive(this.conversation.conversationStages);
    this.sendMessageNewArray.forEach(e => {
      this.conversation.conversationStages.push(e);
    });
    this.sendMessageNewArray = [];
    var myData = this.conversation.conversationStages;
    this.conversation.conversationStages = [...new Map(myData.map(obj => [JSON.stringify(obj), obj])).values()];
    this.getLeftPanelData.emit(this.conversation);
  }

  newClearArray = [];
  sendMsgClearBtn() {
    this.conversation.conversationStages.forEach((e, i) => {
      (e.sendMessage == null) ? this.newClearArray.push(e) : '';
      this.conversation.conversationStages = this.newClearArray;
    });
    this.newClearArray = [];
    this.sendMsgFunc();
    this.sendMsgIsActive(this.conversation.conversationStages);
  }
  // getInfoBlock
  prevAddInfoSlot: Boolean = false;

  getGetInfo(e) {
    this.getInfoNewArray.push(e);
    var myData = this.getInfoNewArray;
    this.getInfoNewArray = [...new Map(myData.map(obj => [JSON.stringify(obj), obj])).values()];
    this.getInfoNewArray.forEach((e, i) => {
      if (e.getInfo.intentSlot.intentSlotName == undefined) {
        this.getInfoNewArray.splice(i, 1)
      } else {
      };
    });
  }


  addInfoSlot() {
    let anyGetInfoError: boolean = false;
    this.getInfoNewArray.length == 0 ? anyGetInfoError = true : '';

    try {
      this.getInfoNewArray.forEach(el => {
        let e=el.getInfo;
        if (e.intentSlot != null) {
          if ((e.intentSlot.entity.entityName!= null) &&(e.intentSlot.entity.entityName!= undefined)&& (e.intentSlot.intentSlotDescription != null)  && (e.promptValidationMessage != null)&&(e.promptValidationMessage != "")) {
            anyGetInfoError = true;
          } else {
            anyGetInfoError = false;
            this.toastr.warning("Enter all Data");
            throw this.BreakException;
          }
        } else {
          anyGetInfoError = false;
          this.toastr.warning("Enter all Data");
          throw this.BreakException;
        }
      });

    } catch (e) {
      if (e !== this.BreakException) throw e;
    }

    if (anyGetInfoError) {
      this.getInfo = new GetInfo();
      let getInfoArray = {
        conversationStageId: null,
        finalResponse: null,
        getInfo: this.getInfo,
        sendMessage: null,
        sequenceNumber: null
      }
      this.getInfoNewArray.push(getInfoArray);
      anyGetInfoError = false;
    }



  }
  checkEmpty(d) {
    return d != null && d != '' && d !=undefined ? true : false;
  }


  showGetInfoErr() {
    this.toastr.warning("Add all fields")
  }

  removeInfoSlot(i) {
    this.getInfoNewArray.forEach((el, idx) => {
      if (i == idx) {
        var a = this.conversation.conversationStages.indexOf(el);
        this.conversation.conversationStages.splice(a, 1);
      }
    });
    this.getInfoNewArray.splice(i, 1);
    this.getInfoBtn();
  }
  message: string;

  getInfoBtn() {
    try {
       this.getInfoNewArray.forEach(el => {
         let e=el.getInfo;
        if (e.intentSlot != null) {
          if ((this.checkEmpty(e.intentSlot.entity.entityName)) && (this.checkEmpty(e.intentSlot.intentSlotDescription)) && (this.checkEmpty(e.intentSlot.intentSlotName)) && (this.checkEmpty(e.promptValidationMessage))) {
          } else {
            this.showGetInfoErr();
            throw this.BreakException;
          }
        } else {
          this.showGetInfoErr();
          throw this.BreakException;
        }
      });
      this.duplicateGetInfo();
    } catch (e) {
      if (e !== this.BreakException) throw e;
    }
  }

  duplicateGetInfo() {
    var valueArr1 = this.getInfoNewArray.map(function (item) { return item.getInfo.intentSlot.intentSlotName });
    var isDuplicate1 = valueArr1.some(function (item, idx) {
      return valueArr1.indexOf(item) != idx
    });
    (isDuplicate1) ? this.showDuplicateErrorMsg() : this.DuplicateGetInfoEntity();
  }

  DuplicateGetInfoEntity() {
    var valueArr2 = this.getInfoNewArray.map(function (item) { return item.getInfo.intentSlot.entity.entityName });
    var isDuplicate2 = valueArr2.some(function (item, idx) {
      return valueArr2.indexOf(item) != idx
    });
    (isDuplicate2) ? this.showDuplicateErrorMsgEntity() : this.getInfoDataPush();
  }

  showDuplicateErrorMsgEntity() {
    this.toastr.warning("", "More than one same Entity is not allowed")
  }
  getInfoDataPush() {
    (this.getInfoNewArray.length == 0) ? this.isGetInfoActive = false : this.isGetInfoActive = true;
    this.getInfoNewArray.forEach((e, i) => {
      this.conversation.conversationStages.push(e);
    });
    var myData = this.conversation.conversationStages;
    this.conversation.conversationStages = [...new Map(myData.map(obj => [JSON.stringify(obj), obj])).values()];
    this.getLeftPanelDataGet.emit(this.conversation);
  }

  newGetInfoClearArray = [];

  getInfoClearBtn() {
    this.getInfoNewArray = [];
    this.conversation.conversationStages.forEach((e, i) => {
      (e.getInfo == null) ? this.newGetInfoClearArray.push(e) : '';
    });
    this.conversation.conversationStages = this.newGetInfoClearArray;
    this.newGetInfoClearArray = [];
    this.isGetInfoActive = false;
    this.getLeftPanelDataGet.emit(this.conversation);
  }


  // ResponseSlot
  addResSlot() {
    let anyFinalResError: boolean = false;
    this.conversation.responseSlots.length == 0 ? anyFinalResError = true : '';
    try {
      this.conversation.responseSlots.forEach(e => {
        if ((this.checkEmpty(e.responseSlotName)) && (this.checkEmpty(e.responseSlotDescription))) {
          anyFinalResError = true;
        } else {
          anyFinalResError = false;
          this.toastr.warning("Enter all Data");
          throw this.BreakException;
        }
      });
    } catch (e) {
      if (e !== this.BreakException) throw e;
    }

    if (anyFinalResError) {
      let getResSlotArray = {
        responseSlotId: null,
        responseSlotName: "",
        responseSlotDescription: ""
      }
      this.conversation.responseSlots.push(getResSlotArray);
    }
  }

  removeResSlot(i) {
    this.conversation.responseSlots.splice(i, 1);
    this.getFinalAddBtn();
  }

  a; position;
  SendTxtMsg() {
    this.a = {
      finalResponse: this.finalResponse
    }
    this.a.finalResponse.positionAndSlots = [];
    this.getInfoDropDown();
    this.getFinalResDropDown();
    this.position = 0;
    let rxp = /<([^>/]+)>/g;
    let curMatch;
    this.a.finalResponse.finalResponseText = this.message;
    // while (curMatch = rxp.exec(this.a.finalResponse.finalResponseText)) {
      while (curMatch =( this.a.finalResponse.finalResponseText.match(/<([^>/]+)>/))) {
      console.log(curMatch[1]);
      var extStr = curMatch[0];
      var extStrP = curMatch[1];
      this.a.finalResponse.finalResponseText = this.a.finalResponse.finalResponseText.replace(extStr, "%"+"pos" + this.position +"%");
      console.log(this.a.finalResponse.finalResponseText);
      if (this.getInfoDropDownValue.filter(item => item.getInfo.intentSlot.intentSlotName == extStrP).length) {
        let ententSlotName = { "position": "pos" + this.position, intentSlot: { "intentSlotName": extStrP } };
        this.a.finalResponse.positionAndSlots.push(ententSlotName);
      }
      if (this.finalResDropDownValue.filter(item => item.responseSlotName == extStrP).length) {
        let ententSlotName = { "position": "pos" + this.position, responseSlot: { "responseSlotName": extStrP } };
        this.a.finalResponse.positionAndSlots.push(ententSlotName);
      }
      this.position++;
    }
        this.duplicateFinalRes();
  }

  showDuplicateErrorMsg() {
    this.toastr.warning('', "More than one Same name cannot be allowed")
  }
  duplicateFinalRes() {
    var valueArr = this.conversation.responseSlots.map(function (item) { return item.responseSlotName });
    var isDuplicate = valueArr.some(function (item, idx) {
      return valueArr.indexOf(item) != idx
    });
    (isDuplicate) ? this.showDuplicateErrorMsg() : this.getLeftPanelDataFinalRes.emit(this.conversation);
  }


  getFinalAddBtn() {
    try {
      this.conversation.responseSlots.forEach(e => {
        if ((this.checkEmpty(e.responseSlotName)) && (this.checkEmpty(e.responseSlotDescription))) {
        } else {
          this.toastr.warning("Enter all Data");
          throw this.BreakException;
        }
      });
          this.SendTxtMsg();
    } catch (e) {
      if (e !== this.BreakException) throw e;
    }

    (this.message == "") ? this.isFinalResActive = false : this.isFinalResActive = true;
    this.createIntentService.changeMessage(this.message);
  }

  // dropdownBindvalue
  compareVal(c1: intentsDropD, c2: intentsDropD): boolean {
    return c1 && c2 ? c1.intentId === c2.intentId : c1 === c2;
  }
  compareSys(c1: systemSlotDropD, c2: systemSlotDropD): boolean {
    return c1 && c2 ? c1.systemSlotKeyId === c2.systemSlotKeyId : c1 === c2;
  }
  compareEntity(c1: Entity, c2: Entity): boolean {
    return c1 && c2 ? c1.entityId === c2.entityId : c1 === c2;
  }
  // dropDownValues
  getSystemSlotDropdowns() {
    this.createIntentService.getSystemSlotDropdown().subscribe((Res: any) => {
      console.log(Res);
      this.systemslots = Res.systemSlotKeys;
    });
  };
  getIntentsDropdowns(vaRoleId, intentId) {
    let validationResArr:any=[];
    this.createIntentService.getIntentsDropdown(vaRoleId, intentId).subscribe((Res: any) => {
      Res.intents.forEach((e,i) => {
        (e.intentType=="VALIDATION")?validationResArr.push(e):'';
      });
      this.valEntity=validationResArr;
    });
  }
  getEntitysDropdowns() {
    this.createIntentService.getEntitys().subscribe((Res: any) => {
      this.entitys = Res.entities;
    });
  }



  getInfoDropDownValue = []; finalResDropDownValue = []
  getInfoDropDown() {
    this.getInfoDropDownValue = [];
    this.conversation.conversationStages.forEach((e, i) => {
      (e.getInfo != null) ? this.getInfoDropDownValue.push(e) : '';
    });
  }
  getFinalResDropDown() {
    this.finalResDropDownValue = [];
    this.finalResDropDownValue = this.conversation.responseSlots;
  }

  @ViewChild(MatMenuTrigger, { static: false })
  contextMenu: MatMenuTrigger;

  contextMenuPosition = { x: '0px', y: '0px' };


  onContextMenu(event: MouseEvent) {
    this.getInfoDropDown();
    this.getFinalResDropDown();
    event.preventDefault();
    this.contextMenuPosition.x = event.clientX + 'px';
    this.contextMenuPosition.y = event.clientY + 'px';
    // this.contextMenu.menuData = { 'item': item };
    this.contextMenu.menu.focusFirstItem('mouse');
    this.contextMenu.openMenu();
  }

  onContextMenuAction1(item) {
    var strSendMsg = " "+"<" + item + ">"+" ";
    this.message += strSendMsg;
  }


  openAddRichCard() {
    const dialogRef = this.dialog.open(AddRichCardComponent);
    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

}



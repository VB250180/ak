import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddRichCardComponent } from './add-rich-card.component';

describe('AddRichCardComponent', () => {
  let component: AddRichCardComponent;
  let fixture: ComponentFixture<AddRichCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddRichCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddRichCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

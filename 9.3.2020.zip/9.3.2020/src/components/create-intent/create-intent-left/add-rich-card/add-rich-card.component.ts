import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-rich-card',
  templateUrl: './add-rich-card.component.html',
  styleUrls: ['./add-rich-card.component.scss']
})
export class AddRichCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  openRichCard(e){
    debugger;
  }

}

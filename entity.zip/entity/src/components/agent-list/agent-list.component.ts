import { Component, OnInit } from '@angular/core';
import { ChartType, ChartDataSets, ChartOptions } from 'chart.js';
import { MultiDataSet, Label, Color } from 'ng2-charts';
import { NgxSpinnerService } from "ngx-spinner";
// import { FormControl, FormGroup, ReactiveFormsModule, FormsModule, Validators } from '@angular/forms';
// import { any } from 'node_modules1/codelyzer/util/function';
// import * as pluginAnnotations from 'chartjs-plugin-annotation';
// import { AssistedTrainingComponent } from '../assisted-training/assisted-training.component';
import { AgentListService } from './agent-list.service';

@Component({
  selector: 'app-agent-list',
  templateUrl: './agent-list.component.html',
  styleUrls: ['./agent-list.component.scss']
})
export class AgentListComponent implements OnInit {
  liveAgentList: Array<any> = [];
  testAgentList: Array<any> = [];
  channelList: Array<any>;
  languageList: Array<any>;
  agentFilter: any = {
    channel: 0,
    language: 0
  }
  showLiveVA: boolean = true;
  showTestVA: boolean = true;

  // VAFilterForm: FormGroup;

  public doughnutChart1Labels: Label[] = ['', ''];
  public doughnutChart1Data: MultiDataSet = [
    [75, 25]
  ];
  public doughnutChart1Options: any = {
    cutoutPercentage: 90,
    elements: {
      arc: {
        borderWidth: 0
      }
    },
    tooltips: {
      enabled: false
    }
  };

  public pieChart1Colors = [
    {
      backgroundColor: ['#57E0D8', 'rgba(87, 224, 216, 0.1)'],
    },
  ];

  public pieChart2Colors = [
    {
      backgroundColor: ['#B1A3F9', 'rgba(177, 163, 249, 0.1)'],
    },
  ];

  public doughnutChartType: ChartType = 'pie';
  public pieChartLegend = false;


  public lineChartData: ChartDataSets[] = [
    { data: [0, 33, 0, 0], label: '', borderWidth: 1 }
  ];

  public lineChartLabels: Label[] = ['', '', '', ''];

  public lineChartOptions: (ChartOptions) = {
    responsive: true,
    maintainAspectRatio: false,
    // pointBorder: 0,
    // borderWidth: 1,
    elements: { point: { radius: 0 } },
    scales: {
      xAxes: [{
        gridLines: {
          display: false,
          drawBorder: false,
          tickMarkLength: 0
        },
      }],
      yAxes: [{
        gridLines: {
          display: false,
          drawBorder: false
        },
        ticks: {
          beginAtZero: true,
          callback: function (value, index, values) {
            return '';
          },
        }
      }]
    }
  };
  public lineChartColors: Color[] = [
    {
      backgroundColor: 'rgba(87, 224, 216, 0.1)',
      borderColor: '#57E0D8',
      pointBackgroundColor: '#57E0D8',
      pointBorderColor: '#57E0D8',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: '#57E0D8'
    }
  ];
  public lineChart2Colors: Color[] = [
    {
      backgroundColor: 'rgba(177, 163, 249, 0.1)',
      borderColor: '#B1A3F9',
      pointBackgroundColor: '#B1A3F9',
      pointBorderColor: '#B1A3F9',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: '#B1A3F9'
    }
  ];
  public lineChartLegend = false;
  public lineChartType = 'line';

  public showTrand = true;

  constructor(private agentListService: AgentListService, private spinner: NgxSpinnerService) {
    // this.VAFilterForm = new FormGroup({
    //   channel: new FormControl(null, Validators.required),
    //   language: new FormControl(null, Validators.required),
    // });
  }

  ngOnInit() {
    this.spinner.show();
    this.getLanguageAndChannelList();
    this.getAgentList();
  }

  getLanguageAndChannelList() {
    this.agentListService.getChannels().subscribe((res: any) => {
      this.spinner.hide();
      this.channelList = res.channels;
      this.languageList = res.languages;
    },
      err => console.error(err));
  }

  getAgentList() {
    this.agentListService.getAgentList(this.agentFilter.channel, this.agentFilter.language).subscribe((res: any) => {
      this.spinner.hide();
      this.filterAgentList(res.virtualAgentDashboardResponseObject.virtualAgentDashboardList);
    },
      err => console.error(err));
  }

  filterAgentList(res) {
    this.liveAgentList = [];
    this.testAgentList = [];
    res.map(val => {
      val.vaDashChannelList.map(cVal => {
        cVal.vaDashLangList.map(lVal => {
          let obj = { ...val, channelData: cVal, languageData: lVal };
          if (obj.vaRoleName == 'live') {
            this.liveAgentList.push(obj);
          } else {
            this.testAgentList.push(obj);
          }
        });
      });
    });
    console.log('liveAgentList', this.liveAgentList);
    console.log('testAgentList', this.testAgentList);
  }

  toggleLiveAgentGraphs = (index) => {
    if (!this.liveAgentList[index].showTrand) {
      this.liveAgentList[index].showTrand = true;
    } else {
      this.liveAgentList[index].showTrand = !this.liveAgentList[index].showTrand;
    }
    if (!this.liveAgentList[index].trandData) {
      // this.spinner.show();
      this.getVATrandData(index);
    }
  }

  getVATrandData(index) {
    this.spinner.show();
    this.agentListService.getVATrandData(this.agentFilter.channel, this.agentFilter.language, this.liveAgentList[index].vaRoleMapId).subscribe((res: any) => {
      setTimeout(() => { this.spinner.hide(); }, 500);
      console.log('Res --> ', res);
      // this.liveAgentList = res;
      this.liveAgentList[index].trandData = res.virtualAgentTrendResponseObject;

      // console.log('newdataaa', this.liveAgentList[index].trandData);

      this.liveAgentList[index].monthTrandData = [{ data: [], label: '', borderWidth: 1 }];
      this.liveAgentList[index].monthTrandLables = [];
      this.liveAgentList[index].trandData.monthTrendList.map(val => {
        this.liveAgentList[index].monthTrandData[0].data.push(val.trendvalue);
        this.liveAgentList[index].monthTrandLables.push('');
      });

      this.liveAgentList[index].weekTrandData = [{ data: [], label: '', borderWidth: 1 }];
      this.liveAgentList[index].weekTrandLables = [];
      this.liveAgentList[index].trandData.weekTrendList.map(val => {
        this.liveAgentList[index].weekTrandData[0].data.push(val.trendvalue);
        this.liveAgentList[index].weekTrandLables.push('');
      });

      //monthTrendListCallHandle //weekTrendListCallHandle
      this.liveAgentList[index].monthTrandCallHandleData = [{ data: [], label: '', borderWidth: 1 }];
      this.liveAgentList[index].monthTrandCallHandleLables = [];
      if (this.liveAgentList[index].trandData.monthTrendListCallHandle) {
        this.liveAgentList[index].trandData.monthTrendListCallHandle.map(val => {
          this.liveAgentList[index].monthTrandCallHandleData[0].data.push(val.trendvalue);
          this.liveAgentList[index].monthTrandCallHandleLables.push('');
        });
      }

      this.liveAgentList[index].weekTrandCallHandleData = [{ data: [], label: '', borderWidth: 1 }];
      this.liveAgentList[index].weekTrandCallHandleLables = [];
      if (this.liveAgentList[index].trandData.weekTrendListCallHandle) {
        this.liveAgentList[index].trandData.weekTrendListCallHandle.map(val => {
          this.liveAgentList[index].weekTrandCallHandleData[0].data.push(val.trendvalue);
          this.liveAgentList[index].weekTrandCallHandleLables.push('');
        });
      }
      console.log('month week TrandData', this.liveAgentList[index].monthTrandData, this.liveAgentList[index].weekTrandData);
      console.log('month week TrandLables', this.liveAgentList[index].monthTrandLables, this.liveAgentList[index].weekTrandLables);
      console.log('month week CallHandle Data', this.liveAgentList[index].monthTrandCallHandleData, this.liveAgentList[index].weekTrandCallHandleData);
      console.log('month week CallHandle Lables', this.liveAgentList[index].monthTrandCallHandleLables, this.liveAgentList[index].weekTrandCallHandleLables);

    },
      err => console.error(err));
  }

  changeLiveDataTime(val, index) {
    this.liveAgentList[index].dataTime = val;
  }

  calculateIncreasePercent(currVal, preVal) {
    let percentChange = ((currVal - preVal) / preVal) * 100;
    return percentChange ? percentChange : 0;
  }

  toggleLiveVA() {
    this.showLiveVA = !this.showLiveVA;
  }

  toggleTestVA() {
    this.showTestVA = !this.showTestVA;
  }

  filterChanged() {
    this.spinner.show();
    this.getAgentList();
  }

}

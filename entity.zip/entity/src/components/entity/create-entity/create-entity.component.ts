import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-entity',
  templateUrl: './create-entity.component.html',
  styleUrls: ['./create-entity.component.scss']
})
export class CreateEntityComponent implements OnInit {
  items = ['Pizza', 'Pasta', 'Parmesan'];

  constructor() {

   let  headElements = ['ID', 'First', 'Last', 'Handle'];
   }

  ngOnInit() {
    
  }

  entityListArray: any = [
    {id: 1, first: 'Mark', last: 'Otto', handle: '@mdo'},
    {id: 2, first: 'Jacob', last: 'Thornton', handle: '@fat'},
    {id: 3, first: 'Larry', last: 'the Bird', handle: '@twitter'},
    
  ];

}

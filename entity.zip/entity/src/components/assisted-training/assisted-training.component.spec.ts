import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { AssistedTrainingComponent } from './assisted-training.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, Component, TemplateRef } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { BsModalService } from "ngx-bootstrap/modal";
import { BsDropdownConfig } from "ngx-bootstrap/dropdown";
import { ToastrService, ToastrModule } from 'ngx-toastr';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AssistedTrainingService } from './assisted-training.service';
import { of } from 'rxjs';
import { TextSelectEvent, TextSelectDirective } from "../../app/shared/directives/text-select.directive";

describe('AssistedTrainingComponent', () => {
  let assistedTrainingService;
  let component: AssistedTrainingComponent;
  let fixture: ComponentFixture<AssistedTrainingComponent>;
  let template: TemplateRef<any>;
  let template2: TemplateRef<any>;
  let template1: TemplateRef<any>;
  let event: TextSelectEvent;

  let assistedTrainingInputs = {
    "virtualAgents": [
      {
        "virtualAgent": {
          "vaId": 2,
          "vaName": "webBot",
          "vaIsLive": false,
          "vaAvatarName": "UMRBOT",
          "vaDescription": "web"
        },
        "languages": [
          {
            "id": 1,
            "value": "English"
          },
          {
            "id": 2,
            "value": "French"
          }
        ],
        "channels": [
          {
            "id": 1,
            "value": "WEB"
          }
        ]
      }
    ]
  };

  let intentList = {
    "mappedCount": 0,
    "inScopeCount": 0,
    "outOfScopeCount": 4,
    "conversationList": [
      {
        "sessionId": 1,
        "mapppedPhrases": [],
        "inScopePhrases": [],
        "outOfScopePhrases": [
          {
            "id": 1,
            "value": "need information"
          }
        ]
      },
      {
        "sessionId": 2,
        "mapppedPhrases": [],
        "inScopePhrases": [],
        "outOfScopePhrases": [
          {
            "id": 7,
            "value": "first class ticket from mumbai"
          },
          {
            "id": 4,
            "value": "ticket book pannanum"
          },
          {
            "id": 3,
            "value": "sollunga"
          }
        ]
      }
    ]
  };

  let intentSlots = [
    {
      "intent": {
        "id": 4,
        "value": "praveen intent"
      },
      "intentSlots": []
    },
    {
      "intent": {
        "id": 6,
        "value": "Booking Cancellation"
      },
      "intentSlots": []
    }
  ];

  let createIntentData = {
    "intent": {
      "intentId": 41,
      "intentName": "Test",
      "intentDescription": "Test",
      "virtualAgent": null,
      "businessUnit": null,
      "languages": [
        {
          "langEngId": 1,
          "langName": "English",
          "channels": [
            {
              "icmId": 65,
              "channelId": 1,
              "channelName": "WEB",
              "intentConfigStage": 0,
              "isLive": false
            }
          ]
        },
        {
          "langEngId": 2,
          "langName": "French",
          "channels": [
            {
              "icmId": 66,
              "channelId": 1,
              "channelName": "WEB",
              "intentConfigStage": 0,
              "isLive": false
            }
          ]
        }
      ]
    }
  }

  let mappedDetails = {
    id: 3,
    intentId: 655,
    intentslots: null,
    value: "sollunga",
    mappedData: { displayValue: "sollunga", intentId: 655, sessionId: 2, mappedHighlightData: [], intentslots: { index: 0, value: "sollunga", isHighlight: false, key: "pos0" } }
  }

  let mappedHighlightData = [{ index: 0, value: "add", isHighlight: false, key: "pos0" },
  { index: 1, value: "new", isHighlight: false, key: "pos1" },
  { index: 2, value: "ticket", isHighlight: false, key: "pos2" }];

  let slots = {
    pos2: {
      intentSlot: { id: 18, value: "Ptype" },
      value: "train"
    },
    pos3: {
      intentSlot: { id: 18, value: "sys.number" },
      value: "train"
    }
  }



  // const assistedTrainingService = jasmine.createSpyObj('AssistedTrainingService', ['getInputs','getIntents','intentSlots','searchIntent','createIntent']);
  // assistedTrainingService.getInputs.and.returnValue(of(assistedTrainingInputs));
  // assistedTrainingService.getIntents.and.returnValue(of(intentList));
  // assistedTrainingService.intentSlots.and.returnValue(of(intentSlots));
  // assistedTrainingService.searchIntent.and.returnValue(of(intentSlots));
  // assistedTrainingService.createIntent.and.returnValue(of(createIntentData));

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        AssistedTrainingService,
        { provide: BsModalService },
        { provide: BsDropdownConfig }
      ],
      declarations: [AssistedTrainingComponent],
      imports: [FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
        ToastrModule.forRoot(),
        BsDropdownModule.forRoot(),
        RouterTestingModule],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(inject([AssistedTrainingService], s => {
    assistedTrainingService = s;
    fixture = TestBed.createComponent(AssistedTrainingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it("should call method subscribe", async(() => {
    spyOn(assistedTrainingService, 'searchIntent').and.returnValue(of(intentSlots))
    component.searchIntentFunc();
    spyOn(assistedTrainingService, 'getInputs').and.returnValue(of(assistedTrainingInputs))
    component.getDropdownInput();
    spyOn(assistedTrainingService, 'getIntents').and.returnValue(of(intentList))
    component.serviceCallUnmappedInputs(1, '2019-11-04', 2, 1, true, '2019-11-10', 2, '');
  }));


  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set submitted to true', () => {
    component.createNewIntent();
    component.renderRectangles(event);
    component.showIntentSlotsDropdown();
    component.showPopup('Info','slot saved successfully');

    expect(component.created).toBeTruthy();
  });


  it('check methods', () => {
    let e = { start: 'moment', end: 'moment' };
    component.rangeClicked("start", e);
    component.getDropdownInput();
    // component.setDropdownValues();
    component.searchIntentFunc();
    component.channelFilter({ id: 1, value: 2 });
    component.languageFilter({ id: 1, value: 2 });
    //  component.onSearch('test');

    component.choosedDate(e);
    component.submitFilter(e);
    component.cancelFilter(e);
    component.cancelCreate();
    component.showMessage("akiera");
    component.intentChanged({ id: 1, value: 1 });
    component.onScroll();

  //  component.showPopup('Info','slot saved successfully');
    // component.getIntentSlotValue({ id: 1, value: 1 });

    // expect(component.intentSlotId[0]).toBe(1);

    // expect(component.selectedIntentId).toBe(1);

    // expect(component.searchText).toBe('test');
  //  component.createNewIntent();
    component.checkEmpty("");
    component.conversationListDetails(intentList);
    // component.conversationListProcess(intentList.conversationList[0]);
    component.mappedPhraseGenerator(mappedDetails, 1);
    component.deleteUnmappedUser();
    component.showContent(mappedDetails);
    //component.openSlotsDropdown();

    //component.saveUnmappedUserBtn();
    component.saveUnmappedUserInputsRequest();
    component.getPOSTIONoftxt(['ticket'], mappedHighlightData);
    component.getIntentSlotValue({ id: 21, value: "Claim Number" });
    component.coloringPhrase();
    component.colorArrayGenrater(slots);
    component.colorDisplayTextAndGenrateInnerPhase(['pos2', 'pos3']);
    //component.showIntentSlotsDropdown();
    //component.coloringPhrase();
    // component.showPopup("akeria","update");
    component.openModals(template1);
    component.openModalTrainInput(template2);
   // component.saveUnmappedUserBtn();
    //component.coloringPhrase();
  });
});

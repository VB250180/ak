// export class Intent{
//     validationIntent:any;
//     systemSlotKey:any;
//     systemSlots:any
// }




    export class SystemSlotKey {
        systemSlotKeyId: number;
        systemSlotKeyName: string;
        constructor(){
            this.systemSlotKeyId=null;
            this.systemSlotKeyName="";
        }
    }

    export class SystemSlot {
        systemSlotId: number;
        systemSlotKey: SystemSlotKey;
        constructor(){
        this.systemSlotId= null;
        this.systemSlotKey=new  SystemSlotKey();
        }
    }

    export class SendMessage {
        messageId: number;
        messageText: string;
        constructor() {
            this.messageId      = null;
            this.messageText   = "";
         }
    }

    export class Entity {
        entityId: number;
        entityName: string;
    }

    export class IntentSlot {
        intenSlotId: number;
        intentSlotName: string;
        intentSlotDescription: string;
        entity: Entity;
        constructor() {
            this.intenSlotId      = null;
            this.intentSlotName   = null;
            this.intentSlotDescription    =null;
            this.entity    =new Entity();
         }
    }

    export class GetInfo {
        getInfoId: any;
        promptQuestion: string;
        promptValidationMessage: string;
        intentSlot: IntentSlot;
        constructor() {
            this.getInfoId      = "";
            this.promptQuestion   = "";
            this.promptValidationMessage    ="";
            this.intentSlot    =new IntentSlot();
         }
    }

    export class ResponseSlot {
        responseSlotId: number;
        responseSlotName: string;
        responseSlotDescription:string;
        constructor() {
            this.responseSlotId      = null;
            this.responseSlotName   ="";
            this.responseSlotDescription   ="";
         }
    }

    export class PositionAndSlot {
        finalResponseSlotId: number;
        position: string;
        intentSlot?: any;
        responseSlot: ResponseSlot;
        constructor() {
            this.finalResponseSlotId      = null;
            this.position   ="";
            this.intentSlot   ="";
        this.responseSlot=new ResponseSlot();

         }
    }

    export class FinalResponse {
        finalResponseId: number;
        finalResponseText: string;
        positionAndSlots: PositionAndSlot[];
        constructor() {
            this.finalResponseId      = null;
            this.finalResponseText   ="";
        this.positionAndSlots=new Array<PositionAndSlot>();

         }
        }
    // export class ResponseSlot {
    //     responseSlotId: number;
    //     responseSlotName: string;
    //     responseSlotDescription: string;
    // }
  export class ConversationStage {
        sequenceNumber?: number;
        conversationStageId?: number;
        sendMessage?: SendMessage;
        getInfo?: GetInfo;
        finalResponse?: FinalResponse;
        constructor() {
            this.sequenceNumber      = null;
            this.conversationStageId   =null;
            this.sendMessage    =null;
            this.getInfo= new GetInfo();
            this.finalResponse=null;
         }
    }

    export class Conversation {
        validationIntent?: any;
        systemSlots: SystemSlot[];
        conversationStages: ConversationStage[];
        responseSlots:ResponseSlot[];
        constructor() {
            this.validationIntent={
                intentName:""
            };
            // this.systemSlot:SystemSlot[];
           this.systemSlots = new Array<SystemSlot>();
            this.conversationStages=new Array<ConversationStage>();
            this.responseSlots=new Array<ResponseSlot>();
        }
    }

    // export class RootObject {
    //     virtualAgent?: any;
    //     virtualAgents?: any;
    //     intent?: any;
    //     intents?: any;
    //     conversation: Conversation;
    //     trainingPhrases?: any;
    //     virtualAgentDashboardResponseObject?: any;
    //     virtualAgentTrendResponseObject?: any;
    //     errorBody?: any;
    //     count?: any;
    // }


    export class intentsDropD{
        intentId:number;
        intentName:any;
        intentDescription:any;
    }
    export class systemSlotDropD{
        systemSlotKeyId:number;
        systemSlotKeyName:any;
    }

    export class intentSelection{
        id:number;
        value:string;
    }
import { async, ComponentFixture, TestBed, fakeAsync } from '@angular/core/testing';
import { CreateIntentLeftComponent } from './create-intent-left/create-intent-left.component';
import { CreateIntentRightComponent } from './create-intent-right/create-intent-right.component';
import { CreateIntentComponent } from './create-intent.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, TemplateRef } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CreateIntentService } from './create-intent.service';
import { NgxCacheIfModule } from 'ngx-cache-if';
import { BsModalService } from "ngx-bootstrap/modal";
import { ToastrModule } from 'ngx-toastr';
import { RouterModule } from '@angular/router';
import { APP_BASE_HREF } from '@angular/common';
import { of } from 'rxjs';

describe('CreateIntentComponent', () => {
  let component: CreateIntentComponent;
  let fixture: ComponentFixture<CreateIntentComponent>;
  let template: TemplateRef<any>;

  let channelAndLanguageList = {
    "languages": [
      { "langName": "French", "langId": 1 },
      { "langName": "Spanish", "langId": 2 }
    ], "channels": [
      { "channelId": 1, "channelName": "WEB" },
      { "channelId": 2, "channelName": "IVR" }
    ]
  };
  let conversationList = {
    "conversation": {
      "validationIntent": {
        "intentId": 61,
        "intentName": "ClaimS",
        "intentType": null,
        "intentDescription": "Claim status ",
        "virtualAgent": null,
        "businessUnit": null,
        "languages": null
      },
      "systemSlots": [
        {
          "systemSlotId": 42,
          "systemSlotKey": {
            "systemSlotKeyId": 1,
            "systemSlotKeyName": "MemberID"
          }
        },
        {
          "systemSlotId": 43,
          "systemSlotKey": {
            "systemSlotKeyId": 2,
            "systemSlotKeyName": "GroupID"
          }
        }
      ],
      "conversationStages": [
        {
          "sequenceNumber": 1,
          "conversationStageId": 129,
          "sendMessage": null,
          "getInfo": {
            "getInfoId": 38,
            "promptQuestion": "asdf",
            "promptValidationMessage": "asdf",
            "intentSlot": {
              "intentSlotId": 38,
              "intentSlotName": "asdf",
              "intentSlotDescription": "asdf",
              "entity": {
                "entityId": 8,
                "entityName": "Policy_Type"
              }
            }
          },
          "finalResponse": null
        },
        {
          "sequenceNumber": 2,
          "conversationStageId": 159,
          "sendMessage": {
            "messageId": 53,
            "messageText": "dsfgsdg"
          },
          "getInfo": null,
          "finalResponse": null
        },
        {
          "sequenceNumber": 3,
          "conversationStageId": 133,
          "sendMessage": {
            "messageId": 39,
            "messageText": "esarfas"
          },
          "getInfo": null,
          "finalResponse": null
        },
        {
          "sequenceNumber": 4,
          "conversationStageId": 134,
          "sendMessage": {
            "messageId": 40,
            "messageText": "dasfsda"
          },
          "getInfo": null,
          "finalResponse": null
        },
        {
          "sequenceNumber": 5,
          "conversationStageId": 130,
          "sendMessage": null,
          "getInfo": {
            "getInfoId": 39,
            "promptQuestion": "asdf",
            "promptValidationMessage": "asdf",
            "intentSlot": {
              "intentSlotId": 39,
              "intentSlotName": "sdafasd",
              "intentSlotDescription": "asdf",
              "entity": {
                "entityId": 3,
                "entityName": "MTPIN"
              }
            }

          },
          "finalResponse": null
        },
        {
          "sequenceNumber": 6,
          "conversationStageId": 132,
          "sendMessage": null,
          "getInfo": {
            "getInfoId": 40,
            "promptQuestion": "asf",
            "promptValidationMessage": "asf",
            "intentSlot": {
              "intentSlotId": 40,
              "intentSlotName": "new ",
              "intentSlotDescription": "asdf",
              "entity": {
                "entityId": 7,
                "entityName": "sys.date"
              }
            }
          },
          "finalResponse": null
        },
        {
          "sequenceNumber": 7,
          "conversationStageId": 171,
          "sendMessage": null,
          "getInfo": null,
          "finalResponse": {
            "finalResponseId": 67,
            "finalResponseText": "final claim status  %pos0% and  %pos1% intent",
            "positionAndSlots": [
              {
                "finalResponseSlotId": 709,
                "position": "pos1",
                "intentSlot": {
                  "intentSlotId": 40,
                  "intentSlotName": "new ",
                  "intentSlotDescription": "asdf",
                  "entity": {
                    "entityId": 7,
                    "entityName": "sys.date"
                  }
                },
                "responseSlot": null
              },
              {
                "finalResponseSlotId": 708,
                "position": "pos0",
                "intentSlot": null,
                "responseSlot": {
                  "responseSlotId": 39,
                  "responseSlotName": "data",
                  "responseSlotDescription": "dasf"
                }
              }
            ]
          }
        }
      ],
      "responseSlots": [
        {
          "responseSlotId": 39,
          "responseSlotName": "data",
          "responseSlotDescription": "dasf"
        }
      ]
    }
  };

  let agents = {
    "virtualAgent": null,
    "virtualAgents": [
      {
        "vaId": 1,
        "vaName": "webBot",
        "vaIsLive": false,
        "vaAvatarName": "UMRBOT",
        "vaDescription": "web",
        "businessUnit": "catOne"
      },
      {
        "vaId": 2,
        "vaName": "webBot",
        "vaIsLive": true,
        "vaAvatarName": "UMRBOT",
        "vaDescription": "web",
        "businessUnit": "catOne"
      },
      {
        "vaId": 3,
        "vaName": "dummyBot",
        "vaIsLive": false,
        "vaAvatarName": "BOT",
        "vaDescription": "web",
        "businessUnit": "catOne"
      },
      {
        "vaId": 4,
        "vaName": "dummyBot",
        "vaIsLive": true,
        "vaAvatarName": "BOT",
        "vaDescription": "web",
        "businessUnit": "catOne"
      },
      {
        "vaId": 5,
        "vaName": "Dev_BOT",
        "vaIsLive": false,
        "vaAvatarName": "DEVBOT",
        "vaDescription": "dev bot desc",
        "businessUnit": "catOne"
      },
      {
        "vaId": 6,
        "vaName": "Dev_BOT",
        "vaIsLive": true,
        "vaAvatarName": "DEVBOT",
        "vaDescription": "dev bot desc",
        "businessUnit": "catOne"
      }
    ],
    "intent": null,
    "intents": null,
    "conversation": null,
    "trainingPhrases": null,
    "virtualAgentDashboardResponseObject": null,
    "virtualAgentTrendResponseObject": null,
    "systemSlotKeys": null,
    "count": null,
    "languages": null,
    "channels": null,
    "intentLanguageChannelMaps": null,
    "intentSlots": null,
    "entities": null,
    "errorBody": null
  }

  let intentDetails = [{
    channels: [{ icmId: 545, channelId: 1, channelName: "WEB", intentConfigStage: 1, isLive: false }],
    langEngId: '2',
    langName: 'French'
  }]

  let language = [{
    channels: [{ icmId: 545, channelId: 1, channelName: "WEB", intentConfigStage: 1, isLive: false }],
    langEngId: '2',
    langName: 'French'
  }]

  let convFlow = [{
    conversationStages: [{
      sequenceNumber: 0,
      conversationStageId: 38,
      sendMessage: null,
      getInfo: null,
      finalResponse: {
        finalResponseId: 18,
        finalResponseText: "The EZ claim form and PDF format of related medical records for the claim can be emailed to XXX-ClaimSubmissions@XXX.com. Claims can also be submitted as hard copies to the mailing address XXX, PO Box 30541, Salt Lake City, UT, 84130. I hope that this helps!",
        positionAndSlots: []
      }
    }],
    responseSlots: [],
    systemSlots: [{
      systemSlotId: null,
      systemSlotKey: {
        systemSlotKeyId: 1,
        systemSlotKeyName: "MemberID"
      }
    }],
    validationIntent: {
      businessUnit: null,
      intentDescription: "Claim status with claim number ",
      intentId: 68,
      intentName: "ClaimStatus_Number",
      intentType: null,
      languages: null,
      virtualAgent: null
    }
  }];

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: BsModalService, useValue: BsModalService }
      ],
      declarations: [CreateIntentComponent],
      imports: [
        BrowserAnimationsModule,
        RouterTestingModule,
        HttpClientTestingModule,
        RouterModule.forRoot([]),
        FormsModule,
        ReactiveFormsModule,
        ToastrModule.forRoot(),
        NgxCacheIfModule],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));


  beforeEach(() => {
    fixture = TestBed.createComponent(CreateIntentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // it('should call updateTimeStamp', () => {
  //   spyOn(component.CreateIntentLeftComponent, 'updateTimeStamp');
  //   component.update();
  //   expect(component.childComponent.updateTimeStamp).toHaveBeenCalled();
  // });


  it('check methods intent', () => {
    component.langId = '2';
    component.chId = '1';
    component.showConversation = false;
    component.showAddPhrases = false;
    component.showIntent === true;
    component.vaRoleId = null;
    component.vaRoleDisable = true;
    component.displayDropdownValues(language);
    component.customStylesone();
    component.customStylestwo();
    component.setConversationStyles();
    component.setPhraseStyles();
    component.setStyles();
    component.receiveData("sample data");
    component.getStatusRes("sample data");
    component.languageFilter(language);
    component.channelFilter(language[0].channels);
        // component.refreshConversationTemp(1,2);
    component.callGetIntentsEditData();
    component.getIntentsEdit(1, 2);
    component.virtualAgents();
    component.getSelectedText();
    component.intentTab();
    component.conversationTab();
    component.addTab();
    component.saveDraftIntent();
    component.saveDraftTrainingPhrases();
    component.openModalTrainInput(template);
    // component.refreshConversationTemp(1,2);
    // component.refreshTrainingPhrases(1,2);
    //     component.getData(conversationList.conversation);
    //     component.getDataGet(conversationList.conversation);
    //     component.getDataFinalRes(conversationList.conversation);
    //     component.refreshConversationTemp(1,2);
    //     component.refreshTrainingPhrases(1,2);
        // component.trainInputEvent();
    //         component.saveasDraft();
    //         component.saveDraftTrainingPhrases();
    //         component.getDataR(conversationList.conversation);
    //         component.fetchValuefromLeftPanelGet(conversationList.conversation);
    //         component.fetchValuefromLeftPanel(conversationList.conversation);
    //         component.fetchValuefromLeftPanelFinalRes(conversationList.conversation);
    // component.saveDraftConversationTemp();



    // component.saveDraftTrainingPhrases();
    //  component.getData(conversationList.conversation);
    //  component.fetchValuefromLeftPanel(conversationList.conversation);

  });
  it('should check methodc', () => {
    component.getDataR(convFlow);
  });

  it('should check method fetch', () => {
    component.fetchValuefromLeftPanelGet(convFlow);
  });

  it('should check method fetch finalres', () => {
    component.fetchValuefromLeftPanelFinalRes(convFlow);
  });

  it('should check left panel data', () => {
    component.fetchValuefromLeftPanel(convFlow);
  });

  it('should check method saveas draft', ()=> {
    component.saveasDraft();
  });

  it('should check method  save', () => {
    component.saveDraftConversationTemp();
  });

  it('should check method refresh training phrase', () => {
    component.refreshConversationTemp(1,2);
  });

  it('should check method temp', () => {
    component.refreshTrainingPhrases(1,2);
  });

  it('should check method modal', () => {
     component.openModalTrainInput(template);
  });

  it('should check train input click method', () => {
    component.trainInputEvent();
  });

  it('should check get data', () => {
    component.getData(convFlow);
  });

  it('should check getdataget method', () => {
    component.getDataGet(convFlow);    
  });

  it('should check getdata final res method', () => {
    component.getDataFinalRes(convFlow);    
  });

  // it('form invalid when empty', () => {
  //   expect(component.saveIntentForm.valid).toBeFalsy();
  // });

  // it('name field validity', () => {
  //   let name = component.saveIntentForm.controls['intentName'];
  //   let desc = component.saveIntentForm.controls['intentDescription'];

  //   expect(name.valid).toBeFalsy();
  //   expect(desc.valid).toBeFalsy();
  // });

  // it('click on virtual agents', () => {
  //   expect(component.virtualAgents()).toHaveBeenCalledTimes(1);
  // });

  // it('click on save intent', () => {
  //   component.saveDraftIntent();
  //   expect(component.savebtn).toBe(true);
  // });

  // it('click on display dropdown values', () => {
  //   component.displayDropdownValues(intentDetails);
  //   expect(component.languages).toBe(intentDetails);
  // })

});






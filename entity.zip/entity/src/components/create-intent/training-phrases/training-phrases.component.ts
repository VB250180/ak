import { Component, OnInit, TemplateRef, Input, SimpleChanges, OnChanges, Output, EventEmitter, ViewChild } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, FormControl } from '@angular/forms';
import { Validators, ValidationErrors, ValidatorFn } from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CreateIntentService } from '../create-intent.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { BsModalService } from "ngx-bootstrap/modal";
import { BsModalRef } from "ngx-bootstrap/modal/bs-modal-ref.service";
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { TextSelectEvent } from "../../../app/shared/directives/text-select.directive";
import { SelectionRectangle } from "../../../app/core/models/selectionRectangle";

@Component({
  selector: 'app-training-phrases',
  templateUrl: './training-phrases.component.html',
  styleUrls: ['./training-phrases.component.scss'],
  host: {
    '(document:click)': 'functionClick($event)',
  }
})
export class TrainingPhrasesComponent implements OnInit, OnChanges {
  @Input() arr;
  @Output() enableTrainEvent = new EventEmitter<boolean>();
  @Output() configurationStatus = new EventEmitter<boolean>();
  @ViewChild('templateWarning', { static: false }) templateRef: TemplateRef<any>;
  @ViewChild('templateEditConfirmation', { static: false }) templateEditConfir: TemplateRef<any>;

  addArray: any = [];
  phrases: any = [];
  posPhraseValues: any = [];
  addForm = this.fb.group({
    addtext: ['', [Validators.required]]
  });
  availablePhrases: any;
  pageNum: number = 1;
  intentId: number;
  langId: number;
  vaRoleId: number;
  chId: number;
  idToDelete: number;
  idToEdit: number = 0;
  valueToEdit: any;
  intentSlots: any = [];
  counter: number = 1;
  slotsToDisplay: any = [];
  isLoaded: boolean = false;
  IsHidden: boolean = true;
  selectedSlot: any = [];
  slotsList: any = [];
  selectedSlotId: any = [];
  selectedSlotValue: any = [];
  selectedIntentSlots: any = [];
  newPhraseSlotDetails: any = {
    "intentSlotMapPojos": [],
    "trainingPhraseId": 0,
    "trainingPhraseText": '',
    "trainingPhraseDisplay": ''
  };
  selectedValues: any = [];
  copyofnewPhraseSlotDetails: any = [];
  valueToDelete: any = [];
  searchText: any;
  checkAddArray: boolean = true;
  editData: any;
  id: number = 0;
  flag: number;
  checkEdited: any = [];
  modalYesEvent: any;
  modalRef: BsModalRef;
  config = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: "my-modaltraining"
  };
  modalRefInfo: BsModalRef;

  newData: any = [];
  modalMsg: string = '';
  modalHeader: string = '';

  mappedHighlightData: any = [];
  intentSlotMapPojos: any = [];
  trainingPhraseText: any = '';

  public hostRectangle: SelectionRectangle | null;
  private selectedText: string;
  public dropdownError: string;
  posStart: number = -1;
  posEnd: number = -1;

  yesnoTitle: string = '';
  yesnoDesc: string = ''
  currentSelectedtxt: string = '';
  intentSlotList: any = [];
  arrayIndex: number = null;
  fromAddarray: boolean = true;
  isdelFromAddArray: boolean = true;
  delIndex: number = null;
  disableAddbtm: boolean = true;
  status: boolean;
  showloader = false;

  constructor(private fb: FormBuilder, private route: ActivatedRoute, private intentService: CreateIntentService,
    private spinner: NgxSpinnerService, private modalService: BsModalService, private toastr: ToastrService
  ) {
    this.route.paramMap.subscribe((params: any) => {
      this.intentId = params.params.intId;
      this.langId = params.params.langId;
      this.flag = params.params.flag;
    });
  }

  ngOnInit() {
    console.log('ngOnInit');
    this.searchText = '';
    console.log(this.flag, this.newData);

    if (!this.flag) {
      this.intentId = this.newData[0];
      this.langId = this.newData[1];
      this.chId = this.newData[2];
      this.vaRoleId = this.newData[3]
    }
    this.fetchPageData(this.intentId, this.langId, this.pageNum, this.searchText);
  }

  refreshTrainingPhrase(langId, chID) {
    console.log("-------->", langId, chID);
    this.langId = langId;
    this.chId = chID;
    this.fetchPageData(this.intentId, this.langId, this.pageNum, this.searchText);
  }

  ngOnChanges() {
    console.log('ngOnChanges', this.intentId, this.langId, this.pageNum, this.searchText);
    this.newData = this.arr;
    this.searchText != undefined ? this.fetchPageData(this.intentId, this.langId, this.pageNum, this.searchText) : '';
  }

  fetchPageData(intentId: number, langId: number, pageNum: number, searchText: any) {
    (this.searchText === ('' || undefined)) ? this.searchText = '' : '';

    this.spinner.show();
    this.intentService.requestaddTrainingPhraseAndintentSlots(intentId, langId, pageNum, searchText).subscribe(responseList => {
      console.log('addTrainingPhrase -->', responseList[0]);
      console.log('intentSlots -->', responseList[1]);

      //addTrainingPhrase response
      (pageNum == 1) ? this.phrases = [] : '';
      let Convphrases = responseList[0]['trainingPhrases'];
      if (Convphrases.length > 0) {
        this.checkAddArray = false;
        this.enableTrainEvent.emit(this.checkAddArray);
      } else {
        this.checkAddArray = true;
        this.enableTrainEvent.emit(this.checkAddArray);
      }
      this.displayTrainingPhrases(Convphrases);

      //intentSlots response
      this.intentSlots = responseList[1]['intentSlots'];
      this.intentSlots.forEach(element => {
        this.slotsToDisplay.push(element.intentSlotName);
      });

      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      console.error('fetchPageData Error', err);
    });

  }



  addPhrases(intentId, langId, pageNum, searchText) {
    (this.searchText === ('' || undefined)) ? this.searchText = '' : '';

    this.intentService.addTrainingPhrase(intentId, langId, pageNum, searchText).subscribe(res => {
      if (pageNum == 1) { this.phrases = [] }
      console.log(res);
      let Convphrases = res['trainingPhrases'];
      (Convphrases.length > 0 ? this.status = true : this.status = false);
      this.configurationStatus.emit(this.status);
      this.displayTrainingPhrases(Convphrases);
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      console.log(err);
    });
  }

  displayTrainingPhrases(phrases) {
    this.isLoaded = true;
    for (let i = 0; i < phrases.length; i++) {
      let trainingPhrases = phrases[i];
      if ((phrases[i].intentSlotMapPojos !== null) && (phrases[i].intentSlotMapPojos.length > 0)) {

        let posPhrase: any,
          rxp = /%([^%/]+)%/g, curMatch, postionArray: string[] = [];
        posPhrase = trainingPhrases.trainingPhraseText;
        for (let k = 0; k < trainingPhrases.intentSlotMapPojos.length; k++) {
          postionArray.push(trainingPhrases.intentSlotMapPojos[k].position);
          while ((curMatch = rxp.exec(posPhrase))) {
            if (trainingPhrases.intentSlotMapPojos[k].position === curMatch[1]) {
              posPhrase = (posPhrase.replace(
                curMatch[1],
                trainingPhrases.intentSlotMapPojos[k].value));
              this.posPhraseValues = posPhrase.replace(/%/g, "");
            }
          }
        }
        trainingPhrases['trainingPhraseDisplay'] = this.posPhraseValues;
        console.log('trainingPhrases -->', trainingPhrases);
        trainingPhrases['mappedHighlightData'] = this.genrateHighlightdata(this.posPhraseValues, true, postionArray);
        console.log('trainingPhrases -->', trainingPhrases);
      } else {
        trainingPhrases['trainingPhraseDisplay'] = trainingPhrases.trainingPhraseText;
        trainingPhrases['mappedHighlightData'] = this.genrateHighlightdata(trainingPhrases.trainingPhraseText, false, []);
        trainingPhrases['intentSlotMapPojos'] = [];
      }
      this.phrases.push(trainingPhrases);
    }
    console.log('update phrases --- ', this.phrases.length);
  }

  genrateHighlightdata(txt: string, isMapped: boolean, postionArray: string[]) {
    console.log('text',txt,isMapped,postionArray);
    let txtArray = txt.split(" "), renderJson = [], colorArray = [];
    txtArray.forEach((e, i) => { renderJson.push({ 'index': i, 'value': e, 'isHighlight': false, 'key': ('pos' + i) }); });
    if (isMapped) {
      for (var key of postionArray) { colorArray.push(key.split('~')); }
      let outputColorArray = [].concat(...colorArray);
      for (let i in renderJson) {
        for (let j in outputColorArray) {
          if (renderJson[i]['key'] === outputColorArray[j]) {
            renderJson[i]['isHighlight'] = true;
            break;
          }
        }
      }
    }
    return renderJson;
  }

  // onSelect(event) {
  //   if (event && event.preventDefault) { event.preventDefault(); }
  //   this.IsHidden = !this.IsHidden;
  //   this.slotsList = [];
  //   this.slotsList = this.slotsToDisplay;
  //   console.log(this.slotsList);
  // }

  functionClick($event) {
    if (!this.IsHidden) {
      this.IsHidden = !this.IsHidden;
    }
  }

  // getSelectionText() {
  //   var selectedText: any;
  //   if (window.getSelection) {
  //     selectedText = window.getSelection().toString();
  //   }

  //   this.selectedSlot.push(selectedText);
  //   return this.selectedSlot;
  // }

  openModalDelete(template: TemplateRef<any>, id, value, isAddArray, index) {
    this.yesnoTitle = 'Confirm';
    this.yesnoDesc = 'Are you sure want to delete?';
    this.idToDelete = id;
    this.valueToDelete = value;
    this.isdelFromAddArray = isAddArray;
    this.delIndex = index
    this.modalRef = this.modalService.show(template, this.config);
  }

  deleteTrainingPhraseCall() {
    this.intentService
      .deleteTrainingPhrase(this.intentId, this.langId, this.idToDelete, this.searchText)
      .subscribe(res => {
        console.log(res);
        this.modalRef.hide();
        this.idToDelete = null;
        this.addPhrases(this.intentId, this.langId, this.pageNum, this.searchText);
      });
  }

  deleteTrainingPhrase() {
    this.modalYesEvent = '';
    console.log('idToDelete', this.idToDelete)
    if (this.isdelFromAddArray && this.idToDelete == 0) {
      this.addArray.splice(this.delIndex, 1);

    } else if (this.isdelFromAddArray && this.idToDelete != 0) {
      console.log('-- in old edit n delete ');
      this.addArray.splice(this.delIndex, 1);
      if (this.searchText === ('' || undefined)) {
        this.searchText = '';
      }
      this.deleteTrainingPhraseCall();
    } else {
      if (this.searchText === ('' || undefined)) {
        this.searchText = '';
      }
      this.deleteTrainingPhraseCall();
    }
    this.cancelAdd();
    this.modalRef.hide();

    // this.modalYesEvent = '';
    // if (this.idToDelete === 0) {
    //   for (let i = 0; i < this.addArray.length; i++) {
    //     if (this.addArray[i].trainingPhraseDisplay === this.valueToDelete) {
    //       this.addArray.splice(i, 1);
    //     }
    //   }
    //   this.modalRef.hide();
    // }
    // else {

    // }
  }

  removeSelectedValue(value) {
    for (let k = 0; k < this.intentSlotMapPojos.length; k++) {
      //console.log(this.intentSlotMapPojos[k])
      if (this.intentSlotMapPojos[k].value == value) {
        this.intentSlotMapPojos.splice(k, 1); break;
        break;
      }
    }
    console.log(this.intentSlotMapPojos);
    this.trainingPhraseText = this.coloringPhrase();
    console.log('trainingPhraseText -->', this.trainingPhraseText);
    this.updateValueToTable();
  }

  checkEmpty = (t) => t != null && t != '' ? true : false;
  checkIfEditWordandDisplayWord = (newtxt, oldtxt) => newtxt != oldtxt ? true : false;

  onChangebtn(txt) {
    console.log('-----> ', txt);
    let diaplayWord = txt.replace(/^\s+/, '').replace(/\s+$/, '');
    if (this.checkEmpty(txt) && this.checkIfEditWordandDisplayWord(txt, this.valueToEdit)) {
      this.trainingPhraseText = diaplayWord;
      this.valueToEdit = diaplayWord;
      this.intentSlotMapPojos = [];
      this.updateValueToTable();
      this.mappedHighlightData = this.genrateHighlightdata(diaplayWord, false, []);
      this.disableAddbtm = false;
    } else {
      console.log('both same');
    }
  }

  editPhrase(data, index, isAddarray) {
    this.cancelAdd();
    console.log('editPhrase --->',data,index,isAddarray);

    this.idToEdit = data.trainingPhraseId;
    this.valueToEdit = data.trainingPhraseDisplay;
    this.mappedHighlightData = data.mappedHighlightData;
    this.intentSlotMapPojos = data.intentSlotMapPojos;
    this.trainingPhraseText = data.trainingPhraseText;
    this.arrayIndex = index;
    this.fromAddarray = isAddarray;
    this.disableAddbtm = false;

    console.log('this.arrayIndex --> ', this.arrayIndex);
    console.log('On edit click ', this.idToEdit, this.valueToEdit, this.mappedHighlightData, this.intentSlotMapPojos);
    this.addForm.setValue({
      'addtext': this.valueToEdit
    });
    if (this.intentSlotMapPojos != null) this.updateValueToTable();
    this.currentSelectedtxt = '';

    console.log(this.phrases, this.addArray);
    // for (let q = 0; q < this.intentSlots.length; q++) {
    //   this.intentSlots[q].selectedValue = '';
    // }

    // for (let i = 0; i < this.phrases.length; i++) {
    //   console.log(this.phrases[i], this.idToEdit);
    //   if (this.phrases[i].trainingPhraseId == this.idToEdit) {
    //     if (this.phrases[i].intentSlotMapPojos !== null) {
    //       for (let k = 0; k < this.phrases[i].intentSlotMapPojos.length; k++) {
    //         for (let j = 0; j < this.intentSlots.length; j++) {
    //           if (this.intentSlots[j].intentSlotName == this.phrases[i].intentSlotMapPojos[k].intentSlot.intentSlotName) {
    //             this.intentSlots[j].selectedValue = this.phrases[i].intentSlotMapPojos[k].value;
    //           }
    //         }
    //       }
    //     }
    //     else {
    //       for (let q = 0; q < this.intentSlots.length; q++) {
    //         this.intentSlots[q].selectedValue = '';
    //         console.log('slot selected remove value', this.intentSlots[q]);
    //       }
    //       console.log('pojos null', this.intentSlots[i]);
    //     }
    //   }
    //   else if (this.addArray[i]) {
    //     console.log(this.addArray[i], this.addArray);
    //     for (let r = 0; r < this.addArray.length; r++) {
    //       console.log(this.addArray[r]);
    //       if ((this.addArray[r].trainingPhraseId == this.idToEdit) && (this.idToEdit != 0)) {
    //         if (this.addArray[r].intentSlotMapPojos !== null) {
    //           for (let k = 0; k < this.addArray[r].intentSlotMapPojos.length; k++) {
    //             for (let j = 0; j < this.intentSlots.length; j++) {
    //               console.log('looped slots mappojos', this.intentSlots, this.intentSlots[j], this.addArray[r], this.addArray[r].intentSlotMapPojos);
    //               if (this.intentSlots[j].intentSlotName == this.addArray[r].intentSlotMapPojos[k].intentSlot.intentSlotName) {
    //                 this.intentSlots[j].selectedValue = this.addArray[r].intentSlotMapPojos[k].value;
    //                 console.log('looped slots mappojos inloop', this.intentSlots, this.intentSlots[j], this.addArray[r], this.addArray[r].intentSlotMapPojos);
    //               }
    //             }
    //           }
    //         }
    //         else {
    //           console.log('add array pojos null');
    //         }
    //       }
    //       else {
    //         if (this.addArray[r].trainingPhraseDisplay == this.valueToEdit) {
    //           for (let k = 0; k < this.addArray[r].intentSlotMapPojos.length; k++) {
    //             for (let j = 0; j < this.intentSlots.length; j++) {
    //               if (this.intentSlots[j].intentSlotName == this.addArray[r].intentSlotMapPojos[k].intentSlot.intentSlotName) {
    //                 this.intentSlots[j].selectedValue = this.addArray[r].intentSlotMapPojos[k].value;
    //               }
    //             }
    //           }
    //         }
    //       }
    //     }
    //   }
    // }
    this.checkEdited.push(this.idToEdit);
    console.log(this.checkEdited, this.addArray);
  }

  checkCanEdit(data, index, isAddarray) {
    console.log("checkCanEdit -->", this.checkEdited.length, data);
    if (this.checkEdited.length == 0) {
      this.editPhrase(data, index, isAddarray);
    } else {
      this.yesnoTitle = 'Warning';
      this.yesnoDesc = 'Your unsaved data will be lost! Are you sure?';
      this.editData = data;
      this.arrayIndex = index;
      this.fromAddarray = isAddarray;
      this.modalRef = this.modalService.show(this.templateEditConfir, this.config);
    }
  }

  editPhraseYes = () => { this.modalRef.hide(); this.editPhrase(this.editData, this.arrayIndex, this.fromAddarray); }
  editPhraseNo = () => this.modalRef.hide();

  cancelAdd() {
    this.addForm.reset();
    this.idToEdit = 0;
    this.valueToEdit = '';
    this.checkEdited = [];
    this.arrayIndex = null;
    this.fromAddarray = true;
    this.mappedHighlightData = [];
    this.intentSlotMapPojos = [];
    this.trainingPhraseText = '';
    this.hostRectangle = null;
    this.selectedText = "";
    this.disableAddbtm = true;
    this.intentSlots.forEach(element => {
      if (element.selectedValue) {
        element.selectedValue = '';
      }
    });
  }

  saveAddedTrainingPhrases() {
    this.flag = 1;
    for (let i = 0; i < this.addArray.length; i++) {
      delete this.addArray[i].trainingPhraseDisplay;
    }

    if (this.addArray.length > 0) {
      this.intentService.addPhraseDetails(this.intentId, this.langId, this.addArray).subscribe(res => {
        //console.log(res);
        this.spinner.show();
        if (res['errorBody'] !== null) {
          this.modalHeader = "Warning";
          this.modalMsg = "Error when adding phrases";
          this.modalRefInfo = this.modalService.show(this.templateRef, this.config);
          this.spinner.hide();
        } else {
          this.spinner.hide();
          this.modalHeader = "Info";
          this.modalMsg = "Phrases added successfully";
          this.modalRefInfo = this.modalService.show(this.templateRef, this.config);
          let convPhrases = res['trainingPhrases'];
          this.displayTrainingPhrases(convPhrases);
          this.addPhrases(this.intentId, this.langId, this.pageNum, this.searchText);
        }
      }, err => {
        //this.toastr.error('', "Phrases aren't added");
        this.modalHeader = "Warning";
        this.modalMsg = "Internal error";
        this.modalRefInfo = this.modalService.show(this.templateRef, this.config);
      });
      this.addArray = [];
      this.addForm.reset();
      this.checkEdited = [];
    }
  }


  onScroll() {
    this.counter += 1;
    if (this.searchText === ('' || undefined)) {
      this.searchText = '';
    }
    this.showloader = true;
    console.log('this.counter', this.counter);
    this.intentService.addTrainingPhrase(this.intentId, this.langId, this.counter, this.searchText).subscribe(res => {
      let phrasesOnScroll = res['trainingPhrases'];
      this.displayTrainingPhrases(phrasesOnScroll);
      console.log('res ====>', phrasesOnScroll);


      if (this.addArray.length > 0) { }
      //  this.phrases = res;
      // this.spinner.show();
      // setTimeout(() => {
      //   //this.displayTrainingPhrases(this.phrases);
      //   this.spinner.hide();
      // }, 1000);
      this.showloader = false;
    }, err => {
      console.error(err);
    });
  }

  onSearch(text) {
    this.pageNum = 1;
    this.searchText = text;
    this.intentService.addTrainingPhrase(this.intentId, this.langId, this.pageNum, this.searchText)
      .subscribe((res: any[]) => {
        this.isLoaded = true;
        this.phrases = [];
        let phrasesOnSearch = res['trainingPhrases'];
        this.displayTrainingPhrases(phrasesOnSearch);
        console.log(res, phrasesOnSearch, 'searchdata');
      });
  }

  openInfoModal(templateRef: TemplateRef<any>) {
    this.modalRefInfo = this.modalService.show(this.templateRef, this.config);
  }

  public renderRectangles(event: TextSelectEvent): void {

    console.group("Text Select Event");
    console.log("Event:", event);
    console.log("Text:", event.text);
    // console.log("start:", event.posStart);
    // console.log("end:", event.posEnd);
    // console.log("Viewport Rectangle:", event.viewportRectangle);
    // console.log("Host Rectangle:", event.hostRectangle);
    console.groupEnd();

    // If a new selection has been created, the viewport and host rectangles will
    // exist. Or, if a selection is being removed, the rectangles will be null.
    if (event.hostRectangle) {
      this.hostRectangle = event.hostRectangle;
      this.selectedText = event.text;
      this.posStart = event.posStart;
      this.posEnd = event.posEnd;
      this.posStart = this.checkForFirstSpace() ? this.posStart = (this.posStart + 1) : this.posStart;
      this.showIntentSlotsDropdown();
    } else {
      this.hostRectangle = null;
      this.selectedText = "";
    }

  }

  checkForFirstSpace = () => this.selectedText.search(/^\S.*$/) === -1;

  showIntentSlotsDropdown() {
    this.currentSelectedtxt = '';
    let currentWords = this.selectedText.replace(/^\s+/, '').replace(/\s+$/, '');
    if (this.intentSlots.length > 0 && this.checkEmpty(currentWords)) {
      let displayedtext = this.valueToEdit;
      let regex = new RegExp("\\b(" + currentWords + ")\\b");
      let isCurrectWords = displayedtext.search(regex);
      console.log('$$$$ ', displayedtext, '---', currentWords, '---', isCurrectWords);
      this.currentSelectedtxt = currentWords;
      if (isCurrectWords > -1) {
        this.openSlotsDropdown();
      } else {
        this.dropdownError = 'Select proper words';
        this.intentSlotList = [];
      }
    } else {
      this.hostRectangle = null;
      this.selectedText = "";
    }
  }

  openSlotsDropdown() {
    this.dropdownError = 'Choose an Intent slot';
    this.intentSlotList = [];
    this.intentSlots.forEach(e => { this.intentSlotList.push(e); });
  }

  getIntentSlotValue(x) {
    console.log('selectedslot', x);
    console.log(this.idToEdit, this.valueToEdit, this.mappedHighlightData, this.intentSlotMapPojos, this.trainingPhraseText);
    let txtary = this.currentSelectedtxt.split(" ");
    let posData = this.getPOSTIONoftxt(txtary, this.mappedHighlightData);
    console.log("getPOSTIONoftxt -->", posData.pos);

    for (let x = 0; x < posData.posAry.length; x++) {
      console.log(posData.posAry[x]);
      var regex = new RegExp("\\b(" + posData.posAry[x] + ")\\b");
      for (let i = 0; i < this.intentSlotMapPojos.length; i++) {
        console.log(i, this.intentSlotMapPojos[i]);
        if (this.intentSlotMapPojos[i]['position'].search(regex) >= 0) {
          this.intentSlotMapPojos.splice(i, 1); break;
        }
      }
    }

    let intentSlotMapPojo = {
      "position": posData.pos,
      "value": this.currentSelectedtxt,
      "intentSlot": x,
    }
    this.intentSlotMapPojos.push(intentSlotMapPojo);

    console.log('------------->', this.intentSlotMapPojos);
    this.updateValueToTable();
    this.trainingPhraseText = this.coloringPhrase();


    console.log(this.idToEdit, this.valueToEdit, this.mappedHighlightData, this.intentSlotMapPojos, this.trainingPhraseText);
    // this.selectedIntentSlots.push(x);
    // this.selectedSlotId.push(x.intentSlotId);
    // this.selectedSlotValue.push(x.intentSlotName);
    // console.log(x, this.selectedSlotId, this.selectedSlotValue);

    // for (let i = 0; i < this.intentSlots.length; i++) {
    //   if (this.intentSlots[i].intentSlotName == this.selectedSlotValue[this.selectedSlotValue.length - 1]) {
    //     this.intentSlots[i].selectedValue = this.selectedSlot[this.selectedSlot.length - 1];
    //   }
    //   console.log(this.intentSlots[i]);
    // }
    // Now that we've shared the text, let's clear the current selection.
    document.getSelection().removeAllRanges();
    this.hostRectangle = null;
    this.selectedText = "";
  }

  coloringPhrase() {
    let outputColorArray = [].concat(...this.colorArrayGenrater(this.intentSlotMapPojos));
    console.log('outputColorArray ', outputColorArray,this.intentSlotMapPojos);
    return this.colorDisplayTextAndGenrateInnerPhase(outputColorArray);
  }

  getPOSTIONoftxt(txtary: any, mappedHighlightData: any) {
    console.log(txtary, mappedHighlightData);
    let posAry = [];
    let pos = 'pos' + this.posStart++;
    posAry.push(pos);
    while (this.posStart <= this.posEnd) {
      let i = this.posStart++
      posAry.push('pos' + i);
      pos += '~pos' + i;
    }
    let posdata = { 'posAry': posAry, 'pos': pos }
    return posdata;
  }

  colorArrayGenrater(intentSlotMapPojos) {
    let colorArray = [];
    for (let i = 0; i < intentSlotMapPojos.length; i++) {
      colorArray.push(intentSlotMapPojos[i]['position'].split('~'));
    }
    return colorArray;
  }

  // to solve this function not clearing selectedValue DONE
  updateValueToTable() {
    for (let b = 0; b < this.intentSlots.length; b++) {
      this.intentSlots[b].selectedValue = '';
      this.intentSlots[b]['isDisable'] = false;
    }
    for (let i = 0; i < this.intentSlotMapPojos.length; i++) {
      let v = this.intentSlotMapPojos[i]['value'];
      for (let b = 0; b < this.intentSlots.length; b++) {
        if (this.intentSlots[b].intentSlotId == this.intentSlotMapPojos[i]['intentSlot']['intentSlotId']) {
          this.intentSlots[b].selectedValue = v;
          this.intentSlots[b]['isDisable'] = true;
          break;
        }
      }
    }

  }

  colorDisplayTextAndGenrateInnerPhase(outputColorArray) {
    console.log(outputColorArray);
    
    let innerPhase = '', dontAdd: boolean = false, rxp = /%[ /]%/g;
    for (let i = 0; i < this.mappedHighlightData.length; i++) {
      this.mappedHighlightData[i]['isHighlight'] = false;
      for (let j in outputColorArray) {
        if (this.mappedHighlightData[i]['key'] === outputColorArray[j]) {
          this.mappedHighlightData[i]['isHighlight'] = true;
          innerPhase += '%' + this.mappedHighlightData[i]['key'] + '% ';
          dontAdd = false;
          break;
        } else {
          dontAdd = true;
        }
      }
      dontAdd ? innerPhase += this.mappedHighlightData[i]['value'] + ' ' : '';
    }
    innerPhase = innerPhase.replace(rxp, '~').replace(/^\s+/, '').replace(/\s+$/, '');
    innerPhase == '' ? innerPhase = this.valueToEdit : '';
    return innerPhase;
  }

  addToList(text: any) {
    this.isLoaded = true;
    let addedPhrase = this.addForm.value.addtext;

    this.checkAddArray = false;

    this.enableTrainEvent.emit(this.checkAddArray);
    console.log('trainingPhraseText --> ', this.trainingPhraseText);
    if (this.trainingPhraseText != '') {
      this.newPhraseSlotDetails =
      {
        "intentSlotMapPojos": this.intentSlotMapPojos,
        "trainingPhraseId": this.idToEdit,
        "trainingPhraseText": this.trainingPhraseText,
        "trainingPhraseDisplay": this.valueToEdit,
        "mappedHighlightData": this.mappedHighlightData
      }
    } else {
      this.fromAddarray = true;
      this.arrayIndex = this.arrayIndex > 0 ? this.arrayIndex : -1;
      this.newPhraseSlotDetails =
      {
        "intentSlotMapPojos": [],
        "trainingPhraseId": 0,
        "trainingPhraseText": addedPhrase,
        "trainingPhraseDisplay": addedPhrase,
        "mappedHighlightData": this.mappedHighlightData
      }
    }

    console.log('intentSlotMapPojos --->', this.newPhraseSlotDetails, 'Index -', this.arrayIndex);

    this.disableAddbtm = true;

    if (this.fromAddarray) {
      console.log('check condition', this.addArray);
      if (this.newPhraseSlotDetails['trainingPhraseId'] > 0) {
        console.log('In edit with id')
        // remove phrases 
        //this.phrases.splice(this.arrayIndex, 1);
        //this.arrayIndex != 0 ? (this.arrayIndex - 1) : this.arrayIndex;
        this.addArray.splice(this.arrayIndex, 1);

        this.addArray.push(this.newPhraseSlotDetails);
        console.log('slice phrase-->', this.phrases, this.addArray);

      } else {
        console.log('In edit with id', this.arrayIndex);
        //remove addArray
        //this.arrayIndex != 0 ? (this.arrayIndex - 1) : this.arrayIndex;
        if (this.arrayIndex != null && this.arrayIndex != -1) { this.addArray.splice(this.arrayIndex, 1); }

        this.addArray.push(this.newPhraseSlotDetails);
        console.log('slice addarray ==>', this.phrases, this.addArray);

      }
    } else {
      // remove phrases
      console.log('in fromAddarray', this.fromAddarray, this.arrayIndex);

      this.phrases.splice(this.arrayIndex, 1);
      this.addArray.push(this.newPhraseSlotDetails);
      console.log('remove value from phrase id added inn add array', this.addArray, this.phrases);
    }
    this.cancelAdd();

    // to in last for valdation
    // if (this.newPhraseSlotDetails.trainingPhraseDisplay == this.valueToEdit) {
    //   if (this.idToEdit != 0) {
    //     this.newPhraseSlotDetails.trainingPhraseId = this.idToEdit;
    //   }
    //   else {
    //     this.newPhraseSlotDetails.intentSlotMapPojos = [];
    //     if (this.addArray.length == 1) {
    //       this.addArray = [];
    //     }
    //   }
    //   console.log('edit addedin o id', this.newPhraseSlotDetails, this.addArray, this.valueToEdit);
    // }

    // if (this.selectedSlot.length > 0) {
    //   this.newPhraseSlotDetails.trainingPhraseText = addedPhrase;
    //   this.newPhraseSlotDetails.trainingPhraseDisplay = addedPhrase;
    //   for (let i = 0; i < this.selectedSlot.length; i++) {
    //     let pos = `pos${i}`;
    //     if (!(this.selectedSlotId[i] || this.selectedSlotValue[i])) {
    //       this.newPhraseSlotDetails.intentSlotMapPojos = [];
    //     }
    //     else {
    //       this.newPhraseSlotDetails.intentSlotMapPojos.push({
    //         "intentSlot": {
    //           "intentSlotId": this.selectedSlotId[i],
    //           "intentSlotName": this.selectedSlotValue[i],
    //         },
    //         "position": pos,
    //         "value": this.selectedSlot[i]
    //       });
    //       this.newPhraseSlotDetails.trainingPhraseText = this.newPhraseSlotDetails.trainingPhraseText.replace(this.selectedSlot[i], `%${pos}%`);
    //     }
    //   }
    // }


    // if (this.newPhraseSlotDetails.trainingPhraseId === 0) {
    //   this.checkAddArray = false;
    //   this.enableTrainEvent.emit(this.checkAddArray);
    //   if (this.addArray.length > 1 && this.valueToEdit) {
    //     for (let i = 0; i < this.addArray.length; i++) {
    //       if (this.addArray[i].trainingPhraseDisplay === this.valueToEdit) {
    //         this.addArray.splice(i, 1);
    //         this.addArray.push(this.newPhraseSlotDetails);
    //       }
    //     }
    //     this.valueToEdit = '';
    //   }
    //   else {
    //     this.addArray.push(this.newPhraseSlotDetails);
    //     this.valueToEdit = '';
    //   }
    // }   else {
    //   console.log('id varies');
    //   if (this.idToEdit == this.newPhraseSlotDetails.trainingPhraseId && this.valueToEdit) {
    //     console.log(this.newPhraseSlotDetails, this.phrases);
    //     for (let i = 0; i < this.phrases.length; i++) {
    //       if (this.phrases[i].trainingPhraseId === this.idToEdit) {
    //         this.phrases.splice(i, 1);
    //         this.addArray.push(this.newPhraseSlotDetails);
    //         this.checkAddArray = false;
    //         this.enableTrainEvent.emit(this.checkAddArray);
    //         console.log(this.addArray, this.newPhraseSlotDetails, this.phrases[i], this.idToEdit);
    //       }
    //       // else{
    //       //   this.addArray.forEach(element => {
    //       //     console.log('element',element.trainingPhraseId);
    //       //     if (element.trainingPhraseId === this.idToEdit) {
    //       //       this.addArray.splice(i, 1);
    //       //       this.addArray.push(this.newPhraseSlotDetails);
    //       //       console.log(this.addArray, this.newPhraseSlotDetails, this.phrases[i], this.idToEdit);
    //       //     }
    //       //   });
    //       // }
    //     }
    //   }
    //   else {
    //     this.addArray.push(this.newPhraseSlotDetails);
    //     this.valueToEdit = '';

    //     this.checkAddArray = false;
    //     this.enableTrainEvent.emit(this.checkAddArray);
    //   }
    // }



  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-virtual-agent-creation',
  templateUrl: './virtual-agent-creation.component.html',
  styleUrls: ['./virtual-agent-creation.component.scss']
})
export class VirtualAgentCreationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

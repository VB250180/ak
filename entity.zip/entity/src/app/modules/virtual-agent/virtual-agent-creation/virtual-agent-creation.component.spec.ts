import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VirtualAgentCreationComponent } from './virtual-agent-creation.component';

describe('VirtualAgentCreationComponent', () => {
  let component: VirtualAgentCreationComponent;
  let fixture: ComponentFixture<VirtualAgentCreationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VirtualAgentCreationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VirtualAgentCreationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

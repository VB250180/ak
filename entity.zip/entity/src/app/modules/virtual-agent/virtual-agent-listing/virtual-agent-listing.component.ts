import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-virtual-agent-listing',
  templateUrl: './virtual-agent-listing.component.html',
  styleUrls: ['./virtual-agent-listing.component.scss']
})
export class VirtualAgentListingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

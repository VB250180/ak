export class Intent{
    validationEntity:any;
    getInfoName:any;
    getInfoDesc:any;
    getInfoQuestion:any;
    getInfoValidationMsg:any
    agent:any;
    finalResDueDate:any;
    finalResDesc:any;

    // validationSlot:ValidationSlot[]
}


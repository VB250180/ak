import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './core/guards/auth.guard';
import { LoginComponent } from './shared/components/login/login.component';
import { TempalateComponent } from './modules/mocks/template.component';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  {
    path: 'dashboard', loadChildren: () => import('../app/modules/dashboard/agent-list/agent-list.module').then(m => m.AgentListModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'va', loadChildren: () => import('../app/modules/virtual-agent/virtual-agent.module').then(m => m.VirtualAgentModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'assisted',
    loadChildren: () => import('../app/modules/assisted-training/assisted-training.module').then(m => m.AssistedTrainingtModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'login', component: LoginComponent, canActivate: [AuthGuard]
  },
  {
    path: 'password', loadChildren: () => import('./modules/password/password.module').then(m => m.PasswordModule),
  },
  {
    path: 'entity', loadChildren: () => import('./modules/entity/entity.module').then(m => m.EntityModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'conversation', loadChildren: () => import('./modules/conversation-packs/conversation-packs.module').then(m => m.ConversationPacksModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'conversational-metrics', loadChildren: () => import('./modules/conversational-metrics/conversational-metrics.module').then(m => m.ConversationalMetricsModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'intent', loadChildren: () => import('../app/modules/intent/intent.module').then(m => m.IntentModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'template', component: TempalateComponent, canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }


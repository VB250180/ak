import { TextSelectDirective } from '../app/shared/directives/text-select.directive';
import { NgModule } from '@angular/core';
import { SimulatorComponent } from './shared/components/simulator/simulator.component';
import { SelectVaComponent } from './shared/components/simulator/select-va/select-va.component';
import { VaChatWindowComponent } from './shared/components/simulator/va-chat-window/va-chat-window.component';
import { VaSendMessageComponent } from './shared/components/simulator/va-send-message/va-send-message.component';
import { SelectedVaComponent } from './shared/components/simulator/selected-va/selected-va.component';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { TextElipsisComponent } from './shared/components/utils/text-elipses.component';
import { SearchFilterPipe } from './shared/pipes/searchfilter.pipe';

import { SafeHtmlPipe } from './shared/pipes/sanitizerHtmlRender.pipe';
import { RestrictCopyPasteDirective } from '../app/shared/directives/restrict-copy-paste.directive';
import { DebounceDelayDirective } from './shared/directives/debounce-delay.directive';
import { MatChipsModule } from '@angular/material/chips';
import { MatIconModule } from '@angular/material';

@NgModule({
    imports: [
        CommonModule,
        ReactiveFormsModule,
        NgSelectModule,
        FormsModule,
        MatChipsModule,
        MatIconModule
    ],
    declarations: [
        TextSelectDirective,
        SimulatorComponent,
        SelectVaComponent,
        VaChatWindowComponent,
        VaSendMessageComponent,
        SelectedVaComponent,
        SafeHtmlPipe,
        TextElipsisComponent,
        RestrictCopyPasteDirective,
        SearchFilterPipe,
        DebounceDelayDirective
    ],
    exports: [
        MatChipsModule,
        MatIconModule,
        TextSelectDirective,
        SimulatorComponent,
        SelectVaComponent,
        VaChatWindowComponent,
        VaSendMessageComponent,
        SelectedVaComponent,
        SafeHtmlPipe,
        TextElipsisComponent,
        RestrictCopyPasteDirective,
        SearchFilterPipe,
        DebounceDelayDirective    ]

})
export class SharedModule { }

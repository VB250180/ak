import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { APP_BASE_HREF } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { RouterTestingModule } from '@angular/router/testing';
import { Component, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ToastrModule } from 'ngx-toastr';
// import { HeaderComponent } from './shared/components/header/header.component';
import { componentFactoryName } from '@angular/compiler';
import { AuthenticationService } from './core/authentication/authentication.service';
import { BehaviorSubject } from 'rxjs';
import { HttpClientTestingModule } from '@angular/common/http/testing';


class AuthenticationServiceStub {
  public logout() { }
}

// class vaDetailServiceStub {
//   public requiredDataLoaded = new BehaviorSubject(false);
// }

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        ToastrModule.forRoot(),
      ],
      declarations: [
        AppComponent
      ],
      // providers: [{ provide: AuthenticationService, useClass: AuthenticationServiceStub },
      // { provide: VirtualDetailsService, useClass: vaDetailServiceStub }
      // ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  //   @Component({selector: 'app-header', template: ''})
  // class HeaderComponent {}


  // it('should create the app', () => {
  //   expect(component).toBeTruthy();
  // });

  // it('should call ngOnint', () => {
  //   const vaDetailSpy = spyOn(TestBed.get(vaDetailServiceStub), 'requiredDataLoaded');
  //   component.ngOnInit();
  //   expect(vaDetailSpy).toHaveBeenCalled();
  // });


  // it('should call ngOndestroy', () => {
  //   fixture.detectChanges();
  //   component.ngOnDestroy();
  //   // expect(paramMapSubscription.unsubscribe).toHaveBeenCalled();
  // });

  // it('should call logout', () => {
  //   const logoutSpy = spyOn(TestBed.get(AuthenticationService), 'logout');
  //   component.logout();
  //   expect(logoutSpy).toHaveBeenCalled();
  // });


});

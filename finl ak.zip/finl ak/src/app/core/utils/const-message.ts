export const modalErrorConfig = {
    primaryText: 'Something went wrong',
    secondaryText: `We are having trouble completing your request.  Apologize for the convenience. Request you try again in some time.`,
    secondaryBtnText: 'Close',
    popUpType: 'warn',
    hasCancelBtn: true
};

export const modalDeleteConfig = {
    primaryText: 'Confirm',
    secondaryText: 'Are you sure want to delete a training phrase?',
    hasPrimaryBtn: true,
    primaryBtnText: 'Yes',
    secondaryBtnText: 'No',
    popUpType: 'delete',
    hasCancelBtn: true
};


export const modalFileErrorConfig = {
    primaryText: 'Invalid Format',
    secondaryText: 'Please upload only .txt & .csv files',
    secondaryBtnText: 'Close',
    popUpType: 'warn',
    hasCancelBtn: true
};

export const modalFileAudioFileErrorConfig = {
    primaryText: 'Invalid Format',
    secondaryText: 'Please upload only mp3 audio files',
    secondaryBtnText: 'Close',
    popUpType: 'warn',
    hasCancelBtn: true
};

export const modalFileSizeConfig = {
    primaryText: 'File Size limit',
    secondaryText: 'Please upload file size less than 1MB',
    secondaryBtnText: 'Close',
    popUpType: 'warn',
    hasCancelBtn: true
};

export const modalEditTrained = {
    primaryText: 'Warning',
    secondaryText: 'Already Is in Edit',
    secondaryBtnText: 'Close',
    popUpType: 'warn',
    hasCancelBtn: true
};

export const modalEditConfig = {
    primaryText: 'Warning',
    secondaryText: 'You just made changes. Your unsaved data will be lost! Are you sure',
    hasPrimaryBtn: true,
    primaryBtnText: 'Yes',
    secondaryBtnText: 'No',
    popUpType: 'warn',
    hasCancelBtn: true
};

export const modalResponseTrainedError = {
    primaryText: 'Warning',
    secondaryText: 'Error when adding phrases',
    secondaryBtnText: 'Close',
    popUpType: 'warn',
    hasCancelBtn: true
};
export const modalResponseTrainedSuccess = {
    primaryText: 'Info',
    secondaryText: 'Phrases added successfully',
    secondaryBtnText: 'Close',
    popUpType: 'success',
    hasCancelBtn: true
};

export const modalResponseSessionTimeOut = {
    primaryText: 'Info',
    secondaryText: 'Phrases added successfully',
    secondaryBtnText: 'Close',
    popUpType: 'success',
    hasCancelBtn: true
};
export const modalFileAudioClose = {
    primaryText: '',
    secondaryText: '',
    secondaryBtnText: 'Close',
    popUpType: 'warn',
    hasCancelBtn: true
};

export const modalResFileAudioConfirm = {
    primaryText: '',
    secondaryText: '',
    hasPrimaryBtn: true,
    primaryBtnText: 'Yes',
    secondaryBtnText: 'No',
    hasCancelBtn: true,
    popUpType: 'success',
    audioFile: ''
};

export const modalSlotRemvConfirm = {
    primaryText: 'Info',
    secondaryText: 'Adding slots to be message will remove any existing audio files.The response will be rendered via any Text to Speech functionality configured in the IVR connector',
    hasPrimaryBtn: true,
    primaryBtnText: 'Yes',
    secondaryBtnText: 'No',
    hasCancelBtn: true,
    popUpType: 'success',
    audioFile: ''
};

export const modalSlotRemvClear = {
    primaryText: 'Info',
    secondaryText: 'Are sure want to remove this audio file?',
    hasPrimaryBtn: true,
    primaryBtnText: 'Yes',
    secondaryBtnText: 'No',
    hasCancelBtn: true,
    popUpType: 'warn',
    audioFile: ''
};
export const modalSlotRemvIntentSlot = {
    primaryText: 'Confirm',
    secondaryText: 'You are removing an Intent Slot which may be mapped to one or more training phrases. If you go ahead the Intent slot mapping in the training phrase will be removed. Are you sure you want to delete the Intent slot?',
    hasPrimaryBtn: true,
    primaryBtnText: 'Yes',
    secondaryBtnText: 'No',
    popUpType: 'delete',
    hasCancelBtn: true
};
export const modalResponseToggleSuccess = {
    primaryText: 'Info',
    popUpType: 'success',
    toggleText: 'Phrases added successfully',
    secondaryBtnText: 'Close',
    toggle: true,
    hasCancelBtn: true
};

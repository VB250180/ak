export const lastDigitOfNumber = (no: number) => no % 10;
export const chooseColorClassByLastDigit = (no: number) => 'slot-c-' + lastDigitOfNumber(no);

export const getRandomRolor = () => {
    let letters = '012345'.split('');
    let color = '#';
    color += letters[Math.round(Math.random() * 5)];
    letters = '0123456789ABCDEF'.split('');
    for (let i = 0; i < 5; i++) {
        color += letters[Math.round(Math.random() * 15)];
    }
    return color;
};

// Object utils
// tslint:disable-next-line: only-arrow-functions
export const getObjById = (x: [], id: any) => x.filter(function(o: any) { return o.id === id; });
export const isEmptyObj = (x: object) => {
    if (x != null && x !== undefined) {
        return Object.keys(x).length === 0;
    } else {
        return true;
    }
};

export const filterByKeyValue = (arr: [], key: string, value: string | boolean | number) => arr.filter(i => i[key] === value);
export const filterByNluConfigured = (arr: []) => filterByKeyValue(arr, 'isNluConfigured', true);

export const getFromLocalStorage = (key: string) => {
    return localStorage.getItem(key);
};


// String utils
export const stringify = (x: object) => JSON.stringify(x);

export const createElement = (r, e) => r.createElement(e);
export const createText = (r, e) => r.createText(e);
export const addAttribute = (r, e, t, c) => r.setAttribute(e, t, c);
export const appendChild = (r, m, c) => r.appendChild(m, c);
export const insertBefore = (r, m, c, refChild) => r.insertBefore(m, c, refChild);
export const removeChild = (r, p, c) => r.removeChild(p, c);
export const setAttributeValidation = (r, i) => {
    addAttribute(r, i, 'maxlength', '30');
};

export const rendererImageInput = (r, nativeElement, placeholder, value) => {
    const divL1 = createElement(r, 'div'); addAttribute(r, divL1, 'class', 'input-group mb-3 input-group-sm');
    const divL2 = createElement(r, 'div'); addAttribute(r, divL2, 'class', 'input-group-prepend');
    const spanL3 = createElement(r, 'span'); addAttribute(r, spanL3, 'class', 'input-group-text');
    const iL4 = createElement(r, 'i'); addAttribute(r, iL4, 'class', 'fa fa-picture-o');

    const inputL2 = createElement(r, 'input'); addAttribute(r, inputL2, 'class', 'form-control');
    addAttribute(r, inputL2, 'placeholder', placeholder); addAttribute(r, inputL2, 'value', value);
    setAttributeValidation(r, inputL2);

    appendChild(r, spanL3, iL4); appendChild(r, divL2, spanL3); appendChild(r, divL1, divL2); appendChild(r, divL1, inputL2);
    appendChild(r, nativeElement, divL1);
    return inputL2;
};

export const rendererInput = (r, nativeElement, placeholder, value) => {
    const divL1 = createElement(r, 'div'); addAttribute(r, divL1, 'class', 'input-group mb-3 input-group-sm');
    const inputL2 = createElement(r, 'input'); addAttribute(r, inputL2, 'class', 'form-control');
    addAttribute(r, inputL2, 'placeholder', placeholder);
    addAttribute(r, inputL2, 'value', value);
    setAttributeValidation(r, inputL2);

    appendChild(r, divL1, inputL2); appendChild(r, nativeElement, divL1);
    return inputL2;
};

export const rendererLabelAlert = (r, nativeElement, no) => {
    const label = createElement(r, 'label'); addAttribute(r, label, 'class', 'input-group mb-3 input-group-sm slot-label');
    const txt = createText(r, ' \u00A0 Add upto ' + no + ' fields as label');
    const image = createElement(r, 'img'); addAttribute(r, image, 'src', '../../../../assets/icons/more_icons/tooltip.svg');
    appendChild(r, label, image); appendChild(r, label, txt);
    appendChild(r, nativeElement, label);
    // return label;
};

export const rendererLabelSlot = (r, nativeElement, v, isFirst, refbtn, id) => {
    let delBtn;
    const divL1 = createElement(r, 'div'); addAttribute(r, divL1, 'class', 'input-group mb-3 input-group-sm');
    const inputL2label = createElement(r, 'input'); addAttribute(r, inputL2label, 'class', 'form-control');
    addAttribute(r, inputL2label, 'placeholder', 'Label');
    addAttribute(r, inputL2label, 'value', v['labelVal']);
    setAttributeValidation(r, inputL2label);

    const inputL2Slot = createElement(r, 'input'); addAttribute(r, inputL2Slot, 'class', 'form-control');
    addAttribute(r, inputL2Slot, 'placeholder', 'Value');
    addAttribute(r, inputL2Slot, 'value', v['slotVal']);
    setAttributeValidation(r, inputL2Slot);

    appendChild(r, divL1, inputL2label); appendChild(r, divL1, inputL2Slot);
    if (!isFirst) {
        delBtn = createElement(r, 'span'); addAttribute(r, delBtn, 'class', 'col-1 removeWrap');
        addAttribute(r, delBtn, 'id', 'delRow' + id);
        const iL1 = createElement(r, 'i'); addAttribute(r, iL1, 'class', 'fa fa-trash plusicon');
        appendChild(r, delBtn, iL1); appendChild(r, divL1, delBtn);
        insertBefore(r, nativeElement, divL1, refbtn);
    } else {
        insertBefore(r, nativeElement, divL1, refbtn);
    }

    return [inputL2label, inputL2Slot, delBtn, divL1];
};

export const rendererButton = (r, nativeElement) => {
    const divL1 = createElement(r, 'div'); addAttribute(r, divL1, 'class', 'rich-crd-container add-slot-label');
    const divL2 = createElement(r, 'div'); addAttribute(r, divL2, 'class', 'add-rich-crd-pad add-slot-label');
    const pL3 = createElement(r, 'p'); addAttribute(r, pL3, 'class', 'add-rich-card-from-t rectangle-add-slot');
    appendChild(r, pL3, createText(r, 'Add more Slots & Label'));
    const iL4 = createElement(r, 'i'); addAttribute(r, iL4, 'class', 'fa fa-plus createicon add-slot');
    appendChild(r, iL4, pL3); appendChild(r, divL2, pL3); appendChild(r, divL1, divL2);
    appendChild(r, nativeElement, divL1);
    return divL1;
};

export const rendererLabelSlotByLimit = (r, nativeElement, manipulateHtml) => {
    const returndt = {};
    let i;
    // tslint:disable-next-line: no-shadowed-variable
    for (let x = (manipulateHtml['limit']); x > 0; x--) {
        returndt['inputLabelSlotAry' + x] = '';
    }
    rendererLabelAlert(r, nativeElement, manipulateHtml['limit']);
    const saveLimit = manipulateHtml['editField']['saveLimit'];

    const b = rendererButton(r, nativeElement);
    returndt['btn'] = b;
    if (saveLimit === 0) {
        i = rendererLabelSlot(r, nativeElement, { labelVal: '', slotVal: '' }, true, b, 0);
        returndt['inputLabelSlotAry0'] = i;
        returndt['length'] = 1;
    } else {
        for (let x = 0; x < saveLimit; x++) {
            const showDelbt = (x !== 0) ? false : true;
            i = rendererLabelSlot(r, nativeElement, manipulateHtml['editField']['fieldValue'][x], showDelbt, b, x);
            returndt['inputLabelSlotAry' + x] = i;
            // deleteListenFunc = (bt, getObj, richCrdEditId, manipulateHtml, v, r)
            // deleteListenFunc(i,getObj,nativeElement,manipulateHtml,v, r);
        }
        returndt['length'] = saveLimit;
    }

    // console.log('returndt ', returndt);
    return returndt;
};

export const findByEditFieldType = (renderer, nativeElement, manipulateHtml) => {
    const editField = manipulateHtml['editField'];
    const sysLimit = manipulateHtml['limit'];
    let returnType;
    switch (editField['type']) {
        case 'input':
            const val = sysLimit === 1 ? editField['fieldValue'][0][manipulateHtml['key'][0]] : '';
            returnType = rendererInput(renderer, nativeElement, editField['placeholder'], val);
            break;
        case 'inputLabelSlot':
            returnType = rendererLabelSlotByLimit(renderer, nativeElement, manipulateHtml);
            break;
        case 'inputImage':
            const val2 = sysLimit === 1 ? editField['fieldValue'][0][manipulateHtml['key'][0]] : '';
            returnType = rendererImageInput(renderer, nativeElement, editField['placeholder'], val2);
            break;
    }
    return returnType;
};

// vino
export const findSynonymsSlotCharLimit = (sysnValue) => {
    const sysLimit = sysnValue.filter(item => item.entitySynonymsValue.length > 51);
    if (sysLimit.length === 0) {
        return true;
    } else {
        return false;
    }
};







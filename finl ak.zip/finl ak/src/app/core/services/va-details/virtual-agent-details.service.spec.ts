import { TestBed, async, inject } from '@angular/core/testing';
import { of, Observable, throwError, BehaviorSubject } from 'rxjs';

import { VirtualDetailsService } from './virtual-agent-details.service';
import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { userInfo } from 'os';
import { AuthenticationService } from '../../authentication/authentication.service';


class BehaviorSubjectMock {
  userDetails = {
    username: '',
    password: '',
    firstName: '',
    lastName: '',
    jwToken: ''
  };

  public currentUserSubject = new BehaviorSubject(this.userDetails);
}

class MockRouter {
  // tslint:disable-next-line: no-shadowed-variable
  public navigate( url: []) { return url; }
}

const vrmDetails = {
  isNluConfigured: true,
  vrmAvatarName: 'Akeira',
  vrmBU: 'Member Services',
  vrmDescription: 'Claims',
  vrmId: 1,
  vrmIsLive: true,
  vrmName: 'Claims Management'
};

const url = {
  data: 'http://3.20.208.15:9903/'
};

const authBodyToken = {
  conversationResponsePojo: null,
  jwtResponse: null,
  sessionId: null,
  // tslint:disable-next-line: object-literal-key-quotes
  errorBody: { 'code': 0, 'summary': null }
};

const initConversation = {
  conversationResponsePojo: null,
  errorBody: null,
  jwtResponse: null,
  sessionId: '11284'
};

const sendMsgResponse = {
  conversationResponsePojo: {
    responseType: 'text',
    responsetext: 'Unable to detect your request, kindly provide more info'
  },
  errorBody: null,
  jwtResponse: null,
  sessionId: null
};

class AuthenticationServiceStub {
  getCurrentUserId() {
      return 1;
  }
}

describe('VirtualDetailsService', () => {
  let httpClientSpy: { get: jasmine.Spy, put: jasmine.Spy, post: jasmine.Spy, delete: jasmine.Spy };
  // let authSpy: { get: jasmine.Spy, put: jasmine.Spy, post: jasmine.Spy, delete: jasmine.Spy, getCurrentUserId: jasmine.Spy };
  let vaServiceStub: VirtualDetailsService;

  const loginPojo = {
    userId: 23,
    username: 'skandha',
    email: 'bhuvan@uniphore.com',
    phoneNumber: '9876540963',
    jwToken: 'Password Reset',
    password: null,
    newPassword: null,
    confirmPassword: null,
    roleId: 0,
    roleName: ''
  };



  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule, HttpClientTestingModule, RouterTestingModule],
      providers: [VirtualDetailsService,
        { provide: BehaviorSubject, useClass: BehaviorSubjectMock },
        { provide: AuthenticationService, useClass: AuthenticationServiceStub },
        { provide: Router, useClass: MockRouter }],
    });

    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get', 'put', 'post', 'delete']);
    // authSpy = jasmine.createSpyObj('AuthenticationService', ['getCurrentUserId']);
    vaServiceStub = new VirtualDetailsService(<any> httpClientSpy, <any> TestBed.get(AuthenticationService));
    // authServiceStub.currentUserSubject = new BehaviorSubject(userInfo);

  });

  it('should be created', () => {
    const service: VirtualDetailsService = TestBed.get(VirtualDetailsService);
    expect(service).toBeTruthy();
  });

  it('should call method getVirtualAgentsDetails', () => {
    httpClientSpy.get.and.returnValue(of(vrmDetails));
    vaServiceStub.getVirtualAgentsDetails();
    vaServiceStub.getVirtualAgentRoleMaps().subscribe(
      res => {
        expect(res['vrmId']).toBe(1);
      },
      fail => { }
    );
    expect(httpClientSpy.get.calls.count()).toBe(2, 'two call');
    // let spyCall = spyOn(vaServiceStub, 'getVirtualAgentRoleMaps');
    // httpClientSpy.get.and.returnValue(of(vrmDetails));
    // vaServiceStub.getVirtualAgentsDetails();
    // expect(spyCall).toHaveBeenCalled();
  });

  it('should call method setSimulatorBaseUrl', () => {
    vaServiceStub.simulatorBaseUrl = 'url';
    vaServiceStub.setSimulatorBaseUrl('url');
    // expect(authServiceStub.setSimulatorBaseUrl('url')).toEqual(authServiceStub.simulatorBaseUrl);
  });

  it('should call method simulator url', () => {
    vaServiceStub.simulatorBaseUrl = 'url';
    expect(vaServiceStub.getSimulatorBaseUrl()).toEqual(vaServiceStub.simulatorBaseUrl);
  });

  it('should call vrmDetails Method', () => {
    httpClientSpy.get.and.returnValue(of(vrmDetails));
    vaServiceStub.getVirtualAgents();
    expect(httpClientSpy.get.calls.count()).toBe(0, 'zero call');
  });

  it('should call getVirtualAgentById', () => {
    httpClientSpy.get.and.returnValue(of(vrmDetails));
    vaServiceStub.getVirtualAgentById(1);
    expect(httpClientSpy.get.calls.count()).toBe(0, 'zero call');
  });

  it('should call getVirtualAgentById', () => {
    httpClientSpy.get.and.returnValue(of(vrmDetails));
    vaServiceStub.getVirtualAgentById(1);
    expect(httpClientSpy.get.calls.count()).toBe(0, 'zero call');
  });


  //   it('should call getChannelsByVrmId', () => {
  //     httpClientSpy.get.and.returnValue(of(vrmDetails));
  //     vaServiceStub.getChannelsByVrmId(1);
  //     expect(httpClientSpy.get.calls.count()).toBe(0, 'zero call');
  //   });

  //   it('should call getLanguagesByVrmId', () => {
  //     httpClientSpy.get.and.returnValue(of(vrmDetails));
  //     vaServiceStub.getLanguagesByVrmId(1);
  //     expect(httpClientSpy.get.calls.count()).toBe(0, 'zero call');
  //   });

  it('should call getVirtualAgentRoleMaps', () => {
    httpClientSpy.get.and.returnValue(of(vrmDetails));
    vaServiceStub.getVirtualAgentRoleMaps().subscribe(
      res => {
        expect(res['vrmId']).toBe(1);
      },
      fail => { }
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('should call getSimulatorDetails', () => {
    httpClientSpy.get.and.returnValue(of(url));
    vaServiceStub.getSimulatorDetails().subscribe(
      res => {
        expect(res['data']).toBe('http://3.20.208.15:9903/');
      },
      fail => { }
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('should call auth token', () => {
    httpClientSpy.post.and.returnValue(of(authBodyToken));
    vaServiceStub.createAuthenticationToken(url.data, 1, {}).subscribe(
      res => {
        expect(res['errorBody'].code).toEqual(0);
      },
      fail => { }
    );
    expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
  });

  it('should call init conversation method', () => {
    httpClientSpy.post.and.returnValue(of(initConversation));
    vaServiceStub.initializeConversation(url.data, 1, 'token').subscribe(
      res => {
        expect(res['sessionId']).toEqual('11284');
      },
      fail => { }
    );
    expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
  });


  it('should call init conversation method', () => {
    httpClientSpy.post.and.returnValue(of(initConversation));
    vaServiceStub.initializeConversation(url.data, 1, 'token').subscribe(
      res => {
        expect(res['sessionId']).toEqual('11284');
      },
      fail => { }
    );
    expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
  });

  it('should call init conversation method', () => {
    httpClientSpy.post.and.returnValue(of(sendMsgResponse));
    vaServiceStub.sendMessage({language: 'English',  sessionId: '11285', userRequest: 'can i know claim status'}).subscribe(
      res => {
        expect(res['conversationResponsePojo'].responseType).toEqual('text');
      },
      fail => { }
    );
    expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
  });

  it('should call terminate conversation method', () => {
    httpClientSpy.post.and.returnValue(of({}));
    vaServiceStub.terminateConversation({language: 'English',  sessionId: '11285', url: 'http://3.20.208.15:9903' , virtualAgentRoleChannelMapId: 1}).subscribe(
      res => {
        expect(res).toEqual({ });
      },
      fail => { }
    );
    expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
  });
});

import { TestBed, async, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClientModule } from '@angular/common/http';
import { of } from 'rxjs';
import { IntentService } from './intent.service';

describe('IntentService', () => {
  let httpClientSpy: { get: jasmine.Spy, post: jasmine.Spy, put: jasmine.Spy };
  let intentListService: IntentService;

  const clonePhrase = {
    virtualAgent: null,
    virtualAgents: null,
    intent: {
      intentId: 41,
      intentName: 'Test',
      intentDescription: 'Test',
      virtualAgent: null,
      businessUnit: null,
      languages: [
        {
          langEngId: 1,
          langName: 'English',
          channels: [
            {
              icmId: 364,
              channelId: 1,
              channelName: 'WEB',
              intentConfigStage: 0,
              isLive: false
            }
          ]
        },
        {
          langEngId: 2,
          langName: 'French',
          channels: [
            {
              icmId: 365,
              channelId: 1,
              channelName: 'WEB',
              intentConfigStage: 0,
              isLive: false
            }
          ]
        }
      ]
    },
    intents: null,
    conversation: null,
    trainingPhrases: null,
    virtualAgentDashboardResponseObject: null,
    virtualAgentTrendResponseObject: null,
    systemSlotKeys: null,
    count: null,
    languages: null,
    channels: null,
    intentLanguageChannelMaps: null,
    intentSlots: null,
    entities: null,
    errorBody: null
  };

  const tableList = {
    virtualAgent: null,
    virtualAgents: null,
    intent: null,
    intents: [
      {
        intentId: 78,
        intentName: 'intentForDummy17',
        intentDescription: 'intentForDummy17',
        virtualAgent: {
          vaId: 3,
          vaName: 'dummyBot',
          vaIsLive: true,
          vaAvatarName: 'BOT',
          vaDescription: 'web'
        },
        businessUnit: 'categoryOne',
        languages: [
          {
            langEngId: 1,
            langName: 'French',
            channels: [
              {
                icmId: 199,
                channelId: 1,
                channelName: 'WEB',
                intentConfigStage: 1,
                isLive: false
              },
              {
                icmId: 200,
                channelId: 2,
                channelName: 'IVR',
                intentConfigStage: 1,
                isLive: false
              }
            ]
          },
          {
            langEngId: 2,
            langName: 'Spanish',
            channels: [
              {
                icmId: 201,
                channelId: 1,
                channelName: 'WEB',
                intentConfigStage: 1,
                isLive: false
              },
              {
                icmId: 202,
                channelId: 2,
                channelName: 'IVR',
                intentConfigStage: 1,
                isLive: false
              }
            ]
          }
        ]
      }
    ],
    conversation: null,
    trainingPhrases: null,
    virtualAgentDashboardResponseObject: null,
    virtualAgentTrendResponseObject: null,
    systemSlotKeys: null,
    count: null,
    languages: null,
    channels: null,
    intentLanguageChannelMaps: null,
    intentSlots: null,
    errorBody: null
  };


  const assistedTrainingInputs = {
    virtualAgents: [
      {
        virtualAgent: {
          vaId: 1,
          vaName: 'webBot',
          vaIsLive: false,
          vaAvatarName: 'UMRBOT',
          vaDescription: 'web'
        },
        languages: [
          {
            id: 1,
            value: 'English'
          },
          {
            id: 2,
            value: 'French'
          }
        ],
        channels: [
          {
            id: 1,
            value: 'WEB'
          }
        ]
      }
    ]
  };

  const intentList = {
    virtualAgent: null,
    virtualAgents: null,
    intent: null,
    intents: [
      {
        intentId: 36,
        intentName: 'FundValue',
        intentType: 'GENERAL',
        intentDescription: 'What is the value of the fund ',
        virtualAgent: {
          vaId: 2,
          vaName: 'Claims Management',
          vaIsLive: false,
          vaAvatarName: 'Akeira',
          vaDescription: 'Claims',
          businessUnit: null
        },
        businessUnit: 'Member Services',
        languages: [
          {
            langEngId: 1,
            langName: 'English',
            channels: [
              {
                icmId: 59,
                channelId: 2,
                channelName: 'IVR',
                intentConfigStage: 7,
                isLive: true
              }
            ]
          },
          {
            langEngId: 11,
            langName: 'Spanish',
            channels: [
              {
                icmId: 60,
                channelId: 2,
                channelName: 'IVR',
                intentConfigStage: 1,
                isLive: false
              }
            ]
          }
        ]
      },
      {
        intentId: 101,
        intentName: 'rests',
        intentType: 'AGENT_TRANSFER',
        intentDescription: 'dsfdasdf',
        virtualAgent: {
          vaId: 2,
          vaName: 'Claims Management',
          vaIsLive: false,
          vaAvatarName: 'Akeira',
          vaDescription: 'Claims',
          businessUnit: null
        },
        businessUnit: 'Member Services',
        languages: [
          {
            langEngId: 1,
            langName: 'English',
            channels: [
              {
                icmId: 148,
                channelId: 2,
                channelName: 'IVR',
                intentConfigStage: 1,
                isLive: false
              }
            ]
          },
          {
            langEngId: 11,
            langName: 'Spanish',
            channels: [
              {
                icmId: 149,
                channelId: 2,
                channelName: 'IVR',
                intentConfigStage: 1,
                isLive: false
              }
            ]
          }
        ]
      }
    ],
    conversation: null,
    trainingPhrases: null,
    virtualAgentDashboardResponseObject: null,
    virtualAgentTrendResponseObject: null,
    systemSlotKeys: null,
    count: 118,
    languages: null,
    channels: null,
    intentLanguageChannelMaps: null,
    intentSlots: null,
    entities: null,
    errorBody: null
  };

  const toggleData = {
    virtualAgent: null,
    virtualAgents: null,
    intent: null,
    intents: null,
    conversation: null,
    trainingPhrases: null,
    virtualAgentDashboardResponseObject: null,
    virtualAgentTrendResponseObject: null,
    systemSlotKeys: null,
    count: null,
    languages: null,
    channels: null,
    intentLanguageChannelMaps: [
      {
        icmId: 51,
        channelId: null,
        channelName: null,
        intentConfigStage: null,
        isLive: true
      }
    ],
    intentSlots: null,
    entities: null,
    errorBody: null
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule, HttpClientTestingModule],
      providers: [IntentService]
    });
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get', 'post', 'put']);
    intentListService = new IntentService(httpClientSpy as any);
  });

  // it(`should create`, async(inject([HttpTestingController, IntentService],
  //   (httpClient: HttpTestingController , service: IntentService) => {
  //     expect(httpClient).toBeTruthy();expect(service).toBeTruthy();
  // })));


  // it(`should create`, async(inject([HttpTestingController, IntentService],
  //   (httpClient: HttpTestingController, service: IntentService) => {
  //     expect(httpClient).toBeTruthy(); expect(service).toBeTruthy();
  //   })));

  //   it('check table response', () => {
  //     httpClientSpy.get.and.returnValue(of(tableList));
  //     intentListService.intentList(1, 0, 0, 0).subscribe(
  //       res => {
  //         expect(res['intents']['languages'].length).toBe(2);
  //       },
  //       fail
  //     );
  //     expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  //   });

  //   it('check header response', () => {
  //     httpClientSpy.get.and.returnValue(of(assistedTrainingInputs));
  //     intentListService.getInputs().subscribe(
  //       res => {
  //         expect(res).toEqual(assistedTrainingInputs);
  //       },
  //       fail
  //     );
  //     expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  //   });


  //   it('check clone', () => {
  //     httpClientSpy.post.and.returnValue(of(clonePhrase));
  //     intentListService.cloneIntent([], 41, 2).subscribe(
  //       res => {
  //         expect(res).toEqual(clonePhrase);
  //       },
  //       fail
  //     );
  //     expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
  //   });

  // it('check intent list', () => {
  //   httpClientSpy.get.and.returnValue(of(intentList));

  //   intentListService.intentListByName(1,1,2,2,'fund').subscribe(
  //     res => {
  //       expect(res['intents'].length).toEqual(2);
  //     },
  //     fail
  //   );
  //   expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  // });

  // it('check toggle method', () => {
  //   httpClientSpy.put.and.returnValue(of(toggleData));

  //   intentListService.toggleIntent({icmIds: [51]},1,2).subscribe(
  //     res => {
  //       expect(res['intentLanguageChannelMaps'].length).toEqual(1);
  //     },
  //     fail
  //   );
  //   expect(httpClientSpy.put.calls.count()).toBe(1, 'one call');
  // });

  // it('check delete intent method', () => {
  //   httpClientSpy.put.and.returnValue(of(tableList));

  //   intentListService.deleteIntents(1,2).subscribe(
  //     res => {
  //       expect(res['intents'].length).toEqual(1);
  //     },
  //     fail
  //   );
  //   expect(httpClientSpy.put.calls.count()).toBe(1, 'one call');
  // });
});

import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import {  environment as env } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class IntentService {

  constructor(private http: HttpClient) { }

  public intentList(userId, PageNo, VaId, VaChan, VaLang): Observable<any> {
    return this.http.get<any>(env.apiUrl + '/user/' + userId + '/intents/pageNumber/' + PageNo + '?' + 'channelId=' + VaChan + '&' + 'langEngId=' + VaLang + '&' + 'vaRoleId=' + VaId);
  }
  public intentListByName(userId, PageNo, VaId, VaChan, VaLang, intenttxt): Observable<any>  {
    return this.http.get<any>(env.apiUrl + '/user/' + userId + '/intents/pageNumber/' + PageNo + '?' + 'channelId=' + VaChan + '&' + 'langEngId=' + VaLang + '&' + 'vaRoleId=' + VaId + '&' + 'intentName=' + intenttxt);
  }

  public getInputs(userId: number): Observable<any> {
    return this.http.get<any>(env.apiUrl + '/user/' + userId + '/virtualAgentRoleMaps/');
  }

  public cloneIntent(body, intId, vaId): Observable<any>  {
    return this.http.post<any>(env.apiUrl + '/virtualAgent/' + vaId + '/intents/' + intId + '/clone', body);
  }

  public toggleIntent(body, icmIds, vaId): Observable<any> {
    return this.http.put<any>(env.apiUrl + '/virtualAgent/' + vaId + '/intents/toggle', icmIds);
  }

  public deleteIntents(vaId, deleteIntentId): Observable<any> {
    return this.http.put<any>(env.apiUrl + '/virtualAgent/' + vaId + '/intents/', deleteIntentId);
  }

}

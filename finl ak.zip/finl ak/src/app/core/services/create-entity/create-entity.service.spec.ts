import { TestBed, async, inject } from '@angular/core/testing';
import { CreateEntityService } from './create-entity.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClientModule } from '@angular/common/http';
import { of } from 'rxjs';
import { NgxCacheIfModule } from 'ngx-cache-if';


describe('CreateEntityService', () => {
  let httpClientSpy: { get: jasmine.Spy, post: jasmine.Spy, put: jasmine.Spy, delete: jasmine.Spy };
  let entityService: CreateEntityService;
  const savedEntity = {
    entityResponseObject: {
      entityId: 32,
      entityName: 'sfadasf',
      entityDescription: 'sdf',
      entityRefernceValuePojoList: [
        {
          entityRefValId: 49,
          languageMasterPojo: {
            langId: 1,
            langName: null
          },
          entityReferenceValue: 'vino22',
          entitySynonymsValueList: [
            {
              entitySynonymsValid: 89,
              entitySynonymsValue: 'vino22'
            },
            {
              entitySynonymsValid: 90,
              entitySynonymsValue: 'suganya'
            }
          ]
        },
        {
          entityRefValId: 50,
          languageMasterPojo: {
            langId: 1,
            langName: null
          },
          entityReferenceValue: 'priya',
          entitySynonymsValueList: [
            {
              entitySynonymsValid: 91,
              entitySynonymsValue: 'priya'
            }
          ]
        },
        {
          entityRefValId: 51,
          languageMasterPojo: {
            langId: 1,
            langName: null
          },
          entityReferenceValue: 'pav',
          entitySynonymsValueList: [
            {
              entitySynonymsValid: 92,
              entitySynonymsValue: 'pav'
            },
            {
              entitySynonymsValid: 93,
              entitySynonymsValue: 'dsf'
            }
          ]
        }
      ]
    }
  };

  // });
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule, HttpClientTestingModule, NgxCacheIfModule],
      providers: [CreateEntityService, HttpClientModule],

    }),
      httpClientSpy = jasmine.createSpyObj('HttpClient', ['get', 'post', 'put', 'delete']);
    entityService = new CreateEntityService(<any> httpClientSpy);
  });


  it(`should create`, async(inject([HttpTestingController, CreateEntityService],
    (httpClient: HttpTestingController, service: CreateEntityService) => {
      expect(httpClient).toBeTruthy(); expect(service).toBeTruthy();
    })));

  it('should be created', () => {
    const service: CreateEntityService = TestBed.get(CreateEntityService);
    expect(service).toBeTruthy();
  });

  it('getEntities', () => {
    httpClientSpy.get.and.returnValue(of(savedEntity));
    entityService.getEntity(1, 2).subscribe(
      res => {
        expect(res).toBe(savedEntity);
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check click on update Enity', () => {
    httpClientSpy.put.and.returnValue(of(savedEntity));
    entityService.updateEntity(1, savedEntity).subscribe(
      res => {
        expect(res).toEqual(savedEntity);
      },
      fail
    );
    expect(httpClientSpy.put.calls.count()).toBe(1, 'one call');
  });

  it('check click on save Enity', () => {
    httpClientSpy.post.and.returnValue(of(savedEntity));
    entityService.saveEntity(1, savedEntity).subscribe(
      res => {
        expect(res).toEqual(savedEntity);
      },
      fail
    );
    expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
  });



});


import { TestBed, async, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { VirtualAgentService } from './virtual-agent.service';
import { HttpClientModule } from '@angular/common/http';
import { of, Observable, throwError } from 'rxjs';


const orgList = {
  organizationData: [{ orgId: 1, organizationName: 'Uniphore' }]
};

const categoryData = {
  busUnit: [{ catId: 16, categoryName: 'Outbound', nluEngine: { engineId: 1, engineName: 'DIALOG_FLOW' }, organization: null }]
};

const languageEngineMaps = { langEngId: 1, langName: 'English', channels: null };

const channels = { channelId: 2, channelName: 'IVR' };

const virtualAgent = {
  vaId: 3,
  vaName: 'Policy Issuance',
  vaIsLive: true,
  isNluConfigured: false,
  vaAvatarName: 'Akeira2.0 av',
  vaDescription: 'Policy issuance',
  businessUnit: null,
  languages: null,
  channels: null,
  businessUnitData: null,
  userName: 'VAadmin'
};


describe('VirtualAgentService', () => {
  let httpClientSpy: { get: jasmine.Spy, put: jasmine.Spy, post: jasmine.Spy, delete: jasmine.Spy };
  let virtualAgentServiceStub: VirtualAgentService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule, HttpClientTestingModule],
      providers: [VirtualAgentService],
    });

    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get', 'put', 'post', 'delete']);
    virtualAgentServiceStub = new VirtualAgentService(httpClientSpy as any);
  });

  it('should be created', () => {
    const service: VirtualAgentService = TestBed.get(VirtualAgentService);
    expect(service).toBeTruthy();
  });

  it('check org list', () => {
    httpClientSpy.get.and.returnValue(of(orgList));
    virtualAgentServiceStub.orgData(1).subscribe(
      res => {
        expect(res['organizationData'][0].orgId).toEqual(1);
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check bus unit list', () => {
    httpClientSpy.get.and.returnValue(of(categoryData));
    virtualAgentServiceStub.busUnitData(1, 2).subscribe(
      res => {
        expect(res['busUnit'][0].categoryName).toEqual('Outbound');
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check lang list', () => {
    httpClientSpy.get.and.returnValue(of(languageEngineMaps));
    virtualAgentServiceStub.langData(1).subscribe(
      res => {
        expect(res['langName']).toEqual('English');
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check chnl list', () => {
    httpClientSpy.get.and.returnValue(of(channels));
    virtualAgentServiceStub.chnData().subscribe(
      res => {
        expect(res['channelName']).toEqual('IVR');
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('save va ', () => {
    httpClientSpy.post.and.returnValue(of(virtualAgent));
    virtualAgentServiceStub.sendVaSaveResponse(1, 2, {
      businessUnit: 'outbound',
      businessUnitData: {
        catId: 1,
        nluEngine: {
          engineId: 0,
          engineName: ''
        },
        organization: {
          orgId: 1,
          organizationName: 'Uniphore'
        }
      },
      userName: '',
      channels: [{ channelId: 2, channelName: 'IVR' }],
      languages: [{ langEngId: 1, langName: 'English', channels: null }],
      vaAvatarName: 'Akeira2.0 av',
      vaDescription: 'Policy issuance',
      vaId: 0,
      vaIsLive: true,
      vaName: 'Policy'
    }).subscribe(
      res => {
        expect(res['vaName']).toEqual('Policy Issuance');
      },
      fail
    );
    expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
  });

  it('update va ', () => {
    httpClientSpy.put.and.returnValue(of(virtualAgent));
    virtualAgentServiceStub.updateVaResponse(1, {
      businessUnit: 'outbound',
      businessUnitData: {
        catId: 1,
        nluEngine: {
          engineId: 0,
          engineName: ''
        },
        organization: {
          orgId: 1,
          organizationName: 'Uniphore'
        }
      },
      userName: '',
      channels: [{ channelId: 2, channelName: 'IVR' }],
      languages: [{ langEngId: 1, langName: 'English', channels: null }],
      vaAvatarName: 'Akeira2.0 av',
      vaDescription: 'Policy issuance',
      vaId: 0,
      vaIsLive: true,
      vaName: 'Policy'
    }, 2).subscribe(
      res => {
        expect(res['vaDescription']).toEqual('Policy issuance');
      },
      fail
    );
    expect(httpClientSpy.put.calls.count()).toBe(1, 'one call');
  });

  xit('get VAlist', () => {
    httpClientSpy.get.and.returnValue(of(virtualAgent));
    virtualAgentServiceStub.getVirtualAgents(1, 2, 2).subscribe(
      res => {
        expect(res['userName']).toEqual('VAadmin');
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

});



import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment as env } from '../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class EntitiesService {

  constructor(private http: HttpClient) { }

  public getVAdetailsByUserId(userId): Observable<any> {
    return this.http.get<any>(env.apiUrl + '/user/' + userId + '/virtualAgentsByUser/');
  }

  public getLanguagessByVaId(vaId): Observable<any> {
    return this.http.get<any>(env.apiUrl + '/virtualAgent/' + vaId + '/languages');
  }

  public getEntityList(pageNo, vaId, vaLang, serachString: string, userId): Observable<any> {
    return this.http.get<any>(env.apiUrl + '/virtualAgent/' + vaId + '/language/' + vaLang + '/page/' + pageNo + '/entity/{entityName}/user/' + userId + '/entities/?entityName=' + serachString);
  }

  public deleteEntity(vaId, entityId) {
    return this.http.delete<any>(env.apiUrl + '/virtualAgent/' + vaId + '/entity/' + entityId + '/entities/');
  }

}

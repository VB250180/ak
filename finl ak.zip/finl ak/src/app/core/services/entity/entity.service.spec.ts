import { TestBed, async, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClientModule } from '@angular/common/http';
import { of } from 'rxjs';
import { EntitiesService } from './entity.service';

const entityResObj = {
  entityResponseObjectList: [{
    entityId: 2,
    entityName: 'SSN',
    entityDescription: '123-45-6789',
    entityRefernceValuePojoList: null,
    virtualAgentPojo: {
      vaId: 4,
      vaName: 'Policy Issuance',
      vaIsLive: false,
      isNluConfigured: null,
      vaAvatarName: null,
      vaDescription: null,
      businessUnit: null,
      languages: [{
        langEngId: 1,
        ilmId: null,
        langName: 'English',
        channels: null,
        langCode: null,
        langId: null
      }],
      channels: null,
      businessUnitData: null,
      userName: null,
      rasaIp: null
    }
  }]
};

const virtualAgents = [{
  vaId: 1,
  vaName: 'Claims Management',
  vaIsLive: true,
  isNluConfigured: true,
  vaAvatarName: 'Akeira',
  vaDescription: 'Claims',
  businessUnit: null,
  languages: null,
  channels: null,
  businessUnitData: null,
  userName: 'VAadmin',
  rasaIp: null
}];

const entityList = {
  entityDescription: '123-45-6789',
  entityId: 2,
  entityName: 'SSN',
  entityRefernceValuePojoList: [],
  virtualAgentPojo: null
};

describe('EntitiesService', () => {
  let httpClientSpy: { get: jasmine.Spy, put: jasmine.Spy, post: jasmine.Spy, delete: jasmine.Spy };
  let entitiesServiceStub: EntitiesService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule, HttpClientTestingModule],
      providers: [EntitiesService],
    });

    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get', 'put', 'post', 'delete']);
    entitiesServiceStub = new EntitiesService(httpClientSpy as any);
  });

  it('should be created', () => {
    const service: EntitiesService = TestBed.get(EntitiesService);
    expect(service).toBeTruthy();
  });

  it('check entity list', () => {
    httpClientSpy.get.and.returnValue(of(entityResObj));
    entitiesServiceStub.getVAdetailsByUserId(1).subscribe(
      res => {
        expect(res['entityResponseObjectList'][0]['entityName']).toEqual('SSN');
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check languages for particular va', () => {
    httpClientSpy.get.and.returnValue(of(virtualAgents));
    entitiesServiceStub.getLanguagessByVaId(1).subscribe(
      res => {
        expect(res[0]['vaName']).toEqual('Claims Management');
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check languages for particular va', () => {
    httpClientSpy.get.and.returnValue(of(entityList));
    entitiesServiceStub.getEntityList(1, 1, 1, 'SSN', 1).subscribe(
      res => {
        expect(res['entityName']).toEqual('SSN');
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  // it('check for deleting particular entity', () => {
  //   httpClientSpy.delete.and.returnValue(of(entityList));
  //   entitiesServiceStub.deleteEntity(1, 1).subscribe(
  //     res => {
  //       expect(res['entityName']).toEqual("SSN");
  //     },
  //     fail
  //   );
  //   expect(httpClientSpy.delete.calls.count()).toBe(1, 'one call');
  // });

});




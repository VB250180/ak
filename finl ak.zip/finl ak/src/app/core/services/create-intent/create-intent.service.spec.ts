import { TestBed, async, inject } from '@angular/core/testing';
import { CreateIntentService } from './create-intent.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClientModule } from '@angular/common/http';
import { of } from 'rxjs';
import { NgxCacheIfModule } from 'ngx-cache-if';


describe('CreateIntentService', () => {
  let httpClientSpy: { get: jasmine.Spy, post: jasmine.Spy, put: jasmine.Spy, delete: jasmine.Spy };
  let intentService: CreateIntentService;

  const intentSlotValues =  {
    virtualAgent: null,
    virtualAgents: null,
    intent: null,
    intents: null,
    conversation: null,
    trainingPhrases: null,
    virtualAgentDashboardResponseObject: null,
    virtualAgentTrendResponseObject: null,
    systemSlotKeys: null,
    count: null,
    languages: null,
    channels: null,
    intentLanguageChannelMaps: null,
    intentSlots: [
      {
        intentSlotId: 7,
        intentSlotName: 'To city',
        intentSlotDescription: 'city',
        entity: {
          entityId: 1,
          entityName: 'fromPlace'
        }
      },
      {
        intentSlotId: 6,
        intentSlotName: 'City from',
        intentSlotDescription: 'from city',
        entity: {
          entityId: 1,
          entityName: 'fromPlace'
        }
      },
      {
        intentSlotId: 1,
        intentSlotName: 'fromPlace',
        intentSlotDescription: 'from city',
        entity: {
          entityId: 1,
          entityName: 'fromPlace'
        }
      },
      {
        intentSlotId: 2,
        intentSlotName: 'toPlace',
        intentSlotDescription: 'to city',
        entity: {
          entityId: 2,
          entityName: 'toPlace'
        }
      }
    ],
    entities: null,
    errorBody: null
  };
  const phrases = {
    virtualAgent: null,
    virtualAgents: null,
    intent: null,
    intents: null,
    conversation: null,
    trainingPhrases: [
      {
        trainingPhraseId: 130,
        trainingPhraseText: 'Book a flight ticket from Singaporee to %pos0%',
        intentSlotMapPojos: [
          {
            position: 'pos0',
            value: 'newzealand',
            intentSlot: {
              intentSlotId: 1,
              intentSlotName: 'fromPlace',
              intentSlotDescription: 'from city',
              entity: {
                entityId: 1,
                entityName: 'fromPlace'
              }
            }
          }
        ],
        trainingPhraseStage: 'notTrained'
      },
      {
        trainingPhraseId: 132,
        trainingPhraseText: 'i want to book a movie ticket from %pos0%',
        intentSlotMapPojos: [
          {
            position: 'pos0',
            value: 'Bengaluru',
            intentSlot: {
              intentSlotId: 1,
              intentSlotName: 'fromPlace',
              intentSlotDescription: 'from city',
              entity: {
                entityId: 1,
                entityName: 'fromPlace'
              }
            }
          }
        ],
        trainingPhraseStage: 'notTrained'
      },
      {
        trainingPhraseId: 135,
        trainingPhraseText: 'agile methodology in akeira 2.0 product %pos1%',
        intentSlotMapPojos: [
          {
            position: 'pos1',
            value: 'development',
            intentSlot: {
              intentSlotId: 7,
              intentSlotName: 'To city',
              intentSlotDescription: 'city',
              entity: {
                entityId: 1,
                entityName: 'fromPlace'
              }
            }
          },
          {
            position: 'pos0',
            value: 'list',
            intentSlot: {
              intentSlotId: 7,
              intentSlotName: 'To city',
              intentSlotDescription: 'city',
              entity: {
                entityId: 1,
                entityName: 'fromPlace'
              }
            }
          }
        ],
        trainingPhraseStage: 'notTrained'
      }],
    virtualAgentDashboardResponseObject: null,
    virtualAgentTrendResponseObject: null,
    systemSlotKeys: null,
    count: null,
    languages: null,
    channels: null,
    intentLanguageChannelMaps: null,
    intentSlots: null,
    entities: null,
    errorBody: null
  };
  const delPhrase = {
    virtualAgent: null,
    virtualAgents: null,
    intent: null,
    intents: null,
    conversation: null,
    trainingPhrases: null,
    virtualAgentDashboardResponseObject: null,
    virtualAgentTrendResponseObject: null,
    systemSlotKeys: null,
    count: 1,
    languages: null,
    channels: null,
    intentLanguageChannelMaps: null,
    intentSlots: null,
    entities: null,
    errorBody: null
  };
  const addPhrases = {
    virtualAgent: null,
    virtualAgents: null,
    intent: null,
    intents: null,
    conversation: null,
    trainingPhrases: [
      {
        trainingPhraseId: 148,
        trainingPhraseText: 'Book flight ticket from Bengaluru',
        intentSlotMapPojos: [
          {
            position: 'pos0',
            value: 'Bengaluru',
            intentSlot: {
              intentSlotId: 1,
              intentSlotName: 'From place',
              intentSlotDescription: null,
              entity: null
            }
          }
        ],
        trainingPhraseStage: 'notTrained'
      }
    ],
    virtualAgentDashboardResponseObject: null,
    virtualAgentTrendResponseObject: null,
    systemSlotKeys: null,
    count: null,
    languages: null,
    channels: null,
    intentLanguageChannelMaps: null,
    intentSlots: null,
    entities: null,
    errorBody: null
  };
  const addPhrasesBody = [
    {
      intentSlotMapPojos: [
        {
          intentSlot: {
            intentSlotId: 1,
            intentSlotName: 'From place'
          },
          position: 'pos0',
          value: 'Bengaluru'
        }
      ],
      trainingPhraseId: 0,
      trainingPhraseText: 'Book flight ticket from Bengaluru'
    }
  ];
  const entities = {
    virtualAgent: null,
    virtualAgents: null,
    intent: null,
    intents: null,
    conversation: null,
    trainingPhrases: null,
    virtualAgentDashboardResponseObject: null,
    virtualAgentTrendResponseObject: null,
    systemSlotKeys: null,
    count: null,
    languages: null,
    channels: null,
    intentLanguageChannelMaps: null,
    intentSlots: null,
    entities: [
      {
        entityId: 3,
        entityName: 'accountNumber'
      },
      {
        entityId: 6,
        entityName: 'Airline name'
      },
      {
        entityId: 5,
        entityName: 'bookingDate'
      },
      {
        entityId: 1,
        entityName: 'fromPlace'
      },
      {
        entityId: 4,
        entityName: 'ticketNumber'
      },
      {
        entityId: 2,
        entityName: 'toPlace'
      }
    ],
    errorBody: null
  };
  const formValues = {
    intentDescription: 'test',
    intentName: 'test bot',
    intentType: 'AGENT_TRANSFER'
  };
  const savedIntent = {
    virtualAgent: null,
    virtualAgents: null,
    intent: {
      intentId: 108,
      intentName: 'test bot',
      intentType: 'AGENT_TRANSFER',
      intentDescription: 'test',
      virtualAgent: null,
      businessUnit: null,
      languages: [
        {
          langEngId: 1,
          langName: 'English',
          channels: [
            {
              icmId: 154,
              channelId: 2,
              channelName: 'IVR',
              intentConfigStage: 0,
              isLive: false
            }
          ]
        }
      ]
    },
    intents: null,
    conversation: null,
    trainingPhrases: null,
    virtualAgentDashboardResponseObject: null,
    virtualAgentTrendResponseObject: null,
    systemSlotKeys: null,
    count: null,
    languages: null,
    channels: null,
    intentLanguageChannelMaps: null,
    intentSlots: null,
    entities: null,
    errorBody: null
  };
  const conversationFlow = {
    virtualAgent: null,
    virtualAgents: null,
    intent: null,
    intents: null,
    conversation: {
      validationIntent: {
        intentId: 76,
        intentName: 'DOB SSN MTPIN',
        intentType: null,
        intentDescription: 'Validate a user using a combination of Date of Birth, Social Security number last 4 digits and Mobile transaction pin ',
        virtualAgent: null,
        businessUnit: null,
        languages: null
      },
      systemSlots: [
        {
          systemSlotId: 47,
          systemSlotKey: {
            systemSlotKeyId: 1,
            systemSlotKeyName: 'MemberID'
          }
        },
        {
          systemSlotId: 46,
          systemSlotKey: {
            systemSlotKeyId: 2,
            systemSlotKeyName: 'GroupID'
          }
        }
      ],
      conversationStages: [
        {
          sequenceNumber: 1,
          conversationStageId: 79,
          sendMessage: {
            messageId: 29,
            messageText: 'Right Away! Let me get you that data'
          },
          getInfo: null,
          finalResponse: null
        },
        {
          sequenceNumber: 2,
          conversationStageId: 80,
          sendMessage: null,
          getInfo: {
            getInfoId: 19,
            promptQuestion: 'I would need your claim number please',
            promptValidationMessage: 'Hmm!...The Claim number you provided is Invalid. Why dont we try it again',
            intentSlot: {
              intentSlotId: 19,
              intentSlotName: 'Claim number',
              intentSlotDescription: 'Claim_number',
              entity: {
                entityId: 6,
                entityName: 'sys.number'
              }
            }
          },
          finalResponse: null
        },
        {
          sequenceNumber: 3,
          conversationStageId: 81,
          sendMessage: null,
          getInfo: null,
          finalResponse: {
            finalResponseId: 33,
            finalResponseText: 'The status of your claim  %pos0% is  %pos1%  for a total  %pos2%  and the due amount is  %pos3% and is payable as of  %pos4% ',
            positionAndSlots: [
              {
                finalResponseSlotId: 719,
                position: 'pos0',
                intentSlot: {
                  intentSlotId: 19,
                  intentSlotName: 'Claim number',
                  intentSlotDescription: 'Claim_number',
                  entity: {
                    entityId: 6,
                    entityName: 'sys.number'
                  }
                },
                responseSlot: null
              },
              {
                finalResponseSlotId: 720,
                position: 'pos1',
                intentSlot: null,
                responseSlot: {
                  responseSlotId: 29,
                  responseSlotName: 'Claim_status',
                  responseSlotDescription: 'Status of the claim '
                }
              },
              {
                finalResponseSlotId: 721,
                position: 'pos2',
                intentSlot: null,
                responseSlot: {
                  responseSlotId: 31,
                  responseSlotName: 'Billed Amount',
                  responseSlotDescription: 'Total bill amount'
                }
              },
              {
                finalResponseSlotId: 722,
                position: 'pos3',
                intentSlot: null,
                responseSlot: {
                  responseSlotId: 32,
                  responseSlotName: 'Due Amount',
                  responseSlotDescription: 'Remaining amount to be paid by the customer'
                }
              },
              {
                finalResponseSlotId: 723,
                position: 'pos4',
                intentSlot: null,
                responseSlot: {
                  responseSlotId: 33,
                  responseSlotName: 'Due Date',
                  responseSlotDescription: 'Pay by date for the remaining amount'
                }
              }
            ]
          }
        }
      ],
      responseSlots: [
        {
          responseSlotId: 29,
          responseSlotName: 'Claim_status',
          responseSlotDescription: 'Status of the claim '
        },
        {
          responseSlotId: 31,
          responseSlotName: 'Billed Amount',
          responseSlotDescription: 'Total bill amount'
        },
        {
          responseSlotId: 32,
          responseSlotName: 'Due Amount',
          responseSlotDescription: 'Remaining amount to be paid by the customer'
        },
        {
          responseSlotId: 33,
          responseSlotName: 'Due Date',
          responseSlotDescription: 'Pay by date for the remaining amount'
        }
      ]
    },
    trainingPhrases: null,
    virtualAgentDashboardResponseObject: null,
    virtualAgentTrendResponseObject: null,
    systemSlotKeys: null,
    count: null,
    languages: null,
    channels: null,
    intentLanguageChannelMaps: null,
    intentSlots: null,
    entities: null,
    errorBody: null
  };

  const systemSlots = {
    virtualAgent: null,
    virtualAgents: null,
    intent: null,
    intents: null,
    conversation: null,
    trainingPhrases: null,
    virtualAgentDashboardResponseObject: null,
    virtualAgentTrendResponseObject: null,
    systemSlotKeys: [
      {
        systemSlotKeyId: 2,
        systemSlotKeyName: 'GroupID'
      },
      {
        systemSlotKeyId: 1,
        systemSlotKeyName: 'MemberID'
      }
    ],
    count: null,
    languages: null,
    channels: null,
    intentLanguageChannelMaps: null,
    intentSlots: null,
    entities: null,
    errorBody: null
  };

  const agents = {
    virtualAgent: null,
    virtualAgents: [
      {
        vaId: 1,
        vaName: 'webBot',
        vaIsLive: false,
        vaAvatarName: 'UMRBOT',
        vaDescription: 'web',
        businessUnit: 'catOne'
      },
      {
        vaId: 2,
        vaName: 'webBot',
        vaIsLive: true,
        vaAvatarName: 'UMRBOT',
        vaDescription: 'web',
        businessUnit: 'catOne'
      },
      {
        vaId: 3,
        vaName: 'dummyBot',
        vaIsLive: false,
        vaAvatarName: 'BOT',
        vaDescription: 'web',
        businessUnit: 'catOne'
      },
      {
        vaId: 4,
        vaName: 'dummyBot',
        vaIsLive: true,
        vaAvatarName: 'BOT',
        vaDescription: 'web',
        businessUnit: 'catOne'
      },
      {
        vaId: 5,
        vaName: 'Dev_BOT',
        vaIsLive: false,
        vaAvatarName: 'DEVBOT',
        vaDescription: 'dev bot desc',
        businessUnit: 'catOne'
      },
      {
        vaId: 6,
        vaName: 'Dev_BOT',
        vaIsLive: true,
        vaAvatarName: 'DEVBOT',
        vaDescription: 'dev bot desc',
        businessUnit: 'catOne'
      }
    ],
    intent: null,
    intents: null,
    conversation: null,
    trainingPhrases: null,
    virtualAgentDashboardResponseObject: null,
    virtualAgentTrendResponseObject: null,
    systemSlotKeys: null,
    count: null,
    languages: null,
    channels: null,
    intentLanguageChannelMaps: null,
    intentSlots: null,
    entities: null,
    errorBody: null
  };

  const intentDropdown = {
    virtualAgent: null,
    virtualAgents: null,
    intent: null,
    intents: [
      {
        intentId: 78,
        intentName: 'Claim Process',
        intentType: null,
        intentDescription: 'Claim Process',
        virtualAgent: null,
        businessUnit: null,
        languages: null
      }
    ],
    conversation: null,
    trainingPhrases: null,
    virtualAgentDashboardResponseObject: null,
    virtualAgentTrendResponseObject: null,
    systemSlotKeys: null,
    count: null,
    languages: null,
    channels: null,
    intentLanguageChannelMaps: null,
    intentSlots: null,
    entities: null,
    errorBody: null
  };

  const intents = {
    virtualAgent: null,
    virtualAgents: null,
    intent: {
      intentId: 60,
      intentName: 'Claim_status',
      intentType: 'GENERAL',
      intentDescription: 'Claim_status',
      virtualAgent: {
        vaId: 4,
        vaName: 'Policy Issuance',
        vaIsLive: false,
        vaAvatarName: 'Akeira2.0',
        vaDescription: 'Policy',
        businessUnit: null
      },
      businessUnit: 'Member Services',
      languages: [
        {
          langEngId: 1,
          langName: 'English',
          channels: [
            {
              icmId: 95,
              channelId: 2,
              channelName: 'IVR',
              intentConfigStage: 7,
              isLive: true
            }
          ]
        }
      ]
    },
    intents: null,
    conversation: null,
    trainingPhrases: null,
    virtualAgentDashboardResponseObject: null,
    virtualAgentTrendResponseObject: null,
    systemSlotKeys: null,
    count: null,
    languages: null,
    channels: null,
    intentLanguageChannelMaps: null,
    intentSlots: null,
    entities: null,
    errorBody: null
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule, HttpClientTestingModule, NgxCacheIfModule],
      providers: [CreateIntentService, HttpClientModule],

    }),
      httpClientSpy = jasmine.createSpyObj('HttpClient', ['get', 'post', 'put', 'delete']);
    intentService = new CreateIntentService(httpClientSpy as any);
  });


  it(`should create`, async(inject([HttpTestingController, CreateIntentService],
    (httpClient: HttpTestingController, service: CreateIntentService) => {
      expect(httpClient).toBeTruthy(); expect(service).toBeTruthy();
    })));

  it('should be created', () => {
    const service: CreateIntentService = TestBed.get(CreateIntentService);
    expect(service).toBeTruthy();
  });

  it('check assisted training input', () => {
    httpClientSpy.get.and.returnValue(of(intentSlotValues));

    intentService.intentSlots(1, 2).subscribe(
      res => {
        expect(res['intentSlots'].length).toBe(4);
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check phrases', () => {
    httpClientSpy.get.and.returnValue(of(phrases));

    intentService.addTrainingPhrase(1, 2, 1, 'test').subscribe(
      res => {
        expect(res).toEqual(phrases);
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check adding phrases', () => {
    httpClientSpy.put.and.returnValue(of(addPhrases));

    intentService.addPhraseDetails(1, 2, addPhrasesBody).subscribe(
      res => {
        expect(res).toEqual(addPhrases);
      },
      fail
    );
    expect(httpClientSpy.put.calls.count()).toBe(1, 'one call');
  });

  it('check click on save intent', () => {
    httpClientSpy.post.and.returnValue(of(savedIntent));
    intentService.saveCreateIntent(1, formValues).subscribe(
      res => {
        expect(res).toEqual(savedIntent);
      },
      fail
    );
    expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
  });

  it('check delete phrase', () => {
    httpClientSpy.delete.and.returnValue(of(delPhrase));
    intentService.deleteTrainingPhrase(1, 2, 1).subscribe(
      res => {
        expect(res['trainingPhrases']).toEqual(null);
      },
      fail
    );
    expect(httpClientSpy.delete.calls.count()).toBe(1, 'one call');
  });

  it('check get entity values', () => {
    httpClientSpy.get.and.returnValue(of(entities));
    intentService.getEntitys('1').subscribe(
      res => {
        expect(res['entities'].length).toBe(6);
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check get intent conversation list', () => {
    httpClientSpy.get.and.returnValue(of(conversationFlow));
    intentService.getIntentConversionList(1, 2, 1).subscribe(
      res => {
        expect(res['conversation'].systemSlots.length).toBe(2);
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check save conversation list', () => {
    httpClientSpy.put.and.returnValue(of(conversationFlow));
    intentService.saveConversations(conversationFlow.conversation, 1, 2, 1).subscribe(
      res => {
        expect(res['conversation']['systemSlots'].length).toBe(2);
      },
      fail
    );
    expect(httpClientSpy.put.calls.count()).toBe(1, 'one call');
  });

  it('check systemslots', () => {
    httpClientSpy.get.and.returnValue(of(systemSlots));
    intentService.getSystemSlotDropdown().subscribe(
      res => {
        expect(res['systemSlotKeys'].length).toEqual(2);
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check systemslots', () => {
    httpClientSpy.get.and.returnValue(of(systemSlots));
    intentService.getSystemSlotDropdown().subscribe(
      res => {
        expect(res['systemSlotKeys'].length).toEqual(2);
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check get virtual agents', () => {
    httpClientSpy.get.and.returnValue(of(agents));
    intentService.virtualAgent().subscribe(
      res => {
        expect(res['virtualAgents'].length).toEqual(6);
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check addconversationflow method', () => {
    httpClientSpy.get.and.returnValue(of('Trained'));
    intentService.addTrainingPhraseDialogFlow(1, 2).subscribe(
      res => {
        expect(res).toEqual('Trained');
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });


  it('check getIntentsDropdown method', () => {
    httpClientSpy.get.and.returnValue(of(intentDropdown));
    intentService.getIntentsDropdown(1, 2).subscribe(
      res => {
        expect(res['intents'].length).toEqual(1);
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check intents method', () => {
    httpClientSpy.get.and.returnValue(of(intents));
    intentService.getIntent(1, 2).subscribe(
      res => {
        expect(res['intent'].businessUnit).toEqual('Member Services');
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check updateCreateIntent', () => {
    httpClientSpy.put.and.returnValue(of(conversationFlow));
    intentService.updateCreateIntent(1, 1, conversationFlow.conversation).subscribe(
      res => {
        expect(res['conversation'].systemSlots.length).toBe(2);
      },
      fail
    );
    expect(httpClientSpy.put.calls.count()).toBe(1, 'one call');
  });

  it('check method', () => {
    intentService.changeMessage('dsfasdfas');
    intentService.requestaddTrainingPhraseAndintentSlots(1, 2, 1, 'd');
  });

  //  it('should have getIntentConversionList', () => {
  //   const service: CreateIntentService = TestBed.get(CreateIntentService);
  //   expect(service.getIntentConversionList).toBeTruthy();
  //  });
  //  it('should have getSystemSlotDropdown', () => {
  //   const service: CreateIntentService = TestBed.get(CreateIntentService);
  //   expect(service.getSystemSlotDropdown).toBeTruthy();
  //  });
  //  it('should have getIntentsDropdown', () => {
  //   const service: CreateIntentService = TestBed.get(CreateIntentService);
  //   expect(service.getIntentsDropdown).toBeTruthy();
  //  });
});


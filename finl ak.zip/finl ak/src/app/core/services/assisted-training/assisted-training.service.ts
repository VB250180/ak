import { Injectable } from '@angular/core';
import { Observable, of, forkJoin } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { catchError, map, tap, delay, filter, scan } from 'rxjs/operators';
import { environment as env } from '../../../../environments/environment';

export interface List {
  agent: string;
  id: number;
  mandatory: boolean;
  language: string;
  channel: string;
  status: string;
}

@Injectable({
  providedIn: 'root'
})
export class AssistedTrainingService {

  constructor(private http: HttpClient) { }

  public getInputs(userId: number): Observable<any> {
    return this.http.get<any>(env.apiUrl + '/user/' + userId + '/virtualAgentRoleMaps/');
  }

  public deleteUnmappedUserInputs(id: number): Observable<any> {
    return this.http.delete(env.apiUrl + '/unmappedUserInputs' + '?' + 'chId=' + id);
  }

  public getUnmappedUserInput(chn, langId, pageNo, VA, text, fromDate, toDate) {
    const url = '/unmappedUserInputs' + '?' + 'channelId=' + chn + '&' + (text !== '' ? 'conversationPhrase=' + text + '&' : '') + 'fromDate=' + fromDate + '&' + 'languageId=' + langId + '&' + 'pageNumber=' + pageNo + '&' + 'toDate=' + toDate + '&' + 'vaId=' + VA;
    return this.http.get(env.apiUrl + url);
  }

  public searchIntent(virtualID, LangID, channelId) {
    return this.http.get(env.apiUrl + '/intentsAndIntentSlots' + '?' + 'languageId=' + LangID + '&' + 'vaId=' + virtualID + '&channelId=' + channelId);
  }

  public languageChange(chn, fromDate, langId, pageNo, toDate, VA, text) {
    const searchIntent = this.searchIntent(VA, langId, chn);
    const getIntents = this.getUnmappedUserInput(chn, langId, pageNo, VA, text, fromDate, toDate);
    return forkJoin([searchIntent, getIntents]);
  }

  public intentSlots(virtualID, LangID, channelId) {
    return this.http.get(env.apiUrl + '/intentsAndIntentSlots' + '?' + 'languageId=' + LangID + '&' + 'vaId=' + virtualID + '&channelId=' + channelId);
  }

  public saveUnmappedInputs(inputs: any) {
    return this.http.put(env.apiUrl + '/unmappedUserInputs', inputs);
  }

  public createIntent(body, vaId) {
    console.log(body, vaId);
    return this.http.post(env.apiUrl + '/virtualAgent/' + vaId + '/' + 'intents', body);
  }

}



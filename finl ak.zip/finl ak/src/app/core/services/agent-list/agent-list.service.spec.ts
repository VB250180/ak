import { TestBed, async, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AgentListService } from './agent-list.service';
import { HttpClientModule } from '@angular/common/http';
import { of } from 'rxjs';

describe('AgentListService', () => {
  let httpClientSpy: { get: jasmine.Spy , post: jasmine.Spy};
  let agentListService: AgentListService;

  const channelAndLanguageList = {
    virtualAgent: null,
    virtualAgents: null,
    intent: null,
    intents: null,
    conversation: null,
    trainingPhrases: null,
    virtualAgentDashboardResponseObject: null,
    virtualAgentTrendResponseObject: null,
    systemSlotKeys: null,
    count: null,
    languages: [
      { langName: 'French', langId: 1 },
      { langName: 'Spanish', langId: 2 }
    ], channels: [
      { channelId: 1, channelName: 'WEB' },
      { channelId: 2, channelName: 'IVR' }
    ],
    intentLanguageChannelMaps: null,
    errorBody: null
  };

  const vadashboardData = {
      trenddata: [
        {
          currenweekintentaccuracy: 0,
          lastweekintentaccuracy: 0,
          currenweekcallaccuracy: 0,
          lastweekcallaccuracy: 0,
          vrmId: 1,
          channelId: 2,
          langEngId: 1
        },
        {
          currenweekintentaccuracy: 0,
          lastweekintentaccuracy: 0,
          currenweekcallaccuracy: 0,
          lastweekcallaccuracy: 0,
          vrmId: 1,
          channelId: 2,
          langEngId: 11
        }
      ]
  };

  const vaListData = {
    virtualAgentDashboardResponseObject: {
      virtualAgentDashboardList: [
        {
          vaAvatarName: 'UMRBOT',
          vaDescription: 'web',
          vaRoleName: 'test',
          vaTotalIntent: 0,
          vaDraftIntent: 0,
          vaDashChannelList: [
            {
              vaChannel: 'WEB',
              vaDashLangList: [
                {
                  vaLanguage: 'English',
                  vaUnmappedInputs: 0,
                  vaCurrentMonthIntentAccuracy: 0,
                  vaPreviousMonthIntentAccuracy: 0,
                  vaCurrentWeekIntentAccuracy: 0,
                  vaPreviousWeekIntentAccuracy: 0,
                  vaCurrentMonthCallHandled: 0,
                  vaPreviousMonthCallHandled: 0,
                  vaCurrentWeekCallHandled: 0,
                  vaPreviousWeekCallHandled: 0
                },
                {
                  vaLanguage: 'French',
                  vaUnmappedInputs: 0,
                  vaCurrentMonthIntentAccuracy: 0,
                  vaPreviousMonthIntentAccuracy: 0,
                  vaCurrentWeekIntentAccuracy: 0,
                  vaPreviousWeekIntentAccuracy: 0,
                  vaCurrentMonthCallHandled: 0,
                  vaPreviousMonthCallHandled: 0,
                  vaCurrentWeekCallHandled: 0,
                  vaPreviousWeekCallHandled: 0
                }
              ]
            }
          ]
        },
        {
          vaAvatarName: 'UMRBOT',
          vaDescription: 'web',
          vaRoleName: 'live',
          vaTotalIntent: 1,
          vaDraftIntent: 0,
          vaDashChannelList: [
            {
              vaChannel: 'WEB',
              vaDashLangList: [
                {
                  vaLanguage: 'English',
                  vaUnmappedInputs: 0,
                  vaCurrentMonthIntentAccuracy: 0,
                  vaPreviousMonthIntentAccuracy: 0,
                  vaCurrentWeekIntentAccuracy: 0,
                  vaPreviousWeekIntentAccuracy: 0,
                  vaCurrentMonthCallHandled: 0,
                  vaPreviousMonthCallHandled: 0,
                  vaCurrentWeekCallHandled: 0,
                  vaPreviousWeekCallHandled: 0
                },
                {
                  vaLanguage: 'French',
                  vaUnmappedInputs: 0,
                  vaCurrentMonthIntentAccuracy: 0,
                  vaPreviousMonthIntentAccuracy: 0,
                  vaCurrentWeekIntentAccuracy: 0,
                  vaPreviousWeekIntentAccuracy: 0,
                  vaCurrentMonthCallHandled: 0,
                  vaPreviousMonthCallHandled: 0,
                  vaCurrentWeekCallHandled: 0,
                  vaPreviousWeekCallHandled: 0
                }
              ]
            }
          ]
        },
        {
          vaAvatarName: 'BOT',
          vaDescription: 'web',
          vaRoleName: 'test',
          vaTotalIntent: 0,
          vaDraftIntent: 0,
          vaDashChannelList: [
            {
              vaChannel: 'IVR',
              vaDashLangList: [
                {
                  vaLanguage: 'French',
                  vaUnmappedInputs: 0,
                  vaCurrentMonthIntentAccuracy: 0,
                  vaPreviousMonthIntentAccuracy: 0,
                  vaCurrentWeekIntentAccuracy: 0,
                  vaPreviousWeekIntentAccuracy: 0,
                  vaCurrentMonthCallHandled: 0,
                  vaPreviousMonthCallHandled: 0,
                  vaCurrentWeekCallHandled: 0,
                  vaPreviousWeekCallHandled: 0
                },
                {
                  vaLanguage: 'English',
                  vaUnmappedInputs: 0,
                  vaCurrentMonthIntentAccuracy: 0,
                  vaPreviousMonthIntentAccuracy: 0,
                  vaCurrentWeekIntentAccuracy: 0,
                  vaPreviousWeekIntentAccuracy: 0,
                  vaCurrentMonthCallHandled: 0,
                  vaPreviousMonthCallHandled: 0,
                  vaCurrentWeekCallHandled: 0,
                  vaPreviousWeekCallHandled: 0
                }
              ]
            }
          ]
        },
        {
          vaAvatarName: 'BOT',
          vaDescription: 'web',
          vaRoleName: 'live',
          vaTotalIntent: 1,
          vaDraftIntent: 0,
          vaDashChannelList: [
            {
              vaChannel: 'IVR',
              vaDashLangList: [
                {
                  vaLanguage: 'French',
                  vaUnmappedInputs: 0,
                  vaCurrentMonthIntentAccuracy: 0,
                  vaPreviousMonthIntentAccuracy: 0,
                  vaCurrentWeekIntentAccuracy: 0,
                  vaPreviousWeekIntentAccuracy: 0,
                  vaCurrentMonthCallHandled: 0,
                  vaPreviousMonthCallHandled: 0,
                  vaCurrentWeekCallHandled: 0,
                  vaPreviousWeekCallHandled: 0
                },
                {
                  vaLanguage: 'English',
                  vaUnmappedInputs: 0,
                  vaCurrentMonthIntentAccuracy: 0,
                  vaPreviousMonthIntentAccuracy: 0,
                  vaCurrentWeekIntentAccuracy: 0,
                  vaPreviousWeekIntentAccuracy: 0,
                  vaCurrentMonthCallHandled: 0,
                  vaPreviousMonthCallHandled: 0,
                  vaCurrentWeekCallHandled: 0,
                  vaPreviousWeekCallHandled: 0
                }
              ]
            }
          ]
        }
      ]
    }
  };

  const vaTrendDatebymonth =  {
    trenddata:
      [[
        {
          startdate: '2020-04-30',
          trendvalue: 0
        },
        {
          startdate: '2020-05-01',
          trendvalue: 0
        }
      ]],
    callhandingdata:
      [[
        {
          startdate: '2020-04-30',
          trendvalue: 63.35
        },
        {
          startdate: '2020-05-01',
          trendvalue: 0
        }
      ]]
  };

  const vaTrenDatabyweeek = {
    trenddata:
      [[{ startdate: '2020-05-04T00:00:00.000Z', enddate: '2020-05-04T23:59:59.059Z', trendvalue: 0 },
      { startdate: '2020-05-05T00:00:00.000Z', enddate: '2020-05-05T23:59:59.059Z', trendvalue: 0 }]],
    callhandingdata:
      [[{ startdate: '2020-05-04T00:00:00.000Z', enddate: '2020-05-04T23:59:59.059Z', trendvalue: 0 },
      { startdate: '2020-05-05T00:00:00.000Z', enddate: '2020-05-05T23:59:59.059Z', trendvalue: 0 }]
      ]
  };
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule, HttpClientTestingModule],
      providers: [AgentListService]
    });
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get', 'post']);
    agentListService = new AgentListService(<any> httpClientSpy);
  });

  it(`should create`, async(inject([HttpTestingController, AgentListService],
    (httpClient: HttpTestingController, service: AgentListService) => {
      expect(httpClient).toBeTruthy(); expect(service).toBeTruthy();
    })));

  it('check language and channel response', () => {
    httpClientSpy.get.and.returnValue(of(channelAndLanguageList));
    agentListService.getChannels().subscribe(
      res => {
        expect(res.languages.length).toBe(2);
        expect(res.channels.length).toBe(2);
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check va agent list response', () => {
    httpClientSpy.get.and.returnValue(of(vaListData));
    agentListService.getAgentList(0, 0, 1).subscribe(
      res => {
        expect(res.virtualAgentDashboardResponseObject.virtualAgentDashboardList.length).toBe(4);
      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('check dasborddata by week response', () => {
    httpClientSpy.post.and.returnValue(of(vadashboardData));
    agentListService.getdashoboardChartbyweek({
      data: [
        {
          vrmId: 1,
          channelId: 2,
          langEngId: 1
        },
        {
          vrmId: 1,
          channelId: 2,
          langEngId: 11
        }
      ],
      graphType: 'week'
    }).subscribe(
      res => {
        expect(res['trenddata'].length).toBe(2);
      },
      fail
    );
    expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
  });

  it('check dasborddata by month response', () => {
    httpClientSpy.post.and.returnValue(of(vadashboardData));
    agentListService.getdashoboardChartbymonth({
      data: [
        {
          vrmId: 1,
          channelId: 2,
          langEngId: 1
        },
        {
          vrmId: 1,
          channelId: 2,
          langEngId: 11
        }
      ],
      graphType: 'month'
    }).subscribe(
      res => {
        expect(res['trenddata'].length).toBe(2);
      },
      fail
    );
    expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
  });

  it('check trendata by month response', () => {
    httpClientSpy.post.and.returnValue(of(vaTrendDatebymonth));
    agentListService.getVATrandDatabymonth({vrmId: 5, channelId: 2, langEngId: 1, graphType: 'month'}).subscribe(
      res => {
        expect(res['trenddata'][0][0].trendvalue).toEqual(0);
      },
      fail
    );
    expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
  });

  it('check trendata by weeek response', () => {
    httpClientSpy.post.and.returnValue(of(vaTrenDatabyweeek));
    agentListService.getVATrandDatabyweek({vrmId: 5, channelId: 2 , langEngId: 1 , graphType: 'week'}).subscribe(
      res => {
        expect(res['trenddata'][0][0].trendvalue).toEqual(0);
      },
      fail
    );
    expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
  });

  it('check method', () => {
    agentListService.getVATrandData({vrmId: 5, channelId: 2 , langEngId: 1, graphType: 'week'}, {vrmId: 5 , channelId: 2 , langEngId: 1, graphType: 'month'});
    agentListService.dashboardChart({
      data: [
        {
          vrmId: 1,
          channelId: 2,
          langEngId: 1
        },
        {
          vrmId: 1,
          channelId: 2,
          langEngId: 11
        }
      ],
      graphType: 'week'
    }, {
      data: [
        {
          vrmId: 1,
          channelId: 2,
          langEngId: 1
        },
        {
          vrmId: 1,
          channelId: 2,
          langEngId: 11
        }
      ],
      graphType: 'month'
    });
  });

});

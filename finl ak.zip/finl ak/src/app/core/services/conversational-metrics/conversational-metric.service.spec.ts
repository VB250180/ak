import { TestBed, async, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ConversationalMetricsService } from './conversational-metrics.service';
import { HttpClientModule } from '@angular/common/http';
import { of, Observable, throwError } from 'rxjs';

describe('ConversationalMetricsService', () => {
  let httpClientSpy: { get: jasmine.Spy, put: jasmine.Spy, post: jasmine.Spy, delete: jasmine.Spy };
  let ConversationalMetricsServiceStub: ConversationalMetricsService;

  const realmetricRes = { data: { averagesessionTime: '5 hrs 25 mins 30 secs', livesessioncount: 10 } };
  const topintentLive = { data: { intentcount: 3, totalintent: 3, intentaccuracy: 100, topintents: [{ value: 2, name: 'Benefit Details' }, { value: 1, name: 'Claim' }] } };
  const settingapi = { data: { updated_date: '2020-05-07T03:34:53.264Z' } };
  const operationmetricRes = { data: { averagesessionTime: '109m 13s', totalsession: 17, data: [{ name: 'Conversation transfered', value: 6 }, { name: 'Conversation Served', value: 11 }, { name: 'Handling Capacity', value: 64.70588235294117 }] } };
  const classifysesRes = { data: [{ name: '0-10sec', value: 14 }, { name: '11-20sec', value: 0 }, { name: '>20sec', value: 2 }], averageminutes: '0m 29s' };
  const top10reasoneRes = { data: { topreasons: [{ value: 12, name: 'Talk to an agent' }] } };
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule, HttpClientTestingModule],
      providers: [ConversationalMetricsService],
    });

    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get', 'put', 'post', 'delete']);
    ConversationalMetricsServiceStub = new ConversationalMetricsService(<any> httpClientSpy);
  });

  it('should be created', () => {
    const service: ConversationalMetricsService = TestBed.get(ConversationalMetricsService);
    expect(service).toBeTruthy();
  });

  it('getlivedata method calling', () => {
    httpClientSpy.get.and.returnValue(of(realmetricRes));
    ConversationalMetricsServiceStub.getliveData(1, 1, 1, 1, 1).subscribe(
      res => {
        expect(res.data.livesessioncount).toEqual(10);

      },
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('gettop10intents live method calling', () => {
    httpClientSpy.post.and.returnValue(of(topintentLive));
    ConversationalMetricsServiceStub.gettop10Intents({ startDate: '2020-05-08', endDate: '2020-05-08', channel: 0, va: 0, lang: 0, userId: 1, active: 'true' }).subscribe(
      res => {
        expect(res['data']['topintents'].length).toBe(2);

      },
      fail
    );
    expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
  });

  it('getUser method calling', () => {
    httpClientSpy.post.and.returnValue(of(settingapi));
    ConversationalMetricsServiceStub.gettop10Intents({ userId: 1 }).subscribe(
      res => {
        expect(res.data.updated_date).toEqual('2020-05-07T03:34:53.264Z');

      },
      fail
    );
    expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
  });

  it('getoperationData live method calling', () => {
    httpClientSpy.post.and.returnValue(of(operationmetricRes));
    ConversationalMetricsServiceStub.getoperationData({ startDate: '2020-05-01', endDate: '2020-05-08', channel: 0, va: 0, lang: 0, userId: 1 }).subscribe(
      res => {
        expect(res.data.data.length).toBe(3);

      },
      fail
    );
    expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
  });

  it('getclassifysessionlen live method calling', () => {
    httpClientSpy.post.and.returnValue(of(classifysesRes));
    ConversationalMetricsServiceStub.getclassifysessionlen({ startDate: '2020-05-01', endDate: '2020-05-08', channel: 0, va: 0, lang: 0, userId: 1 }).subscribe(
      res => {
        expect(res.data.length).toBe(3);

      },
      fail
    );
    expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
  });

  it('top10liveagenttransfer live method calling', () => {
    httpClientSpy.post.and.returnValue(of(top10reasoneRes));
    ConversationalMetricsServiceStub.top10liveagenttransfer({ startDate: '2020-05-01', endDate: '2020-05-08', channel: 0, va: 0, lang: 0, userId: 1 }).subscribe(
      res => {
        expect(res.data.topreasons.length).toBe(1);

      },
      fail
    );
    expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
  });

  it('check method', () => {
    ConversationalMetricsServiceStub.livemetricdata('live', 1, 1, 1, {
      startDate: new Date(),
      endDate: new Date(),
      channel: 1,
      va: 1,
      lang: 1,
      userId: 1,
      active: 'true'
    }, {
      userId: 1
    });
    ConversationalMetricsServiceStub.joindata({
      startDate: new Date(),
      endDate: new Date(),
      channel: 1,
      va: 1,
      lang: 1,
      userId: 1
    }, {
      startDate: new Date(),
      endDate: new Date(),
      channel: 1,
      va: 1,
      lang: 1,
      userId: 1,
      active: 'false'
    }, {
      userId: 1
    });
  });

});

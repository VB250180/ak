import { Injectable } from '@angular/core';
import { Observable, of, forkJoin } from 'rxjs';
import { HttpClient } from '@angular/common/http';
// import { catchError, map, tap, delay,filter,scan } from 'rxjs/operators';
import { environment as env } from '../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ConversationalMetricsService {

  constructor(private http: HttpClient) { }

  public getliveData(mode, va, channel, language, uid) {
    return this.http.get<any>(env.nodeapiUrl + '/api/realmetrics?period=' + mode + '&va=' + va + '&channel=' + channel + '&lang=' + language + '&userId=' + uid + '&view=' + 'graph');

  }

  public gettop10Intents(data) {
    return this.http.post<any>(env.nodeapiUrl + '/api/topintent?view=' + 'graph', data);

  }

  public getoperationData(data) {
    return this.http.post<any>(env.nodeapiUrl + '/api/operationalmetrics?view=' + 'graph', data);

  }


  public getclassifysessionlen(data) {
    return this.http.post<any>(env.nodeapiUrl + '/api/classifySessions?view=' + 'graph', data);

  }

  public top10liveagenttransfer(data) {
    return this.http.post<any>(env.nodeapiUrl + '/api/topreasonforcalltransfer?view=' + 'graph', data);

  }

  public getUser(data) {
    return this.http.post<any>(env.nodeapiUrl + '/api/settings', data);

  }

  public livemetricdata(mode, va, channel, language, postdata, paramUserid) {
    const graph1 = this.getliveData(mode, va, channel, language, paramUserid.userId);
    const graph2 = this.gettop10Intents(postdata);
    const graph3 = this.getUser(paramUserid);
    return forkJoin([graph1, graph2, graph3]);
  }

  public joindata(data, top10params, paramUserid) {
    const graph1 = this.getoperationData(data);
    const graph2 = this.gettop10Intents(top10params);
    const graph3 = this.getclassifysessionlen(data);
    const graph4 = this.top10liveagenttransfer(data);
    const graph5 = this.getUser(paramUserid);
    return forkJoin([graph1, graph2, graph3, graph4, graph5]);
  }

}



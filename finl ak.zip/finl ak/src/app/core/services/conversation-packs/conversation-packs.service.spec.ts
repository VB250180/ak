import { TestBed } from '@angular/core/testing';

import { ConversationPacksService } from './conversation-packs.service';
import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('ConversationPacksService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule, HttpClientTestingModule],
      providers: [ConversationPacksService],
    });
  });

  it('should be created', () => {
    const service: ConversationPacksService = TestBed.get(ConversationPacksService);
    expect(service).toBeTruthy();
  });
});

import { BehaviorSubject } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment as env } from '../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ConversationPacksService {

  initialSettingsChanged = new BehaviorSubject<any>(false);

  constructor(private http: HttpClient) { }

  getConversationPacks(data) {
    console.log('data', data);
    let params = new HttpParams();
    params = params.append('channelId', data.channels);
    params = params.append('langId', data.languages);
    params = params.append('pageNumber', data.pageNo);
    params = params.append('cpName', data.cpName);
    params = params.append('vaRoleId', data.vaRoleId);
    return this.http.get(env.apiUrl + '/conversationalPackListing', { params });
  }

  checkIntentConflict(vaRoleId, data) {
    let params = new HttpParams();
    params = params.append('vaRoleId', vaRoleId);
    return this.http.post(env.apiUrl + '/intentConflict', data, { params });
  }

  importConversationPack(vaRoleId, data) {
    let params = new HttpParams();
    params = params.append('vaRoleId', vaRoleId);
    return this.http.post(env.apiUrl + '/importConversationPack', data, { params });
  }
}

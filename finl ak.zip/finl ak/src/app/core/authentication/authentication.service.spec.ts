// import { TestBed, async, inject } from '@angular/core/testing';
// import { of, Observable, throwError, BehaviorSubject } from 'rxjs';

// import { AuthenticationService } from './authentication.service';
// import { HttpClientModule } from '@angular/common/http';
// import { HttpClientTestingModule } from '@angular/common/http/testing';
// import { RouterTestingModule } from '@angular/router/testing';
// import { Router } from '@angular/router';
// import { userInfo } from 'os';


// class BehaviorSubjectMock {
//     userDetails = {
//       username: "",
//       password: "",
//       firstName: "",
//       lastName: "",
//       jwToken: ""
//     }
//     public currentUserSubject = new BehaviorSubject(this.userDetails);
//   }

//   class MockRouter {

//     public navigate(url: string) { return url; }
//   }
//   describe('AuthenticationService', () => {
//     let httpClientSpy: { get: jasmine.Spy, put: jasmine.Spy, post: jasmine.Spy, delete: jasmine.Spy };
//     let authServiceStub : AuthenticationService;
//     let routerSpy: Router;
//     // let  currentUserSubject = new BehaviorSubject(null);

//     let loginPojo= {
//         userId: 23,
//         username: "skandha",
//         email: "bhuvan@uniphore.com",
//         phoneNumber: "9876540963",
//         jwToken: "Password Reset",
//         password: null,
//         newPassword: null,
//         confirmPassword: null,
//         roleId: 0,
//         roleName: ""
//       }
//     beforeEach(() => {
//         TestBed.configureTestingModule({
//           imports: [HttpClientModule, HttpClientTestingModule,RouterTestingModule],
//           providers: [AuthenticationService,
//                         {provide:BehaviorSubject, useClass:BehaviorSubjectMock},
//                         { provide: Router, useClass: MockRouter }],
//         });
//         httpClientSpy = jasmine.createSpyObj('HttpClient', ['get', 'put', 'post', 'delete']);
//         authServiceStub = new AuthenticationService(<any>httpClientSpy , routerSpy);
//         // authServiceStub.currentUserSubject = new BehaviorSubject(userInfo);

//       });
//   it('should be created', () => {
//     const service: AuthenticationService = TestBed.get(AuthenticationService);
//     expect(service).toBeTruthy();
//   });

//   // it('should call method setSimulatorBaseUrl', () => {
//   //   authServiceStub.simulatorBaseUrl = 'url';
//   //   authServiceStub.setSimulatorBaseUrl('url');
//   //   // expect(authServiceStub.setSimulatorBaseUrl('url')).toEqual(authServiceStub.simulatorBaseUrl);
//   // });

//   // it('should call method simulator url', () => {
//   //   authServiceStub.simulatorBaseUrl = 'url';
//   //   expect(authServiceStub.getSimulatorBaseUrl()).toEqual(authServiceStub.simulatorBaseUrl);
//   // });

//   // it('call login method', () => {
//   //   httpClientSpy.post.and.returnValue(of(loginPojo));
//   //   authServiceStub.login('skandha','skandhapass').subscribe(
//   //     res => {
//   //       expect(res['jwToken']).toEqual('Password Reset');
//   //     },
//   //     fail
//   //   );
//   //   expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
//   // });

//   // it('call resetpassword method', () => {
//   //   httpClientSpy.put.and.returnValue(of(loginPojo));
//   //   authServiceStub.resetPassword({oldpass:"oldpass",newpass:"newpass"},1,'skandha').subscribe(
//   //     res => {
//   //       expect(res['jwToken']).toEqual('Password Reset');
//   //     },
//   //     fail
//   //   );
//   //   expect(httpClientSpy.put.calls.count()).toBe(1, 'one call');
//   // });

//   // it('call forgotpassword method', () => {
//   //   httpClientSpy.put.and.returnValue(of(loginPojo));
//   //   authServiceStub.forgotPassword('skandha').subscribe(
//   //     res => {
//   //       expect(res['jwToken']).toEqual('Password Reset');
//   //     },
//   //     fail
//   //   );
//   //   expect(httpClientSpy.put.calls.count()).toBe(1, 'one call');
//   // });

//   // it('call forgotpasswordvalidation method', () => {
//   //   httpClientSpy.put.and.returnValue(of(loginPojo));
//   //   authServiceStub.forgotPasswordLinkValidateToken('skandha').subscribe(
//   //     res => {
//   //       expect(res['roleId']).toEqual(0);
//   //     },
//   //     fail
//   //   );
//   //   expect(httpClientSpy.put.calls.count()).toBe(1, 'one call');
//   // });

//   // it('call logout method', () => {
//   //   httpClientSpy.post.and.returnValue(of(loginPojo));
//   //   authServiceStub.logout();
//   //   expect(httpClientSpy.post).toHaveBeenCalled();
//   // });

// //   it('call logoutlocal/clear storage method', () => {
// //     currentUserSubject = new BehaviorSubject(true);
// //     const router = TestBed.get(Router);
// //     const spy = spyOn(router, 'navigate');
// //     authServiceStub.logoutLocally();
// //     expect(spy).toHaveBeenCalledWith(['/login']);
// //   });
//   // it('call loginDiffBrowser method', () => {
//   //   httpClientSpy.post.and.returnValue(of(loginPojo));
//   //   authServiceStub.loginDiffBrowser({username:'skandha', password:'skandhapass'}).subscribe(
//   //     res => {
//   //       expect(res['roleId']).toEqual(0);
//   //     },
//   //     fail
//   //   );
//   //   expect(httpClientSpy.post.calls.count()).toBe(1, 'one call');
//   // });
// //   it('should call method simulator url', () => {
// //     expect(authService.getSimulatorBaseUrl()).toEqual('url');
// //   });
// });

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { environment } from '../../../environments/environment';
import { User } from '../../core/models/user/user.model';
import { Router } from '@angular/router';


@Injectable({ providedIn: 'root' })
export class AuthenticationService {
    value: any;
    username: any;
    userid: any;
    public currentUserSubject: BehaviorSubject<User>;
    public currentUser: Observable<User>;
    public simulatorBaseUrl: string;

    constructor(private http: HttpClient, private router: Router) {
        // if (localStorage.getItem('currentUser') !== undefined && localStorage.getItem('currentUser') !== "undefined" && localStorage.getItem('currentUser') !== null) {
        this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
        this.currentUser = this.currentUserSubject.asObservable();
        // }

        // if (((getCurrentUserId() && getCurrentUserName()) != null) && ((getCurrentUserId() && getCurrentUserName()) != undefined)) {
        //     this.username = getCurrentUserName();
        //     this.userid = getCurrentUserId();
        // }
    }

    public setSimulatorBaseUrl(url) {
        this.simulatorBaseUrl = url;
    }

    public getSimulatorBaseUrl() {
        return this.simulatorBaseUrl;
    }

    public get currentUserValue(): User {
        // if (localStorage.getItem('currentUser') !== undefined && localStorage.getItem('currentUser') !== "undefined" && localStorage.getItem('currentUser') !== null) {
        return this.currentUserSubject.value;
        // }
    }


    login(username: string, password: string) {
        const body = {
            confirmPassword: 'string',
            email: 'string',
            jwToken: 'string',
            newPassword: 'string',
            password,
            phoneNumber: 'string',
            roleId: 0,
            roleName: '',
            userId: 0,
            username
        };

        return this.http.post<any>(environment.apiUrl + '/login', body);
    }

    resetPassword(form, userId, userName) {

        console.log(form, userId, userName);
        const newpassword = form.newpass;
        let oldpassword = form.oldpass;

        oldpassword = (form.oldpass) ? form.oldpass : '';

        const body = {
            confirmPassword: form.confirmpass,
            email: 'string',
            jwToken: 'string',
            newPassword: newpassword,
            password: oldpassword,
            phoneNumber: 'string',
            roleId: 0,
            roleName: '',
            userId,
            username: userName
        };
        return this.http.put<any>(environment.apiUrl + '/reset-password', body);
    }

    forgotPassword(username) {
        console.log(username);
        const body = {
            confirmPassword: '',
            email: '',
            jwToken: '',
            newPassword: '',
            password: '',
            phoneNumber: '',
            roleId: 0,
            roleName: '',
            userId: '',
            username
        };
        return this.http.put(environment.apiUrl + '/forgot-password', body);
    }

    forgotPasswordLinkValidateToken(token) {
        console.log('tokennnn', token);
        const body = {
            confirmPassword: 'string',
            email: 'string',
            jwToken: token,
            newPassword: 'string',
            password: 'string',
            phoneNumber: 'string',
            roleId: 0,
            roleName: 'string',
            userId: 0,
            username: 'string'
        };

        console.log(body);
        return this.http.put(environment.apiUrl + '/forgot-password-link', body);
    }

    logout() {
        const body = {
            confirmPassword: '',
            email: '',
            jwToken: '',
            newPassword: '',
            password: '',
            phoneNumber: '',
            roleId: 0,
            roleName: '',
            userId: this.getCurrentUserId(),
            username: ''
        };

        this.http.post(environment.apiUrl + '/log-out', body).subscribe(res => {
            console.log('res', res);
            this.logoutLocally();
        });
    }

    logoutLocally() {
        localStorage.removeItem('currentUser');
        this.currentUserSubject.next(null);
        this.router.navigate(['/login']);
    }

    loginDiffBrowser(formvalues) {
        console.log('new api login to diff browser', formvalues.username);
        const body = {
            confirmPassword: 'string',
            email: 'string',
            jwToken: 'string',
            newPassword: 'string',
            password: formvalues.password,
            phoneNumber: 'string',
            roleId: 0,
            roleName: '',
            userId: 0,
            username: formvalues.username
        };

        return this.http.post<any>(environment.apiUrl + '/user-loggedin', body);
    }

    getCurrentUserId() {
        // try { return Number(JSON.parse(getFromLocalStorage('currentUser')).userId);}
        // catch (error) {console.error('Error ',error); console.info('Error -- No Login user ');return null; }
        if (localStorage.getItem('currentUser') !== 'undefined' && localStorage.getItem('currentUser') !== undefined) {
            const user = JSON.parse(localStorage.getItem('currentUser'));
            if (user !== null) {
                return Number(user.userId);
            } else {
                // console.info('Error -- No Login user ');
                return null;
            }
        } else { return null; }
    }

    getCurrentUserName() {
        if (localStorage.getItem('currentUser') !== 'undefined' && localStorage.getItem('currentUser') !== undefined) {
            return JSON.parse(localStorage.getItem('currentUser')).username;
        }
    }
}


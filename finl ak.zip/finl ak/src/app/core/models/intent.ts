export class SystemSlotKey {
    systemSlotKeyId: number;
    systemSlotKeyName: string;
    constructor() {
        this.systemSlotKeyId = null;
        this.systemSlotKeyName = '';
    }
}

// export class SystemSlot {
//     systemSlotId: number;
//     systemSlotKey: SystemSlotKey;
//     constructor(){
//     this.systemSlotId= null;
//     this.systemSlotKey=new  SystemSlotKey();
//     }
// }

export class SendMessage {
    messageId: number;
    messageText: string;
    positionAndSlots: PositionAndSlot2[];
    audioFileId: any;
    audioFileSize: any;
    constructor() {
        this.messageId = null;
        this.messageText = '';
        this.positionAndSlots = new Array<PositionAndSlot2>();
        this.audioFileId = null;
        this.audioFileSize = null;
    }
}

export class Entity {
    entityId: number;
    entityName: string;
}

export class IntentSlot {
    intenSlotId: number;
    intentSlotName: string;
    intentSlotDescription: string;
    entity: Entity;
    constructor() {
        this.intenSlotId = null;
        this.intentSlotName = null;
        this.intentSlotDescription = null;
        this.entity = new Entity();
    }
}
export class IntentSlotRichCardTemplate {
    manipulateHtml: string;
    renderHtml: string;
    templateId: number;
    templateName: string;
}
export class IntentSlotRcPojo {
    html: string;
    id: number;
    intentSlotRichCardTemplate: IntentSlotRichCardTemplate;
    slotMap: any;
    dataMap: any;
    richCardInfo: any;
    renderHtml: any;
    constructor() {
        this.html = '';
        this.id = null;
        this.intentSlotRichCardTemplate = new IntentSlotRichCardTemplate();
        this.slotMap = {};
        this.dataMap = new Map<string, any>();
        this.richCardInfo = '';
        this.renderHtml = '';
    }
}

export class IntenRichCardResponse {
    html: string;
    id: number;
    intentSlotRichCardTemplatePojo: IntentSlotRichCardTemplate;
    slotMap: any;
    dataMap: any;
    richCardInfo: any;
    renderHtml: any;
    constructor() {
        this.html = '';
        this.id = null;
        this.intentSlotRichCardTemplatePojo = new IntentSlotRichCardTemplate();
        this.slotMap = {};
        this.dataMap = new Map<string, any>();
        this.richCardInfo = '';
        this.renderHtml = '';
    }
}
export class SystemSlot2 {
    // storeValue: boolean;
    // systemSlotKeyDataType: string;
    // systemSlotKeyId: number;
    systemSlotKeyName: string;
}
export class PositionAndSlot2 {
    // ispsmId: number;
    position: string;
    systemSlot: SystemSlot2;
    // value: string;
}

export class GetInfo {
    getInfoId: any;
    intentSlotRcPojo: IntentSlotRcPojo;
    positionAndSlots: PositionAndSlot2[];
    promptQuestion: string;
    promptValidationMessage: string;
    intentSlot: IntentSlot;
    promptQuestionAudioId: any;
    promptQuestionAudioFileSize: any;
    promptQuestionValidationMessageAudioId: any;
    promptQuestionValidationMessageAudioSize: any;
    constructor() {
        this.getInfoId = '';
        this.intentSlotRcPojo = new IntentSlotRcPojo();
        this.positionAndSlots = new Array<PositionAndSlot2>();
        this.promptQuestion = '';
        this.promptValidationMessage = '';
        this.intentSlot = new IntentSlot();
        this.promptQuestionAudioId = null;
        this.promptQuestionAudioFileSize = null;
        this.promptQuestionValidationMessageAudioId = null;
        this.promptQuestionValidationMessageAudioSize = null;
    }
}

export class RichCardData {
    richCardInfo: any;
    dataMap: any;
    renderHtml: any;
    sendHtml: any;
    sendHtmlMap: any;
    constructor() {
        this.dataMap = new Map<string, any>();
        this.richCardInfo = '';
        this.renderHtml = '';
        this.sendHtml = '';
        this.sendHtmlMap = {};
    }
}

export class ResponseSlot {
    responseSlotId: number;
    responseSlotName: string;
    responseSlotDescription: string;
    constructor() {
        this.responseSlotId = null;
        this.responseSlotName = null;
        this.responseSlotDescription = null;
    }
}

export class SystemSlot {
    storeValue: boolean;
    systemSlotKeyDataType: string;
    systemSlotKeyId: number;
    systemSlotKeyName: string;
}
export class PositionAndSlot {
    finalResponseSlotId: number;
    position: string;
    intentSlot?: any;
    responseSlot: ResponseSlot;
    systemSlot: SystemSlot;
    constructor() {
        this.finalResponseSlotId = null;
        this.position = '';
        this.intentSlot = '';
        this.responseSlot = new ResponseSlot();
        this.systemSlot = new SystemSlot();

    }
}

export class FinalResponse {
    finalResponseId: number;
    finalResponseText: string;
    finalResponseTextTemp: string;
    positionAndSlots: any;
    intenRichCardResponse: IntenRichCardResponse;
    finalResponseTextAudioId: any;
    finalResponseTextAudioSize: any;
    constructor() {
        this.finalResponseId = null;
        this.finalResponseText = null;
        this.finalResponseTextTemp = '';
        this.positionAndSlots = {};
        // this.positionAndSlots=new Array<PositionAndSlot>(any);
        this.intenRichCardResponse = new IntenRichCardResponse();
        this.finalResponseTextAudioId = null;
        this.finalResponseTextAudioId = null;
    }
}
// export class ResponseSlot {
//     responseSlotId: number;
//     responseSlotName: string;
//     responseSlotDescription: string;
// }
export class ConversationStage {
    sequenceNumber?: number;
    conversationStageId?: number;
    sendMessage?: SendMessage;
    getInfo?: GetInfo;
    finalResponse?: FinalResponse;
    constructor() {
        this.sequenceNumber = null;
        this.conversationStageId = null;
        this.sendMessage = null;
        this.getInfo = new GetInfo();
        this.finalResponse = null;
    }
}

export class Conversation {
    validationIntent?: any;
    systemSlots: SystemSlot[];
    conversationStages: ConversationStage[];
    responseSlots: ResponseSlot[];
    cancelledIds: any;
    constructor() {
        this.validationIntent = {
            intentName: ''
        };
        this.systemSlots = new Array<SystemSlot>();
        this.conversationStages = new Array<ConversationStage>();
        this.responseSlots = new Array<ResponseSlot>();
        this.cancelledIds = [];
    }
}



export class IntentsDropD {
    intentId: number;
    intentName: any;
    intentDescription: any;
}
export class SystemSlotDropD {
    systemSlotKeyId: number;
    systemSlotKeyName: any;
}

export class IntentSelection {
    id: number;
    value: string;
}

export class VaDetails {
    vaName: string;
    vaIsLive: boolean;
}

export class ParentMessageLanChanVaPojo {
    lang: any;
    langNam: any;
    chann: any;
    chanNam: any;
    vaDetails: VaDetails;
}

export class EntitySynonymsValueList {
    entitySynonymsValue: string;
    constructor() {
        // this.entitySynonymsValue;
    }
}

export class LanguageMasterPojo {
    langId: number;
    constructor() {
        this.langId = null;
    }
}

export class EntityRefernceValuePojoList {
    entityReferenceValue: string;
    entitySynonymsValueList: EntitySynonymsValueList[];
    languageMasterPojo: LanguageMasterPojo;
    constructor() {
        this.entityReferenceValue = null;
        this.entitySynonymsValueList = new Array<EntitySynonymsValueList>();
        this.languageMasterPojo = new LanguageMasterPojo();
    }
}

export class EntityObj {
    entityDescription: string;
    entityName: string;
    entityRefernceValuePojoList: EntityRefernceValuePojoList[];
    constructor() {
        this.entityDescription = null;
        this.entityName = null;
        this.entityRefernceValuePojoList = new Array<EntityRefernceValuePojoList>();
}
}


export class Language {
    langEngId: number;
    langName: string;
}
export class VaDropDown {
    vaId: number;
    vaName: string;
    vaIsLive: string;
}

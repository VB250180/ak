export interface Language {
langEngId: number;
langName: string;
channels?: any;
}

export interface VirtualAgentPojo {
vaId: number;
vaName: string;
vaIsLive?: any;
vaAvatarName?: any;
vaDescription?: any;
businessUnit?: any;
languages: Language[];
channels?: any;
businessUnitData?: any;
userName?: any;
}

export interface EntityResponseObjectList {
entityId: number;
entityName: string;
entityDescription: string;
entityRefernceValuePojoList?: any;
virtualAgentPojo: VirtualAgentPojo;
}

export interface SelectionRectangle {
    left: number;
    top: number;
    width: number;
    height: number;
}

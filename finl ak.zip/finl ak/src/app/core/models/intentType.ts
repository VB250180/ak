enum IntentTypeId {
    GENERAL = 'GENERAL',
    VALIDATION = 'VALIDATION',
    AGENT_TRANSFER = 'AGENT_TRANSFER'
}

export interface IntentType {
    id: IntentTypeId;
    value: IntentTypeId;
}

export const intentTypeList: IntentType[] = [
    { id: IntentTypeId.GENERAL, value: IntentTypeId.GENERAL },
    { id: IntentTypeId.VALIDATION, value: IntentTypeId.VALIDATION },
    { id: IntentTypeId.AGENT_TRANSFER, value: IntentTypeId.AGENT_TRANSFER }
];

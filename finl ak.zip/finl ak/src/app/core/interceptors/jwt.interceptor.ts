import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpHeaders } from '@angular/common/http';
import { Observable, EMPTY } from 'rxjs';

import { environment } from '../../../environments/environment';
import { AuthenticationService } from '../authentication/authentication.service';
import { Router } from '@angular/router';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';
import { CreateIntentService } from 'src/app/core/services/create-intent/create-intent.service';

export const InterceptorSkipHeader = 'X-Skip-Interceptor';

@Injectable()
export class JwtInterceptor implements HttpInterceptor {
  constructor(private authenticationService: AuthenticationService, private router: Router, private matDialog: MatDialog) { }
  authReq: any;
  //   formData = new FormData();

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // add auth header with jwt if user is logged in and request is to api url
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    const isLoggedIn = currentUser && currentUser.jwToken;
    const isApiUrl = request.url.startsWith(environment.apiUrl);
    const nodeApiUrl = request.url.startsWith(environment.nodeapiUrl);
    const isSimulatorUrl = request.url.startsWith(this.authenticationService.getSimulatorBaseUrl());
    console.log('router url', this.router.url);
    if (isLoggedIn && isApiUrl) {
      if (currentUser.jwToken !== 'Password Reset' && !request.headers.has(InterceptorSkipHeader)) {
        request = request.clone({
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Cache-Control': 'no-cache,no-store',
            Pragma: 'no-cache',
            Authorization: `Bearer ${currentUser.jwToken}`
          })
        });
        // console.log("req", request);
      }

      // console.log('api url header passeeeeeeeeee', request, this.authReq);
      return next.handle(request);
    } else if (isLoggedIn && isSimulatorUrl) {
      // console.log('Simulator URL -- no header is set in interceptor', request, this.authReq);
      return next.handle(request);
    } else if (this.router.url.startsWith('/login')) {
      // console.log('api url header passe', request, this.authReq);
      return next.handle(request);
    } else if (this.router.url.startsWith('/password/forgot')) {
      // console.log('api url header passe', 'forgotpass url);
      return next.handle(request);
    } else if (isLoggedIn && nodeApiUrl) {
      request = request.clone({
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          // 'Cache-Control': 'no-cache,no-store',
          // 'Pragma': 'no-cache',
          Authorization: 'Bearer ' + environment.nodeapiToken
        })
      });
      // console.log('api url header passe', request, this.authReq);
      return next.handle(request);
    } else {
      const dialogConfigReset = new MatDialogConfig();
      dialogConfigReset.disableClose = true;
      dialogConfigReset.width = '800px';
      dialogConfigReset.data = {
        primaryText: 'Your earlier session timed out. Please login again to continue. ',
        hasPrimaryBtn: true,
        primaryBtnText: 'Ok',
        popUpType: 'warn',
        hasCancelBtn: true
      };

      const modalDialog = this.matDialog.open(ModalComponent, dialogConfigReset);
      modalDialog.afterClosed().subscribe(data => {
        // console.log('data',data);
        this.router.navigate(['/login']);
      });
    }
    return EMPTY;
  }
}

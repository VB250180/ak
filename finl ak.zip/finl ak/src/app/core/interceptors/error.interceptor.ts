import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { AuthenticationService } from '../authentication/authentication.service';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
  constructor(private authenticationService: AuthenticationService, private matDialog: MatDialog) { }

  countunauthorized = 0;
  countothererr = 0;

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // console.log('request',request);
    return next.handle(request).pipe(catchError(err => {
      if ([401, 403].indexOf(err.status) !== -1) {

        this.countunauthorized = this.countunauthorized + 1;
        console.log(this.countunauthorized);

        // auto logout if 401 Unauthorized or 403 Forbidden response returned from api
        const dialogConfigReset = new MatDialogConfig();
        dialogConfigReset.disableClose = true;
        dialogConfigReset.width = '800px';
        dialogConfigReset.data = {
          primaryText: 'You have been logged out of akeira. Request you to login again.',
          hasPrimaryBtn: true,
          primaryBtnText: 'Ok',
          popUpType: 'warn',
          hasCancelBtn: true
        };

        if (this.countunauthorized === 1) {
          const modalDialog = this.matDialog.open(ModalComponent, dialogConfigReset);
          modalDialog.afterClosed().subscribe(data => {
            this.countunauthorized = 0;
            // console.log(data);
          });
          this.authenticationService.logoutLocally();
        }
        // location.reload(true);
      } else {
        this.countothererr = this.countothererr + 1;

        const dialogConfigReset = new MatDialogConfig();
        dialogConfigReset.disableClose = true;
        dialogConfigReset.width = '800px';
        dialogConfigReset.data = {
          warnText: 'Apologies. We are facing difficulties in accessing your akeira account at the moment. Please contact Uniphore Customer Support for further action.',
          hasWarnBtn: true,
          warnBtnText: 'Ok',
          popUpType: 'singlewarn',
        };

        if (this.countothererr === 1) {
        const modalDialog = this.matDialog.open(ModalComponent, dialogConfigReset);
        modalDialog.afterClosed().subscribe(data => {
          this.countothererr = 0;
          console.log(data);
        });
      }
    }

      const error = err.message || err.statusText;
      return throwError(error);
    }));
  }
}

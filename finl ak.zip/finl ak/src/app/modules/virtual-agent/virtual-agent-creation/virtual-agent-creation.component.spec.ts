import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VirtualAgentCreationComponent } from './virtual-agent-creation.component';
import { VirtualAgentService } from '../../../core/services/virtual-agent/virtual-agent.service';

import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MatDialogModule, MatDialog, MatDialogConfig } from '@angular/material';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { Observable, BehaviorSubject, of } from 'rxjs';
import { Router } from '@angular/router';
import { NgxSpinnerModule } from 'ngx-spinner';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';

class MatDialogStub {
  public open(template, data) {
    // this.afterClosed(true);
    return {
      afterClosed: () => {
        return Observable.of(true);
      }
    };
  }
}

// class ActivatedRouteStub {
//   paramsObj = {
//     params: {
//       flag: 1,
//       vaId: 1,
//     },

//     get: (property) => {
//       console.log('coming in get', this.paramsObj[property]);
//       return this.paramsObj[property];
//     }
//   }
//   public paramMap = new BehaviorSubject(this.paramsObj);
// }

class VirtualServiceStub {
  constructor() { }

  public getVirtualAgent(vaId: 1): Observable<any> {
    return of({
      virtualAgent: [
        {
          vaId: 3,
          vaName: 'Policy Issuance',
          vaIsLive: true,
          isNluConfigured: false,
          vaAvatarName: 'Akeira2.0 av',
          vaDescription: 'Policy issuance',
          businessUnit: null,
          languages: null,
          channels: null,
          businessUnitData: null,
          userName: 'VAadmin'
        }]
    });

  }

  public sendVaSaveResponse(id: 1, userId: 16, respoonse: any): Observable<any> {
    return of({
      virtualAgent: [{
        vaId: 0,
        vaIsLive: true,
        businessUnit: 'Member Services',
        vaAvatarName: 'Akeira2.0',
        vaDescription: 'Policy issuance',
        vaName: 'Policy Issuance',
        channels: [{ id: 1, Name: 'Web' }],
        languages: [{ id: 1, Name: 'English' }]
      }]
    });
  }

  public updateVaResponse(id: 1, response: any, userid: 16): Observable<any> {
    return of({
      virtualAgent: {
        vaId: 1,
        vaIsLive: true,
        businessUnit: 'Member Services',
        vaAvatarName: 'Akeira2.0',
        vaDescription: 'Policy issuance',
        vaName: 'Policy Issuance',
        channels: [{ id: 1, Name: 'Web' }],
        languages: [{ id: 1, Name: 'English' }]
      },
    });
  }

  public orgData(): Observable<any> {
    return of({
      organizationData: [{ orgId: 1, organizationName: 'Uniphore' }]
    });
  }

  public busUnitData(): Observable<any> {
    return of({
      categoryData: [{ catId: 16, categoryName: 'Outbound', nluEngine: { engineId: 1, engineName: 'DIALOG_FLOW' }, organization: null }]
    });
  }

  public langData(): Observable<any> {
    return of({
      languageEngineMaps: [{ langEngId: 1, langName: 'English', channels: null }]
    });
  }

  public chnData(): Observable<any> {
    return of({
      channels: [{ channelId: 2, channelName: 'IVR' }]
    });
  }

}

class AuthenticationServiceStub {
  getCurrentUserId() {
      return 1;
  }
}


describe('VirtualAgentCreationComponent', () => {
  let component: VirtualAgentCreationComponent;
  let fixture: ComponentFixture<VirtualAgentCreationComponent>;


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [VirtualAgentCreationComponent],
      imports: [FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
        RouterTestingModule,
        MatDialogModule,
        NgMultiSelectDropDownModule,
        NgxSpinnerModule,
      ],
      providers: [
        { provide: VirtualAgentService, useClass: VirtualServiceStub },
        { provide: MatDialogConfig, useClass: MatDialogStub },
        { provide: AuthenticationService, useClass: AuthenticationServiceStub },
        { provide: MatDialog, useClass: MatDialogStub }],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VirtualAgentCreationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check on initialization on oninit method', () => {
    component.flag = 1;
    component.createAgentForm.patchValue({
      avatarName: '',
      agentName: '',
      agentDescription: '',
      agentBusinessUnit: '',
      agentOrganization: '',
      agentLanguages: [{ id: 1, lang: 'Eng' }],
      agentChannels: [{ id: 1, chn: 'Ivr' }]
    });
    // const langspy = spyOn(component, 'getLangs');
    // const chnspy = spyOn(component, 'getChnls');

    component.ngOnInit();

    expect(component.Organizations).toEqual([{ orgId: 1, organizationName: 'Uniphore' }]);
    // expect(langspy).toHaveBeenCalled();
    // expect(chnspy).toHaveBeenCalled();
    // expect(component.BusinessUnits).toEqual([{ catId: 1, categoryName: 'Claims' }]);
  });

  it('cancel should redirect to va-listing screen', () => {
    const router = fixture.debugElement.injector.get(Router);
    const routerSpy = spyOn(router, 'navigateByUrl');
    component.onCancel();
    expect(routerSpy).toHaveBeenCalled();

  });

  it('get organization dropdown values', () => {
    component.getOrgs();
    expect(component.Organizations).toEqual([{ orgId: 1, organizationName: 'Uniphore' }]);
  });

  it('get business dropdown values', () => {
    component.createAgentForm.patchValue({
      agentBusinessUnit: '',
      agentLanguages: [],
      agentChannels: []
    });
    const orgId = 1;
    component.orgChange(orgId);
    expect(component.BusinessUnits).toEqual([{ catId: 16, categoryName: 'Outbound', nluEngine: { engineId: 1, engineName: 'DIALOG_FLOW' }, organization: null }]);
  });

  it('get business language values', () => {
    component.createAgentForm.patchValue({
      agentLanguages: [],
      agentChannels: []
    });
    const catId = 1;
    component.businessUnitChange(catId);
    expect(component.languages.length).toEqual(1);
  });

  it('get list of channels on selection of language/s', () => {
    component.onLanguageSelect({ langEngId: 4, langName: 'English-Indian' });
    expect(component.createAgentForm.controls['agentChannels'].value).toEqual([]);
    // expect(component.createAgentForm.value.agentChannels).toBe([]);
  });

  it('get list of channels on selection of language/s', () => {
    component.onLanguageSelect({ langEngId: 4, langName: 'English-Indian' });
    expect(component.createAgentForm.controls['agentChannels'].value).toEqual([]);
    // expect(component.createAgentForm.value.agentChannels).toBe([]);
  });

  it('on uncheck of languages that are selected', () => {
    const agentDetails = [{
      businessUnit: null,
      businessUnitData: { catId: 2, categoryName: 'Claims', nluEngine: null, organization: {} },
      channels: [],
      isNluConfigured: null,
      languages: [],
      rasaIp: null,
      userName: null,
      vaAvatarName: 'msg name',
      vaDescription: 'desc',
      vaId: 85,
      vaIsLive: null,
      vaName: 'checkmsg'
    }];
    const spyDeselect = spyOn(component, 'deselectPopUp');
    component.onLanguageDeSelect({ langEngId: 4, langName: 'English-Indian' });

    agentDetails.forEach((test, index) => {
      expect(agentDetails[index].vaId).toEqual(85);
    });
    expect(component.createAgentForm.controls['agentChannels'].value).toEqual('');
    expect(component.createAgentForm.controls['agentLanguages'].value).toEqual('');

    expect(spyDeselect).toHaveBeenCalledTimes(0);
  });

  it('select of channels', () => {
    const chnSelected = { channelId: 2, channelName: 'IVR' };
    component.channelsList = [];
    component.onChannelSelect(chnSelected);
    expect(component.channelsList).toEqual([{ channelId: 2, channelName: 'IVR' }]);
  });

  it('should call method cancel', () => {
    const router = TestBed.get(Router);
    const spy = spyOn(router, 'navigate');

    component.onCancel();
    expect(spy).toHaveBeenCalledWith(['/va/va-listing']);
  });

  it('deselectPopUp should call method openModalPopUpDeselect and set agentLanguages and agentChannels form control', () => {
    const openModalPopUpDeselectSpy = spyOn(component, 'openModalPopUpDeselect');
    const value = 'lang';
    component.agentDetails = {
      languages: [{ langId: 1 }, { langId: 2 }],
      channels: [{ chnId: 1 }, { chnId: 2 }]
    };

    component.deselectPopUp(value);

    expect(openModalPopUpDeselectSpy).toHaveBeenCalledWith(value);
    expect(component.createAgentForm.controls['agentLanguages'].value).toEqual(component.agentDetails.languages);
    expect(component.createAgentForm.controls['agentChannels'].value).toEqual(component.agentDetails.channels);
  });

  it('deselectPopUp should call method openModalPopUpDeselect and set agentChannels form control', () => {
    const openModalPopUpDeselectSpy = spyOn(component, 'openModalPopUpDeselect');
    const value = 'chnl';
    component.agentDetails = {
      languages: [{ langId: 1 }, { langId: 2 }],
      channels: [{ chnId: 1 }, { chnId: 2 }]
    };

    component.deselectPopUp(value);

    expect(openModalPopUpDeselectSpy).toHaveBeenCalledWith(value);
    expect(component.createAgentForm.controls['agentLanguages'].value).toEqual('');
    expect(component.createAgentForm.controls['agentChannels'].value).toEqual(component.agentDetails.channels);
  });

  it('deselectPopUp should set agentChannels form control from agentDetails', () => {
    const item = 'chnl';
    component.agentDetails = {
      languages: [{ langId: 1 }, { langId: 2 }],
      channels: [{ chnId: 1 }, { chnId: 2 }]
    };
    component.flag = 1;

    component.onLanguageSelect(item);

    expect(component.createAgentForm.controls['agentLanguages'].value).toEqual('');
    expect(component.createAgentForm.controls['agentChannels'].value).toEqual(component.agentDetails.channels);
  });

  it('onLanguageSelect should set agentChannels form control to []', () => {
    const item = 'chnl';
    component.agentDetails = {
      languages: [{ langId: 1 }, { langId: 2 }],
      channels: [{ chnId: 1 }, { chnId: 2 }]
    };
    component.flag = 0;

    component.onLanguageSelect(item);

    expect(component.createAgentForm.controls['agentLanguages'].value).toEqual('');
    expect(component.createAgentForm.controls['agentChannels'].value).toEqual([]);
  });

  it('onLanguageDeSelect should call deselectPopUp once', () => {
    const deselectPopUpSpy = spyOn(component, 'deselectPopUp');
    const item = {
      langName: 'English'
    };
    component.agentDetails = {
      languages: [{ langId: 1, langName: 'English' }, { langId: 2, langName: 'Spanish' }],
      channels: [{ chnId: 1 }, { chnId: 2 }]
    };
    component.flag = 1;

    component.onLanguageDeSelect(item);

    expect(deselectPopUpSpy).toHaveBeenCalledTimes(1);
  });

  it('onLanguageDeSelect should not call deselectPopUp', () => {
    const deselectPopUpSpy = spyOn(component, 'deselectPopUp');
    const item = {
      langName: 'English'
    };
    component.agentDetails = {
      languages: [{ langId: 1, langName: 'English' }, { langId: 2, langName: 'Spanish' }],
      channels: [{ chnId: 1 }, { chnId: 2 }]
    };
    component.flag = 0;

    component.onLanguageDeSelect(item);

    expect(deselectPopUpSpy).toHaveBeenCalledTimes(0);
  });

  it('onDeselectAllLanguages should not call deselectPopUp', () => {
    const deselectPopUpSpy = spyOn(component, 'deselectPopUp');
    component.flag = 0;

    component.onDeselectAllLanguages();

    expect(deselectPopUpSpy).toHaveBeenCalledTimes(0);
  });

  it('onDeselectAllLanguages should call deselectPopUp', () => {
    const deselectPopUpSpy = spyOn(component, 'deselectPopUp');
    component.flag = 1;

    component.onDeselectAllLanguages();

    expect(deselectPopUpSpy).toHaveBeenCalledTimes(1);
  });

  it('onDeSelectChannels should call deselectPopUp once', () => {
    const deselectPopUpSpy = spyOn(component, 'deselectPopUp');
    const item = {
      channelName: 'IVR'
    };
    component.agentDetails = {
      languages: [{ langId: 1, langName: 'English' }, { langId: 2, langName: 'Spanish' }],
      channels: [{ chnId: 1, channelName: 'IVR' }, { chnId: 2, channelName: 'WEB' }]
    };
    component.flag = 1;

    component.onDeSelectChannels(item);

    expect(deselectPopUpSpy).toHaveBeenCalledTimes(1);
  });

  it('onDeSelectChannels should not call deselectPopUp', () => {
    const deselectPopUpSpy = spyOn(component, 'deselectPopUp');
    const item = {
      channelName: 'IVR'
    };
    component.agentDetails = {
      languages: [{ langId: 1, langName: 'English' }, { langId: 2, langName: 'Spanish' }],
      channels: [{ chnId: 1, channelName: 'IVR' }, { chnId: 2, channelName: 'WEB' }]
    };
    component.flag = 0;

    component.onDeSelectChannels(item);

    expect(deselectPopUpSpy).toHaveBeenCalledTimes(0);
  });

  it('onDeSelectAllChannels should not call deselectPopUp', () => {
    const deselectPopUpSpy = spyOn(component, 'deselectPopUp');
    component.flag = 0;

    component.onDeSelectAllChannels();

    expect(deselectPopUpSpy).toHaveBeenCalledTimes(0);
  });

  it('onDeSelectAllChannels should call deselectPopUp', () => {
    const deselectPopUpSpy = spyOn(component, 'deselectPopUp');
    component.flag = 1;

    component.onDeSelectAllChannels();

    expect(deselectPopUpSpy).toHaveBeenCalledTimes(1);
  });
});

import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { VirtualAgentService } from '../../../core/services/virtual-agent/virtual-agent.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';
import { Subscription } from 'rxjs';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';

@Component({
  selector: 'app-virtual-agent-creation',
  templateUrl: './virtual-agent-creation.component.html',
  styleUrls: ['./virtual-agent-creation.component.scss']
})
export class VirtualAgentCreationComponent implements OnInit, OnDestroy {
  createAgentForm: FormGroup;
  dropdownList = [];
  languages = [];
  channels = [];
  channelsList = [];
  languageList = [];
  deselectedValues = [];
  selectedItems = [];
  dropdownSettings: IDropdownSettings = {};

  public loadContent = false;
  public data = [];
  public settings = {};
  public chnsettings = {};

  saveResponse = [];

  Organizations = [];
  BusinessUnits = [];
  bunit: any;
  orgs: any;
  flag: any;
  vaId: any;
  userId: any;
  agentorg: any;
  agentOrgId: any;
  agentCatId: any;
  agentCatName: any;
  agentDetails: any;
  hidedropdown: boolean;
  isAlphCheckAgentValue: boolean;
  isAlphCheckAvatarValue: boolean;
  NLUEngine: any;
  getVirtualAgentSubscribe: Subscription;
  sendVaSaveResponseSubscribe: Subscription;
  orgDataSubscribe: Subscription;
  chnDataSubscribe: Subscription;
  langDataSubscribe: Subscription;
  busUnitDataSubscribe: Subscription;
  updateVaResponseSubscribe: Subscription;

  constructor(
    private fb: FormBuilder,
    private vaService: VirtualAgentService,
    private route: ActivatedRoute,
    private spinner: NgxSpinnerService,
    private matDialog: MatDialog,
    private router: Router,
    private authService: AuthenticationService
  ) {
    this.createAgentForm = this.fb.group({
      avatarName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(15)]],
      agentName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(50)]],
      agentDescription: ['', [Validators.maxLength(50)]],
      agentOrganization: ['', [Validators.required]],
      agentBusinessUnit: ['', [Validators.required]],
      agentLanguages: ['', [Validators.required]],
      agentChannels: ['', [Validators.required]]
    });

    this.route.paramMap.subscribe((params: any) => {
      console.log('params -->', params);
      this.flag = params.params.flag;
      this.vaId = params.params.vaId;
    });

    this.userId = this.authService.getCurrentUserId();
  }
  ngOnDestroy(): void {
    if (this.getVirtualAgentSubscribe) {
      this.getVirtualAgentSubscribe.unsubscribe();
    }
    if (this.sendVaSaveResponseSubscribe) {
      this.sendVaSaveResponseSubscribe.unsubscribe();
    }
    if (this.orgDataSubscribe) {
      this.orgDataSubscribe.unsubscribe();
    }
    if (this.chnDataSubscribe) {
      this.chnDataSubscribe.unsubscribe();
    }
    if (this.langDataSubscribe) {
      this.langDataSubscribe.unsubscribe();
    }
    if (this.busUnitDataSubscribe) {
      this.busUnitDataSubscribe.unsubscribe();
    }
    if (this.updateVaResponseSubscribe) {
      this.updateVaResponseSubscribe.unsubscribe();
    }
  }

  ngOnInit() {

    if (Number(this.flag) === 1) {
      console.log(this.flag);
      this.spinner.show();
      console.log(this.userId);
      this.getVirtualAgentSubscribe = this.vaService.getVirtualAgent(this.vaId).subscribe(res => {
        console.log(res);
        this.agentDetails = res['virtualAgent'];
        console.log(res['virtualAgent'], this.agentDetails);
        this.Organizations = [{ orgId: this.agentDetails.businessUnitData.organization.orgId, organizationName: this.agentDetails.businessUnitData.organization.organizationName }];
        this.BusinessUnits = [{ catId: this.agentDetails.businessUnitData.catId, categoryName: this.agentDetails.businessUnitData.categoryName }];

        this.createAgentForm.patchValue({
          avatarName: this.agentDetails.vaAvatarName,
          agentName: this.agentDetails.vaName,
          agentDescription: this.agentDetails.vaDescription,
          agentOrganization: this.Organizations[0].orgId,
          agentBusinessUnit: this.BusinessUnits[0].catId,
          agentLanguages: this.agentDetails.languages,
          agentChannels: this.agentDetails.channels
        });

        this.getLangs();
        this.getChnls();

        this.languages.push(this.agentDetails.languages),
          this.channels = this.agentDetails.channels,
          this.orgs = this.Organizations,
          this.bunit = this.BusinessUnits;
      }, err => {
        console.error(err);
      });
      this.spinner.hide();
    } else {
      this.getOrgs();
    }

    this.languages = [];
    this.channels = [];

    this.settings = {
      singleSelection: false,
      idField: 'langEngId',
      textField: 'langName',
      enableCheckAll: true,
      selectAllText: 'Select All',
      unSelectAllText: 'Unselect All',
      allowSearchFilter: true,
      limitSelection: -1,
      clearSearchFilter: true,
      maxHeight: 197,
      itemsShowLimit: 1,
      searchPlaceholderText: 'search here',
      // noDataAvailablePlaceholderText: 'No data available',
      // closeDropDownOnSelection: true,
      showSelectedItemsAtTop: false,
      defaultOpen: false
    };
    this.chnsettings = {
      singleSelection: false,
      idField: 'channelId',
      textField: 'channelName',
      enableCheckAll: true,
      selectAllText: 'Select All',
      unSelectAllText: 'Unselect All',
      allowSearchFilter: true,
      limitSelection: -1,
      clearSearchFilter: true,
      maxHeight: 197,
      itemsShowLimit: 1,
      searchPlaceholderText: 'search here',
      // noDataAvailablePlaceholderText: 'No data available',
      closeDropDownOnSelection: true,
      showSelectedItemsAtTop: false,
      defaultOpen: false
    };

  }

  specialCharPresent(section, agentName) {
    let patt: any;
    console.log(section);
    (section === 'agent') ? (patt = /^[a-zA-Z0-9\_]*$/) : (patt = /^[a-zA-Z0-9\_\s]*$/);
    if (section === 'agent') {
      if (patt.test(agentName)) {
        this.isAlphCheckAgentValue = false;
      } else {
        this.createAgentForm.controls['agentName'].setErrors({ invalid: true });
        this.isAlphCheckAgentValue = true;
        this.isAlphCheckAvatarValue = false;
        return false;
      }
    }

    if (section === 'avatar') {
      if (patt.test(agentName)) {
        this.isAlphCheckAvatarValue = false;
      } else {
        console.log(this.isAlphCheckAvatarValue, this.isAlphCheckAgentValue);
        this.createAgentForm.controls['avatarName'].setErrors({ invalid: true });
        this.isAlphCheckAvatarValue = true;
        this.isAlphCheckAgentValue = false;
        return false;
      }
    }
  }

  getOrgs() {
    this.orgDataSubscribe = this.vaService.orgData(this.userId).subscribe(res => {
      this.Organizations = res['organizationData'];
      console.log(this.Organizations);
    });
  }

  getChnls() {
    this.chnDataSubscribe = this.vaService.chnData().subscribe(res => {
      this.channels = res['channels'];
    });
  }

  getBusUnit() {
    this.busUnitDataSubscribe = this.vaService.busUnitData(this.createAgentForm.value.agentOrganization, this.userId).subscribe(res => {
      this.BusinessUnits = res['categoryData'];
    });
  }

  getLangs() {
    this.langDataSubscribe = this.vaService.langData(this.createAgentForm.value.agentBusinessUnit).subscribe(res => {
      this.languages = res['languageEngineMaps'];
    });
  }

  orgChange(orgId) {
    this.createAgentForm.patchValue({
      agentBusinessUnit: '',
      agentLanguages: [],
      agentChannels: []
    });
    this.orgs = this.Organizations.filter(x => x.orgId === Number(orgId));
    console.log(this.orgs, orgId);
    this.getBusUnit();
  }

  businessUnitChange(unitId) {
    this.createAgentForm.patchValue({
      agentLanguages: [],
      agentChannels: []
    });
    this.bunit = this.BusinessUnits.filter(x => x.catId === Number(unitId));
    console.log(unitId, this.bunit);

    this.getLangs();
    this.getChnls();
  }


  deselectPopUp(value) {
    if (value === 'lang') {
      this.openModalPopUpDeselect(value);
      this.createAgentForm.patchValue({
        agentLanguages: this.agentDetails.languages,
        agentChannels: this.agentDetails.channels
      });
    } else {
      this.openModalPopUpDeselect(value);
      this.createAgentForm.patchValue({
        agentChannels: this.agentDetails.channels
      });
    }
  }

  onLanguageSelect(item) {
    console.log('', item, this.createAgentForm.value.agentChannels);
    if (Number(this.flag) === 1) {
      this.createAgentForm.patchValue({
        agentChannels: this.agentDetails.channels
      });
    } else {
      this.createAgentForm.patchValue({
        agentChannels: []
      });
    }
    console.log('', this.createAgentForm.value.agentChannels);
  }


  onLanguageDeSelect(item) {
    if (Number(this.flag) === 1) {
      for (let i = 0; i < this.agentDetails.languages.length; i++) {
        if (this.agentDetails.languages[i].langName === item.langName) {
          const value = 'lang';
          this.deselectPopUp(value);
        }
      }
    }
  }

  onDeselectAllLanguages() {
    const value = 'lang';
    // tslint:disable-next-line: no-unused-expression
    Number(this.flag) === 1 ? this.deselectPopUp(value) : '';
  }

  public onChannelSelect(chn: any) {
    this.channelsList = [];
    this.channelsList.push(chn);
  }

  onDeSelectChannels(item) {
    if (Number(this.flag) === 1) {
      for (let i = 0; i < this.agentDetails.channels.length; i++) {
        if (this.agentDetails.channels[i].channelName === item.channelName) {
          const value = 'chn';
          this.deselectPopUp(value);
        }
      }
    }
  }

  onDeSelectAllChannels() {
    const value = 'chn';
    // tslint:disable-next-line: no-unused-expression
    Number(this.flag) === 1 ? this.deselectPopUp(value) : '';
  }

  onSave() {
    this.spinner.show();
    console.log('flaggggggggggggggggggg', this.saveResponse, this.flag);

    this.saveResponse = [
      {
        businessUnit: this.bunit[0].categoryName,
        businessUnitData: {
          catId: this.bunit[0].catId,
          nluEngine: {
            engineId: 0,
            engineName: ''
          },
          organization: {
            orgId: this.orgs[0].orgId,
            organizationName: this.orgs[0].organizationName
          }
        },
        userName: '',
        channels: this.createAgentForm.value.agentChannels,
        languages: this.createAgentForm.value.agentLanguages,
        vaAvatarName: this.createAgentForm.value.avatarName,
        vaDescription: this.createAgentForm.value.agentDescription,
        vaId: '',
        vaIsLive: true,
        vaName: this.createAgentForm.value.agentName
      }
    ];

    if (Number(this.flag) === 1) {
      console.log('aaaaaaaaaaaaaaaaaaaaa', this.saveResponse);
      this.saveResponse[0].vaId = Number(this.vaId);
      this.updateVaResponseSubscribe = this.vaService.updateVaResponse(this.saveResponse[0].vaId, this.saveResponse[0], this.userId).subscribe(arg => {
        console.log(arg);
        if (arg['errorBody'] != null) {
          this.openModalErrorPopUp(arg['errorBody'].summary);
        } else {
          this.NLUEngine = arg['virtualAgent'].businessUnitData.nluEngine.engineId;
          this.openModalPopUp(this.flag, this.NLUEngine);
        }
        this.spinner.hide();
      }, err => {
        console.log(err);
      });
    } else {
      this.sendVaSaveResponseSubscribe = this.vaService.sendVaSaveResponse(this.bunit[0].catId, this.userId, this.saveResponse).subscribe(arg => {
        console.log(arg);
        if (arg['errorBody'] != null) {
          (arg['errorBody'].summary.indexOf('exists') !== -1) ? this.openModalErrorPopUp(`The VA with name ${this.createAgentForm.value.agentName} already exists`) : this.openModalErrorPopUp(arg['errorBody'].summary);
        } else {
          this.NLUEngine = arg['virtualAgents'][0].businessUnitData.nluEngine.engineId;
          this.openModalPopUp(this.flag, this.NLUEngine);
        }
        this.spinner.hide();
      });
    }
  }

  onCancel() {
    this.router.navigate(['/va/va-listing']);
    //  this.flag == 1 ? this.router.navigate(['/va-listing']) : this.router.navigate(['/agent-list']);
  }


  openModalPopUp(flag, nluId) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = '800px';
    dialogConfig.data = {
      primaryText: '',
      secondaryText: '',
      hasPrimaryBtn: true,
      primaryBtnText: 'Create another',
      hasSecondaryBtn: true,
      secondaryBtnText: 'Go to VA list page',
      suggestedText: '',
      popUpType: 'save',
      hasCancelBtn: false
    };
    console.log(nluId);

    dialogConfig.data.primaryText = (Number(this.flag) === 1) ? 'You have successfully updated a Virtual Agent (VA) which you can view in the VA listing page.' : 'You have successfully created a new Virtual Agent (VA) which you can view in the VA listing page.';
    dialogConfig.data.suggestedText = (nluId === 1) ? `Please contact Uniphore customer support to complete the VA configuration.` : ' ';

    const modalDialog = this.matDialog.open(ModalComponent, dialogConfig);
    modalDialog.afterClosed().subscribe(data => {
      if (data === 'secondary') {
        this.router.navigate(['/va/va-listing']);
      } else {
        this.createAgentForm.reset();
        this.languages = [];
        this.channels = [];
        this.router.navigate(['/va/va-creation']);
        console.log('channels', this.createAgentForm, this.languages, this.channels);
      }
    });
  }

  openModalErrorPopUp(err) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = '800px';
    dialogConfig.data = {
      warnText: err,
      hasWarnBtn: true,
      warnBtnText: 'Ok',
      popUpType: 'singlewarn',
    };
    const modalDialog = this.matDialog.open(ModalComponent, dialogConfig);
    modalDialog.afterClosed().subscribe(data => {
      console.log('material data err', data);
    });
  }

  openModalPopUpDeselect(value) {
    this.settings['closeDropDownOnSelection'] = true;
    this.chnsettings['closeDropDownOnSelection'] = true;

    console.log('value', this.settings, this.chnsettings);

    this.hidedropdown = true;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = '500px';
    dialogConfig.data = {
      primaryText: '',
      hasPrimaryBtn: true,
      primaryBtnText: 'Ok',
      popUpType: 'warn',
      hasCancelBtn: true
    };

    dialogConfig.data.primaryText = (value === 'lang') ? 'Currently you will only be able to add a language. Thank you' : 'Currently you will only be able to add a channel. Thank you';

    const modalDialog = this.matDialog.open(ModalComponent, dialogConfig);
    modalDialog.afterClosed().subscribe(data => {
      console.log(data);
      this.hidedropdown = false;
    });
  }

}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IntentListingComponent } from './intent-listing/intent-listing.component';
import { CreateIntentComponent } from './create-intent/create-intent.component';

const routes: Routes = [
      { path: '', loadChildren: () => import('./create-intent/create-intent.module').then(m => m.CreateIntentModule) },
      { path:  'listing', component:  IntentListingComponent},
      { path:  'listing/:id/:name/:desc/:channel/:lang/:chId/:langId', component:  IntentListingComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class IntentRoutingModule { }

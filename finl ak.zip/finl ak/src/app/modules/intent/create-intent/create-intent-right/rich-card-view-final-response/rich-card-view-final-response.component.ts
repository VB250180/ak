import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-rich-card-view-final-response',
  templateUrl: './rich-card-view-final-response.component.html',
  styleUrls: ['./rich-card-view-final-response.component.scss']
})
export class RichCardViewFinalResponseComponent implements OnInit {
  @Input() clonedFinalResNewArray: any;

  constructor() { }
  ngOnInit() {}
  // tslint:disable-next-line: triple-equals
  checkEmpty = (t) => t != '' && t != null && t != undefined ? true : false;
}

import { Component, OnInit, ViewChild, Output, AfterViewInit, EventEmitter, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, Form, Validators, SelectControlValueAccessor } from '@angular/forms';
import { Conversation, ConversationStage, GetInfo, SendMessage } from '../../../../../app/core/models/intent';
import { CreateIntentService } from '../../../../core/services/create-intent/create-intent.service';
import { ActivatedRoute } from '@angular/router';
import * as cloneDeep from 'lodash/cloneDeep';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { NgxSpinnerService } from 'ngx-spinner';
import { RichCardViewFinalResponseComponent } from './rich-card-view-final-response/rich-card-view-final-response.component';
import { RichCardViewGetInfoComponent } from './rich-card-view-get-info/rich-card-view-get-info.component';
import { Subscription } from 'rxjs';
declare var $: any;

@Component({
  selector: 'app-create-intent-right',
  templateUrl: './create-intent-right.component.html',
  styleUrls: ['../create-intent-left/create-intent-left.component.scss']
})
export class CreateIntentRightComponent implements OnInit, OnDestroy, AfterViewInit {
  @Output() public getLeftPanelDataR = new EventEmitter<any>();
  conversationListRight = new Conversation();
  intentId; chId; langId;
  clonedFinalResNewArray;
  getIntentConversionListSubscription: Subscription;
  constructor(private spinner: NgxSpinnerService, private route: ActivatedRoute, public createIntentService: CreateIntentService) {
    this.route.paramMap.subscribe((params: any) => {
      this.intentId = params.params.intId;
      const roleId = params.params.vaID;
      this.chId = params.params.chId;
      this.langId = params.params.langId;
      this.getConversationList(this.intentId, this.langId, this.chId);
    });
  }
  // message: string; sendResMessage;
  ngOnInit() { }

  ngAfterViewInit() {
    // tslint:disable-next-line: only-arrow-functions
    $(document).ready(function() {
      $('.card-body-right-panel-final-response').parent('.example-box').css('visibility', 'hidden');
      $('.card-body-right-panel-final-response').parent('.example-box').css('padding', '0');
    });
  }

  getConversationList(intentId, langId, chId) {
    if (intentId !== undefined) {
      this.spinner.show();
      this.getIntentConversionListSubscription = this.createIntentService.getIntentConversionList(intentId, langId, chId)
        .subscribe((res: any) => {
          this.spinner.hide();
          this.conversationListRight = res.conversation;
          this.ngAfterViewInit();
        });
    }
  }

  // tslint:disable-next-line: triple-equals
  checkEmpty = (t) => t != '' && t != null && t != undefined ? true : false;

  drop(event: CdkDragDrop<any[]>) {
    moveItemInArray(this.conversationListRight.conversationStages, event.previousIndex, event.currentIndex);
  }

// finalResponse
  bindTempDataFinalRes(e, intentId, langId, chId) {
    const clonedFinalResObj = cloneDeep(e);
    this.conversationListRight = clonedFinalResObj;
    const result = clonedFinalResObj.conversationStages.filter(obj => {
      return obj.finalResponse != null;
    });
    if (result.length === 1) {
      this.clonedFinalResNewArray = result[0].finalResponse;
    }
    this.ngAfterViewInit();
  }


  // GetInfo
  bindTempDataGet(e, intentId, langId, chId) {
    this.conversationListRight = cloneDeep(e);
    this.ngAfterViewInit();
  }


  // validationBlock ,sendMessage
  bindTempData(e, intentId, langId, chId) {
    this.conversationListRight = e;
    this.ngAfterViewInit();
  }

  ngOnDestroy() {
    if (this.getIntentConversionListSubscription) {
      this.getIntentConversionListSubscription.unsubscribe();
    }
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RichCardViewFinalResponseComponent } from './rich-card-view-final-response.component';

describe('RichCardViewFinalResponseComponent', () => {
  let component: RichCardViewFinalResponseComponent;
  let fixture: ComponentFixture<RichCardViewFinalResponseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RichCardViewFinalResponseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RichCardViewFinalResponseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // it('bindTempData method should be called', () => {
  //   component.checkEmpty(undefined);
  // });
});

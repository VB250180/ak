import { Component, OnInit, Input} from '@angular/core';

@Component({
  selector: 'app-rich-card-view-get-info',
  templateUrl: './rich-card-view-get-info.component.html',
  styleUrls: ['./rich-card-view-get-info.component.scss']
})
export class RichCardViewGetInfoComponent implements OnInit {
  @Input() conversationStageRight: any;

  constructor() { }
  ngOnInit() {}
  // tslint:disable-next-line: triple-equals
  checkEmpty = (t) => t != '' && t != null && t != undefined ? true : false;
}

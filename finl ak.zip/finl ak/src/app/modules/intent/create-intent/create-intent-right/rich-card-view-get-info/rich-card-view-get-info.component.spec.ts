import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RichCardViewGetInfoComponent } from './rich-card-view-get-info.component';

describe('RichCardViewGetInfoComponent', () => {
  let component: RichCardViewGetInfoComponent;
  let fixture: ComponentFixture<RichCardViewGetInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RichCardViewGetInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RichCardViewGetInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

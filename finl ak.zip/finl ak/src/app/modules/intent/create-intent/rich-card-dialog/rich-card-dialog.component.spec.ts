import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RichCardDialogComponent } from './rich-card-dialog.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { MatCardModule, MatDialogModule } from '@angular/material';
import { SafeHtmlPipe } from 'src/app/shared/pipes/sanitizerHtmlRender.pipe';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CreateIntentService } from '../../../../core/services/create-intent/create-intent.service';
import { of } from 'rxjs';


class CreateIntentServiceStub {
  public intentSlotRichCardTemplatesGetInfo() {
    return of({
      intentSlotRichCardTemplates: ['Hello']
    });
  }

  public intentResponseRichCardTemplatesFinalRes() {
    return of({
      intentResponseRichCardTemplates: ['Hi']
    });
  }
}


describe('RichCardDialogComponent', () => {
  let component: RichCardDialogComponent;
  let fixture: ComponentFixture<RichCardDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RichCardDialogComponent, SafeHtmlPipe],
      providers: [
        { provide: CreateIntentService, useClass: CreateIntentServiceStub }
      ],
      imports: [
        NgxSpinnerModule,
        MatCardModule,
        MatDialogModule,
        HttpClientTestingModule,
        BrowserAnimationsModule
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RichCardDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('ngOnInit should call intentSlotRichCardTemplatesGetInfo', () => {
    const intentSlotRichCardTemplatesGetInfoSpy = spyOn(component, 'intentSlotRichCardTemplatesGetInfo');
    const intentResponseRichCardTemplatesFinalResSpy = spyOn(component, 'intentResponseRichCardTemplatesFinalRes');
    component.name = 'richCrdGetInfo';
    component.ngOnInit();

    expect(intentSlotRichCardTemplatesGetInfoSpy).toHaveBeenCalled();
    expect(intentResponseRichCardTemplatesFinalResSpy).toHaveBeenCalledTimes(0);
  });

  it('ngOnInit should call intentResponseRichCardTemplatesFinalRes', () => {
    const intentSlotRichCardTemplatesGetInfoSpy = spyOn(component, 'intentSlotRichCardTemplatesGetInfo');
    const intentResponseRichCardTemplatesFinalResSpy = spyOn(component, 'intentResponseRichCardTemplatesFinalRes');
    component.name = 'Info';
    component.ngOnInit();

    expect(intentSlotRichCardTemplatesGetInfoSpy).toHaveBeenCalledTimes(0);
    expect(intentResponseRichCardTemplatesFinalResSpy).toHaveBeenCalled();
  });

  it('ngOnInit should call intentResponseRichCardTemplatesFinalRes', () => {
    component.intentSlotRichCardTemplatesGetInfo();

    expect(component.displayhtml).toEqual(['Hello']);
  });

  it('ngOnInit should call intentResponseRichCardTemplatesFinalRes', () => {
    component.intentResponseRichCardTemplatesFinalRes();

    expect(component.displayhtml).toEqual(['Hi']);
  });
});

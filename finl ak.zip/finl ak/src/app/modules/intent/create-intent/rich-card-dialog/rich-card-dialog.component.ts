import { Component, OnInit, Output, EventEmitter, Input, ViewChild, OnDestroy } from '@angular/core';
import { CreateIntentService } from '../../../../core/services/create-intent/create-intent.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { SafeHtmlPipe } from 'src/app/shared/pipes/sanitizerHtmlRender.pipe';
import { Subscription } from 'rxjs';
// import { CreateIntentLeftComponent } from '../create-intent-left/create-intent-left.component';
// SafeHtmlPipe
@Component({
    selector: 'app-rich-card-dialog',
    templateUrl: './rich-card-dialog.component.html',
    styleUrls: ['./rich-card-dialog.component.scss']
})
export class RichCardDialogComponent implements OnInit, OnDestroy {
    displayhtml;
    name: string;
    intentResponseRichCardTemplatesFinalResSubscription: Subscription;
    intentSlotRichCardTemplatesGetInfoSubscription: Subscription;
    constructor(public createIntentService: CreateIntentService, private spinner: NgxSpinnerService, ) { }
    ngOnInit() {
        this.spinner.show();
        (this.name === 'richCrdGetInfo') ? this.intentSlotRichCardTemplatesGetInfo() : this.intentResponseRichCardTemplatesFinalRes();

    }

    intentSlotRichCardTemplatesGetInfo() {
        this.intentSlotRichCardTemplatesGetInfoSubscription = this.createIntentService.intentSlotRichCardTemplatesGetInfo()
            .subscribe((res: any) => {
                this.displayhtml = res.intentSlotRichCardTemplates;
                this.spinner.hide();
            },
                err => { this.spinner.hide(); console.error(err); }
            );
    }

    intentResponseRichCardTemplatesFinalRes() {
        this.intentResponseRichCardTemplatesFinalResSubscription = this.createIntentService.intentResponseRichCardTemplatesFinalRes()
            .subscribe((res: any) => {
                this.displayhtml = res.intentResponseRichCardTemplates;
                this.spinner.hide();
            },
                err => { this.spinner.hide(); console.error(err); }
            );
    }

    ngOnDestroy() {
        if (this.intentResponseRichCardTemplatesFinalResSubscription) {
            this.intentResponseRichCardTemplatesFinalResSubscription.unsubscribe();
        }
        if (this.intentSlotRichCardTemplatesGetInfoSubscription) {
            this.intentSlotRichCardTemplatesGetInfoSubscription.unsubscribe();
        }
      }

}

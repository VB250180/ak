// import { LoginComponent } from './../../../app/modules/login/login.component';
import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { TrainingPhrasesComponent } from './training-phrases.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, Component, TemplateRef } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { BsDropdownConfig } from 'ngx-bootstrap/dropdown';
import { ToastrService, ToastrModule } from 'ngx-toastr';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { CreateIntentService } from '../../../../core/services/create-intent/create-intent.service';
import { of, BehaviorSubject, Observable, throwError } from 'rxjs';
import { TextSelectEvent } from 'src/app/shared/directives/text-select.directive';
import { ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { MatDialogModule, MatDialog } from '@angular/material';
import { chooseColorClassByLastDigit, getObjById, isEmptyObj } from '../../../../../app/core/utils/akeira-utils';

class ActivatedRouteStub {
    paramsObj = {
        params: {
            name: 'name',
            id: 1,
            desc: 'desc',
            channel: 'channel',
            lang: 'en-uk',
            chId: 'chId',
            langId: 'lanID'
        }
    };
    public paramMap = new BehaviorSubject(this.paramsObj);
}

class BsModalRefStub {
    public hide() { }

    public show() { }
}

class BsModalServiceStub {
    public show() { }
}

class CreateIntentServiceStub {
    public requestaddTrainingPhraseAndintentSlots(intentId, langId, pageNo, text): Observable<any[]> {
        if (intentId === 1) {
            return of([{
                trainingPhrases: [
                    {
                        trainingPhraseId: 130,
                        trainingPhraseText: 'Book a flight ticket from Singaporee to %pos0%',
                        intentSlotMapPojos: [
                            {
                                position: 'pos0',
                                value: 'newzealand',
                                intentSlot: {
                                    intentSlotId: 1,
                                    intentSlotName: 'fromPlace',
                                    intentSlotDescription: 'from city',
                                    entity: {
                                        entityId: 1,
                                        entityName: 'fromPlace'
                                    }
                                }
                            }
                        ],
                        trainingPhraseStage: 'notTrained'
                    },
                    {
                        trainingPhraseId: 132,
                        trainingPhraseText: 'i want to book a movie ticket from %pos0%',
                        intentSlotMapPojos: [
                            {
                                position: 'pos0',
                                value: 'Bengaluru',
                                intentSlot: {
                                    intentSlotId: 1,
                                    intentSlotName: 'fromPlace',
                                    intentSlotDescription: 'from city',
                                    entity: {
                                        entityId: 1,
                                        entityName: 'fromPlace'
                                    }
                                }
                            }
                        ],
                        trainingPhraseStage: 'notTrained'
                    },
                    {
                        trainingPhraseId: 135,
                        trainingPhraseText: 'agile methodology in akeira 2.0 product %pos1%',
                        intentSlotMapPojos: [
                            {
                                position: 'pos1',
                                value: 'development',
                                intentSlot: {
                                    intentSlotId: 7,
                                    intentSlotName: 'To city',
                                    intentSlotDescription: 'city',
                                    entity: {
                                        entityId: 1,
                                        entityName: 'fromPlace'
                                    }
                                }
                            },
                            {
                                position: 'pos0',
                                value: 'list',
                                intentSlot: {
                                    intentSlotId: 7,
                                    intentSlotName: 'To city',
                                    intentSlotDescription: 'city',
                                    entity: {
                                        entityId: 1,
                                        entityName: 'fromPlace'
                                    }
                                }
                            }
                        ],
                        trainingPhraseStage: 'notTrained'
                    }]
            },
            {
                intentSlots: [
                    {
                        intentSlotId: 7,
                        intentSlotName: 'To city',
                        intentSlotDescription: 'city',
                        entity: {
                            entityId: 1,
                            entityName: 'fromPlace'
                        }
                    },
                    {
                        intentSlotId: 6,
                        intentSlotName: 'City from',
                        intentSlotDescription: 'from city',
                        entity: {
                            entityId: 1,
                            entityName: 'fromPlace'
                        }
                    },
                    {
                        intentSlotId: 1,
                        intentSlotName: 'fromPlace',
                        intentSlotDescription: 'from city',
                        entity: {
                            entityId: 1,
                            entityName: 'fromPlace'
                        }
                    },
                    {
                        intentSlotId: 2,
                        intentSlotName: 'toPlace',
                        intentSlotDescription: 'to city',
                        entity: {
                            entityId: 2,
                            entityName: 'toPlace'
                        }
                    }
                ]
            }]);
        } else if (intentId === 0) {
            return of([{
                trainingPhrases: []
            },
            {
                intentSlots: []
            }]);
        } else {
            return throwError({});
        }
    }

    public addTrainingPhrase(intentId, langId, pageNo, text) {
        if (intentId === 1) {
            return of({
                trainingPhrases: [
                    {
                        trainingPhraseId: 130,
                        trainingPhraseText: 'Book a flight ticket from Singaporee to %pos0%',
                        intentSlotMapPojos: [
                            {
                                position: 'pos0',
                                value: 'newzealand',
                                intentSlot: {
                                    intentSlotId: 1,
                                    intentSlotName: 'fromPlace',
                                    intentSlotDescription: 'from city',
                                    entity: {
                                        entityId: 1,
                                        entityName: 'fromPlace'
                                    }
                                }
                            }
                        ],
                        trainingPhraseStage: 'notTrained'
                    },
                    {
                        trainingPhraseId: 132,
                        trainingPhraseText: 'i want to book a movie ticket from %pos0%',
                        intentSlotMapPojos: [
                            {
                                position: 'pos0',
                                value: 'Bengaluru',
                                intentSlot: {
                                    intentSlotId: 1,
                                    intentSlotName: 'fromPlace',
                                    intentSlotDescription: 'from city',
                                    entity: {
                                        entityId: 1,
                                        entityName: 'fromPlace'
                                    }
                                }
                            }
                        ],
                        trainingPhraseStage: 'notTrained'
                    },
                    {
                        trainingPhraseId: 135,
                        trainingPhraseText: 'agile methodology in akeira 2.0 product %pos1%',
                        intentSlotMapPojos: [
                            {
                                position: 'pos1',
                                value: 'development',
                                intentSlot: {
                                    intentSlotId: 7,
                                    intentSlotName: 'To city',
                                    intentSlotDescription: 'city',
                                    entity: {
                                        entityId: 1,
                                        entityName: 'fromPlace'
                                    }
                                }
                            },
                            {
                                position: 'pos0',
                                value: 'list',
                                intentSlot: {
                                    intentSlotId: 7,
                                    intentSlotName: 'To city',
                                    intentSlotDescription: 'city',
                                    entity: {
                                        entityId: 1,
                                        entityName: 'fromPlace'
                                    }
                                }
                            }
                        ],
                        trainingPhraseStage: 'notTrained'
                    }]
            });
        } else if (intentId === 0) {
            return of({
                trainingPhrases: []
            });
        } else {
            return throwError({});
        }
    }

    public deleteTrainingPhrase(intentId, langId, phraseId, text) {
        return of({});
    }

    public addPhraseDetails(intentId, langId, addArray) {
        if (intentId === 1) {
            return of({
                errorBody: null
            });
        } else if (intentId === 2) {
            return of({
                errorBody: {}
            });
        } else {
            return throwError('ERROR');
        }

    }
}

class NgxSpinnerServiceStub {
    public show() { }

    public hide() { }
}

class MatDialogStub {
    public open(template, data) {
        // this.afterClosed(true);
        return {
            afterClosed: () => {
                return of(true);
            }
        };
    }
}

describe('TrainingPhrasesComponent', () => {
    let component: TrainingPhrasesComponent;
    let fixture: ComponentFixture<TrainingPhrasesComponent>;
    // tslint:disable-next-line: prefer-const
    let template: TemplateRef<any>;


    beforeEach(async(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: ActivatedRoute, useClass: ActivatedRouteStub },
                { provide: CreateIntentService, useClass: CreateIntentServiceStub },
                { provide: NgxSpinnerService, useClass: NgxSpinnerServiceStub },
                { provide: BsModalService, useClass: BsModalServiceStub },
                { provide: BsModalRef, useClass: BsModalRefStub },
                { provide: MatDialog, useClass: MatDialogStub },
                { provide: BsDropdownConfig }
            ],
            declarations: [TrainingPhrasesComponent],
            imports: [
                FormsModule,
                ReactiveFormsModule,
                BrowserAnimationsModule,
                HttpClientTestingModule,
                ToastrModule.forRoot(),
                BsDropdownModule.forRoot(),
                MatDialogModule,
                RouterTestingModule
            ],
            schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
        })
            .compileComponents();
    }));

    beforeEach(inject([CreateIntentService], s => {
        fixture = TestBed.createComponent(TrainingPhrasesComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    }));

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('ngOnInit should call fetchPageData method', () => {
        const fetchPageDataSpy = spyOn(component, 'fetchPageData');
        component.flag = 0;
        component.ngOnInit();
        expect(fetchPageDataSpy).toHaveBeenCalled();
    });


    it('refreshTrainingPhrase should call fetchPageData method', () => {
        const fetchPageDataSpy = spyOn(component, 'fetchPageData');
        const langId = 1;
        const chId = 1;
        component.refreshTrainingPhrase(langId, chId);
        expect(component.langId).toEqual(langId);
        expect(component.chId).toEqual(chId);
        expect(fetchPageDataSpy).toHaveBeenCalled();
    });

    it('ngOnChanges should call fetchPageData method', () => {
        const fetchPageDataSpy = spyOn(component, 'fetchPageData');
        component.arr = [1, 2, 3];
        // component.searchText = '';
        component.ngOnChanges();
        expect(component.newData).toEqual([1, 2, 3]);
        expect(fetchPageDataSpy).toHaveBeenCalled();
    });

    it('ngOnChanges should not call fetchPageData method', () => {
        const fetchPageDataSpy = spyOn(component, 'fetchPageData');
        component.arr = [1, 2, 3];
        component.searchTextRight = undefined;
        // component.searchText = undefined;
        component.ngOnChanges();
        expect(component.newData).toEqual([1, 2, 3]);
        expect(fetchPageDataSpy).toHaveBeenCalledTimes(0);
    });

    it('fetchPageData should call displayTrainingPhrases method', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const spinnerShowSpy = spyOn(spinner, 'show');
        const spinnerHideSpy = spyOn(spinner, 'hide');
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        const intentId = 1;
        const langId = 1;
        const pageNum = 1;
        const searchText = '';
        component.slotsToDisplay = [];
        component.fetchPageData(intentId, langId, pageNum);
        expect(displayTrainingPhrasesSpy).toHaveBeenCalled();
        // expect(component.searchText).toEqual('');
        expect(component.slotsToDisplay.length).toEqual(4);
        expect(spinnerShowSpy).toHaveBeenCalledBefore(spinnerHideSpy);
        expect(spinnerHideSpy).toHaveBeenCalled();
    });

    it('fetchPageData should call displayTrainingPhrases method and slotsToDisplay length should be zero', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const spinnerShowSpy = spyOn(spinner, 'show');
        const spinnerHideSpy = spyOn(spinner, 'hide');
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        const intentId = 0;
        const langId = 1;
        const pageNum = 1;
        const searchText = undefined;
        // component.searchText = '';
        component.slotsToDisplay = [];
        component.fetchPageData(intentId, langId, pageNum);
        expect(displayTrainingPhrasesSpy).toHaveBeenCalled();
        // expect(component.searchText).toEqual('');
        expect(component.slotsToDisplay.length).toEqual(0);
        expect(spinnerShowSpy).toHaveBeenCalledBefore(spinnerHideSpy);
        expect(spinnerHideSpy).toHaveBeenCalled();
    });

    it('fetchPageData should not call displayTrainingPhrases method', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const spinnerShowSpy = spyOn(spinner, 'show');
        const spinnerHideSpy = spyOn(spinner, 'hide');
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        const intentId = -1;
        const langId = 1;
        const pageNum = 1;
        const searchText = 'Hello';
        // component.searchText = 'Hello';
        component.slotsToDisplay = [];
        component.fetchPageData(intentId, langId, pageNum);
        expect(displayTrainingPhrasesSpy).toHaveBeenCalledTimes(0);
        // expect(component.searchText).toEqual('Hello');
        expect(component.slotsToDisplay.length).toEqual(0);
        expect(spinnerShowSpy).toHaveBeenCalledBefore(spinnerHideSpy);
        expect(spinnerHideSpy).toHaveBeenCalled();
    });

    it('addPhrases should call displayTrainingPhrases method and set status to true', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const spinnerHideSpy = spyOn(spinner, 'hide');
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        const intentId = 1;
        const langId = 1;
        const pageNum = 1;
        const searchText = undefined;
        // component.searchText = 'Hello';
        component.addPhrases(intentId, langId, pageNum);
        expect(displayTrainingPhrasesSpy).toHaveBeenCalled();
        // expect(component.status).toBeTruthy();
        // expect(component.searchText).toEqual('Hello');
        expect(spinnerHideSpy).toHaveBeenCalled();
    });

    it('addPhrases should call displayTrainingPhrases method and set status to false', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const spinnerHideSpy = spyOn(spinner, 'hide');
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        const intentId = 0;
        const langId = 1;
        const pageNum = 1;
        const searchText = undefined;
        component.addPhrases(intentId, langId, pageNum);
        expect(displayTrainingPhrasesSpy).toHaveBeenCalled();
        // expect(component.status).toBeFalsy();
        // expect(component.searchText).toEqual('');
        expect(spinnerHideSpy).toHaveBeenCalled();
    });

    it('addPhrases should not call displayTrainingPhrases method', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const spinnerHideSpy = spyOn(spinner, 'hide');
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        const intentId = -1;
        const langId = 1;
        const pageNum = 1;
        const searchText = 'Hello';
        component.addPhrases(intentId, langId, pageNum);
        expect(displayTrainingPhrasesSpy).toHaveBeenCalledTimes(0);
        // expect(component.searchText).toEqual('');
        expect(spinnerHideSpy).toHaveBeenCalled();
    });

    it('functionClick should set isHidden to true', () => {
        component.IsHidden = false;
        component.functionClick({});
        expect(component.IsHidden).toBeTruthy();
    });

    it('functionClick should set isHidden to false', () => {
        component.IsHidden = true;
        component.functionClick({});
        expect(component.IsHidden).toBeTruthy();
    });

    it('openModalDelete should open modal', () => {
        const deleteTrainingPhraseCallSpy = spyOn(component, 'deleteTrainingPhraseCall');
        component.openModalDelete(template, 1, 2);
        expect(deleteTrainingPhraseCallSpy).toHaveBeenCalled();
    });

    it('getColorClassById method calling', () => {
        const result = component.getColorClassById(2);
        expect(result).toEqual('slot-c-2');
    });


    it('displayTrainingPhrases method calling', () => {
        const genrateHighlightdataSpy = spyOn(component, 'genrateHighlightdata');
        const phrase = [{
            intentSlotMapPojos: [{ position: 'pos1', value: 'val1' }, { position: 'pos2', value: 'val2' }]
        },
        {
            intentSlotMapPojos: [{ position: 'pos1', value: 'val1' }, { position: 'pos2', value: 'val2' }]
        }
        ];
        component.displayTrainingPhrases(phrase);
        expect(genrateHighlightdataSpy).toHaveBeenCalled();

    });

    it('displayTrainingPhrases method calling else method callinh', () => {
        const genrateHighlightdataSpy = spyOn(component, 'genrateHighlightdata');
        const phrase = [{
            intentSlotMapPojos: null
        },
        {
            intentSlotMapPojos: null
        }
        ];
        component.displayTrainingPhrases(phrase);

        expect(genrateHighlightdataSpy).toHaveBeenCalled();

    });

    it('deleteTrainingPhraseCall should call addPhrases method', () => {
        const addPhrasesSpy = spyOn(component, 'addPhrases');
        // const modal = TestBed.get(BsModalRef);
        // const modalShowSpy = spyOn(modal, 'hide');
        // component.modalRef = modal;
        component.deleteTrainingPhraseCall(1);
        // expect(modalShowSpy).toHaveBeenCalled();
        expect(addPhrasesSpy).toHaveBeenCalled();
    });

    it('genrateHighlightdata should call', () => {
        const txt = ' Hi how r u';
        const isMapped = true;
        const postionArray = [];
        const intentSlotMapPojos = 'value';
        component.genrateHighlightdata(txt, isMapped, postionArray, intentSlotMapPojos);

    });

    it('getColorCodeByPostion should call', () => {
        const key = 'how';
        component.slotsToDisplayMap.set('id', { colorClass: 'color' });
        const intentSlotMapPojos = [{
            position: 'Hi how r u',
            intentSlot: {
                intentSlotId: 'id'
            }
        }];
        const result = component.getColorCodeByPostion(key, intentSlotMapPojos);
        expect(result).toEqual('color');

    });

    it('traniedPhraseEdit should call', () => {
        const index = 0;
        const phraseId = 1;
        component.traniedPhraseEdit(index, phraseId);
        expect(component.showTabNewPhrase).toBeTruthy();

    });




    // it('deleteTrainingPhrase should not call deleteTrainingPhraseCall method and remove a num from addArray', () => {
    //     const deleteTrainingPhraseCallSpy = spyOn(component, 'deleteTrainingPhraseCall');
    //     const cancelAddSpy = spyOn(component, 'cancelAdd');
    //     const modal = TestBed.get(BsModalRef);
    //     const modalShowSpy = spyOn(modal, 'hide');
    //     // component.modalRef = modal;
    //     component.isdelFromAddArray = true;
    //     component.idToDelete = 0;
    //     component.delIndex = 1;
    //     component.addArray = [1, 2];

    //     component.deleteTrainingPhrase();

    //     expect(modalShowSpy).toHaveBeenCalled();
    //     expect(component.addArray).toEqual([1]);
    //     expect(deleteTrainingPhraseCallSpy).toHaveBeenCalledTimes(0);
    //     expect(cancelAddSpy).toHaveBeenCalledTimes(1);
    // });

    // it('deleteTrainingPhrase should call deleteTrainingPhraseCall method and remove a num from addArray', () => {
    //     const deleteTrainingPhraseCallSpy = spyOn(component, 'deleteTrainingPhraseCall');
    //     const cancelAddSpy = spyOn(component, 'cancelAdd');
    //     const modal = TestBed.get(BsModalRef);
    //     const modalShowSpy = spyOn(modal, 'hide');
    //     component.modalRef = modal;
    //     component.isdelFromAddArray = true;
    //     component.idToDelete = 1;
    //     component.delIndex = 1;
    //     component.addArray = [1, 2];
    //     component.searchText = undefined;

    //     component.deleteTrainingPhrase();

    //     expect(modalShowSpy).toHaveBeenCalled();
    //     expect(component.searchText).toEqual('');
    //     expect(component.addArray).toEqual([1]);
    //     expect(deleteTrainingPhraseCallSpy).toHaveBeenCalled();
    //     expect(cancelAddSpy).toHaveBeenCalledTimes(1);
    // });

    // it('deleteTrainingPhrase should call deleteTrainingPhraseCall', () => {
    //     const deleteTrainingPhraseCallSpy = spyOn(component, 'deleteTrainingPhraseCall');
    //     const cancelAddSpy = spyOn(component, 'cancelAdd');
    //     const modal = TestBed.get(BsModalRef);
    //     const modalShowSpy = spyOn(modal, 'hide');
    //     component.modalRef = modal;
    //     component.isdelFromAddArray = false;
    //     component.searchText = undefined;

    //     component.deleteTrainingPhrase();

    //     expect(modalShowSpy).toHaveBeenCalled();
    //     expect(component.searchText).toEqual('');
    //     expect(deleteTrainingPhraseCallSpy).toHaveBeenCalled();
    //     expect(cancelAddSpy).toHaveBeenCalledTimes(1);
    // });

    // it('removeSelectedValue should remove given value from intentSlotMapPojos array', () => {
    //     const coloringPhraseSpy = spyOn(component, 'coloringPhrase');
    //     const updateValueToTableSpy = spyOn(component, 'updateValueToTable');
    //     component.intentSlotMapPojos = [{ value: 1 }, { value: 2 }];
    //     const value = 2;

    //     component.removeSelectedValue(value);

    //     expect(component.intentSlotMapPojos).toEqual([{ value: 1 }]);
    //     expect(coloringPhraseSpy).toHaveBeenCalled();
    //     expect(updateValueToTableSpy).toHaveBeenCalled();
    // });

    it('checkEmpty should return true', () => {
        const value = 'Hello';
        const result = component.checkEmpty(value);
        expect(result).toBeTruthy();
    });

    it('checkEmpty should return false', () => {
        const value = '';
        const result = component.checkEmpty(value);
        expect(result).toBeFalsy();
    });

    // it('checkIfEditWordandDisplayWord should return true', () => {
    //     const newTxt = 'Hello';
    //     const oldTxt = 'Hi'

    //     const result = component.checkIfEditWordandDisplayWord(newTxt, oldTxt);

    //     expect(result).toBeTruthy();
    // });

    // it('checkIfEditWordandDisplayWord should return false', () => {
    //     const newTxt = 'Hello';
    //     const oldTxt = 'Hello'

    //     const result = component.checkIfEditWordandDisplayWord(newTxt, oldTxt);

    //     expect(result).toBeFalsy();
    // });

    // it('onChangebtn should call genrateHighlightdata and updateValueToTable methods', () => {
    //     const genrateHighlightdataSpy = spyOn(component, 'genrateHighlightdata');
    //     // const updateValueToTableSpy = spyOn(component, 'updateValueToTable');
    //     const txt = 'Hello';

    //     component.onChangebtn(txt);

    //     expect(genrateHighlightdataSpy).toHaveBeenCalled();
    //     // expect(updateValueToTableSpy).toHaveBeenCalled();
    //     expect(component.disableAddbtm).toBeFalsy();
    // });

    // it('onChangebtn should not call genrateHighlightdata and updateValueToTable methods', () => {
    //     const genrateHighlightdataSpy = spyOn(component, 'genrateHighlightdata');
    //     const updateValueToTableSpy = spyOn(component, 'updateValueToTable');
    //     const txt = '';

    //     component.onChangebtn(txt);

    //     expect(genrateHighlightdataSpy).toHaveBeenCalledTimes(0);
    //     expect(updateValueToTableSpy).toHaveBeenCalledTimes(0);
    // });

    // it('editPhrase should not call genrateHighlightdata and updateValueToTable methods', () => {
    //     const cancelAddSpy = spyOn(component, 'cancelAdd');
    //     const updateValueToTableSpy = spyOn(component, 'updateValueToTable');
    //     const data = {};
    //     const index = 1;
    //     const isAddArray = false;
    //     component.intentSlotMapPojos = [];
    //     component.valueToEdit = 'value';

    //     component.editPhrase(data, index, isAddArray);

    //     expect(cancelAddSpy).toHaveBeenCalled();
    //     expect(component.addForm.controls['addtext'].value).toEqual('value');
    //     expect(updateValueToTableSpy).toHaveBeenCalled();
    // });

    // it('checkCanEdit should call editPhrase and modal should not open', () => {
    //     const editPhraseSpy = spyOn(component, 'editPhrase');
    //     const modalShowSpy = spyOn(TestBed.get(BsModalService), 'show');
    //     const data = {};
    //     const index = 1;
    //     const isAddArray = false;
    //     component.intentSlotMapPojos = [];
    //     component.checkEdited = '';

    //     component.checkCanEdit(data, index, isAddArray);

    //     expect(editPhraseSpy).toHaveBeenCalled();
    //     expect(modalShowSpy).toHaveBeenCalledTimes(0);
    // });

    // it('checkCanEdit should not call editPhrase and modal should open', () => {
    //     const modalService = TestBed.get(BsModalService);
    //     const editPhraseSpy = spyOn(component, 'editPhrase');
    //     const modalShowSpy = spyOn(modalService, 'show');
    //     const data = {};
    //     const index = 1;
    //     const isAddArray = false;
    //     component.intentSlotMapPojos = [];
    //     component.checkEdited = 'check';

    //     component.checkCanEdit(data, index, isAddArray);

    //     expect(editPhraseSpy).toHaveBeenCalledTimes(0);
    //     expect(modalShowSpy).toHaveBeenCalled();
    // });

    // it('editPhraseYes should call editPhrase and close the modal', () => {
    //     const modalRef = TestBed.get(BsModalRef);
    //     const editPhraseSpy = spyOn(component, 'editPhrase');
    //     const modalHideSpy = spyOn(modalRef, 'hide');
    //     component.modalRef = modalRef;

    //     component.editPhraseYes();

    //     expect(editPhraseSpy).toHaveBeenCalled();
    //     expect(modalHideSpy).toHaveBeenCalled();
    // });

    // it('editPhraseNo should call close the modal', () => {
    //     const modalRef = TestBed.get(BsModalRef);
    //     const modalHideSpy = spyOn(modalRef, 'hide');
    //     component.modalRef = modalRef;

    //     component.editPhraseNo();

    //     expect(modalHideSpy).toHaveBeenCalled();
    // });

    // it('cancelAdd should re-initialize variables to empty', () => {
    //     component.idToEdit = 1;
    //     component.valueToEdit = 'Hi';
    //     component.checkEdited = [1, 2, 3];
    //     component.arrayIndex = 1;
    //     component.fromAddarray = false;
    //     component.mappedHighlightData = [2, 3, 4];
    //     component.intentSlotMapPojos = [3, 4, 5];
    //     component.trainingPhraseText = 'training';
    //     component.disableAddbtm = false;
    //     component.intentSlots = [{ selectedValue: 'selected' }];
    //     component.addForm.setValue({
    //         'addtext': 'value'
    //     });

    //     component.cancelAdd();

    //     expect(component.idToEdit).toEqual(0);
    //     expect(component.valueToEdit).toEqual('');
    //     expect(component.checkEdited).toEqual([]);
    //     expect(component.arrayIndex).toEqual(null);
    //     expect(component.fromAddarray).toBeTruthy();
    //     expect(component.mappedHighlightData).toEqual([]);
    //     expect(component.intentSlotMapPojos).toEqual([]);
    //     expect(component.trainingPhraseText).toEqual('');
    //     expect(component.disableAddbtm).toBeTruthy();
    //     expect(component.intentSlots[0].selectedValue).toEqual('');
    //     expect(component.addForm.controls['addtext'].value).toEqual(null);
    // });

    it('saveAddedTrainingPhrases should call displayTrainingPhrases and addPhrases on API success', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const spinnerShowSpy = spyOn(spinner, 'show');
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        const addPhrasesSpy = spyOn(component, 'addPhrases');
        component.addPhraseArray = [1, 2];
        component.intentId = 1;

        component.saveAddedTrainingPhrases();

        expect(spinnerShowSpy).toHaveBeenCalled();
        expect(displayTrainingPhrasesSpy).toHaveBeenCalled();
        expect(addPhrasesSpy).toHaveBeenCalled();
    });

    it('saveAddedTrainingPhrases should not call displayTrainingPhrases and addPhrases when API respone has error and open Info modal', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const spinnerShowSpy = spyOn(spinner, 'show');
        const spinnerHideSpy = spyOn(spinner, 'hide');
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        const addPhrasesSpy = spyOn(component, 'addPhrases');
        component.addPhraseArray = [1, 2];
        component.intentId = 2;

        component.saveAddedTrainingPhrases();

        expect(spinnerShowSpy).toHaveBeenCalledBefore(spinnerHideSpy);
        expect(spinnerHideSpy).toHaveBeenCalled();
        expect(displayTrainingPhrasesSpy).toHaveBeenCalledTimes(0);
        expect(addPhrasesSpy).toHaveBeenCalledTimes(0);
    });

    it('saveAddedTrainingPhrases should not call displayTrainingPhrases and addPhrases when API fails or throws an error and open Warning modal', () => {
        const spinner = TestBed.get(NgxSpinnerService);
        const spinnerShowSpy = spyOn(spinner, 'show');
        const spinnerHideSpy = spyOn(spinner, 'hide');
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        const addPhrasesSpy = spyOn(component, 'addPhrases');
        component.addPhraseArray = [1, 2];
        component.intentId = 0;

        component.saveAddedTrainingPhrases();

        expect(spinnerShowSpy).toHaveBeenCalled();
        expect(spinnerHideSpy).toHaveBeenCalled();
        expect(displayTrainingPhrasesSpy).toHaveBeenCalledTimes(0);
        expect(addPhrasesSpy).toHaveBeenCalledTimes(0);
    });

    it('onScroll should increment counter call displayTrainingPhrases on API success', () => {
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        component.intentId = 1;
        component.counter = 1;

        component.onScroll();

        expect(component.counter).toEqual(2);
        expect(displayTrainingPhrasesSpy).toHaveBeenCalled();
    });

    it('onScroll should increment counter not call displayTrainingPhrases on API failure', () => {
        const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
        component.intentId = 2;
        component.counter = 1;

        component.onScroll();

        expect(component.counter).toEqual(2);
        expect(displayTrainingPhrasesSpy).toHaveBeenCalledTimes(0);
    });

    it('checkIfNewPhraseHas  method calling as equal', () => {
        component.addPhraseArray = [{
            trainingPhraseId: 1
        }];
        const result = component.checkIfNewPhraseHas(1);
        expect(result).toBeFalsy();
    });

    it('checkIfNewPhraseHas method calling as not equal', () => {
        component.addPhraseArray = [{
            trainingPhraseId: 2
        }];
        const result = component.checkIfNewPhraseHas(1);
        expect(result).toBeTruthy();
    });

    it('openModalAlreadyAdded method calling', () => {
        component.openModalAlreadyAdded();
    });

    it('openModalFileError method calling', () => {
        component.openModalFileError();
    });

    it('openModalFilesizeLimit method calling', () => {
        component.openModalFilesizeLimit();
    });

    xit('onselectfile method calling', () => {
        const data = [
            {
                lastModifiedDate: 'Thu Nov 28 2019 08:33:02 GMT+0530 (India Standard Time)',
                name: 'bugs fixedon-28morn.txt',
                size: 138,
                type: 'text/plain',
                webkitRelativePath: '',
                length: 1
            }
        ];

        const allowedext = ['application/vnd.ms-excel', 'text/plain'];
        component.onselectFile(data);
        expect(component.fileContent).toEqual('');
    });

    it('getRegexPattern method calling', () => {
        const pattern = ['Hi', 'How'];
        const result = component.getRegexPattern(pattern);
        expect(result).toBeTruthy();
    });

    it('onEnter method calling', () => {
        const addNewPhraseSpy = spyOn(component, 'addNewPhrase');
        component.onEnter('Hi ow r u', 2);
        expect(addNewPhraseSpy).toHaveBeenCalledTimes(1);
    });
    it('onEnter method calling', () => {
        const addNewPhraseSpy = spyOn(component, 'addNewPhrase');
        component.onEnter('Hi ow r u', 2);
        expect(addNewPhraseSpy).toHaveBeenCalledTimes(1);
    });

    it('stringToArray method calling not empty', () => {
        const result = component.stringToArray('Hi how are you');
        expect(result).toEqual(['Hi', 'how', 'are', 'you']);
    });

    it('stringToArray method calling not empty', () => {
        const result = component.stringToArray('');
        expect(result).toEqual([]);
    });

    it('highlightSearchTxt method calling not empty', () => {
        component.highlightSearchTxt();
    });

    it('remove method calling ', () => {
        const index = 1;
        // component.remove(ssss: seach);
    });

    it('renderSelectionLeft should call if part ', () => {
        // tslint:disable-next-line: no-shadowed-variable
        const event = {
            text: 'Text With Space',
            posStart: 0,
            posEnd: 2,
            viewportRectangle: null,
            hostRectangle: {
                left: 0,
                top: 0,
                width: 0,
                height: 0
            }
        };
        component.renderSelectionLeft(event);
        expect(component.hostSelectionLeft).toEqual(event.hostRectangle);

    });

    it('renderSelectionLeft should call else part ', () => {
        const eventdata = {
            text: 'Text With Space',
            posStart: 0,
            posEnd: 2,
            viewportRectangle: null,
            hostRectangle: null
        };
        component.renderSelectionLeft(eventdata);
        expect(component.hostSelectionLeft).toEqual(null);

    });

    it('getcopiedData should call ', () => {
        component.getcopiedData();
        expect(component.hostSelectionLeft).toEqual(null);

    });

    it('addNewPhrase should call editFromSavePhrase is true ', () => {
        const txt = 'hi ow r u';
        component.editFromSavePhraseData = { trainingPhraseId: 1 };
        component.editFromSavePhrase = true;
        component.addNewPhrase(txt, false);
        // expect(component.checkAddArray).toBeFalsy();
        expect(component.showTabNewPhrase).toBeTruthy();

    });

    it('addNewPhrase should call editFromSavePhrase is false ', () => {
        const txt = 'ddddd';
        component.editFromSavePhraseData = { trainingPhraseId: 1 };
        component.editFromSavePhrase = false;
        component.addNewPhrase('hi ow r u', false);
        // expect(component.checkAddArray).toBeFalsy();
        expect(component.showTabNewPhrase).toBeTruthy();

    });


    it('editAddPhrase should call ', () => {
        const index = 1;
        component.addPhraseArray = [{
            trainingPhraseId: 1
        },
        {
            trainingPhraseId: 1
        }];
        component.editAddPhrase(index);
        expect(component.editFromSavePhrase).toBeTruthy();

    });

    it('editAddPhrase should call ', () => {
        const index = 1;
        component.addPhraseArray = [{
            trainingPhraseId: 1
        },
        {
            trainingPhraseId: 0
        }];
        component.editAddPhrase(index);
        expect(component.editFromSavePhrase).toBeFalsy();

    });

    it('openModalAddPhraseEdit method calling manualPhrase not empty', () => {
        const index = 1;
        component.manualPhrase = 'yes i am in';
        const addNewPhraseSpy = spyOn(component, 'addNewPhrase');
        component.openModalAddPhraseEdit(index);
        expect(addNewPhraseSpy).toHaveBeenCalledTimes(0);
    });

    it('openModalAddPhraseEdit method calling manual phrase empty', () => {
        const index = 1;
        component.manualPhrase = '';
        const editAddPhraseeSpy = spyOn(component, 'editAddPhrase');
        component.openModalAddPhraseEdit(index);
        expect(editAddPhraseeSpy).toHaveBeenCalledTimes(1);
    });

    it('openModalAddPhraseDelete method calling ', () => {
        const index = 1;
        component.openModalAddPhraseDelete(index);

    });

    it('renderSelectionRight should call showIntentSlotsDropdown and set posStart to 1', () => {
        const showIntentSlotsDropdownSpy = spyOn(component, 'showIntentSlotsDropdown');
        const key = 1;
        // tslint:disable-next-line: no-shadowed-variable
        const event = {
            text: ' Text With First Space',
            posStart: 0,
            posEnd: 2,
            viewportRectangle: null,
            hostRectangle: {
                left: 0,
                top: 0,
                width: 0,
                height: 0
            }
        };
        component.renderSelectionRight(event, key);
        expect(component.posStartRight).toEqual(1);
        expect(showIntentSlotsDropdownSpy).toHaveBeenCalled();
    });

    it('renderRectangles should not call showIntentSlotsDropdown', () => {
        const showIntentSlotsDropdownSpy = spyOn(component, 'showIntentSlotsDropdown');
        const key = 1;
        // tslint:disable-next-line: no-shadowed-variable
        const event = {
            text: ' Text With First Space',
            posStart: 0,
            posEnd: 2,
            viewportRectangle: null,
            hostRectangle: null
        };
        component.renderSelectionRight(event, key);
        expect(showIntentSlotsDropdownSpy).toHaveBeenCalledTimes(0);
        expect(component.hostSelectionRight).toEqual(null);
    });

    it('renderRectangles posStart  greater posEnd', () => {
        const showIntentSlotsDropdownSpy = spyOn(component, 'showIntentSlotsDropdown');
        const key = 1;
        // tslint:disable-next-line: no-shadowed-variable
        const event = {
            text: ' Text With First Space',
            posStart: 2,
            posEnd: 1,
            viewportRectangle: null,
            hostRectangle: {
                left: 0,
                top: 0,
                width: 0,
                height: 0
            }
        };
        component.renderSelectionRight(event, key);
        expect(showIntentSlotsDropdownSpy).toHaveBeenCalledTimes(1);
        expect(component.posEndRight).toEqual(event.posStart);
        expect(component.posStartRight).toEqual(event.posEnd + 1);
    });

    it('showIntentSlotsDropdown should not call openSlotsDropdown', () => {
        const openSlotsDropdownSpy = spyOn(component, 'openSlotsDropdown');
        const key = 1;
        // tslint:disable-next-line: no-shadowed-variable
        const event = {
            text: ' Text With First Space',
            posStart: 0,
            posEnd: 2,
            viewportRectangle: null,
            hostRectangle: {
                left: 0,
                top: 0,
                width: 0,
                height: 0
            }
        };
        component.dropdownError = ' Text how are you';
        component.intentSlots = [{ id: 1 }];
        const value = 'hello';
        // component.checkEmpty(value);
        // component.renderSelectionRight(event, key);
        component.showIntentSlotsDropdown(key);
        expect(openSlotsDropdownSpy).toHaveBeenCalledTimes(0);
        expect(component.dropdownError).toEqual(' Text how are you');
        expect(component.intentSlotList).toEqual([]);
    });

    it('showIntentSlotsDropdown should call openSlotsDropdown', () => {
        const openSlotsDropdownSpy = spyOn(component, 'openSlotsDropdown');
        component.intentSlots = [1, 3];
        component.selectedTextRight = 'how';
        component.addPhraseArray = {
            hi: {
                trainingPhraseDisplay: 'Hi how are you',
                intentSlotMapPojos: [{
                    position: 'Hi how r u',
                    intentSlot: {
                        intentSlotId: 'id'
                    }
                }]
            }
        };
        const key = 'hi';
        // tslint:disable-next-line: no-shadowed-variable
        const event = {
            text: ' Text',
            posStart: 0,
            posEnd: 2,
            viewportRectangle: null,
            hostRectangle: {
                left: 0,
                top: 0,
                width: 0,
                height: 0
            }
        };
        component.dropdownError = ' Text how are you';
        component.intentSlots = [{ id: 1 }];
        // component.renderSelectionRight(event, key);
        component.showIntentSlotsDropdown(key);
        expect(openSlotsDropdownSpy).toHaveBeenCalled();
    });

    it('showIntentSlotsDropdown should not call openSlotsDropdown and set hostRectangle to null', () => {
        const openSlotsDropdownSpy = spyOn(component, 'openSlotsDropdown');
        const key = 1;
        component.intentSlots = [];
        // tslint:disable-next-line: no-shadowed-variable
        const event = {
            text: ' Text',
            posStart: 0,
            posEnd: 2,
            viewportRectangle: null,
            hostRectangle: {
                left: 0,
                top: 0,
                width: 0,
                height: 0
            }
        };

        component.renderSelectionRight(event, key);
        component.showIntentSlotsDropdown(key);
        expect(openSlotsDropdownSpy).toHaveBeenCalledTimes(0);
    });

    it('openSlotsDropdown should set intentSlotList length to 2', () => {
        const key = 1;
        const slotAry = [1, 2];
        component.slotsToDisplay = [{ id: 1, intentSlotId: 1 }, { id: 2, intentSlotId: 3 }];
        component.openSlotsDropdown(key, slotAry);

        expect(component.dropdownError).toEqual('Choose an Intent slot');
        expect(component.intentSlotList.length).toEqual(2);
    });


    // it('onScroll should initialize searchText to argument passed and call displayTrainingPhrases on API success', () => {
    //     const displayTrainingPhrasesSpy = spyOn(component, 'displayTrainingPhrases');
    //     component.intentId = 1;
    //     const text = 'Hi';

    //     component.onSearch(text);

    //     expect(component.searchText).toEqual(text);
    //     expect(displayTrainingPhrasesSpy).toHaveBeenCalled();
    // });

    // it('openInfoModal should open modal', () => {
    //     const modalShowSpy = spyOn(TestBed.get(BsModalService), 'show');
    //     component.openInfoModal(template);
    //     expect(modalShowSpy).toHaveBeenCalled();
    // });

    it('getIntentSlotValue should call getPOSTIONoftxt and updateValueToTable', () => {
        const posData = {
            posAry: [],
            pos: ''
        };
        const getPOSTIONoftxtSpy = spyOn(component, 'getPOSTIONoftxt').and.returnValue(posData);
        component.addPhraseArray = [{ mappedHighlightData: [], intentSlotMapPojos: [] }];
        component.selectedaddPhraseArrayKey = 0;
        component.getIntentSlotValue('');
        expect(getPOSTIONoftxtSpy).toHaveBeenCalled();
    });

    it('getPOSTIONoftxt should call', () => {
        const txtary = 'hello,how';
        const mappedvalue = 'hello';
        component.getPOSTIONoftxt(txtary, mappedvalue);
    });

    it('getPOSTIONoftxt should call', () => {
        const txtary = 'hello,how';
        const mappedvalue = 'hello';
        component.getPOSTIONoftxt(txtary, mappedvalue);
    });

    it('clearIntentPhrase should call', () => {
        const coloringPhraseSpy = spyOn(component, 'coloringPhrase');
        const index = 0;
        component.addPhraseArray = [{ intentSlotMapPojos: [{ id: 1 }] }];
        // component.coloringPhrase(this.addPhraseArray[index]) ={'id':1}
        component.clearIntentPhrase(index);
        expect(coloringPhraseSpy).toHaveBeenCalled();
        expect(component.addPhraseArray[index]['intentSlotMapPojos']).toEqual([]);
    });


});

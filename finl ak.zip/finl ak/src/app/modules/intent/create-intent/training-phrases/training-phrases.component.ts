import { Component, OnInit, Input, OnChanges, Output, EventEmitter, OnDestroy } from '@angular/core';
import { CreateIntentService } from '../../../../core/services/create-intent/create-intent.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { TextSelectEvent } from '../../../../../app/shared/directives/text-select.directive';
import { SelectionRectangle } from '../../../../../app/core/models/selectionRectangle';
import { MatDialog } from '@angular/material';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatChipInputEvent } from '@angular/material/chips';
import { ModalComponent } from '../../../../../app/shared/components/modal/modal.component';
import * as cloneDeep from 'lodash/cloneDeep';
import { modalFileErrorConfig, modalFileSizeConfig, modalEditConfig, modalEditTrained, modalResponseTrainedError, modalDeleteConfig, modalResponseTrainedSuccess } from '../../../../../app/core/utils/const-message';
import { chooseColorClassByLastDigit, getObjById, isEmptyObj } from '../../../../../app/core/utils/akeira-utils';
import { Subscription, SubscriptionLike } from 'rxjs';

export interface SearchWord {
    name: string;
}


@Component({
    selector: 'app-training-phrases',
    templateUrl: './training-phrases.component.html',
    styleUrls: ['./training-phrases.component.scss'],
    // tslint:disable-next-line: no-host-metadata-property
    host: {
        '(document:click)': 'functionClick($event)',
    }
})
export class TrainingPhrasesComponent implements OnInit, OnChanges, OnDestroy {

    // Other Page data
    @Input() arr;

    // Pass To other page
    @Output() enableTrainEvent = new EventEmitter<boolean>();
    @Output() enableSaveDraft = new EventEmitter<boolean>();
    @Output() configurationStatus = new EventEmitter<boolean>();

    // TOP
    intentId: number;
    langId: number;
    vaRoleId: number;
    chId: number;
    flag: number;
    newData: any = [];
    IsHidden = true;


    // Left
    fileContent: any;
    orginalContent: any;
    manualPhrase: any = '';
    visible = true;
    selectable = true;
    removable = true;
    addOnBlur = true;
    readonly separatorKeysCodes: number[] = [ENTER, COMMA];
    srchword: SearchWord[] = [];
    upcontent: any;

    hostSelectionLeft: SelectionRectangle | null;
    viewportRectangleLeft: SelectionRectangle | null;
    selectedTextLeft = '';
    posStartLeft: any;
    posEndLeft: any;


    // Right
    showTabNewPhrase = false;

    // Right -- Section 1
    addPhraseArray: any = [];
    currentSelectedtxt = '';
    hostSelectionRight: SelectionRectangle | null;
    viewportRectangleRight: SelectionRectangle | null;
    selectedTextRight = '';
    posStartRight: any;
    posEndRight: any;
    dropdownError;
    intentSlotList: any = [];
    selectedaddPhraseArrayKey: any;

    // Right-- Section 2
    searchTextRight: string;
    pageNum = 1;
    phrases: any = [];
    checkAddArray = true;
    isLoaded = false;

    intentSlots: any = [];
    slotsToDisplay: any = [];
    slotsToDisplayMap = new Map<string, any>();
    counter = 1;
    showSection2Loader = false;
    editFromSavePhrase = false;
    editFromSavePhraseData: any;
    trainingPhraseIntentSlotSubscription: Subscription;
    addTrainingPhraseSubscription: Subscription;
    addTrainingPhraseSubscriptionScroll: Subscription;
    deleteSubscription: Subscription;
    addPhrasedetailSubscription: Subscription;

    constructor(private route: ActivatedRoute, private intentService: CreateIntentService,
                private spinner: NgxSpinnerService, private modalService: BsModalService, private toastr: ToastrService,
                private matDialog: MatDialog, private router: Router, public dialog: MatDialog) {
        this.route.paramMap.subscribe((params: any) => {
            this.intentId = params.params.intId;
            this.langId = params.params.langId;
            this.flag = params.params.flag;
        });
    }

    functionClick($event) {
        if (!this.IsHidden) {
            this.IsHidden = !this.IsHidden;
        }
    }


    ngOnInit() {
        this.searchTextRight = '';
        console.log(this.flag, this.newData);

        if (!this.flag) {
            this.intentId = this.newData[0];
            this.langId = this.newData[1];
            this.chId = this.newData[2];
            this.vaRoleId = this.newData[3];
        }
        this.fetchPageData(this.intentId, this.langId, this.pageNum);
    }

    ngOnDestroy() {
        if (this.trainingPhraseIntentSlotSubscription) {
            this.trainingPhraseIntentSlotSubscription.unsubscribe();
        }
        if (this.addTrainingPhraseSubscription) {
            this.addTrainingPhraseSubscription.unsubscribe();
        }
        if (this.addTrainingPhraseSubscriptionScroll) {
            this.addTrainingPhraseSubscriptionScroll.unsubscribe();
        }
        if (this.deleteSubscription) {
            this.deleteSubscription.unsubscribe();
        }
        if (this.addPhrasedetailSubscription) {
            this.addPhrasedetailSubscription.unsubscribe();
        }
    }

    ngOnChanges() {
        console.log('ngOnChanges', this.intentId, this.langId, this.pageNum, this.searchTextRight);
        this.newData = this.arr;
        // tslint:disable-next-line: no-unused-expression
        this.searchTextRight !== undefined ? this.fetchPageData(this.intentId, this.langId, this.pageNum) : '';
    }

    refreshTrainingPhrase(langId, chID) {
        console.log('----From other page---->', langId, chID);
        this.langId = langId;
        this.chId = chID;
        this.fetchPageData(this.intentId, this.langId, this.pageNum);
    }

    makeStringEmpty = (s) => s === ('' || undefined) ? '' : '';

    fetchPageData(intentId: number, langId: number, pageNum: number) {
        this.spinner.show();
        this.intentSlots = [];
        this.slotsToDisplay = [];
        this.slotsToDisplayMap = new Map<string, any>();
        this.searchTextRight = this.makeStringEmpty(this.searchTextRight);
        this.trainingPhraseIntentSlotSubscription = this.intentService.requestaddTrainingPhraseAndintentSlots(intentId, langId, pageNum, this.searchTextRight).subscribe(responseList => {
            console.log('addTrainingPhrase -->', responseList[0]);
            console.log('intentSlots -->', responseList[1]);

            // intentSlots response
            this.intentSlots = responseList[1]['intentSlots'];
            this.intentSlots.forEach((e, i) => {
                const colorClassName = this.getColorClassById(i);
                e['colorClass'] = colorClassName;
                this.slotsToDisplayMap.set(e.intentSlotId, e);
                this.slotsToDisplay.push({
                    color: colorClassName,
                    value: e.intentSlotName,
                    intentSlotId: e.intentSlotId,
                });
            });

            // addTrainingPhrase response
            // tslint:disable-next-line: no-unused-expression
            (pageNum === 1) ? this.phrases = [] : '';
            const Convphrases = responseList[0]['trainingPhrases'];
            this.displayTrainingPhrases(Convphrases);
            this.spinner.hide();
        }, err => {
            this.spinner.hide();
            console.error('fetchPageData Error', err);
        });

    }

    emitenableTrainEvent(dt) {
        dt.length > 0 ? this.enableTrainEvent.emit(false) : this.enableTrainEvent.emit(true);
    }

    addPhrases(intentId, langId, pageNum) {
        this.searchTextRight = this.makeStringEmpty(this.searchTextRight);
        this.addTrainingPhraseSubscription =  this.intentService.addTrainingPhrase(intentId, langId, pageNum, this.searchTextRight).subscribe(res => {
            if (pageNum === 1) { this.phrases = []; }
            console.log(res);
            const Convphrases = res['trainingPhrases'];
            const status = (Convphrases.length > 0 ? true : false);
            this.configurationStatus.emit(status);
            this.displayTrainingPhrases(Convphrases);
            this.spinner.hide();
        }, err => {
            this.spinner.hide();
            console.log(err);
        });
    }

    onScroll() {
        this.counter += 1;
        this.searchTextRight = this.makeStringEmpty(this.searchTextRight);
        this.showSection2Loader = true;
        console.log('this.counter', this.counter);
        this.addTrainingPhraseSubscriptionScroll = this.intentService.addTrainingPhrase(this.intentId, this.langId, this.counter, this.searchTextRight).subscribe(res => {
            const phrasesOnScroll = res['trainingPhrases'];
            this.displayTrainingPhrases(phrasesOnScroll);
            this.showSection2Loader = false;
        }, err => {
            this.showSection2Loader = false;
            console.error(err);
        });
    }

    getColorClassById(id) {
        return chooseColorClassByLastDigit(id);
    }

    displayTrainingPhrases(phrases) {
        // phrases.length > 0 ? this.isLoaded = true : '';
        this.emitenableTrainEvent(phrases);
        let posPhraseValues: any = [];
        for (let i = 0; i < phrases.length; i++) {
            const trainingPhrases = phrases[i];
            if ((phrases[i].intentSlotMapPojos !== null) && (phrases[i].intentSlotMapPojos.length > 0)) {

                let posPhrase: any; const rxp = /%([^%/]+)%/g; let curMatch; const postionArray: string[] = [];
                posPhrase = trainingPhrases.trainingPhraseText;
                for (let k = 0; k < trainingPhrases.intentSlotMapPojos.length; k++) {
                    postionArray.push(trainingPhrases.intentSlotMapPojos[k].position);
                    // tslint:disable-next-line: no-conditional-assignment
                    while ((curMatch = rxp.exec(posPhrase))) {
                        if (trainingPhrases.intentSlotMapPojos[k].position === curMatch[1]) {
                            posPhrase = (posPhrase.replace(
                                curMatch[1],
                                trainingPhrases.intentSlotMapPojos[k].value));
                            posPhraseValues = posPhrase.replace(/%/g, '');
                        }
                    }
                }
                trainingPhrases['trainingPhraseDisplay'] = posPhraseValues;
                trainingPhrases['mappedHighlightData'] = this.genrateHighlightdata(posPhraseValues, true, postionArray, trainingPhrases.intentSlotMapPojos);
                console.log('trainingPhrases -->', trainingPhrases);
            } else {
                trainingPhrases['trainingPhraseDisplay'] = trainingPhrases.trainingPhraseText;
                trainingPhrases['mappedHighlightData'] = this.genrateHighlightdata(trainingPhrases.trainingPhraseText, false, [], '');
                trainingPhrases['intentSlotMapPojos'] = [];
            }
            this.phrases.push(trainingPhrases);
        }
        console.log('update phrases --- ', this.phrases.length);
    }

    genrateHighlightdata(txt: string, isMapped: boolean, postionArray: string[], intentSlotMapPojos: any) {
        console.log('text', txt, isMapped, postionArray, intentSlotMapPojos);
        const txtArray = txt.split(' '); const renderJson = []; const colorArray = [];
        txtArray.forEach((e, i) => { renderJson.push({ index: i, value: e, isHighlight: false, key: ('pos' + i) }); });
        if (isMapped) {
            // tslint:disable-next-line: prefer-const
            for (let key of postionArray) { colorArray.push(key.split('~')); }
            const outputColorArray = [].concat(...colorArray);
            // tslint:disable-next-line: forin , prefer-const , forin
            for (let k in renderJson) {
                // tslint:disable-next-line: prefer-const
                for (let j in outputColorArray) {
                    if (renderJson[k]['key'] === outputColorArray[j]) {
                        renderJson[k]['isHighlight'] = true;
                        renderJson[k]['colorClass'] = this.getColorCodeByPostion(renderJson[k]['key'], intentSlotMapPojos);
                        break;
                    }
                }
            }
        }
        return renderJson;
    }

    getColorCodeByPostion(pos, intentSlotMapPojosList) {
        let keyIntent = '';
        const regex = new RegExp('\\b(' + pos + ')\\b');
        // tslint:disable-next-line: prefer-const
        for (let intent in intentSlotMapPojosList) {
            if (intentSlotMapPojosList[intent]['position'].search(regex) >= 0) {
                keyIntent = intentSlotMapPojosList[intent]['intentSlot']['intentSlotId'];
                break;
            }
        }
        console.log('########### ', this.slotsToDisplayMap, keyIntent);
        return this.slotsToDisplayMap.get(keyIntent)['colorClass'];
    }

    traniedPhraseEdit(index: number, phraseId: number) {
        const tempAry = cloneDeep(this.phrases[index]);
        console.log(tempAry);
        if (this.checkIfNewPhraseHas(phraseId)) {
            // Add to new phrases list
            this.addPhraseArray.push(tempAry);
            this.showTabNewPhrase = true;
        } else {
            this.openModalAlreadyAdded();
        }
        this.emitenableSaveDraft();
    }

    checkIfNewPhraseHas(phraseId) {
        // tslint:disable-next-line: prefer-const
        for (let i in this.addPhraseArray) {
            if (this.addPhraseArray[i]['trainingPhraseId'] === phraseId) {
                return false;
            }
        }
        return true;
    }

    openModalAlreadyAdded() {
        this.dialog.open(ModalComponent, {
            disableClose: true,
            data: modalEditTrained
        });
    }

    openModalDelete(id: any, value: any, index: any) {
        const dialogRef = this.dialog.open(ModalComponent, {
            disableClose: true,
            data: modalDeleteConfig
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result) {
                this.deleteTrainingPhraseCall(id);
            }
        });
        console.log(this.phrases.length);
    }

    deleteTrainingPhraseCall(idToDelete) {
       this.deleteSubscription = this.intentService
            .deleteTrainingPhrase(this.intentId, this.langId, idToDelete)
            .subscribe(res => {
                console.log(res);
                this.addPhrases(this.intentId, this.langId, this.pageNum);
            }, err => {
                console.error(err);
            });
    }

    onselectFile(data) {
        const allowedext = ['application/vnd.ms-excel', 'text/plain'];
        const file = data[0];
        if (allowedext.includes(file.type)) {
            if (file.size < 1048576) {
                this.fileContent = '';
                this.orginalContent = '';
                const fileReader: FileReader = new FileReader();
                const that = this;
                fileReader.onloadend = (x) => {
                    that.fileContent = fileReader.result;
                    that.orginalContent = fileReader.result;
                };
                fileReader.readAsText(file);
            } else {
                this.openModalFilesizeLimit();
            }

        } else {
            this.openModalFileError();

        }
    }

    openModalFileError() {
        this.dialog.open(ModalComponent, {
            disableClose: true,
            data: modalFileErrorConfig
        });
    }

    openModalFilesizeLimit() {
        this.dialog.open(ModalComponent, {
            disableClose: true,
            data: modalFileSizeConfig
        });
    }

    serachWord(event: MatChipInputEvent): void {
        const input = event.input;
        const value = event.value;
        console.log(input, value);
        if ((value || '').trim()) {
            this.srchword.push({ name: value.trim() });
            const splitary = [];
            for (let i = 0; i < this.srchword.length; i++) {
                splitary.push(this.srchword[i].name);
            }
            const convertstr = splitary.toString();
            console.log(convertstr);
            const replacedata = convertstr.replace(/,/g, ' ');
            console.log(replacedata);
            let filteredText = this.fileContent;
            if (splitary !== null) {
                const keywordList = this.stringToArray(replacedata);
                const pattern = this.getRegexPattern(keywordList);
                console.log(pattern);
                filteredText = this.fileContent.replace(pattern, '<span class="training_phrse_sch_highlight">$2</span>');

            } else {
                console.log('splitary emmpty');
            }
            this.fileContent = filteredText;

        }
        if (input) {
            input.value = '';
        }
    }

    stringToArray(keywrd) {
        console.log(keywrd);
        if (keywrd) {
            const dat = keywrd.match(/\S+/g);
            return dat;

        } else {
            return [];
        }
    }

    getRegexPattern(patrn) {
        const pattern = '(^|\\b)(' + patrn.join('|') + ')';

        return new RegExp(pattern, 'gi');
    }



    // serachWord(event: MatChipInputEvent): void {
    //     const input = event.input;
    //     const value = event.value;
    //     if ((value || '').trim()) {
    //         this.srchword.push({ name: value.trim() });
    //         if (this.srchword[0].name != undefined) {
    //             this.highlightSearchTxt();
    //         }
    //     }
    //     // Reset the input value
    //     if (input) {
    //         input.value = '';
    //     }
    // }

    onEnter(phrase, value) {
        this.addNewPhrase(phrase, value);
    }

    highlightSearchTxt() {
        let searchkeyWord: any;
        for (let i = 0; i < this.srchword.length; i++) {

            searchkeyWord = this.srchword[i].name;
            if (!searchkeyWord) {
                return this.fileContent;
            }
            const gf = this.fileContent.replace(new RegExp(searchkeyWord, 'gi'), match => {
                console.log(match);
                return '<span class="training_phrse_sch_highlight">' + match + '</span>';
            });
            this.fileContent = gf;

        }
    }

    // remove(data: SearchWord): void {
    //     const index = this.srchword.indexOf(data);
    //     if (index >= 0) {
    //         this.srchword.splice(index, 1);
    //         if (this.srchword.length > 0) {
    //             for (var i = 0; i < this.srchword.length; i++) {
    //                 let remov = this.srchword[i].name;
    //                 if (i == 0) {
    //                     this.upcontent = this.orginalContent
    //                 } else {
    //                     this.upcontent = this.fileContent
    //                 }
    //                 var gf = this.upcontent.replace(new RegExp(remov, 'gi'), match => {
    //                     console.log(match);
    //                     return '<span class='training_phrse_sch_highlight'>' + match + '</span>';
    //                 });
    //                 this.fileContent = gf;
    //             }
    //         }
    //         else {
    //             return this.fileContent = this.orginalContent;
    //         }
    //     }
    // }

    remove(data: SearchWord): void {
        const index = this.srchword.indexOf(data);
        if (index >= 0) {
            this.srchword.splice(index, 1);

            const splitary = [];
            for (let i = 0; i < this.srchword.length; i++) {
                splitary.push(this.srchword[i].name);
            }
            const convertstr = splitary.toString();
            console.log(convertstr);
            const replacedata = convertstr.replace(/,/g, ' ');
            console.log(replacedata);
            let filteredText = this.orginalContent;
            if (splitary !== null) {
                const keywordList = this.stringToArray(replacedata);
                const pattern = this.getRegexPattern(keywordList);
                console.log(pattern);
                filteredText = this.orginalContent.replace(pattern, '<span class="training_phrse_sch_highlight">$2</span>');

            } else {
                console.log('splitary emmpty');
            }
            this.fileContent = filteredText;

        }
    }

    public renderSelectionLeft(event: TextSelectEvent): void {
        console.group('Left Text Select Event <----');
        console.log('Event:', event);
        console.log('Text:', event.text);
        console.log('start:', event.posStart);
        console.log('end:', event.posEnd);
        console.log('Viewport Rectangle:', event.viewportRectangle);
        console.log('Host Rectangle:', event.hostRectangle);
        console.groupEnd();

        if (event.hostRectangle) {
            this.hostSelectionLeft = event.hostRectangle;
            this.viewportRectangleLeft = event.viewportRectangle;
            this.selectedTextLeft = event.text;
            this.posStartLeft = event.posStart;
            this.posEndLeft = event.posEnd;
        } else {
            this.hostSelectionLeft = null;
            this.viewportRectangleLeft = null;
            this.selectedTextLeft = '';
        }
    }

    getcopiedData() {
        const cptxt = this.selectedTextLeft.replace(/\r/g, '').replace(/\n/g, '');
        this.hostSelectionLeft = null;
        this.viewportRectangleLeft = null;
        this.addNewPhrase(cptxt, false);
        // Now that we've shared the text, let's clear the current selection.
        document.getSelection().removeAllRanges();
        this.hostSelectionLeft = null;
        this.viewportRectangleLeft = null;
        this.selectedTextLeft = '';
    }

    addNewPhrase(txt, onEdit) {
        console.log('txt', txt);
        if (txt === '' || txt === undefined || txt == null || txt === ' ') {
            console.log('please enter data');
        } else {
            const addtxt = txt.replace(/^\s+/, '').replace(/\s+$/, '');
            console.log('addNewPhrase ---> ', txt, onEdit);
            // this.checkAddArray = false;
            // this.enableTrainEvent.emit(this.checkAddArray);
            let newPhraseSlotDetails = {};
            if (this.editFromSavePhrase) {
                newPhraseSlotDetails = {
                    intentSlotMapPojos: [],
                    trainingPhraseId: this.editFromSavePhraseData['trainingPhraseId'],
                    trainingPhraseText: addtxt,
                    trainingPhraseDisplay: addtxt,
                    mappedHighlightData: this.genrateHighlightdata(addtxt, false, [], '')
                };
            } else {
                newPhraseSlotDetails = {
                    intentSlotMapPojos: [],
                    trainingPhraseId: 0,
                    trainingPhraseText: addtxt,
                    trainingPhraseDisplay: addtxt,
                    mappedHighlightData: this.genrateHighlightdata(addtxt, false, [], '')
                };
            }
            this.addPhraseArray.push(newPhraseSlotDetails);
            this.showTabNewPhrase = true;
            this.manualPhrase = '';
            this.editFromSavePhrase = false;
            this.editFromSavePhraseData = '';
        }
        this.emitenableSaveDraft();

    }

    emitenableSaveDraft() {
        this.addPhraseArray.length > 0 ? this.enableSaveDraft.emit(false) : this.enableSaveDraft.emit(true);
    }

    editAddPhrase(index: number) {
        const ph = this.addPhraseArray[index];
        console.log(ph);
        if (this.addPhraseArray[index]['trainingPhraseId'] !== 0) {
            this.editFromSavePhrase = true;
            this.editFromSavePhraseData = this.addPhraseArray[index];
            this.manualPhrase = this.addPhraseArray[index].trainingPhraseDisplay;
            this.addPhraseArray.splice(index, 1);
        } else {
            this.editFromSavePhrase = false;
            this.manualPhrase = this.addPhraseArray[index].trainingPhraseDisplay;
            this.addPhraseArray.splice(index, 1);
        }
    }

    openModalAddPhraseEdit(index: number) {
        if (this.manualPhrase !== '') {
            const dialogRef = this.dialog.open(ModalComponent, {
                disableClose: true, data: modalEditConfig
            });
            dialogRef.afterClosed().subscribe(result => {
                // tslint:disable-next-line: no-unused-expression
                result ? this.editAddPhrase(index) : '';
            });
        } else {
            this.editAddPhrase(index);
        }
    }

    openModalAddPhraseDelete(index: number) {
        const dialogRef = this.dialog.open(ModalComponent, {
            disableClose: true, data: modalDeleteConfig
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result) {
                this.addPhraseArray.splice(index, 1);
                this.emitenableSaveDraft();
            }
        });
    }

    public renderSelectionRight(event: TextSelectEvent, key: any): void {
        console.group('Right Text Select Event ---->');
        console.log('Event:', event);
        console.log('Text:', event.text);
        console.log('start:', event.posStart);
        console.log('end:', event.posEnd);
        console.log('Viewport Rectangle:', event.viewportRectangle);
        console.log('Host Rectangle:', event.hostRectangle);
        console.groupEnd();

        if (event.hostRectangle) {
            this.hostSelectionRight = event.hostRectangle;
            this.viewportRectangleRight = event.viewportRectangle;
            this.selectedTextRight = event.text;
            if (event.posStart > event.posEnd) {
                this.posStartRight = event.posEnd;
                this.posEndRight = event.posStart;
            } else {
                this.posStartRight = event.posStart;
                this.posEndRight = event.posEnd;
            }
            this.posStartRight = this.checkForFirstSpace(event.text) ? this.posStartRight = (this.posStartRight + 1) : this.posStartRight;
            // console.log(this.posStartRight, this.posEndRight, this.checkForFirstSpace(event.text));
            this.showIntentSlotsDropdown(key);
        } else {
            this.clearRightSelection();
        }
    }
    checkForFirstSpace = (t) => t.search(/^\S.*$/) === -1;
    checkEmpty = (t) => t != null && t !== '' ? true : false;

    clearRightSelection() {
        this.hostSelectionRight = null;
        this.viewportRectangleRight = null;
        this.selectedTextRight = '';
    }

    showIntentSlotsDropdown(key: any) {
        this.currentSelectedtxt = '';
        this.selectedaddPhraseArrayKey = key;
        const currentWords = this.selectedTextRight.replace(/^\s+/, '').replace(/\s+$/, '');
        if (this.intentSlots.length > 0 && this.checkEmpty(currentWords)) {
            const displayedtext = this.addPhraseArray[key]['trainingPhraseDisplay'];
            const regex = new RegExp('\\b(' + currentWords + ')\\b');
            const isCurrectWords = displayedtext.search(regex);
            this.currentSelectedtxt = currentWords;
            if (isCurrectWords > -1) {
                const mappedSlot = this.addPhraseArray[key].intentSlotMapPojos;
                const slotAry = [];
                mappedSlot.forEach(e => {
                    slotAry.push(e.intentSlot.intentSlotId);
                });
                this.openSlotsDropdown(key, slotAry);
            } else {
                this.dropdownError = 'Select proper words';
                this.intentSlotList = [];
            }
        } else {
            this.clearRightSelection();
        }
    }

    openSlotsDropdown(key: any, slotAry) {
        this.dropdownError = 'Choose an Intent slot';
        this.intentSlotList = [];
        this.slotsToDisplay.forEach(e => {
            e['active'] = true;
            for (let x = 0; x < slotAry.length; x++) {
                // tslint:disable-next-line: no-unused-expression
                slotAry[x] === e['intentSlotId'] ? e['active'] = false : '';
            }
            this.intentSlotList.push(e);
        });
        console.log('this.intentSlotList', this.intentSlotList);
    }

    getIntentSlotValue(x) {
        console.log('selectedslot', x, this.selectedaddPhraseArrayKey);
        console.log('--obj-> ', this.addPhraseArray[this.selectedaddPhraseArrayKey]);
        const txtary = this.currentSelectedtxt.split(' ');
        const posData = this.getPOSTIONoftxt(txtary, this.addPhraseArray[this.selectedaddPhraseArrayKey]['mappedHighlightData']);
        console.log(posData);
        if (posData !== undefined) {
            // tslint:disable-next-line: no-shadowed-variable
            for (let x = 0; x < posData.posAry.length; x++) {
                const regex = new RegExp('\\b(' + posData.posAry[x] + ')\\b');
                for (let i = 0; i < this.addPhraseArray[this.selectedaddPhraseArrayKey]['intentSlotMapPojos'].length; i++) {
                    console.log(i, this.addPhraseArray[this.selectedaddPhraseArrayKey]['intentSlotMapPojos'][i], regex);
                    if (this.addPhraseArray[this.selectedaddPhraseArrayKey]['intentSlotMapPojos'][i]['position'].search(regex) >= 0) {
                        this.addPhraseArray[this.selectedaddPhraseArrayKey]['intentSlotMapPojos'].splice(i, 1); break;
                    }
                }
            }
        }
        const intentSlotMapPojo = {
            position: posData.pos,
            value: this.currentSelectedtxt,
            intentSlot: x,
        };
        this.addPhraseArray[this.selectedaddPhraseArrayKey]['intentSlotMapPojos'].push(intentSlotMapPojo);
        this.addPhraseArray[this.selectedaddPhraseArrayKey]['trainingPhraseText'] = this.coloringPhrase(this.addPhraseArray[this.selectedaddPhraseArrayKey]);

        // Now that we've shared the text, let's clear the current selection.
        document.getSelection().removeAllRanges();
        this.clearRightSelection();
        console.log('------> ', this.addPhraseArray);
    }

    getPOSTIONoftxt(txtary: any, mappedHighlightData: any) {
        const posAry = [];
        let pos = 'pos' + this.posStartRight++;
        posAry.push(pos);
        while (this.posStartRight <= this.posEndRight) {
            const i = this.posStartRight++;
            posAry.push('pos' + i);
            pos += '~pos' + i;
        }
        // tslint:disable-next-line: object-literal-shorthand
        const posdata = { posAry: posAry, pos: pos };
        return posdata;
    }

    coloringPhrase(phrase) {
        console.log('phrase <3', phrase);
        const outputColorArray = [].concat(...this.colorArrayGenrater(phrase['intentSlotMapPojos']));
        return this.colorDisplayTextAndGenrateInnerPhase(phrase, outputColorArray);
    }

    colorArrayGenrater(intentSlotMapPojos) {
        const colorArray = [];
        for (let i = 0; i < intentSlotMapPojos.length; i++) {
            colorArray.push(intentSlotMapPojos[i]['position'].split('~'));
        }
        return colorArray;
    }

    colorDisplayTextAndGenrateInnerPhase(phrase, outputColorArray) {
        console.log(phrase, outputColorArray);
        let innerPhase = ''; let dontAdd = false; const rxp = /%[ /]%/g;
        for (let i = 0; i < phrase['mappedHighlightData'].length; i++) {
            phrase['mappedHighlightData'][i]['isHighlight'] = false;
            // tslint:disable-next-line: prefer-const
            for (let j in outputColorArray) {
                if (phrase['mappedHighlightData'][i]['key'] === outputColorArray[j]) {
                    phrase['mappedHighlightData'][i]['isHighlight'] = true;
                    phrase['mappedHighlightData'][i]['colorClass'] = this.getColorCodeByPostion(phrase['mappedHighlightData'][i]['key'], phrase['intentSlotMapPojos']);
                    innerPhase += '%' + phrase['mappedHighlightData'][i]['key'] + '% ';
                    dontAdd = false;
                    break;
                } else {
                    dontAdd = true;
                }
            }
            // tslint:disable-next-line: no-unused-expression
            dontAdd ? innerPhase += phrase['mappedHighlightData'][i]['value'] + ' ' : '';
        }
        // .replace(rxp, '~') moved out of bug -- BG
        innerPhase = innerPhase.replace(/^\s+/, '').replace(/\s+$/, '');
        let txtArray = []; let clearAry = [];
        for (let x = 0; x < phrase['intentSlotMapPojos'].length; x++) {
            console.log(phrase['intentSlotMapPojos'][x]['position']);
            const key = phrase['intentSlotMapPojos'][x]['position'];
            if (key.includes('~')) {
                txtArray = innerPhase.split(' ');
                let firstTime = true;
                // tslint:disable-next-line: forin , prefer-const
                for (let z in txtArray) {
                    const rxpPer = /[%]/g;
                    const yesPerThr = rxpPer.test(txtArray[z]);
                    txtArray[z] = txtArray[z].replace(/[%]/g, '');
                    console.log('yesPerThr', yesPerThr, txtArray[z]);
                    if (key.includes(txtArray[z])) {
                        if (firstTime) { txtArray[z] = '%' + key + '%'; firstTime = false; } else { txtArray[z] = ''; }
                    } else {
                        txtArray[z] = yesPerThr ? '%' + txtArray[z] + '%' : txtArray[z];
                    }
                }
                clearAry = txtArray.filter(n => n);
            }
            innerPhase = clearAry.length > 0 ? clearAry.join(' ') : innerPhase;
        }
        console.log('innerPhase  -->', innerPhase);
        // tslint:disable-next-line: no-unused-expression
        innerPhase === '' ? innerPhase = phrase['trainingPhraseDisplay'] : '';
        return innerPhase;
    }

    saveAddedTrainingPhrases() {
        this.spinner.show();
        this.flag = 1;
        for (let i = 0; i < this.addPhraseArray.length; i++) {
            delete this.addPhraseArray[i].trainingPhraseDisplay;
        }

        if (this.addPhraseArray.length > 0) {
           this.addPhrasedetailSubscription = this.intentService.addPhraseDetails(this.intentId, this.langId, this.addPhraseArray).subscribe(res => {
                if (res['errorBody'] !== null) {
                    this.spinner.hide();
                    this.dialog.open(ModalComponent, {
                        disableClose: true, data: modalResponseTrainedError
                    });
                } else {
                    this.spinner.hide();
                    this.emitenableSaveDraft();
                    this.dialog.open(ModalComponent, {
                        disableClose: true, data: modalResponseTrainedSuccess
                    });
                    const convPhrases = res['trainingPhrases'];
                    this.displayTrainingPhrases(convPhrases);
                    this.addPhrases(this.intentId, this.langId, this.pageNum);
                }
            }, err => {
                this.spinner.hide();
                console.error(err);
                this.dialog.open(ModalComponent, {
                    disableClose: true, data: modalResponseTrainedError
                });
            });
            // tslint:disable-next-line: align
            this.addPhraseArray = [];
        } else {
            this.spinner.hide();
        }
    }

    clearIntentPhrase(i) {
        console.log('clearIntentPhrase ', i, this.addPhraseArray[i]);
        this.addPhraseArray[i]['intentSlotMapPojos'] = [];
        this.addPhraseArray[i]['trainingPhraseText'] = this.coloringPhrase(this.addPhraseArray[i]);
    }
}

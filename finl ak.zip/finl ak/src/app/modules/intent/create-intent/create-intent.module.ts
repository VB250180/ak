
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, OnInit, ViewChild, Output, EventEmitter, Input, Renderer2, ElementRef, ViewContainerRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreateIntentLeftComponent } from './create-intent-left/create-intent-left.component';
import { CreateIntentRightComponent } from './create-intent-right/create-intent-right.component';
import { TrainingPhrasesComponent } from './training-phrases/training-phrases.component';
import { CreateIntentRoutingModule } from './create-intent-routing.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgxSpinnerModule } from 'ngx-spinner';
import { SharedModule } from 'src/app/shared.module';
import { MatMenuModule } from '@angular/material/menu';
import { CreateIntentComponent } from './create-intent.component';
import { NgxCacheIfModule } from 'ngx-cache-if';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { RichCardViewGetInfoComponent } from './create-intent-right/rich-card-view-get-info/rich-card-view-get-info.component';
import { RichCardViewFinalResponseComponent } from './create-intent-right/rich-card-view-final-response/rich-card-view-final-response.component';


@NgModule({
  declarations: [
    CreateIntentLeftComponent,
    CreateIntentRightComponent,
    TrainingPhrasesComponent,
    CreateIntentComponent,
    RichCardViewGetInfoComponent,
    RichCardViewFinalResponseComponent,
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    NgSelectModule,
    NgxSpinnerModule,
    CreateIntentRoutingModule,
    SharedModule,
    MatMenuModule,
    NgxCacheIfModule,
    AccordionModule.forRoot(),
    DragDropModule
  ],


  schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],

})
export class CreateIntentModule { }

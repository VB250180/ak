import { TrainingPhrasesComponent } from './training-phrases/training-phrases.component';
import { async, ComponentFixture, TestBed, fakeAsync, inject } from '@angular/core/testing';
import { CreateIntentLeftComponent } from './create-intent-left/create-intent-left.component';
import { CreateIntentRightComponent } from './create-intent-right/create-intent-right.component';
import { CreateIntentComponent } from './create-intent.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, TemplateRef, Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormControl } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CreateIntentService } from '../../../core/services/create-intent/create-intent.service';
import { NgxCacheIfModule } from 'ngx-cache-if';
import { BsModalService, ModalModule, BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { RouterModule } from '@angular/router';
import { APP_BASE_HREF } from '@angular/common';
import { of, empty, Subject, Observable } from 'rxjs';
import 'rxjs/add/observable/of';
import { MatDialog } from '@angular/material';
import { NgSelectModule } from '@ng-select/ng-select';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';

class CreateIntentServiceStub {
  virtualAgents = new Subject();

  constructor() { }

  public changeMessage(message: string) { }

  public saveCreateIntent(vaRoleId, saveIntentForm) {
    return Observable.of({
      intent: {
        intentName: 'Name',
        intentId: 'ID',
        languages: [
          {
            langEngId: 'en-id',
            channels: [
              { channelId: 'ch-id' }
            ]
          }
        ]
      }
    });
  }
  public updateCreateIntent(vaRoleId, intentId, saveIntentForm) {
    return Observable.of({ virtualAgents: 'abc' });
  }
  public getIntent(roleId, intentId) {
    return Observable.of({ intent: { intentName: 'Akira', intentDescription: 'Description', intentType: 'Type', languages: [] } });
  }
  public getIntentConversionList(intentId, langId, chId): Observable<any> {
    return Observable.of({ conversation: { conversationStages: [], validationIntent: '' } });
  }
  public saveConversations(saveConversation, intentId, langEngId, channelId) {
    return Observable.of({ virtualAgents: 'abc' });
  }

  public getSystemSlotDropdown() {
    return Observable.of({ virtualAgents: 'abc' });
  }
  public getIntentsDropdown(vaRoleId, intentId) {
    return Observable.of({ virtualAgents: 'abc' });
  }

  public addTrainingPhrase(intentId, langId, pageNo, text) {
    return Observable.of({ virtualAgents: 'abc' });
  }

  public requestaddTrainingPhraseAndintentSlots(intentId, langId, pageNo, text): Observable<any[]> {
    return Observable.of([]);
  }

  public deleteTrainingPhrase(intentId, langId, phraseId, text) {
    return Observable.of({ virtualAgents: 'abc' });
  }

  public intentSlots(intentId, langId) {
    return Observable.of({ virtualAgents: 'abc' });
  }

  public addPhraseDetails(intentId, langId, phrases) {
    return Observable.of({ virtualAgents: 'abc' });
  }
  public getEntitys() {
    return Observable.of({ virtualAgents: 'abc' });
  }
  public virtualAgent() {
    return Observable.of({ virtualAgents: [] });
  }

  public addTrainingPhraseDialogFlow(langId, vaId) {
    return Observable.of({ virtualAgents: 'abc' });
  }

  public getVAdetailsByUserId(userId: number): Observable<any> {
    return Observable.of({
      virtualAgents: []
    });
  }

}

class ToastrServiceStub {
  public warning(message, title) { }
  public success(message, title) { }
}

class MatDialogStub {
  public open(template, config) { }
}

class AuthenticationServiceStub {
  getCurrentUserId() {
      return 1;
  }
}

describe('CreateIntentComponent', () => {
  let component: CreateIntentComponent;
  let fixture: ComponentFixture<CreateIntentComponent>;
  // tslint:disable-next-line: prefer-const
  let template: TemplateRef<any>;


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        BsModalService,
        BsModalRef,
        CreateIntentLeftComponent,
        { provide: ToastrService, useClass: ToastrServiceStub },
        { provide: CreateIntentService, useClass: CreateIntentServiceStub },
        { provide: AuthenticationService, useClass: AuthenticationServiceStub },
        { provide: MatDialog, useClass: MatDialogStub }
        // CreateIntentService
      ],
      declarations: [CreateIntentComponent, TrainingPhrasesComponent],
      imports: [
        BrowserAnimationsModule,
        RouterTestingModule,
        HttpClientTestingModule,
        RouterModule.forRoot([]),
        FormsModule,
        ReactiveFormsModule,
        NgSelectModule,
        ModalModule.forRoot(),
        NgxCacheIfModule],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));


  beforeEach(() => {
    fixture = TestBed.createComponent(CreateIntentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open the modal', () => {
    const modalService = TestBed.get(BsModalService);
    const spy = spyOn(modalService, 'show');

    component.openModalTrainInput(template);

    expect(spy).toHaveBeenCalled();
  });

  it('should return null if there are no whitespaces in input field', () => {
    const control = new FormControl();
    control.setValue('ValueWithNoSpace');

    expect(component.noWhitespaceValidator(control)).toBeNull();
  });

  it('should return true if there are whitespaces in input field', () => {
    const control = new FormControl();
    control.setValue('');

    expect(component.noWhitespaceValidator(control)).toBeTruthy();
  });

  it('should set vaRoleDisable and enableNext to true and call getIntentsEdit method', () => {
    component.vaRoleId = 'Admin';
    const spy = spyOn(component, 'getIntentsEdit');

    component.callGetIntentsEditData();

    expect(component.vaRoleDisable).toBeTruthy();
    expect(component.enableNext).toBeTruthy();
    expect(spy).toHaveBeenCalledWith(component.vaRoleId, component.intentId);
  });

  it('should call callGetIntentsEditData method', () => {
    const spy = spyOn(component, 'callGetIntentsEditData');

    component.virtualAgents();

    expect(spy).toHaveBeenCalled();
  });

  it('should initialize the correct values returned by service in and call displayDropdownValues method in getIntentsEdit method', () => {
    const spy = spyOn(component, 'displayDropdownValues');
    component.vaRoleId = 'Admin';

    component.getIntentsEdit('', '');

    expect(component.intentResName).toBe('Akira');
    expect(component.saveIntentForm.controls['intentName'].value).toBe('Akira');
    expect(component.saveIntentForm.controls['intentDescription'].value).toBe('Description');
    expect(component.saveIntentForm.controls['intentType'].value).toBe('Type');
    expect(component.saveIntentForm.controls['virtualAgent'].value).toBe(component.vaRoleId);
    expect(component.intentDetails.length).toBe(0);
    expect(spy).toHaveBeenCalledWith(component.intentDetails);
    expect(component.intentInfoStatus).toBeTruthy();
  });

  it('displayDropdownValues method should initialize the values correctly', () => {
    component.chId = 'chId';
    component.langId = 'en-uk';
    const langObj = {
      langEngId: 'en-uk',
      channels: [{ channelId: 'chId', channelName: 'channelName' }],
      langName: 'English',
    };
    const intentDetails = [langObj];

    component.displayDropdownValues(intentDetails);

    expect(component.languages).toBe(intentDetails);
    expect(component.language).toBe('English');
    expect(component.channel).toBe('channelName');
  });

  // it('conversationTab method should display a warning when enableNext is not true', () => {
  //   let toastr = TestBed.get(ToastrService);
  //   let spy = spyOn(toastr, 'warning');
  //   component.enableNext = false;

  //   component.conversationTab();

  //   expect(spy).toHaveBeenCalled();
  // });

  // it('conversationTab method should initialize correctly when enableNext is true', () => {
  //   let toastr = TestBed.get(ToastrService);
  //   let spy = spyOn(toastr, 'warning');
  //   component.enableNext = true;
  //   component.intentId = 'ID';

  //   component.conversationTab();

  //   expect(component.parentMessageIntentId).toBe(component.intentId);
  //   expect(component.showIntent).toBeFalsy();
  //   expect(component.showConversation).toBeTruthy();
  //   expect(component.showAddPhrases).toBeFalsy();
  //   expect(spy).toHaveBeenCalledTimes(0);
  // });

  it('addTab method should initialize correct values', () => {

    component.addTab();

    expect(component.showIntent).toBeFalsy();
    expect(component.showConversation).toBeFalsy();
    expect(component.showAddPhrases).toBeTruthy();
  });

  it('saveasDraft method should only call saveDraftIntent method when showIntent is true', () => {
    const saveDraftIntentSpy = spyOn(component, 'saveDraftIntent');
    const saveDraftConversationTempSpy = spyOn(component, 'saveDraftConversationTemp');
    const saveDraftTrainingPhrasesSpy = spyOn(component, 'saveDraftTrainingPhrases');
    component.showIntent = true;

    component.saveasDraft();

    expect(saveDraftIntentSpy).toHaveBeenCalled();
    expect(saveDraftConversationTempSpy).toHaveBeenCalledTimes(0);
    expect(saveDraftTrainingPhrasesSpy).toHaveBeenCalledTimes(0);
  });

  it('saveasDraft method should only call saveDraftConversationTemp method when showIntent is false and showConversation is true', () => {
    const saveDraftIntentSpy = spyOn(component, 'saveDraftIntent');
    const saveDraftConversationTempSpy = spyOn(component, 'saveDraftConversationTemp');
    const saveDraftTrainingPhrasesSpy = spyOn(component, 'saveDraftTrainingPhrases');
    component.showIntent = false;
    component.showConversation = true;

    component.saveasDraft();

    expect(saveDraftIntentSpy).toHaveBeenCalledTimes(0);
    expect(saveDraftConversationTempSpy).toHaveBeenCalled();
    expect(saveDraftTrainingPhrasesSpy).toHaveBeenCalledTimes(0);
  });

  it('saveasDraft method should only call saveDraftTrainingPhrases method when showIntent and showConversation both are false', () => {
    const saveDraftIntentSpy = spyOn(component, 'saveDraftIntent');
    const saveDraftConversationTempSpy = spyOn(component, 'saveDraftConversationTemp');
    const saveDraftTrainingPhrasesSpy = spyOn(component, 'saveDraftTrainingPhrases');
    component.showIntent = false;
    component.showConversation = false;

    component.saveasDraft();

    expect(saveDraftIntentSpy).toHaveBeenCalledTimes(0);
    expect(saveDraftConversationTempSpy).toHaveBeenCalledTimes(0);
    expect(saveDraftTrainingPhrasesSpy).toHaveBeenCalled();
  });

  it('saveasDraft method should only call saveDraftTrainingPhrases method when showIntent and showConversation both are false', () => {
    const saveDraftIntentSpy = spyOn(component, 'saveDraftIntent');
    const saveDraftConversationTempSpy = spyOn(component, 'saveDraftConversationTemp');
    const saveDraftTrainingPhrasesSpy = spyOn(component, 'saveDraftTrainingPhrases');
    component.showIntent = false;
    component.showConversation = false;

    component.saveasDraft();

    expect(saveDraftIntentSpy).toHaveBeenCalledTimes(0);
    expect(saveDraftConversationTempSpy).toHaveBeenCalledTimes(0);
    expect(saveDraftTrainingPhrasesSpy).toHaveBeenCalled();
  });

  it('saveDraftIntent method should return from method immediately if saveIntentForm is not valid', () => {
    const toastr = TestBed.get(ToastrService);
    const toastrSpy = spyOn(toastr, 'success');
    const displayDropdownValuesSpy = spyOn(component, 'displayDropdownValues');

    expect(component.saveDraftIntent()).toBeTruthy();

    expect(component.savebtn).toBeTruthy();
    expect(displayDropdownValuesSpy).toHaveBeenCalledTimes(0);
    expect(toastrSpy).toHaveBeenCalledTimes(0);
  });

  it('saveDraftIntent method should call only toster success method if intentId is not null', () => {
    const toastr = TestBed.get(ToastrService);
    const toastrSpy = spyOn(toastr, 'success');
    const displayDropdownValuesSpy = spyOn(component, 'displayDropdownValues');
    component.saveIntentForm.controls['intentName'].setValue('Name');
    component.saveIntentForm.controls['intentDescription'].setValue('Description');
    component.saveIntentForm.controls['virtualAgent'].setValue('VA');
    component.saveIntentForm.controls['intentType'].setValue('Type');
    component.intentId = 'ID';

    expect(component.saveDraftIntent()).toBe(undefined);

    expect(component.savebtn).toBeTruthy();
    expect(displayDropdownValuesSpy).toHaveBeenCalledTimes(0);
    expect(toastrSpy).toHaveBeenCalled();
  });

  it('saveDraftIntent method should call only toster success method if intentId is not null', () => {
    const toastr = TestBed.get(ToastrService);
    const toastrSpy = spyOn(toastr, 'success');
    const displayDropdownValuesSpy = spyOn(component, 'displayDropdownValues');
    component.saveIntentForm.controls['intentName'].setValue('Name');
    component.saveIntentForm.controls['intentDescription'].setValue('Description');
    component.saveIntentForm.controls['virtualAgent'].setValue('VA');
    component.saveIntentForm.controls['intentType'].setValue('Type');
    component.intentId = null;

    expect(component.saveDraftIntent()).toBe(undefined);

    expect(component.savebtn).toBeTruthy();
    expect(component.intentResName).toBe('Name');
    expect(component.enableNext).toBeTruthy();
    expect(component.vaRoleDisable).toBeTruthy();
    expect(component.intentId).toBe('ID');
    expect(component.langId).toBe('en-id');
    expect(component.chId).toBe('ch-id');
    expect(component.intentInfoStatus).toBeTruthy();
    expect(displayDropdownValuesSpy).toHaveBeenCalled();
    expect(toastrSpy).toHaveBeenCalled();
  });

  it('saveDraftTrainingPhrases method should call saveAddedTrainingPhrases from TrainingPhraseComponent', () => {
    const trainingPhraseComponent = jasmine.createSpyObj('TrainingPhrasesComponent', ['saveAddedTrainingPhrases']);
    component.trainingPhraseComponent = trainingPhraseComponent;

    component.saveDraftTrainingPhrases();

    expect(trainingPhraseComponent.saveAddedTrainingPhrases).toHaveBeenCalled();
  });

  // it('should modal hide method to hide the modal', () => {
  //   let modalService = TestBed.get(BsModalRef);
  //   let spy = spyOn(modalService, 'hide');
  //   console.log('lets see whats in here', component.modalRefTrainInput);

  //   component.trainInputEvent();

  //   expect(spy).toHaveBeenCalled();
  // });

  it('getDataR method should only call addMsg from CreateIntentLeftComponent', () => {
    const componentLeftPanel = jasmine.createSpyObj('CreateIntentLeftComponent', ['addMsg', 'getGetInfo']);
    component.componentLeftPanel = componentLeftPanel;

    component.getDataR({ sendMessage: { messageText: 'Hello' } });

    expect(componentLeftPanel.addMsg).toHaveBeenCalled();
    expect(componentLeftPanel.getGetInfo).toHaveBeenCalledTimes(0);
  });

  it('getDataR method should call only call getGetInfo from CreateIntentLeftComponent', () => {
    const componentLeftPanel = jasmine.createSpyObj('CreateIntentLeftComponent', ['addMsg', 'getGetInfo']);
    component.componentLeftPanel = componentLeftPanel;

    component.getDataR({});

    expect(componentLeftPanel.addMsg).toHaveBeenCalledTimes(0);
    expect(componentLeftPanel.getGetInfo).toHaveBeenCalled();
  });

  it('fetchValuefromLeftPanelGet method should call bindTempDataGet from CreateIntentRightComponent', () => {
    const componentRightPanel = jasmine.createSpyObj('CreateIntentRightComponent', ['bindTempDataGet']);
    component.componentRightPanel = componentRightPanel;

    component.fetchValuefromLeftPanelGet({});

    expect(componentRightPanel.bindTempDataGet).toHaveBeenCalled();
  });

  it('fetchValuefromLeftPanel method should call bindTempData from CreateIntentRightComponent', () => {
    const componentRightPanel = jasmine.createSpyObj('CreateIntentRightComponent', ['bindTempData']);
    component.componentRightPanel = componentRightPanel;

    component.fetchValuefromLeftPanel({});

    expect(componentRightPanel.bindTempData).toHaveBeenCalled();
  });

  it('fetchValuefromLeftPanelFinalRes method should call bindTempDataFinalRes from CreateIntentRightComponent', () => {
    const componentRightPanel = jasmine.createSpyObj('CreateIntentRightComponent', ['bindTempDataFinalRes']);
    component.componentRightPanel = componentRightPanel;

    component.fetchValuefromLeftPanelFinalRes({});

    expect(componentRightPanel.bindTempDataFinalRes).toHaveBeenCalled();
  });

  it('getData method should call fetchValuefromLeftPanel', () => {
    const spy = spyOn(component, 'fetchValuefromLeftPanel');
    const value = 'Dummy Data';

    component.getData(value);

    expect(spy).toHaveBeenCalledWith(value);
  });

  it('getDataGet method should call fetchValuefromLeftPanelGet', () => {
    const spy = spyOn(component, 'fetchValuefromLeftPanelGet');
    const value = 'Dummy Data';

    component.getDataGet(value);

    expect(spy).toHaveBeenCalledWith(value);
  });

  it('getDataFinalRes method should call fetchValuefromLeftPanelFinalRes', () => {
    const spy = spyOn(component, 'fetchValuefromLeftPanelFinalRes');
    const value = 'Dummy Data';

    component.getDataFinalRes(value);

    expect(spy).toHaveBeenCalledWith(value);
  });

  it('setStyles method should only call customStylesone', () => {
    const customStylesoneSpy = spyOn(component, 'customStylesone');
    const customStylestwoSpy = spyOn(component, 'customStylestwo');
    component.intentInfoStatus = true;

    expect(component.setStyles()).toEqual(component.styles);

    expect(customStylesoneSpy).toHaveBeenCalled();
    expect(customStylestwoSpy).toHaveBeenCalledTimes(0);
  });

  it('setStyles method should only call customStylestwo', () => {
    const customStylesoneSpy = spyOn(component, 'customStylesone');
    const customStylestwoSpy = spyOn(component, 'customStylestwo');
    component.intentInfoStatus = false;

    expect(component.setStyles()).toEqual(component.styles);

    expect(customStylesoneSpy).toHaveBeenCalledTimes(0);
    expect(customStylestwoSpy).toHaveBeenCalled();
  });

  it('setConversationStyles method should only call customStylesone', () => {
    const customStylesoneSpy = spyOn(component, 'customStylesone');
    const customStylestwoSpy = spyOn(component, 'customStylestwo');
    component.conversationFlowStatus = true;

    expect(component.setConversationStyles()).toEqual(component.styles);

    expect(customStylesoneSpy).toHaveBeenCalled();
    expect(customStylestwoSpy).toHaveBeenCalledTimes(0);
  });

  it('setConversationStyles method should only call customStylestwo', () => {
    const customStylesoneSpy = spyOn(component, 'customStylesone');
    const customStylestwoSpy = spyOn(component, 'customStylestwo');
    component.conversationFlowStatus = false;

    expect(component.setConversationStyles()).toEqual(component.styles);

    expect(customStylesoneSpy).toHaveBeenCalledTimes(0);
    expect(customStylestwoSpy).toHaveBeenCalled();
  });

  it('setPhraseStyles method should only call customStylesone', () => {
    const customStylesoneSpy = spyOn(component, 'customStylesone');
    const customStylestwoSpy = spyOn(component, 'customStylestwo');
    component.trainingPhraseStatus = true;

    expect(component.setPhraseStyles()).toEqual(component.styles);

    expect(customStylesoneSpy).toHaveBeenCalled();
    expect(customStylestwoSpy).toHaveBeenCalledTimes(0);
  });

  it('setPhraseStyles method should only call customStylestwo', () => {
    const customStylesoneSpy = spyOn(component, 'customStylesone');
    const customStylestwoSpy = spyOn(component, 'customStylestwo');
    component.trainingPhraseStatus = false;

    expect(component.setPhraseStyles()).toEqual(component.styles);

    expect(customStylesoneSpy).toHaveBeenCalledTimes(0);
    expect(customStylestwoSpy).toHaveBeenCalled();
  });

  it('customStylesone method should set style -> background to rgb(210, 255, 234) and styles -> color to #4BCB8D', () => {

    component.customStylesone();

    expect(component.styles.background).toEqual('rgb(210, 255, 234)');
    expect(component.styles.color).toEqual('#4BCB8D');
  });

  it('customStylestwo method should set style -> background to rgb(255, 220, 199) and styles -> color to #ff6a13', () => {

    component.customStylestwo();

    expect(component.styles.background).toEqual('rgb(255, 220, 199)');
    expect(component.styles.color).toEqual('#ff6a13');
  });

  it('receiveData method should set checkAddArray variable to the value passed to it', () => {
    const value = false;
    component.receiveData(value);

    expect(component.checkAddArray).toEqual(value);
  });

  it('getStatusRes method should set trainingPhraseStatus variable to the value passed to it', () => {
    const value = false;
    component.getStatusRes(value);

    expect(component.trainingPhraseStatus).toEqual(value);
  });

  it('languageFilter method should initialize values and call only refreshConversationTemp method', () => {
    const refreshConversationTempSpy = spyOn(component, 'refreshConversationTemp');
    const refreshTrainingPhrasesSpy = spyOn(component, 'refreshTrainingPhrases');
    const languale = { channels: [1, 2, 3] };
    component.language = { langEngId: 'en-uk' };
    component.showConversation = true;
    component.showAddPhrases = true;

    component.languageFilter(languale);

    expect(component.langId).toEqual('en-uk');
    expect(component.channels).toEqual([1, 2, 3]);
    expect(refreshConversationTempSpy).toHaveBeenCalled();
    expect(refreshTrainingPhrasesSpy).toHaveBeenCalledTimes(0);
  });

  it('languageFilter method should initialize values and call only refreshTrainingPhrases method', () => {
    const refreshConversationTempSpy = spyOn(component, 'refreshConversationTemp');
    const refreshTrainingPhrasesSpy = spyOn(component, 'refreshTrainingPhrases');
    const language = { channels: [1, 2, 3] };
    component.language = { langEngId: 'en-uk' };
    component.showConversation = false;
    component.showAddPhrases = true;

    component.languageFilter(language);

    expect(component.langId).toEqual('en-uk');
    expect(component.channels).toEqual([1, 2, 3]);
    expect(refreshConversationTempSpy).toHaveBeenCalledTimes(0);
    expect(refreshTrainingPhrasesSpy).toHaveBeenCalled();
  });

  it('channelFilter method should initialize values and call only refreshConversationTemp method', () => {
    const componentLeftPanelSpy = jasmine.createSpyObj('CreateIntentLeftComponent', ['isChckChannelWeb']);
    const refreshConversationTempSpy = spyOn(component, 'refreshConversationTemp');
    const refreshTrainingPhrasesSpy = spyOn(component, 'refreshTrainingPhrases');
    const channel = 'chnName';
    component.componentLeftPanel = componentLeftPanelSpy;
    component.channels = [{ channelId: 1, channelName: 'chnName' }, { channelId: 2, channelName: 'chnName1' }];
    component.showConversation = true;
    component.showAddPhrases = true;

    component.channelFilter(channel);

    expect(component.chId).toEqual(1);
    expect(refreshConversationTempSpy).toHaveBeenCalled();
    expect(componentLeftPanelSpy.isChckChannelWeb).toHaveBeenCalled();
    expect(refreshTrainingPhrasesSpy).toHaveBeenCalledTimes(0);
  });

  it('channelFilter method should initialize values and call only refreshTrainingPhrases method', () => {
    const componentLeftPanelSpy = jasmine.createSpyObj('CreateIntentLeftComponent', ['isChckChannelWeb']);
    const refreshConversationTempSpy = spyOn(component, 'refreshConversationTemp');
    const refreshTrainingPhrasesSpy = spyOn(component, 'refreshTrainingPhrases');
    component.channels = [{ channelId: 1, channelName: 'chnName' }, { channelId: 2, channelName: 'chnName1' }];
    const channel = 'chnName';
    component.showConversation = false;
    component.showAddPhrases = true;

    component.channelFilter(channel);

    expect(component.chId).toEqual(1);
    expect(componentLeftPanelSpy.isChckChannelWeb).toHaveBeenCalledTimes(0);
    expect(refreshConversationTempSpy).toHaveBeenCalledTimes(0);
    expect(refreshTrainingPhrasesSpy).toHaveBeenCalled();
  });

  it('refreshConversationTemp should call getConversationList in CreateIntentLeftComponent with correct parameters', () => {
    const componentLeftPanelSpy = jasmine.createSpyObj('CreateIntentLeftComponent', ['getConversationList']);
    component.componentLeftPanel = componentLeftPanelSpy;
    const langId = 'en-uk';
    const chId = 'ID';

    component.refreshConversationTemp(langId, chId);

    expect(componentLeftPanelSpy.getConversationList).toHaveBeenCalled();
  });

  it('refreshConversationTemp should call getConversationList in CreateIntentLeftComponent with correct parameters', () => {
    const trainingPhraseComponentSpy = jasmine.createSpyObj('TrainingPhrasesComponent', ['refreshTrainingPhrase']);
    component.trainingPhraseComponent = trainingPhraseComponentSpy;
    const langId = 'en-uk';
    const chId = 'ID';

    component.refreshTrainingPhrases(langId, chId);

    expect(trainingPhraseComponentSpy.refreshTrainingPhrase).toHaveBeenCalledWith(langId, chId);
  });


});

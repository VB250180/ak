import { Component, OnInit, ViewChild, EventEmitter, Output, TemplateRef, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, Form, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { CreateIntentLeftComponent } from './create-intent-left/create-intent-left.component';
import { CreateIntentService } from '../../../core/services/create-intent/create-intent.service';
import { TrainingPhrasesComponent } from './training-phrases/training-phrases.component';
import { CreateIntentRightComponent } from './create-intent-right/create-intent-right.component';
import { ToastrService } from 'ngx-toastr';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { IntentType, intentTypeList } from '../../../../app/core/models/intentType';
import { ModalComponent } from '../../../../app/shared/components/modal/modal.component';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { modalErrorConfig } from '../../../../app/core/utils/const-message';
import { DebounceClickDirective } from 'src/app/shared/directives/prevent-double-click.directive';
import * as cloneDeep from 'lodash/cloneDeep';
import { ItemsList } from '@ng-select/ng-select/lib/items-list';
import { Conversation, ParentMessageLanChanVaPojo, VaDetails } from '../../../../app/core/models/intent';
import { NgxSpinnerService } from 'ngx-spinner';
import { Subscription } from 'rxjs';
import { VirtualDetailsService } from 'src/app/core/services/va-details/virtual-agent-details.service';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { filterByNluConfigured } from 'src/app/core/utils/akeira-utils';
// import { SimulatorComponent } from 'src/app/shared/components/simulator/simulator.component';
// import { AccordionPanelComponent } from 'ngx-bootstrap/accordion';
// import { Observable } from 'rxjs';
// import { map } from 'rxjs/operators';

declare var $: any;

@Component({
  selector: 'app-create-intent',
  templateUrl: './create-intent.component.html',
  styleUrls: ['./create-intent.component.scss'],
  preserveWhitespaces: false
})
export class CreateIntentComponent implements OnInit, OnDestroy {
  showNextBtn = false;
  isValidFormSubmitted = null;
  intentStatus: any;
  intentResName;
  parentMessage; parentMessageChannel; parentMessageIntentId;
  parentMessageLanChanVa = new ParentMessageLanChanVaPojo();
  @ViewChild('leftPanel', { static: false }) componentLeftPanel: CreateIntentLeftComponent;
  @ViewChild('trainingPhrase', { static: false }) trainingPhraseComponent: TrainingPhrasesComponent;
  @ViewChild('rightPanel', { static: false }) componentRightPanel: CreateIntentRightComponent;

  modalRef: BsModalRef;
  config = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: 'my-modaltraining'
  };

  modalRefTrainInput: BsModalRef;
  trainInputconfig = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: 'my-modaltraining'
  };
  toastrConfig = {
    timeOut: 3000
  };

  value: any; chId: any; langId: any;
  i; savebtn;
  intentId; vaRoleId;
  arr: any = [];
  channel: any;
  language: any;
  channels = [];
  languages = [];
  showIntent;
  showConversation: boolean;
  showAddPhrases: boolean;
  vaRoleDisable = false;
  enableNext = false;
  chan; vaAgents; textMsg: any;
  getUserSendResTxt;

  enableCurrentField = false; conversation: any = []; intentInfoStatus = false;
  intentDetails: any = []; intentChannels: any = []; checkAddArray = true; enableConversation;
  conversationFlowStatus = false; trainingPhraseStatus = false; checkNewTraining = true;
  trainingPhraseForm: FormGroup;
  intentType: IntentType[] = intentTypeList;
  styles = {
    border: '1px solid rgb(247, 228, 228)',
    'border-radius': '14px',
    background: '',
    color: ''
  };
  userId = 0;
  saveIntentForm: FormGroup;
  isFinalResPresent = [];
  finalResNewArray = null;
  positionSystmSlt;
  systemslots;
  addPhraseSubscription: Subscription;
  getVaDetailsSubscription: Subscription;
  getIntentsSubscription: Subscription;
  conversationListSubscription: Subscription;
  addTrainingPhraseSubscription: Subscription;
  saveIntentSubscription: Subscription;
  updateSubscription: Subscription;
  systemSlotsDropdownSubscription: Subscription;
  saveConversationSubscription: Subscription;

  wait = ms => new Promise(resolve => setTimeout(resolve, ms));

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private spinner: NgxSpinnerService,
    private modalService: BsModalService,
    private fb: FormBuilder,
    public createIntentService: CreateIntentService,
    private toastr: ToastrService,
    public dialog: MatDialog,
    private virtualDetailsService: VirtualDetailsService,
    private authService: AuthenticationService
  ) {

    this.trainingPhraseForm = new FormGroup({
      channel: new FormControl(null, Validators.required),
      language: new FormControl(null, Validators.required)
    });
    this.userId = this.authService.getCurrentUserId();
  }


  public getData(value) {
    this.fetchValuefromLeftPanel(value);
  }
  public getDataGet(value) {
    this.fetchValuefromLeftPanelGet(value);
  }
  public getDataFinalRes(value) {
    const result = value.conversationStages.filter(obj => {
     if (obj.finalResponse) {
      (obj.finalResponse.finalResponseText) ? (this.conversationFlowStatus = true) : (this.conversationFlowStatus = false);
     }
    });
    this.fetchValuefromLeftPanelFinalRes(value);
  }

  ngOnInit() {
    this.getSystemSlotDropdowns();
    this.intentStatus = 'Create Intent';
    this.intentResName = '';
    $(document).on('keypress', 'input', (e) => {
      const startPos = e.currentTarget.selectionStart;
      if (e.which === 32 && startPos === 0) {
        e.preventDefault();
      }
    });

    $(document).on('keypress', 'textarea', (e) => {
      const startPos = e.currentTarget.selectionStart;
      if (e.which === 32 && startPos === 0) {
        e.preventDefault();
      }
    });

    this.i = 0;
    this.saveIntentForm = this.fb.group({
      intentName: ['', [Validators.required, this.noWhitespaceValidator, Validators.minLength(2), Validators.maxLength(50)]],
      intentDescription: ['', [Validators.required, this.noWhitespaceValidator, Validators.minLength(2), Validators.maxLength(200)]],
      virtualAgent: ['', [Validators.required]],
      intentType: ['', [Validators.required]]
    });

    this.route.paramMap.subscribe((params: any) => {
      console.log('params -->', params);
      this.intentId = params.params.intId;
      this.vaRoleId = params.params.vaID;
      this.chId = params.params.chId;
      this.langId = params.params.langId;
      console.log(this.chId, this.langId, this.vaRoleId);
      this.intentType = intentTypeList;
      this.intentTab();
      this.virtualAgents();

    });

  }

  // tslint:disable-next-line: use-lifecycle-interface
  ngAfterViewInit() {
    if ((window.history.state) && (window.history.state.vaId) && (this.vaAgents)) {
      const isChkVaId = this.vaAgents.find(item => item.vaId === window.history.state.vaId);
      // tslint:disable-next-line: no-unused-expression
      (isChkVaId) ? this.saveIntentForm.controls['virtualAgent'].setValue(window.history.state.vaId) : '';
    }
  }

  ngOnDestroy() {
    if (this.addPhraseSubscription) {
      this.addPhraseSubscription.unsubscribe();
    }
    if (this.getVaDetailsSubscription) {
      this.getVaDetailsSubscription.unsubscribe();
    }
    if (this.getIntentsSubscription) {
      this.getIntentsSubscription.unsubscribe();
    }
    if (this.conversationListSubscription) {
      this.conversationListSubscription.unsubscribe();
    }
    if (this.addTrainingPhraseSubscription) {
      this.addTrainingPhraseSubscription.unsubscribe();
    }
    if (this.saveIntentSubscription) {
      this.saveIntentSubscription.unsubscribe();
    }
    if (this.updateSubscription) {
      this.updateSubscription.unsubscribe();
    }
    if (this.systemSlotsDropdownSubscription) {
      this.systemSlotsDropdownSubscription.unsubscribe();
    }
    if (this.saveConversationSubscription) {
      this.saveConversationSubscription.unsubscribe();
    }
  }

  setStyles() {
    (this.intentInfoStatus === true) ? this.customStylesone() : this.customStylestwo();
    return this.styles;
  }

  setConversationStyles() {
    (this.conversationFlowStatus === true) ? this.customStylesone() : this.customStylestwo();
    return this.styles;
  }

  setPhraseStyles() {
    (this.trainingPhraseStatus === true) ? this.customStylesone() : this.customStylestwo();
    return this.styles;
  }

  customStylesone() {
    this.styles.background = 'rgb(210, 255, 234)',
      this.styles.color = '#4BCB8D';
  }

  customStylestwo() {
    this.styles.background = 'rgb(255, 220, 199)',
      this.styles.color = '#ff6a13';
  }

  receiveData($event) {
    this.checkAddArray = $event;
    // console.log('receiveData woooooooooooooooooooooooooooo -->',this.checkAddArray);
  }

  receiveSaveDraft($event) {
    this.checkNewTraining = $event;
    // console.log('receiveSaveDraft woooooooooooooooooooooooooooo -->',this.checkNewTraining);
  }

  getStatusRes($event) {
    this.trainingPhraseStatus = $event;
    console.log(this.trainingPhraseStatus, $event);

  }

  // code to trigger event onselection of language
  languageFilter(language) {
    // this.displayDropdownValues(language)
    this.langId = this.language.langEngId;
    this.channels = language.channels;
    if (this.showConversation === true) {
      this.refreshConversationTemp(this.langId, this.chId);
    } else if (this.showAddPhrases === true) {
      this.refreshTrainingPhrases(this.langId, this.chId);
    }

  }

  // code to trigger event onselection of channel
  channelFilter(channelNam) {
    // this.componentLeftPanel.isChckChannelWeb(channelNam);
    this.chan = channelNam;
    const channel: any = this.channels.filter(item => (item.channelName === channelNam));
    this.chId = channel[0].channelId;
    if (this.showConversation === true) {
      this.refreshConversationTemp(this.langId, this.chId);
      this.componentLeftPanel.isChckChannelWeb(channelNam);
    } else if (this.showAddPhrases === true) {
      this.refreshTrainingPhrases(this.langId, this.chId);
    }
  }

  refreshConversationTemp(langId, chID) {
    this.componentLeftPanel.getConversationList(this.intentId, langId, chID);
    // this.componentRightPanel.getConversationList(this.intentId, langId, chID);
  }

  refreshTrainingPhrases(langId, chID) {
    this.trainingPhraseComponent.refreshTrainingPhrase(langId, chID);
  }

  openModalTrainInput(templatetrain: TemplateRef<any>) {
    console.log('train input');
    // this.modalRef = this.modalService.show(templatetrain, this.config);
    this.modalRefTrainInput = this.modalService.show(templatetrain, this.trainInputconfig);
  }
  trainInputEvent() {
    this.addPhraseSubscription = this.createIntentService.addTrainingPhraseDialogFlow(this.langId, this.vaRoleId)
      .subscribe(res => console.log(res),
        (error: any) => {
          console.log(error);
          const responsetxt = error.error.text;
          console.log('responsetxt ', responsetxt);
          // if (responsetxt == 'Trained') {
          //   this.toastr.success('', 'Training is Scheduled', this.toastrConfig);
          // }
          if (responsetxt === 'Training in Progress') {
            this.toastr.warning('', `The VA is currently being trained. Request you to try the 'Train Inputs' option again after some time. `, this.toastrConfig);
          }
          // else {
          //   this.toastr.error('', 'Error While scheduling! Try agian later', this.toastrConfig);
          // }
        });
    // this.toastr.success('', 'Training is Scheduled', this.toastrConfig);
    this.modalRefTrainInput.hide();
  }

  public noWhitespaceValidator(control: FormControl) {
    const isWhitespace = (control.value || '').trim().length === 0;
    const isValid = !isWhitespace;
    return isValid ? null : { whitespace: true };
  }

  callGetIntentsEditData() {
    if (this.vaRoleId !== undefined && this.vaRoleId != null) {
      this.vaRoleDisable = true;
      this.enableNext = true;
      this.getIntentsEdit(this.vaRoleId, this.intentId);
    }
  }

  virtualAgents() {
    this.getVaDetailsSubscription = this.createIntentService.getVAdetailsByUserId(this.userId)
      .subscribe((response: any) => {
        console.log('response --', response);
        this.vaAgents = filterByNluConfigured(response.virtualAgents);
        this.ngAfterViewInit();
        this.callGetIntentsEditData();
      });
  }
  getIntentsEdit(roleID, intentID) {
    this.getIntentsSubscription = this.createIntentService.getIntent(roleID, intentID)
      .subscribe((response: any) => {
        this.intentStatus = 'Edit Intent';
        this.intentResName = response.intent.intentName;
        this.saveIntentForm.controls['intentName'].setValue(response.intent.intentName);
        this.saveIntentForm.controls['intentDescription'].setValue(response.intent.intentDescription);
        this.saveIntentForm.controls['intentType'].setValue(response.intent.intentType);
        this.saveIntentForm.controls['virtualAgent'].setValue(this.vaRoleId);
        this.intentDetails = response.intent.languages;
        this.displayDropdownValues(this.intentDetails);

        if ((this.saveIntentForm.controls['intentName'].value.length > 1) || ((this.saveIntentForm.controls['intentDescription'].value.length > 1) && (this.saveIntentForm.controls['virtualAgent'].value.length > 1))) {
          this.intentInfoStatus = true;
          console.log('display intent', this.intentInfoStatus, response, this.saveIntentForm.controls['intentName'].value.length);
        }

      });
  }

  displayDropdownValues(intentDetails) {
    console.log('intent', this.languages, intentDetails);
    this.languages = intentDetails;
    // tslint:disable-next-line: prefer-const , triple-equals
    let langObj = this.languages.find(item => item.langEngId == this.langId);
    this.channels = langObj.channels;
    this.language = langObj.langName;
    // tslint:disable-next-line: prefer-const , triple-equals
    let channelObj = langObj.channels.find(item => item.channelId == this.chId);
    this.channel = channelObj.channelName;
    this.parentMessageChannel = this.channel;
    this.chan = this.parentMessageChannel;
    this.parentMessageLanChanVa = {
      lang: this.langId,
      langNam: this.language,
      chann: this.chId,
      chanNam: this.channel,
      vaDetails: new VaDetails()
    };
    this.virtualDetailsService.requiredDataLoaded.subscribe(data => {
      if (data === true) {
        const selectionDetails = {
          vrmAgentDetails: this.virtualDetailsService.getVirtualAgentById(Number(this.vaRoleId)),
          vrmAgentChannelDetails: this.virtualDetailsService.getChannelsByVrmId(Number(this.vaRoleId)).find(channel => channel.channelId === this.chId),
          vrmAgentLanguageDetails: this.language
        };
        this.virtualDetailsService.currentAgentLoaded.next(selectionDetails);
      }
    });
    // this.componentLeftPanel.isChckChannelWeb(this.channel);
    // vn
  }

  getSelectedText() {
    if (window.getSelection) {
      const selectedText = window.getSelection();
      console.log(selectedText);
    }
  }

  intentTab() {
    this.showIntent = true;
    this.showConversation = false;
    this.showAddPhrases = false;
    if (this.intentId !== undefined) {
      this.conversationListSubscription = this.createIntentService.getIntentConversionList(this.intentId, this.langId, this.chId)
        .subscribe((res: any) => {
          console.log(res);
          this.conversation = res.conversation;
          if (this.conversation != null) {
            const sendFinalResponseArray = this.conversation.conversationStages;
            sendFinalResponseArray.forEach(e => {
              if (e.finalResponse != null) {
                ((e.finalResponse.finalResponseText != null) && (e.finalResponse.finalResponseText.length > 0)) ? (this.conversationFlowStatus = true) : (this.conversationFlowStatus = false);
              }
            });
          }
        });

      const pageNum = 1; const searchText = '';
      this.addTrainingPhraseSubscription = this.createIntentService.addTrainingPhrase(this.intentId, this.langId, pageNum, searchText).subscribe(responseList => {
        if (responseList['trainingPhrases'] != null) {
          (responseList['trainingPhrases'].length > 0) ? (this.trainingPhraseStatus = true) : (this.trainingPhraseStatus = false);
        }
      });
    }
  }


  conversationTab(state) {
    this.conversationTabCpy().then(res => {
      // tslint:disable-next-line: triple-equals
      const isChkVaId = this.vaAgents.find(item => item.vaId == this.saveIntentForm.value.virtualAgent);
      this.parentMessageLanChanVa['vaDetails'] = isChkVaId;
      if (state === 'prev') {
        this.wait(1).then(() => {
          this.channelFilter(this.chan);
        });
      }
    });
  }

  conversationTabCpy() {
    return Promise.resolve((() => {
      console.log('In conversationTab --->');
      if (this.enableNext) {
        this.parentMessage = this.saveIntentForm.value.virtualAgent;
        this.parentMessageIntentId = this.intentId;
        this.showIntent = false;
        this.showConversation = true;
        this.showAddPhrases = false;

      } else {
        this.toastr.warning('', `Your intent has not been saved. Please 'Save as Draft' to not loose any changes.`);
        return;
      }
      this.arr = [this.intentId, this.langId, this.chId, this.saveIntentForm.controls['virtualAgent'].value];
      console.log(this.arr, this.saveIntentForm.controls['virtualAgent'].value);
      return this.showConversation;
    })());
  }

  addTab() {
    console.log('In addtab --->');
    this.showIntent = false;
    this.showConversation = false;
    this.showAddPhrases = true;
    this.arr = [this.intentId, this.langId, this.chId, this.saveIntentForm.controls['virtualAgent'].value];
    console.log(this.arr);
  }

  saveasDraft() {
    if (this.showIntent === true) {
      this.saveDraftIntent();
    } else if (this.showConversation === true) {
      this.saveDraftConversationTemp();

    } else {
      this.saveDraftTrainingPhrases();
    }
  }

  saveDraftIntent() {
    console.log(this.saveIntentForm);
    this.savebtn = true;
    const saveIntent = {
      intentDescription: this.saveIntentForm.value.intentDescription,
      intentName: this.saveIntentForm.value.intentName,
      intentType: this.saveIntentForm.value.intentType,
    };

    if (!this.saveIntentForm.valid) {
      return true;
    }
    if (this.intentId == null || undefined) {
      this.spinner.show();
      this.saveIntentSubscription = this.createIntentService.saveCreateIntent(this.saveIntentForm.value.virtualAgent, saveIntent)
        .subscribe((res: any) => {
          this.spinner.hide();
          if (res.intent != null) {
            if (res.intent.intentName != null) {
              this.toastr.success('', res.intent.intentName + ' Intent Created Successfully');
              this.intentResName = res.intent.intentName;
              this.createIntentService.changeMessage('');
              this.enableNext = true;
              this.vaRoleDisable = true;
              this.intentId = res.intent.intentId;
              this.vaRoleId = this.saveIntentForm.value.virtualAgent;
              // tslint:disable-next-line: triple-equals
              if (res.intent.languages != undefined) {
                this.langId = res.intent.languages[0].langEngId;
                this.chId = res.intent.languages[0].channels[0].channelId;
              }
              if ((this.saveIntentForm.controls['intentName'].value.length > 1) || ((this.saveIntentForm.controls['intentDescription'].value.length > 1) && (this.saveIntentForm.controls['virtualAgent'].value.length > 1))) {
                this.intentInfoStatus = true;
              }
              this.displayDropdownValues(res.intent.languages);
              console.log('chn,lang', this.langId, this.chId, res, this.saveIntentForm);
            }
          } else {
            this.toastr.success('', res.errorBody.summary);
          }
        }, error => { this.spinner.hide(); });
    } else {
      this.updateSubscription = this.createIntentService.updateCreateIntent(this.saveIntentForm.value.virtualAgent, this.intentId, saveIntent)
        .subscribe(res => {
          this.toastr.success('', ' Intent updated Successfully');
        });
    }
    console.log('intent creation params', this.intentId, this.langId, this.chId, this.vaRoleId);
  }


  saveDraftTrainingPhrases() {
    this.trainingPhraseComponent.saveAddedTrainingPhrases();
  }


  getDataR(e) {
    if (e.sendMessage != null) {
      if (e.sendMessage.messageText != null) {
        this.componentLeftPanel.addMsg(e.sendMessage.messageText);
      }
    } else {
      this.componentLeftPanel.getGetInfo(e);
    }
  }

  fetchValuefromLeftPanelGet(e) {
    this.componentRightPanel.bindTempDataGet(e, this.intentId, this.langId, this.chId);
  }
  fetchValuefromLeftPanel(e) {
    this.componentRightPanel.bindTempData(e, this.intentId, this.langId, this.chId);
  }
  fetchValuefromLeftPanelFinalRes(e) {
    this.componentRightPanel.bindTempDataFinalRes(e, this.intentId, this.langId, this.chId);
  }

  getSystemSlotDropdowns() {
    this.systemSlotsDropdownSubscription = this.createIntentService.getSystemSlotDropdown().subscribe((Res: any) => {
      console.log(Res);
      this.systemslots = Res.systemSlotKeys;
    });
  }

  setSystemSlotPosEntity(el, text, blkName) {
    el.positionAndSlots = [];
    this.positionSystmSlt = 0;
    let curMatch; let extStr: any; let extStrP: any;
    if (blkName === 'sendMsg') {
      // tslint:disable-next-line: no-conditional-assignment
      while (curMatch = (el.messageText.match(/<([^>/]+)>/))) {
        console.log(curMatch[1]);
        extStr = curMatch[0];
        extStrP = curMatch[1];
        el.messageText = el.messageText.replace(extStr, '%' + 'pos' + this.positionSystmSlt + '%');
        // tslint:disable-next-line: triple-equals
        if (this.systemslots.filter(item => item.systemSlotKeyName == extStrP).length) {
          // tslint:disable-next-line: triple-equals
          const sysObj = this.systemslots.filter(item => item.systemSlotKeyName == extStrP);
          const systemSlotName = { position: 'pos' + this.positionSystmSlt, systemSlot: { systemSlotKeyName: extStrP, systemSlotKeyId: sysObj[0].systemSlotKeyId } };
          el.positionAndSlots.push(systemSlotName);
        }
        this.positionSystmSlt++;
      }
    } else {
      // tslint:disable-next-line: no-conditional-assignment
      while (curMatch = (el.promptQuestion.match(/<([^>/]+)>/))) {
        console.log(curMatch[1]);
        extStr = curMatch[0];
        extStrP = curMatch[1];
        el.promptQuestion = el.promptQuestion.replace(extStr, '%' + 'pos' + this.positionSystmSlt + '%');
        // tslint:disable-next-line: triple-equals
        if (this.systemslots.filter(item => item.systemSlotKeyName == extStrP).length) {
          // tslint:disable-next-line: triple-equals
          const sysObj = this.systemslots.filter(item => item.systemSlotKeyName == extStrP);
          const systemSlotName = { position: 'pos' + this.positionSystmSlt, systemSlot: { systemSlotKeyName: extStrP, systemSlotKeyId: sysObj[0].systemSlotKeyId } };
          el.positionAndSlots.push(systemSlotName);
        }
        this.positionSystmSlt++;
      }
    }
  }
  setIndexStringifyRichCrd(): Promise<any> {
    return Promise.resolve((() => {
      this.componentRightPanel.conversationListRight.conversationStages.forEach((el, idx) => {

        //  el.sequenceNumber = null;
        if (el.finalResponse) {
          // el.sequenceNumber = (this.componentRightPanel.conversationListRight.conversationStages.length);
          if (el.finalResponse.finalResponseText) {
            this.getUserSendResTxt = el.finalResponse.finalResponseText;
          }
          // tslint:disable-next-line: triple-equals
          if (el.finalResponse.finalResponseTextTemp != undefined) {
            el.finalResponse.finalResponseText = el.finalResponse.finalResponseTextTemp;
            this.getUserSendResTxt = el.finalResponse.finalResponseText;
            delete el.finalResponse.finalResponseTextTemp;
          }
          if (this.chan === 'WEB') {
            const findType = (typeof el.finalResponse.intenRichCardResponse.richCardInfo);
            // tslint:disable-next-line: no-unused-expression
            (findType === 'object') ? el.finalResponse.intenRichCardResponse.richCardInfo = JSON.stringify(el.finalResponse.intenRichCardResponse.richCardInfo) : '';
          }
        }
        // else{
        //   el.sequenceNumber = idx + 1;
        // }
        if (el.getInfo) {
          this.setSystemSlotPosEntity(el.getInfo, el.getInfo.promptQuestion, 'getInfo');
          if (this.chan === 'WEB') {
            const findType = (typeof el.getInfo.intentSlotRcPojo.richCardInfo);
            // tslint:disable-next-line: no-unused-expression
            (findType === 'object') ? el.getInfo.intentSlotRcPojo.richCardInfo = JSON.stringify(el.getInfo.intentSlotRcPojo.richCardInfo) : '';
          }
        }
        if (el.sendMessage) {
          this.setSystemSlotPosEntity(el.sendMessage, el.sendMessage.messageText, 'sendMsg');
        }
      });
      return this.componentRightPanel.conversationListRight;
    })());
  }

  validationIntNamNull(): Promise<any> {
    return Promise.resolve((() => {
      if (this.componentRightPanel.conversationListRight.validationIntent != null) {
        if (!this.componentRightPanel.conversationListRight.validationIntent.intentName) {
          this.componentRightPanel.conversationListRight.validationIntent = null;
        }
      }
      return 'valIntent';
    })());
  }

  setIndxSeqNo(): Promise<any> {
    return Promise.resolve((() => {
      this.finalResNewArray = null;
      if (this.componentRightPanel.conversationListRight.conversationStages.length !== 0) {
        this.componentRightPanel.conversationListRight.conversationStages.forEach((el, idx) => {
          if (el.finalResponse) {
            this.finalResNewArray = el;
            this.componentRightPanel.conversationListRight.conversationStages.splice(idx, 1);
          }
        });

        if (this.finalResNewArray != null) {
          if ((this.finalResNewArray.finalResponse.finalResponseText) || (this.finalResNewArray.finalResponse.intenRichCardResponse.renderHtml)) {
            this.componentRightPanel.conversationListRight.conversationStages.push(this.finalResNewArray);
          }
          this.finalResNewArray = null;
        }

        this.componentRightPanel.conversationListRight.conversationStages.forEach((el, idx) => {
          el.sequenceNumber = null;
          el.sequenceNumber = idx + 1;
        });

      }
      return 'seqIdx';
    })());
  }
  saveDraftConversationTemp() {
    this.validationIntNamNull().then(data => {
      this.setIndexStringifyRichCrd().then(data1 => {
        this.setIndxSeqNo().then(data2 => {
          this.saveDraftConversationTempPromise().then(data3 => { });
        });
      });
    });
  }

  saveDraftConversationTempPromise(): Promise<any> {
    return Promise.resolve((() => {
      const saveFinalConv = this.componentRightPanel.conversationListRight;
      this.saveConversationSubscription = this.createIntentService.saveConversations(saveFinalConv, this.intentId, this.langId, this.chId)
        .subscribe((Res: any) => {
          // tslint:disable-next-line: triple-equals
          if (Res.errorBody != undefined || Res.errorBody != null) {
            console.log('Res.errorBody ', Res.errorBody);
            const errorbody = Res.errorBody;
            // tslint:disable-next-line: triple-equals
            if (errorbody.code == 1409) {
              this.openModalApiErrorMSG(errorbody.summary);
              // tslint:disable-next-line: triple-equals
            } else if (errorbody.code == 1410) {
              this.openModalApiErrorMSG(errorbody.summary);
            } else {
              // this.toastr.warning('', 'Data not Saved');
              this.openModalApiError();
            }
          } else {
            // tslint:disable-next-line: triple-equals
            if (this.getUserSendResTxt != undefined) {
              (this.getUserSendResTxt.length > 0) ? (this.conversationFlowStatus = true) : (this.conversationFlowStatus = false);
            }
            this.toastr.success('', 'Saved Successfully');
            this.componentLeftPanel.getConversationList(this.intentId, this.langId, this.chId);
            // this.componentRightPanel.getConversationList(this.intentId, this.langId, this.chId);
          }
        }, error => {
          this.componentRightPanel.conversationListRight = new Conversation();
        });
    })());
  }

  openModalApiErrorMSG(txt) {
    const dialogRef = this.dialog.open(ModalComponent, {
      disableClose: true,
      data: {
        primaryText: txt,
        secondaryText: '',
        secondaryBtnText: 'Close',
        popUpType: 'warn',
        hasCancelBtn: true
      }
    });
  }

  openModalApiError() {
    const dialogRef = this.dialog.open(ModalComponent, {
      disableClose: true,
      data: modalErrorConfig
    });
  }

  compareVal(c1: any, c2: any) {
    // tslint:disable-next-line: triple-equals
    if (c2 == c1) {
      return c2;
    }
    // return c1 && c2 ? c1.vaId === c2.vaId : c1 === c2;
  }
}

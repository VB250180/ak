import { Component, OnInit, ViewChild, Output, EventEmitter, Input, Renderer2, ElementRef, ViewContainerRef, OnDestroy} from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, Form, Validators, SelectControlValueAccessor } from '@angular/forms';
import { Conversation, ConversationStage, FinalResponse, GetInfo, IntentSlot, SendMessage, IntentsDropD, SystemSlotDropD, SystemSlot, Entity, RichCardData, IntentSlotRcPojo, IntenRichCardResponse } from '../../../../../app/core/models/intent';
import { CreateIntentService } from '../../../../core/services/create-intent/create-intent.service';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { MatMenuTrigger } from '@angular/material';
import { RichCardDialogComponent } from '../rich-card-dialog/rich-card-dialog.component';
import { MatDialog, MatDialogRef, MatDialogConfig } from '@angular/material/dialog';
import { addAttribute, findByEditFieldType, rendererLabelSlot, removeChild } from '../../../../../app/core/utils/akeira-utils';
import { NgxSpinnerService } from 'ngx-spinner';
import * as cloneDeep from 'lodash/cloneDeep';
import { ModalComponent } from '../../../../../app/shared/components/modal/modal.component';
import { modalResFileAudioConfirm, modalFileAudioClose, modalSlotRemvConfirm, modalSlotRemvClear, modalSlotRemvIntentSlot } from '../../../../../app/core/utils/const-message';
import { Subscription } from 'rxjs';
declare var $: any;
declare var contextMenuIdx: number;


@Component({
  selector: 'app-create-intent-left',
  templateUrl: './create-intent-left.component.html',
  styleUrls: ['./create-intent-left.component.scss']

})
export class CreateIntentLeftComponent implements OnInit, OnDestroy {
  @ViewChild('fileInput', null) fileInput: ElementRef;
  @ViewChild('fileInputMsg', null) fileInputMsg: ElementRef;
  @ViewChild('fileInputQt', null) fileInputQt: ElementRef;
  @ViewChild('fileInputFr', null) fileInputFr: ElementRef;
  @ViewChild('richCrdEdit', { static: false }) richCrdEdit: ElementRef;
  @Output() public getLeftPanelData = new EventEmitter<any>();
  @Output() public getLeftPanelDataGet = new EventEmitter<any>();
  @Output() public getLeftPanelDataFinalRes = new EventEmitter<any>();
  @Input() childMessage: any;
  @Input() childMessageChannel: any;
  @Input() childMessageIntentId: any;
  @Input() childMessageLanChanVa: any;
  sendMsg; msg; changeEditIcon;
  isValidationActive = false;
  isSendMsgActive = false;
  isGetInfoActive = false;
  isFinalResActive = false;
  showAddRichCard: any = false;
  showRichCardBtn: any = {};
  showAddRichCardFinalRes: any = false;
  showRichCardBtnFinalRes: any = false;
  isEmptyValChkGetInfo: any = false;
  isEmptyValChkfinalRes: any = false;
  conversation = new Conversation();
  sendMessageNewArray: any = [];
  newTempGetInfoArr: any = [];
  getInfoNewArray: any = [];
  systemSlot = new SystemSlot();
  intentSlot = new IntentSlot();
  finalResponseNewArray = new FinalResponse();
  audioSendMsg: any = false;
  audioGetInfoQuest: any = false;
  audioGetInfoValMsg: any = false;
  audioFinalRes: any = false;
  isShowAduioIcon: any = false;
  getInfo = new GetInfo();
  valEntity: IntentsDropD;
  entitys: Entity;
  systemslots: SystemSlotDropD[];
  intentId; chId; langId; vaRoleId;
  isOpenActive = false;
  BreakException = {};
  tildeVal; dataMapLabelName; slotArryGenHtml; slotArryRendGenHtml;
  valEntityDropDown;
  valSys;
  systemSlotKeyName;
  showloader = false;
  //  for Audio Prompt
  sendMessagee = new SendMessage();
  fileUploadStatusValMsg = {};
  fileUploadStatusQuest = {};
  audioDisabledQt = {};
  audioDisabledMsg = false;
  audioDisabledRes: any = false;
  fileUploadStatusMsg: any = false;
  fileUploadStatusRes: any = false;
  replaceStr; lastElement; finalResSlot: any; sendFinalResTxt;
  positionSystmSlt;
  positionAndSlotsSystem = [];
  elemt; inpArrayObjs = []; elemtObj; elObj;
  getInfoFinalResObj; intentSlotRcPojoObj;
  channelRef;
  @ViewChild(MatMenuTrigger, { static: false })
  contextMenu: MatMenuTrigger;
  contextMenuPosition = { x: '0px', y: '0px' };
  // tslint:disable-next-line: ban-types
  prevAddInfoSlot: Boolean = false;
  message: string;
  getInfoDropDownValue = []; finalResDropDownValue = [];
  position;
  getIntentConversionListSubscription: Subscription;
  getSystemSlotDropdownSubscription: Subscription;
  getIntentsDropdownSubscription: Subscription;
  getEntitysSubscription: Subscription;
  saveConversationFlowAudiosSubscription: Subscription;

  constructor(private route: ActivatedRoute,
              private spinner: NgxSpinnerService,
              public createIntentService: CreateIntentService,
              private toastr: ToastrService,
              public dialog: MatDialog,
              private renderer: Renderer2,
              private el: ElementRef) {
    this.conversation.validationIntent = null;
    this.route.paramMap.subscribe((params: any) => {
      this.intentId = params.params.intId;
      this.vaRoleId = params.params.vaID;
      this.chId = params.params.chId;
      this.langId = params.params.langId;
      if (this.intentId !== undefined) {
        this.getConversationList(this.intentId, this.langId, this.chId);
        this.getIntentsDropdowns(this.vaRoleId, this.intentId);
      }
    });
  }

  ngOnInit() {
    // tslint:disable-next-line: only-arrow-functions
    $(document).on('keypress', 'input', function(e) {
      const startPos = e.currentTarget.selectionStart;
      if (e.which === 32 && startPos === 0) {
        e.preventDefault();
      }
    });
    // tslint:disable-next-line: only-arrow-functions
    $(document).on('keypress', 'textarea', function(e) {
      const startPos = e.currentTarget.selectionStart;
      if (e.which === 32 && startPos === 0) {
        e.preventDefault();
      }
    });
    this.channelRef = this.childMessageChannel;

    this.getIntentsDropdowns(this.childMessage, this.childMessageIntentId);
    this.getSystemSlotDropdowns();
    this.getEntitysDropdowns(this.childMessage);
    this.isChckChannelWeb(this.childMessageChannel);
  }

  // tslint:disable-next-line: use-lifecycle-interface
  ngAfterViewInit() {
    // tslint:disable-next-line: only-arrow-functions
    $(document).bind('contextmenu', function(e) {
      // var getSysIdx = ((<HTMLInputElement> event.target).dataset.sysvalue);
      // tslint:disable-next-line: deprecation
      const getSysIdx = ((event.target as HTMLInputElement).dataset.sysvalue);
      globalThis.contextMenuIdx = getSysIdx;
      if (e.toElement.id === 'getInfoAskQuest' + getSysIdx) {
        e.preventDefault();
        console.log(e.pageX + ',' + e.pageY);
        $('#cntnr').css('left', e.pageX);
        $('#cntnr').css('top', e.pageY);
        $('#cntnr').fadeIn(200, startFocusOut());
        $('.create_intent_container').css('overflow', 'hidden');
      }
      if (e.toElement.id === 'restrictSpaceSendMsg') {
        e.preventDefault();
        console.log(e.pageX + ',' + e.pageY);
        $('#cntnr-send-msg').css('left', e.pageX);
        $('#cntnr-send-msg').css('top', e.pageY);
        $('#cntnr-send-msg').fadeIn(200, startFocusOut());
        $('.create_intent_container').css('overflow', 'hidden');
      }
    });

    function startFocusOut() {
      // tslint:disable-next-line: only-arrow-functions
      $(document).on('click', function(e) {
        $('#cntnr').hide();
        $('#cntnr-send-msg').hide();
        $(document).off('click');
        $('.create_intent_container').css('overflow', 'auto');
      });
    }

  }

  onClickSystemSlot(choosenSysName) {
    if (this.channelRef === 'IVR') {
      (this.getInfoNewArray[globalThis.contextMenuIdx].getInfo.promptQuestionAudioId) ? this.showSlotAddingRigntClkPopUp(choosenSysName) : this.onClickSystemSlotItems(choosenSysName);
    } else {
      this.onClickSystemSlotItems(choosenSysName);
    }

  }

  onClickSendMsg(choosenSysName) {
    if (this.channelRef === 'IVR') {
      if (this.sendMessageNewArray.length !== 0) {
        (this.sendMessageNewArray[0].sendMessage.audioFileId) ? this.showSlotSendMsgAddingRigntClkPopUp(choosenSysName) : this.onClickSendMsgSlotItems(choosenSysName);
      } else {
        (this.sendMessagee.audioFileId) ? this.showSlotSendMsgAddingRigntClkPopUp(choosenSysName) : this.onClickSendMsgSlotItems(choosenSysName);
      }
    } else {
      this.onClickSendMsgSlotItems(choosenSysName);
    }
  }

  onClickSendMsgSlotItems(choosenSysName) {
    (this.msg) ? this.msg = this.msg + '<' + choosenSysName + '>' : this.msg = '<' + choosenSysName + '>';
    this.audioDisabledMsg = true;
  }

  changeVal(valEntity) {
    this.valEntityDropDown = valEntity;
  }

  getConversationList(intentId, langId, chId) {
    this.spinner.show();
    this.getIntentConversionListSubscription  = this.createIntentService.getIntentConversionList(intentId, langId, chId)
      .subscribe((res: any) => {
        this.conversation = res.conversation;
        this.valEntityDropDown = this.conversation.validationIntent;
        this.methodExecutionGetConversationList(this.conversation);
        this.validationIsActive();
        this.spinner.hide();
      }, error => {
        this.spinner.hide();
      });
  }


  methodExecutionGetConversationList(conversation) {
    this.sendMsgIsActive(conversation.conversationStages).then(data1 => {
      this.getInfoActive(conversation.conversationStages).then(data2 => {
        this.getFinalResSendMsgTxt(conversation.conversationStages).then(finalResAry => {
          this.wait(500).then(() => { this.getFinalAddBtnPromise(); });
        });
      });
    });
  }

  //  getInfo...................................START............................................
  getInfoActive(getInfoArrT): Promise<any> {
    return Promise.resolve((() => {
      this.setGetInfoArray(getInfoArrT).then((getInfoNewArray) => {  //  return  #this.getInfoNewArray  #Active Inavtive getInfo Block
        this.populateAudioRichCrdData(getInfoNewArray).then((res) => {  // Bind rich card leftPanel Audio Icon Color change blue or green
          this.wait(500).then(() => { this.getInfoBtn(); });            //  send all getInfo data from Left panel to Right panel
        });
      });
      return 'from getInfo';
    })());
  }
  wait = ms => new Promise(resolve => setTimeout(resolve, ms));

  setGetInfoArray(getInfoArrT): Promise<any> {
    return Promise.resolve((() => {
      this.getInfoNewArray = [];
      let hasDataGet = 0;
      getInfoArrT.forEach((e, i) => {
        if (e.getInfo != null || undefined) {
          hasDataGet += 1;
          // tslint:disable-next-line: no-unused-expression
          (e.getInfo.positionAndSlots.length === 0) ? ' ' : this.bindPromptQuest(e, i);
          this.getInfoNewArray.push(e);
          this.isGetInfoActive = true;
        }
      });
      this.isGetInfoActive = hasDataGet > 0 ? true : false;
      return this.getInfoNewArray;
    })());
  }


  bindPromptQuest(el, i) {
    let replaceStr: any;
    el.getInfo.positionAndSlots.forEach(elePos => {
      if (elePos.systemSlot != null) {
        replaceStr = elePos.systemSlot.systemSlotKeyName;
      }
      const str1 = '<' + replaceStr + '>';
      el.getInfo.promptQuestion = el.getInfo.promptQuestion.replace(elePos.position, str1);
      el.getInfo.promptQuestion = el.getInfo.promptQuestion.replace(/%/g, '');
      this.audioDisabledQt[i] = true;                    // audio upload restriction
    });
  }

  bindSendMsg(el, i) {
    let replaceStr: any;
    el.sendMessage.positionAndSlots.forEach(elePos => {
      if (elePos.systemSlot != null) {
      replaceStr = elePos.systemSlot.systemSlotKeyName;
      }
      const str2 = '<' + replaceStr + '>';
      el.sendMessage.messageText = el.sendMessage.messageText.replace(elePos.position, str2);
      el.sendMessage.messageText = el.sendMessage.messageText.replace(/%/g, '');
      //  this.audioDisabledQt[i] = true;                    // audio upload restriction
    });
  }

  populateAudioRichCrdData(getInfoNewArrayRes): Promise<any> {
    return Promise.resolve((() => {
      setTimeout(() => {
        getInfoNewArrayRes.forEach((e, i) => {
          // tslint:disable-next-line: no-unused-expression
          (this.channelRef === 'WEB') ? this.bindRichCrdGetInfoVal(e.getInfo, 'richCrdGetInfo', i, 'get') : '';
          if (this.channelRef === 'IVR') {
            (e.getInfo.promptQuestionAudioId) ? this.fileUploadStatusQuest[i] = true : this.fileUploadStatusQuest[i] = false;
            (e.getInfo.promptQuestionValidationMessageAudioId) ? this.fileUploadStatusValMsg[i] = true : this.fileUploadStatusValMsg[i] = false;
          }
        });
        return 'BindStatusAudioRichCard';
      }, 500);
    })());
  }

  // Delete Remove Info Slot
  removeInfoSlot(i) {
    const dialogRef = this.dialog.open(ModalComponent, {
      disableClose: true,
      data: modalSlotRemvIntentSlot
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.remGetInfoSlot(i).then(delRes => {
          this.resetuploadChangeStatusValMsg(this.getInfoNewArray);
          this.getInfoBtn();
        });
      }
    });
  }

  remGetInfoSlot(i): Promise<any> {
    return Promise.resolve((() => {
      this.getInfoNewArray.forEach((el, idx) => {
        // tslint:disable-next-line: triple-equals
        if (i == idx) {
          // tslint:disable-next-line: no-unused-expression
          (el.getInfo.promptQuestionAudioId) ? this.cancelledIds(el.getInfo.promptQuestionAudioId) : '';
          // tslint:disable-next-line: no-unused-expression
          (el.getInfo.promptQuestionValidationMessageAudioId) ? this.cancelledIds(el.getInfo.promptQuestionValidationMessageAudioId) : '';
          const a = this.conversation.conversationStages.indexOf(el);
          this.conversation.conversationStages.splice(a, 1);
          this.showRichCardBtn[i] = false;
          this.getInfoNewArray.splice(i, 1);
        }
      });
      return 'deletedArr';
    })());
  }

  resetuploadChangeStatusValMsg(getInfoArr): Promise<any> {
    return Promise.resolve((() => {
      getInfoArr.forEach((el, i) => {
        (el.getInfo.promptQuestionAudioId) ? this.fileUploadStatusQuest[i] = true : this.fileUploadStatusQuest[i] = false;
        (el.getInfo.promptQuestionValidationMessageAudioId) ? this.fileUploadStatusValMsg[i] = true : this.fileUploadStatusValMsg[i] = false;
      });
      return '';
    })());
  }

  //  getInfo................................END............................................

  // Final response............................START....................................
  getFinalResSendMsgTxt(conversationStages): Promise<any> {
    return Promise.resolve((() => {
      const finalResponseNewArrays = new FinalResponse();
      this.finalResponseNewArray = finalResponseNewArrays;
      this.lastElement = conversationStages.filter(obj => {
        return obj.finalResponse != null;
      });
      if (this.lastElement.length === 1) {
        this.finalResponseNewArray = this.lastElement[0].finalResponse;
        // tslint:disable-next-line: no-unused-expression
        (this.finalResponseNewArray.positionAndSlots.length === 0) ? '' : this.setMsgPos();
        (this.finalResponseNewArray.finalResponseTextAudioId) ? this.fileUploadStatusRes = true : this.fileUploadStatusRes = false;
        // tslint:disable-next-line: no-unused-expression
        (this.channelRef === 'WEB') ? this.bindRichCrdGetInfoVal(this.finalResponseNewArray, 'richCrdFinalRes', 0, 'final') : '';
      }
      return this.finalResponseNewArray; //  return whatever you want not neccessory
    })());
  }

  //  set %pos% into <slotName>
  setMsgPos() {
    let replaceStr: any;
    this.audioDisabledRes = true;  // audio upload restriction
    this.finalResponseNewArray.positionAndSlots.forEach(e => {
      if (e.intentSlot != null) {
        replaceStr = e.intentSlot.intentSlotName;
      } else if (e.responseSlot != null) {
        replaceStr = e.responseSlot.responseSlotName;
      } else {
        replaceStr = e.systemSlot.systemSlotKeyName;
      }
      const str1 = '<' + replaceStr + '>';
      this.finalResponseNewArray.finalResponseText = this.finalResponseNewArray.finalResponseText.replace(e.position, str1);
      this.sendFinalResTxt = this.finalResponseNewArray.finalResponseText;
      const res = this.sendFinalResTxt.replace(/%/g, '');
      this.finalResponseNewArray.finalResponseText = res;
    });

  }

  // Final response............................END....................................


  sendMsgIsActive(sendMsgArr): Promise<any> {
    return Promise.resolve((() => {
      let hasData = 0;
      sendMsgArr.forEach((e, i) => {
        if (e.sendMessage != null || undefined) {
          hasData += 1;
          // tslint:disable-next-line: no-unused-expression
          (e.sendMessage.positionAndSlots.length === 0) ? ' ' : this.bindSendMsg(e, i);
        }
      });
      this.isSendMsgActive = hasData > 0 ? true : false;
      return 'from sendMsg';
    })());
  }


  addMsg(msgRef) {
    if (msgRef === '' || undefined) {
      // tslint:disable-next-line: no-unused-expression
      (this.sendMessagee.audioFileId) ? this.openModalFileError('Warning', 'Please provide a static text response along with a suitable audio file. ') : '';
      return true;
    }
    this.msg = '';
    this.sendMessagee.messageText = msgRef,
      this.sendMsg = {
        sendMessage: this.sendMessagee,
        sequenceNumber: 0
      };
    this.conversation.conversationStages.push(this.sendMsg);
    const myDataM = this.conversation.conversationStages;
    const newConversationSendMsgArray = [...new Map(myDataM.map(obj => [JSON.stringify(obj), obj])).values()];
    this.conversation.conversationStages = [];
    this.conversation.conversationStages = newConversationSendMsgArray;
    this.sendMsgFunc();
  }


  delMsg(i) {
    // tslint:disable-next-line: no-unused-expression
    (this.conversation.conversationStages[i].sendMessage.audioFileId) ? this.cancelledIds(this.conversation.conversationStages[i].sendMessage.audioFileId) : '';
    this.conversation.conversationStages.splice(i, 1);
    this.sendMsgFunc();
  }
  editMsg(i, data) {
    this.sendMessageNewArray = [];
    this.msg = data.sendMessage.messageText;
    this.checkSlotValMsg(this.msg);
    this.sendMessageNewArray.push(data);
    (data.sendMessage.audioFileId) ? this.fileUploadStatusMsg = true : this.fileUploadStatusMsg = false;
    this.changeEditIcon = true;
  }
  updateMsg(msgReg) {
    if (msgReg === '') {
      this.msg = msgReg;
      this.sendMessageNewArray = [];
      this.changeEditIcon = false;
    }
    this.sendMessageNewArray.forEach((e, i) => {
      this.conversation.conversationStages.forEach((el) => {
        if (e.conversationStageId === el.conversationStageId) {
          e.sendMessage.messageText = msgReg;
          this.msg = '';
          this.sendMessageNewArray = [];
          this.changeEditIcon = false;
          this.fileUploadStatusMsg = false;
        }
      });
    });
    this.sendMsgFunc();
  }
  sendMsgFunc() {
    this.sendMsgIsActive(this.conversation.conversationStages);
    this.sendMessageNewArray.forEach(e => {
      this.conversation.conversationStages.push(e);
    });
    this.sendMessageNewArray = [];
    const myData = this.conversation.conversationStages;
    this.conversation.conversationStages = [...new Map(myData.map(obj => [JSON.stringify(obj), obj])).values()];
    this.getLeftPanelData.emit(this.conversation);
    this.sendMessagee = new SendMessage();
    this.fileUploadStatusMsg = false;
    this.audioDisabledMsg = false;
  }


  getInfoBtn() {
    if (this.channelRef === 'WEB') {
      this.richCardValuBind(this.getInfoNewArray, 'richCrdGetInfo').then(data1 => {
        (data1 === true) ? this.showGetInfoErrSpecial() : this.getInfoBtnPromis().then(data2 => { });
      });
    } else {
      this.getInfoBtnPromis();
    }
  }

  getInfoBtnPromis(): Promise<any> {
    return Promise.resolve((() => {
      try {
        this.getInfoNewArray.forEach(el => {
          const e = el.getInfo;
          if (e.intentSlot != null) {
            if ((this.checkEmpty(e.intentSlot.entity.entityName)) && (this.checkEmpty(e.intentSlot.intentSlotDescription)) && (this.checkEmpty(e.intentSlot.intentSlotName)) && (this.checkEmpty(e.promptQuestion)) && (this.checkEmpty(e.promptValidationMessage))) {
            } else {
              this.showGetInfoErr();
              throw this.BreakException;
            }
          } else {
            this.showGetInfoErr();
            throw this.BreakException;
          }
        });
        this.duplicateGetInfo();
      } catch (e) {
        if (e !== this.BreakException) { throw e; }
      }
      return 'getInfoAddBtnRes';
    })());
  }

  duplicateGetInfo() {
    // tslint:disable-next-line: only-arrow-functions
    const valueArr1 = this.getInfoNewArray.map(function(item) { return item.getInfo.intentSlot.intentSlotName; });
    // tslint:disable-next-line: only-arrow-functions
    const isDuplicate1 = valueArr1.some(function(item, idx) {
      return valueArr1.indexOf(item) !== idx;
    });
    (isDuplicate1) ? this.showDuplicateErrorMsg() : this.DuplicateGetInfoEntity();
  }

  DuplicateGetInfoEntity() {
    // tslint:disable-next-line: only-arrow-functions
    const valueArr2 = this.getInfoNewArray.map(function(item) { return item.getInfo.intentSlot.entity.entityName; });
    // tslint:disable-next-line: only-arrow-functions
    const isDuplicate2 = valueArr2.some(function(item, idx) {
      return valueArr2.indexOf(item) !== idx;
    });
    (isDuplicate2) ? this.showDuplicateErrorMsgEntity() : this.getInfoDataPush();
  }

  showDuplicateErrorMsgEntity() {
    this.toastr.warning('', 'The Intent already has a Get Info Intent Slot with the same entity. An Intent cannot have two Intent slots with the same entity. Request to change the entity mapping for one of the two  Intent Slots. ');
  }
  getInfoDataPush() {
    (this.getInfoNewArray.length === 0) ? this.isGetInfoActive = false : this.isGetInfoActive = true;
    this.getInfoNewArray.forEach((e, i) => {
      this.conversation.conversationStages.push(e);
    });
    const myData = this.conversation.conversationStages;
    this.conversation.conversationStages = [...new Map(myData.map(obj => [JSON.stringify(obj), obj])).values()];
    // BG
    this.getLeftPanelDataGet.emit(this.conversation);
  }


  addInfoSlot() {
    if (this.channelRef === 'WEB') {
      this.richCardValuBind(this.getInfoNewArray, 'richCrdGetInfo').then(data1 => {
        (data1 === true) ? this.showGetInfoErrSpecial() : this.addInfoSlotPromis().then(data2 => { });
      });
    } else {
      this.addInfoSlotPromis();
    }
  }
  showGetInfoErrSpecial() {
    this.toastr.warning('Empty value and special characters are not allowed in rich card. (Note: Underscore allowed for value and space allowed for label)');
  }


  addInfoSlotPromis(): Promise<any> {
    return Promise.resolve((() => {
      let anyGetInfoError = false;
      // tslint:disable-next-line: no-unused-expression
      this.getInfoNewArray.length === 0 ? anyGetInfoError = true : '';
      try {
        this.getInfoNewArray.forEach(el => {
          const e = el.getInfo;
          if (e.intentSlot != null) {
            if ((this.checkEmpty(e.intentSlot.entity.entityName)) && (this.checkEmpty(e.intentSlot.intentSlotName)) && (this.checkEmpty(e.intentSlot.intentSlotDescription)) && (this.checkEmpty(e.promptValidationMessage)) && (this.checkEmpty(e.promptValidationMessage))) {
              anyGetInfoError = true;
            } else {
              anyGetInfoError = false;
              this.toastr.warning(' Please provide all the necessary data points ');
              throw this.BreakException;
            }
          } else {
            anyGetInfoError = false;
            this.toastr.warning('Please provide all the necessary data points ');
            throw this.BreakException;
          }
        });

      } catch (e) {
        if (e !== this.BreakException) { throw e; }
      }

      if (anyGetInfoError) {
        this.getInfo = new GetInfo();
        const richCardData = new RichCardData();
        const getInfoArray = {
          conversationStageId: null,
          finalResponse: null,
          getInfo: this.getInfo,
          sendMessage: null,
          sequenceNumber: null,
        };
        this.getInfoNewArray.push(getInfoArray);
        this.populateAudioRichCrdData(this.getInfoNewArray);
        this.isOpenActive = true;
        anyGetInfoError = false;
      }
      return 'from addslotval';
    })());
  }

  checkEmpty(d) {
    return d != null && d !== '' && d !== undefined ? true : false;
  }


  showGetInfoErr() {
    this.toastr.warning('Add all fields');
  }


  //  import
  getGetInfo(e) {
    this.getInfoNewArray.push(e);
    const myData = this.getInfoNewArray;
    this.getInfoNewArray = [...new Map(myData.map(obj => [JSON.stringify(obj), obj])).values()];
    this.getInfoNewArray.forEach((el, i) => {
      if (el.getInfo.intentSlot.intentSlotName === undefined) {
        this.getInfoNewArray.splice(i, 1);
      } else {
      }
    });
  }


  validateAddBtn() {
    if (this.valEntityDropDown != null) {
      this.conversation.validationIntent = this.valEntityDropDown;
      this.getLeftPanelData.emit(this.conversation);
    }
    this.validationIsActive();
  }

  validationIsActive() {
    this.checkValidationTab() ? this.isValidationActive = true : this.isValidationActive = false;
  }
  checkValidationTab() {
    return (this.valEntityDropDown) ? true : false;
  }

  validateCancelBtn() {
    this.conversation.validationIntent = null;
    this.isValidationActive = false;
    //  this.validationIsActive();
    this.getLeftPanelData.emit(this.conversation);
  }
  //  ResponseSlot
  addResSlot() {
    let anyFinalResError = false;
    // tslint:disable-next-line: no-unused-expression
    this.conversation.responseSlots.length === 0 ? anyFinalResError = true : '';
    try {
      this.conversation.responseSlots.forEach(e => {
        if ((this.checkEmpty(e.responseSlotName)) && (this.checkEmpty(e.responseSlotDescription))) {
          anyFinalResError = true;
        } else {
          anyFinalResError = false;
          this.toastr.warning('Please provide all the necessary data points ');
          throw this.BreakException;
        }
      });
    } catch (e) {
      if (e !== this.BreakException) { throw e; }
    }

    if (anyFinalResError) {
      const getResSlotArray = {
        responseSlotId: null,
        responseSlotName: '',
        responseSlotDescription: ''
      };
      this.conversation.responseSlots.push(getResSlotArray);
      this.isOpenActive = true;
    }
  }

  removeResSlot(i) {
    this.conversation.responseSlots.splice(i, 1);
    this.getFinalAddBtn();
  }

  SendTxtMsgFinalRes(message): Promise<any> {
    return Promise.resolve((() => {
      this.finalResponseNewArray.positionAndSlots = [];
      this.getInfoDropDown();
      this.getFinalResDropDown();
      this.position = 0;
      const rxp = /<([^>/]+)>/g;
      let curMatch;
      this.finalResponseNewArray.finalResponseTextTemp = message;
      if (this.finalResponseNewArray.finalResponseTextTemp) {
        // tslint:disable-next-line: no-conditional-assignment
        while (curMatch = (this.finalResponseNewArray.finalResponseTextTemp.match(/<([^>/]+)>/))) {
          console.log(curMatch[1]);
          const extStr = curMatch[0];
          const extStrP = curMatch[1];
          this.finalResponseNewArray.finalResponseTextTemp = this.finalResponseNewArray.finalResponseTextTemp.replace(extStr, '%' + 'pos' + this.position + '%');
          if (this.getInfoDropDownValue.filter(item => item.getInfo.intentSlot.intentSlotName === extStrP).length) {
            const ententSlotName = { position: 'pos' + this.position, intentSlot: { intentSlotName: extStrP } };
            this.finalResponseNewArray.positionAndSlots.push(ententSlotName);
          }
          if (this.finalResDropDownValue.filter(item => item.responseSlotName === extStrP).length) {
            const ententSlotName = { position: 'pos' + this.position, responseSlot: { responseSlotName: extStrP } };
            this.finalResponseNewArray.positionAndSlots.push(ententSlotName);
          }
          if (this.systemslots.filter(item => item.systemSlotKeyName === extStrP).length) {
            const sysObj = this.systemslots.filter(item => item.systemSlotKeyName === extStrP);
            const systemSlotName = { position: 'pos' + this.position, systemSlot: { systemSlotKeyName: extStrP, systemSlotKeyId: sysObj[0].systemSlotKeyId } };
            this.finalResponseNewArray.positionAndSlots.push(systemSlotName);
          }
          this.position++;
        }
      }
      return 'from bindSendResUserText'; //  return whatever you want not neccessory
    })());
  }


  showDuplicateErrorMsg() {
    this.toastr.warning('', 'The Intent already has a Get Info Intent Slot with the same name. An Intent cannot have two Intent slots with the same name. Request to change the name of the Intent slot.');
  }
  duplicateFinalRes() {
    // tslint:disable-next-line: only-arrow-functions
    const valueArr = this.conversation.responseSlots.map(function(item) { return item.responseSlotName; });
    // tslint:disable-next-line: only-arrow-functions
    const isDuplicate = valueArr.some(function(item, idx) {
      return valueArr.indexOf(item) !== idx;
    });
    // tslint:disable-next-line: no-unused-expression
    (isDuplicate) ? this.showDuplicateErrorMsg() : '';
    return isDuplicate;
  }


  addResSlotFinalAdd(): Promise<any> {
    return Promise.resolve((() => {
      try {
        this.conversation.responseSlots.forEach(e => {
          if ((this.checkEmpty(e.responseSlotName)) && (this.checkEmpty(e.responseSlotDescription))) {
          } else {
            this.toastr.warning('Please provide all the necessary data points ');
            throw this.BreakException;
          }
        });
        const dupRes = this.duplicateFinalRes();
        return dupRes;
      } catch (e) {
        if (e !== this.BreakException) { throw e; }
      }
      // return dupRes; //  return whatever you want not neccessory
    })());
  }

  getFinalAddBtn(): Promise<any> {
    return Promise.resolve((() => {
      (this.finalResponseNewArray.finalResponseText) ? this.isFinalResActive = true : this.isFinalResActive = false;
      if (this.channelRef === 'WEB') {
        this.richCardValuBind(this.finalResponseNewArray, 'richCrdFinalRes').then(dataR1 => {
          (dataR1 === true) ? this.showGetInfoErrSpecial() : this.getFinalBtnPromise();
        });
      }
      if (this.channelRef === 'IVR') {
        if ((!this.finalResponseNewArray.finalResponseText) && (this.finalResponseNewArray.finalResponseTextAudioId)) {
          this.openModalFileError('Warning', 'Please provide a static text response along with a suitable audio file.');
        } else {
          this.getFinalBtnPromise();
        }
      }

      //  } else {
      //    this.getFinalBtnPromise();
      //  }
      return 'from bindRes'; //  return whatever you want not neccessory
    })());
  }


  //  showAudioCancelPopUp() {
  //    let matdia = this.dialog.open(ModalComponent, {
  //      disableClose: true,
  //      data: modalFileAudioCanel
  //    });
  //    matdia.afterClosed().subscribe(data => {
  //      if (data == true) {
  //        this.audioFinalRes = false;
  //        this.finalResponseNewArray.finalResponseTextAudioId = null;
  //        this.getLeftPanelDataFinalRes.emit({ 'ResponseSlot': this.conversation.responseSlots, 'FinalResText': this.finalResponseNewArray });
  //        //   this.saveConversationFlowAudio(this.intentId,this.langId,this.chId,'TEXTRESPMSG',formData);
  //      }
  //    });

  //  }
  updateFinalText(conver) {
    conver.conversationStages.forEach((el, idx) => {
      if (el.finalResponse) {
        el.finalResponse = this.finalResponseNewArray;
      }
    });
  }

  getFinalBtnPromise() {
    const result = this.conversation.conversationStages.filter(obj => {
      return obj.finalResponse != null;
    });
    (result.length === 0) ? this.conversation.conversationStages.push({ finalResponse: this.finalResponseNewArray }) : this.updateFinalText(this.conversation);
    this.getLeftPanelDataFinalRes.emit(this.conversation);
    //  this.getLeftPanelDataFinalRes.emit({ 'ResponseSlot': this.conversation.responseSlots, 'FinalResText': this.finalResponseNewArray, 'conversation': this.conversation });
  }


  getFinalAddBtnPromise() {
    this.addResSlotFinalAdd().then(da1 => {
      if (da1 !== true) {
      this.SendTxtMsgFinalRes(this.finalResponseNewArray.finalResponseText).then(da2 => {
        this.getFinalAddBtn();
      });
    }
    });
  }

  //  checkSlotVal(e) {
  //    this.uploadAudioFinal = 'Upload Audio';
  //    this.audioDisabled = false;
  //    if ((e.match(/<([^>/]+)>/))) {
  //      this.uploadAudioFinal = 'Cancel Audio';
  //      this.audioDisabled = true;
  //    }
  //  }

  //  uploadAudioFinal = 'Upload Audio';
  //  audioDisabled: any = false;
  //  onContextMenuAction1(item) {
  //    this.audioFinalRes = false;
  //    this.audioDisabled = true;
  //    this.uploadAudioFinal = 'Cancel Audio';
  //    this.finalResponseNewArray.finalResponseTextAudioId = null;
  //    var strSendMsg = ' ' + '<' + item + '>' + ' ';
  //    this.finalResponseNewArray.finalResponseText += strSendMsg;

  //  }
  onContextMenuAction1(item) {
    if (this.channelRef === 'IVR') {
      (this.finalResponseNewArray.finalResponseTextAudioId) ? this.showSlotAddingRigntClkPopUpRes(item) : this.onContextMenuActionItems(item);
    } else {
      this.onContextMenuActionItems(item);
    }
  }

  onContextMenuActionItems(item) {
    const strSendMsg = ' ' + '<' + item + '>' + ' ';
    (!this.finalResponseNewArray.finalResponseText) ? this.finalResponseNewArray.finalResponseText = strSendMsg : this.finalResponseNewArray.finalResponseText += strSendMsg;
    this.audioDisabledRes = true;   // IVR Audio disable
  }

  //  dropdownBindvalue
  compareVal(c1: IntentsDropD, c2: IntentsDropD): boolean {
    return c1 && c2 ? c1.intentId === c2.intentId : c1 === c2;
  }
  compareSys(c1: SystemSlotDropD, c2: SystemSlotDropD): boolean {
    return c1 && c2 ? c1.systemSlotKeyId === c2.systemSlotKeyId : c1 === c2;
  }
  compareEntity(c1: Entity, c2: Entity): boolean {
    return c1 && c2 ? c1.entityId === c2.entityId : c1 === c2;
  }
  //  dropDownValues
  getSystemSlotDropdowns() {
    this.getSystemSlotDropdownSubscription = this.createIntentService.getSystemSlotDropdown().subscribe((Res: any) => {
      console.log(Res);
      this.systemslots = Res.systemSlotKeys;
    });
  }
  getIntentsDropdowns(vaRoleId, intentId) {
    const validationResArr: any = [];
    this.getIntentsDropdownSubscription = this.createIntentService.getIntentsDropdown(vaRoleId, intentId).subscribe((Res: any) => {
      Res.intents.forEach((e, i) => {
        // tslint:disable-next-line: no-unused-expression
        (e.intentType === 'VALIDATION') ? validationResArr.push(e) : '';
      });
      this.valEntity = validationResArr;
    });
  }
  getEntitysDropdowns(vrmId) {
    this.getEntitysSubscription = this.createIntentService.getEntitys(vrmId).subscribe((Res: any) => {
      this.entitys = Res.entities;
    });
  }

  getInfoDropDown() {
    this.getInfoDropDownValue = [];
    this.conversation.conversationStages.forEach((e, i) => {
      // tslint:disable-next-line: no-unused-expression
      (e.getInfo != null) ? this.getInfoDropDownValue.push(e) : '';
    });
  }
  getFinalResDropDown() {
    this.finalResDropDownValue = [];
    this.finalResDropDownValue = this.conversation.responseSlots;
  }


  onContextMenu(event: MouseEvent) {
    this.getInfoDropDown();
    this.getFinalResDropDown();
    event.preventDefault();
    this.contextMenuPosition.x = event.clientX + 'px';
    this.contextMenuPosition.y = event.clientY + 'px';
    //  this.contextMenu.menuData = { 'item': item };
    this.contextMenu.menu.focusFirstItem('mouse');
    this.contextMenu.openMenu();
  }


  isChckChannelWeb(channelName) {
    this.channelRef = channelName;
    if (channelName === 'WEB') {
      this.showAddRichCard = true;
      this.showAddRichCardFinalRes = true;
    } else {
      this.showAddRichCard = false;
      this.showAddRichCardFinalRes = false;
    }
    this.updateMsg('');
  }


  //  Richcard
  openAddRichCardGetInfo(i, blockName, action) {
    const config = new MatDialogConfig();
    const dialogRef: MatDialogRef<RichCardDialogComponent> = this.dialog.open(RichCardDialogComponent, config);
    dialogRef.componentInstance.name = blockName;
    dialogRef.afterClosed().subscribe(result => {
      if (result.templateId !== undefined && result.templateId !== '') {
        // tslint:disable-next-line: no-unused-expression
        (action === 'change') ? this.cancelRichCardGetInfo(i, blockName) : '';
        console.log(result);
        (blockName === 'richCrdGetInfo') ? this.showRichCardBtn[i] = true : this.showRichCardBtnFinalRes = true;
        const manipulateHtml = JSON.parse(result.manipulateHtml);
        this.genrateRichCardEditer(result, manipulateHtml, i, blockName);
      }
    });
  }

  cancelRichCardGetInfo(i, blockName) {
    console.log('blovk name', blockName, i);
    const richCrdEditId = document.getElementById(blockName + i);
    richCrdEditId.querySelectorAll('*').forEach(n => n.remove());
    if (blockName === 'richCrdGetInfo') {
      this.showRichCardBtn[i] = false;
      this.getInfoNewArray[i].getInfo.intentSlotRcPojo = new IntentSlotRcPojo();
    } else {
      this.showRichCardBtnFinalRes = false;
      this.finalResponseNewArray.intenRichCardResponse = new IntenRichCardResponse();
    }
  }

  genrateRichCardEditer(result, manipulateHtml, i, blockName) {
    (blockName === 'richCrdGetInfo') ? this.getInfoFinalResObj = this.getInfoNewArray[i].getInfo : this.getInfoFinalResObj = this.finalResponseNewArray;
    if (blockName === 'richCrdGetInfo') {
      this.intentSlotRcPojoObj = this.getInfoFinalResObj.intentSlotRcPojo;
      this.intentSlotRcPojoObj.slotMap = {};
      this.intentSlotRcPojoObj.intentSlotRichCardTemplate.templateId = result.templateId;
    } else {
      this.intentSlotRcPojoObj = this.getInfoFinalResObj.intenRichCardResponse;
      this.intentSlotRcPojoObj.slotMap = {};
      this.intentSlotRcPojoObj.intentSlotRichCardTemplatePojo.templateId = result.templateId;
    }
    this.intentSlotRcPojoObj.richCardInfo = manipulateHtml;
    this.genEditFieldType(this.intentSlotRcPojoObj, manipulateHtml, i, blockName, 'getBtn');
  }
  bindRichCrdGetInfoVal(el, blockName, i, chkEdit): Promise<any> {
    return Promise.resolve((() => {
      if (blockName === 'richCrdGetInfo') {
        this.elObj = el.intentSlotRcPojo;
      } else {
        const myNode = document.getElementById('richCrdFinalRes0');
        myNode.innerHTML = '';
        this.elObj = el.intenRichCardResponse;
      }
      if (this.elObj.richCardInfo) {
        this.elObj.richCardInfo = JSON.parse(this.elObj.richCardInfo);
        const manipulateHtml = this.elObj.richCardInfo;
        const aa = this.genEditFieldType(this.elObj, manipulateHtml, i, blockName, chkEdit);
        (blockName === 'richCrdGetInfo') ? this.showRichCardBtn[i] = true : this.showRichCardBtnFinalRes = true;
        return 'from bindGetVal';
      }
    })());
  }


  genEditFieldType(getObj, manipulateHtml, i, blockName, chkEdit): Promise<any> {
    return Promise.resolve((() => {
      getObj.dataMap = new Map<string, any>();
      const richCrdEditId = document.getElementById(blockName + i);
      for (const v of manipulateHtml.elementKey) {
        console.log(manipulateHtml[v], v);
        const dt = findByEditFieldType(this.renderer, richCrdEditId, manipulateHtml[v]);
        // tslint:disable-next-line: no-unused-expression
        manipulateHtml[v].editField.type === 'inputLabelSlot' ? this.addbuttonSlotLabel(this.renderer, getObj, dt, richCrdEditId, manipulateHtml[v], i, v) : '';
        getObj.dataMap.set(v, dt);
        if (dt.length > 1) {
          // tslint:disable-next-line: no-shadowed-variable
          for (let i = 1; i < dt.length; i++) {
            console.log('data --->', dt['inputLabelSlotAry' + i], dt.length, manipulateHtml);
            this.deleteListenFunc(dt['inputLabelSlotAry' + i], getObj, richCrdEditId, manipulateHtml[v], v, this.renderer);
          }
        }
      }
      return 'inputFields';
    })());
  }

  addbuttonSlotLabel(r, getObj, dtby, richCrdEditId, manipulateHtml, i, v) {
    this.renderer.listen(dtby.btn, 'click', () => {
      // tslint:disable-next-line: no-shadowed-variable
      const map = getObj.dataMap.get(v);
      const tablength = map.length;
      if (tablength < manipulateHtml.limit) {
        console.log('tablength ----->', tablength);
        const dt = rendererLabelSlot(this.renderer, richCrdEditId, { labelVal: '', slotVal: '' }, false, dtby.btn, tablength);
        map.length = map.length + 1;
        map['inputLabelSlotAry' + tablength] = dt;
        // delete btn function
        this.deleteListenFunc(dt, getObj, richCrdEditId, manipulateHtml, v, r);
        getObj.dataMap.set(v, map);
        console.log('getObj[dataMap].get(v);', getObj.dataMap.get(v));
      }
    });
  }

  deleteListenFunc = (bt, getObj, richCrdEditId, manipulateHtml, v, r) => {
    r.listen(bt[2], 'click', (evt) => {
      console.log(' click ', evt.path[1].id);
      // tslint:disable-next-line: no-shadowed-variable
      const map = getObj.dataMap.get(v);
      const delId = evt.path[1].id;
      const re = /delRow/gi; const newstr = delId.replace(re, '');
      console.log('del iD', evt.path[1].id, newstr);
      const mapInner = cloneDeep(getObj.dataMap.get(v));
      removeChild(r, richCrdEditId, bt[3]);
      mapInner['inputLabelSlotAry' + newstr] = '';
      mapInner.length = cloneDeep(map.length - 1);
      console.log(mapInner, manipulateHtml.limit);
      const res = this.rearrangeMapValueOrder(r, mapInner, manipulateHtml.limit);
      getObj.dataMap.delete(v);
      getObj.dataMap.set(v, res);
      console.log('---------------', getObj.dataMap.get(v));
    });
  }

  // tslint:disable-next-line: no-shadowed-variable
  rearrangeMapValueOrder = (r, map, limit) => {
    console.log(' click ', map, limit);
    for (let i = 0; i < limit; i++) {
      console.log(i, map['inputLabelSlotAry' + i]);
      if (map['inputLabelSlotAry' + i] === '') {
        const movedTemp = cloneDeep(map['inputLabelSlotAry' + (i + 1)]);
        map['inputLabelSlotAry' + i] = movedTemp;
        if (movedTemp !== '') {
          addAttribute(r, map['inputLabelSlotAry' + i][2], 'id', 'delRow' + i);
          map['inputLabelSlotAry' + (i + 1)] = '';
        }
      }
    }
    return map;
  }

  //  rich card Methods common getInfo FinalResponse
  richCardValuBind(inpArrayObj, blockName): Promise<any> {
    return Promise.resolve((() => {
      //  var format = /[ `!@#$%^&*()_+\-=\[\]{};':'\\|,.<>\/?~]/;
      const formatWithSpace = /[`!@#$%^&*()_+\-=\[\]{};':'\\|,.<>\/?~]/;
      const format = /[ `!@#$%^&*()+\-=\[\]{};':'\\|,.<>\/?~]/;
      this.inpArrayObjs = [];
      (blockName === 'richCrdGetInfo') ? this.isEmptyValChkGetInfo = false : this.isEmptyValChkfinalRes = false;
      (blockName === 'richCrdFinalRes') ? this.inpArrayObjs.push(inpArrayObj) : this.inpArrayObjs = inpArrayObj;
      this.inpArrayObjs.forEach((el, idx) => {
        (blockName === 'richCrdGetInfo') ? this.elemt = el.getInfo : this.elemt = el;
        (blockName === 'richCrdGetInfo') ? this.elemtObj = el.getInfo.intentSlotRcPojo : this.elemtObj = el.intenRichCardResponse;
        if (this.elemtObj) {
          this.elemtObj.slotMap = {};
          if (this.elemtObj.richCardInfo !== '' && this.elemtObj.richCardInfo != null) {
            const totalEditFields = this.elemtObj.richCardInfo.elementKey;
            this.elemtObj.html = this.elemtObj.richCardInfo.html;
            this.elemtObj.renderHtml = this.elemtObj.richCardInfo.html;

            totalEditFields.forEach((elmFields, idxFields) => {
              const getGeneratedHtml = this.elemtObj.richCardInfo[elmFields].remderHtml;
              this.dataMapLabelName = this.elemtObj.dataMap.get(elmFields);
              if (elmFields === 'slotLabelAry') {
                this.elemtObj.richCardInfo.slotLabelAry.editField.fieldValue = [];
                this.slotArryRendGenHtml = undefined;
                this.slotArryGenHtml = undefined;
                for (let i = 0; this.dataMapLabelName.length > i; i++) {
                  if (this.dataMapLabelName['inputLabelSlotAry' + i] !== undefined && this.dataMapLabelName['inputLabelSlotAry' + i] !== '') {
                    let slotLablHtml = getGeneratedHtml;
                    let slotLablRendHtml = getGeneratedHtml;
                    const slotIndx = idxFields + (i);
                    const labName = this.dataMapLabelName['inputLabelSlotAry' + i][0].value;
                    const slotName = this.dataMapLabelName['inputLabelSlotAry' + i][1].value;
                    const positionKey = 'pos' + slotIndx;
                    slotLablHtml = slotLablHtml.replace('~labelVal~', labName);
                    (this.slotArryGenHtml !== undefined) ? this.slotArryGenHtml += slotLablHtml.replace('~slotVal~', '%' + positionKey + '%') : this.slotArryGenHtml = slotLablHtml.replace('~slotVal~', '%' + positionKey + '%');
                    slotLablRendHtml = slotLablHtml.replace('~labelVal~', labName);
                    (this.slotArryRendGenHtml !== undefined) ? this.slotArryRendGenHtml += slotLablRendHtml.replace('~slotVal~', slotName) : this.slotArryRendGenHtml = slotLablRendHtml.replace('~slotVal~', slotName);
                    this.elemtObj.slotMap[positionKey] = slotName;
                    this.setValueForEditField(this.elemtObj, labName, slotName, i, blockName);
                  }
                }
                this.elemtObj.html = this.elemtObj.html.replace('~' + elmFields + '~', this.slotArryGenHtml);
                this.elemtObj.renderHtml = this.elemtObj.renderHtml.replace('~' + elmFields + '~', this.slotArryRendGenHtml);
              } else {
                const tildeVals = getGeneratedHtml.match(/~(.*?)~/g);
                this.tildeVal = tildeVals[0];
                this.elemtObj.html = this.elemtObj.html.replace('~' + elmFields + '~', getGeneratedHtml);
                this.elemtObj.renderHtml = this.elemtObj.renderHtml.replace('~' + elmFields + '~', getGeneratedHtml);
                // tslint:disable-next-line: no-shadowed-variable
                const positionKey = 'pos' + idxFields;
                this.elemtObj.html = this.elemtObj.html.replace(this.tildeVal, '%' + positionKey + '%');
                this.elemtObj.renderHtml = this.elemtObj.renderHtml.replace(this.tildeVal, this.dataMapLabelName.value);
                this.elemtObj.slotMap[positionKey] = this.dataMapLabelName.value;
                (elmFields === 'imageURL') ? this.elemtObj.richCardInfo[elmFields].editField.fieldValue[0].url = this.dataMapLabelName.value : this.elemtObj.richCardInfo[elmFields].editField.fieldValue[0].value = this.dataMapLabelName.value;
                if ((this.dataMapLabelName.value === '') || (format.test(this.dataMapLabelName.value.trim()))) {
                  (blockName === 'richCrdGetInfo') ? this.isEmptyValChkGetInfo = true : this.isEmptyValChkfinalRes = true;
                }
              }
            });
          }
        }
        //  end
      });
      return (blockName === 'richCrdGetInfo') ? this.isEmptyValChkGetInfo : this.isEmptyValChkfinalRes;
    })());
  }

  setValueForEditField(elemtObj, labName, slotName, i, blockName) {
    //  var format = /[ `!@#$%^&*()_+\-=\[\]{};':'\\|,.<>\/?~]/;
    const formatWithSpace = /[`!@#$%^&*()_+\-=\[\]{};':'\\|,.<>\/?~]/;
    const formatUnderScore = /[ `!@#$%^&*()+\-=\[\]{};':'\\|,.<>\/?~]/;
    if ((labName === '' || slotName === '') || (formatWithSpace.test(labName.trim())) || (formatUnderScore.test(slotName.trim()))) {
      (blockName === 'richCrdGetInfo') ? this.isEmptyValChkGetInfo = true : this.isEmptyValChkfinalRes = true;
    }
    elemtObj.richCardInfo.slotLabelAry.editField.saveLimit = i + 1;
    elemtObj.richCardInfo.slotLabelAry.editField.fieldValue.push({ labelVal: labName, slotVal: slotName });
  }


  showSlotAddingRigntClkPopUp(choosenSysName) {
    const askQstSlotModel = this.dialog.open(ModalComponent, {
      disableClose: true,
      data: modalSlotRemvConfirm
    });
    askQstSlotModel.afterClosed().subscribe(data => {
      if (data === true) {
        // tslint:disable-next-line: no-unused-expression
        (this.getInfoNewArray[globalThis.contextMenuIdx].getInfo.promptQuestionAudioId) ? this.cancelledIds(this.getInfoNewArray[globalThis.contextMenuIdx].getInfo.promptQuestionAudioId) : '';
        this.getInfoNewArray[globalThis.contextMenuIdx].getInfo.promptQuestionAudioId = null;
        this.getInfoNewArray[globalThis.contextMenuIdx].getInfo.promptQuestionAudioFileSize = null;
        this.fileUploadStatusQuest[globalThis.contextMenuIdx] = false;
        this.audioDisabledQt[globalThis.contextMenuIdx] = true;
        this.onClickSystemSlotItems(choosenSysName);
      }
    });
  }
  showSlotSendMsgAddingRigntClkPopUp(choosenSysName) {
    const askQstSlotModel = this.dialog.open(ModalComponent, {
      disableClose: true,
      data: modalSlotRemvConfirm
    });
    askQstSlotModel.afterClosed().subscribe(data => {
      if (data === true) {
        if (this.sendMessageNewArray.length !== 0) {
          // tslint:disable-next-line: no-unused-expression
          (this.sendMessageNewArray[0].sendMessage.audioFileId) ? this.cancelledIds(this.sendMessageNewArray[0].sendMessage.audioFileId) : '';
          this.sendMessageNewArray[0].sendMessage.audioFileId = null;
          this.sendMessageNewArray[0].sendMessage.audioFileSize = null;
        } else {
          // tslint:disable-next-line: no-unused-expression
          (this.sendMessagee.audioFileId) ? this.cancelledIds(this.sendMessagee.audioFileId) : '';
          this.sendMessagee.audioFileId = null;
          this.sendMessagee.audioFileSize = null;
        }
        this.fileUploadStatusMsg = false;
        this.onClickSendMsgSlotItems(choosenSysName);
      }
    });
  }


  cancelledIds(delAudioId) {
    this.conversation.cancelledIds.push(delAudioId);
  }
  onClickSystemSlotItems(choosenSysName) {
    this.audioDisabledQt[globalThis.contextMenuIdx] = true;
    const tempQuestRes = this.getInfoNewArray[globalThis.contextMenuIdx].getInfo.promptQuestion;
    this.getInfoNewArray[globalThis.contextMenuIdx].getInfo.promptQuestion = tempQuestRes + '<' + choosenSysName + '>';
  }

  //  uploadAndChangeFileStatusValMsg(el, i) {
  //    (el.getInfo.promptQuestionAudioId) ? this.fileUploadStatusQuest[i] = true : this.fileUploadStatusQuest[i] = false;
  //    (el.getInfo.promptQuestionValidationMessageAudioId) ? this.fileUploadStatusValMsg[i] = true : this.fileUploadStatusValMsg[i] = false;

  //  }



  //  removeInfoSloPromise(i) {
  //  this.remGetInfoSlot(i).then(rem1 => {
  //  (this.getInfoNewArray[i].getInfo.promptQuestionAudioId) ? this.cancelledIds(this.getInfoNewArray[i].getInfo.promptQuestionAudioId) : '';
  //  (this.getInfoNewArray[i].getInfo.promptQuestionValidationMessageAudioId) ? this.cancelledIds(this.getInfoNewArray[i].getInfo.promptQuestionValidationMessageAudioId) : '';
  //  this.resetuploadChangeStatusValMsg(this.getInfoNewArray);
  //  })
  //  };

  //  remGetInfoSlot(i): Promise<any> {
  //    return Promise.resolve((() => {
  //      this.getInfoNewArray.forEach((el, idx) => {
  //        if (i == idx) {
  //          (el.getInfo.promptQuestionAudioId) ? this.cancelledIds(el.getInfo.promptQuestionAudioId) : '';
  //          (el.getInfo.promptQuestionValidationMessageAudioId) ? this.cancelledIds(el.getInfo.promptQuestionValidationMessageAudioId) : '';
  //          var a = this.conversation.conversationStages.indexOf(el);
  //          this.conversation.conversationStages.splice(a, 1);
  //        }
  //      });
  //      return 'getRemovSlot';
  //    })());
  //  }


  showSlotAddingRigntClkPopUpRes(item) {
    const askQstSlotModelRes = this.dialog.open(ModalComponent, {
      disableClose: true,
      data: modalSlotRemvConfirm
    });
    askQstSlotModelRes.afterClosed().subscribe(data => {
      if (data === true) {
        this.cancelledIds(this.finalResponseNewArray.finalResponseTextAudioId);
        this.finalResponseNewArray.finalResponseTextAudioId = null;
        this.finalResponseNewArray.finalResponseTextAudioSize = null;
        this.fileUploadStatusRes = false;
        this.audioDisabledRes = true;
        this.onContextMenuActionItems(item);
      }
    });
  }
  //  audioPrompt
  onselectFile(data: FileList, type, i) {
    const allowedext = ['audio/mp3', 'audio/mpeg'];
    const file = data[0];
    if (allowedext.includes(file.type)) {
      const formData = new FormData();
      formData.append('file', file);
      const primaryTxt = 'Info';
      const secondaryTxt = 'Are you sure want to upload this audio file?';
      this.openModalFileConfirm(formData, type, i, primaryTxt, secondaryTxt);
    } else {
      this.openModalFileError('Invalid Format', 'Please upload only mp3 audio files');
      this.fileInputMsg.nativeElement.value = '';
    }
  }


  openModalFileConfirm(formData, type, i, primaryTxt, secondaryTxt) {
    modalResFileAudioConfirm.primaryText = primaryTxt;
    modalResFileAudioConfirm.secondaryText = secondaryTxt;
    const modalDialog = this.dialog.open(ModalComponent, {
      disableClose: true,
      data: modalResFileAudioConfirm
    });

    modalDialog.afterClosed().subscribe(data => {
      if (data === true) {
        if (this.intentId === undefined) {
          this.intentId = this.childMessageIntentId;
          this.langId = this.childMessageLanChanVa.lang;
          this.chId = this.childMessageLanChanVa.chann;
        }
        this.saveConversationFlowAudio(this.intentId, this.langId, this.chId, type, formData, i);
      } else {
        this.sameFileUploadFunc();
      }
    });
  }

  sameFileUploadFunc() {
    this.fileInputQt.nativeElement.value = '';
    this.fileInput.nativeElement.value = '';
    this.fileInputMsg.nativeElement.value = '';
    this.fileInputFr.nativeElement.value = '';
  }

  saveConversationFlowAudio(intentId, langId, chId, type, formData, i) {
    this.spinner.show();
    this.saveConversationFlowAudiosSubscription = this.createIntentService.saveConversationFlowAudios(intentId, langId, chId, type, formData)
      .subscribe(res => {
        this.spinner.hide();
        if (res.audioData.status === 'success') {
          if (type === 'PROMPTMSG') {
            // tslint:disable-next-line: no-unused-expression
            (this.getInfoNewArray[i].getInfo.promptQuestionAudioId) ? this.cancelledIds(this.getInfoNewArray[i].getInfo.promptQuestionAudioId) : '';
            this.getInfoNewArray[i].getInfo.promptQuestionAudioId = res.audioData.audifileId;
            this.getInfoNewArray[i].getInfo.promptQuestionAudioFileSize = res.audioData.fileSize;
            this.fileUploadStatusQuest[i] = true;
            this.fileInputQt.nativeElement.value = '';
          } else if (type === 'PROMPTVALIDMSG') {
            // tslint:disable-next-line: no-unused-expression
            (this.getInfoNewArray[i].getInfo.promptQuestionValidationMessageAudioId) ? this.cancelledIds(this.getInfoNewArray[i].getInfo.promptQuestionValidationMessageAudioId) : '';
            this.getInfoNewArray[i].getInfo.promptQuestionValidationMessageAudioId = res.audioData.audifileId;
            this.getInfoNewArray[i].getInfo.promptQuestionValidationMessageAudioSize = res.audioData.fileSize;
            this.fileUploadStatusValMsg[i] = true;
            this.fileInput.nativeElement.value = '';
          } else if (type === 'SENDMSG') {
            if (this.sendMessageNewArray.length === 1) {
              this.sendMessageNewArray[0].sendMessage.audioFileId = res.audioData.audifileId;
              this.sendMessageNewArray[0].sendMessage.audioFileSize = res.audioData.fileSize;
            } else {
              this.sendMessagee.audioFileId = res.audioData.audifileId;
              this.sendMessagee.audioFileSize = res.audioData.fileSize;
            }
            this.fileUploadStatusMsg = true;
            this.fileInputMsg.nativeElement.value = '';
          } else if (type === 'TEXTRESPMSG') {
            // tslint:disable-next-line: no-unused-expression
            (this.finalResponseNewArray.finalResponseTextAudioId) ? this.cancelledIds(this.finalResponseNewArray.finalResponseTextAudioId) : '';
            this.finalResponseNewArray.finalResponseTextAudioId = res.audioData.audifileId;
            this.finalResponseNewArray.finalResponseTextAudioSize = res.audioData.fileSize;
            this.fileUploadStatusRes = true;
            this.fileInputFr.nativeElement.value = '';
          }

        } else {
          this.sameFileUploadFunc();
          this.openModalFileError('Something went wrong', 'We are having trouble completing your request.  Apologize for the convenience. Request you try again in some time. ');
        }
      }, err => {
        this.sameFileUploadFunc();
        this.openModalFileError('Something went wrong', 'We are having trouble completing your request.  Apologize for the convenience. Request you try again in some time. ');
        this.spinner.hide();
      });
  }



  openModalFileError(primaryTxt, secondaryTxt) {
    modalFileAudioClose.primaryText = primaryTxt;
    modalFileAudioClose.secondaryText = secondaryTxt;
    this.dialog.open(ModalComponent, {
      disableClose: true,
      data: modalFileAudioClose
    });
  }

  checkSlotValQt(val, i) {
    this.audioDisabledQt[i] = false;
    if ((val.match(/<([^>/]+)>/))) {
      this.audioDisabledQt[i] = true;
    }
  }
  checkSlotValRes(val) {
    this.audioDisabledRes = false;
    if ((val.match(/<([^>/]+)>/))) {
      this.audioDisabledRes = true;
    }
  }

  checkSlotValMsg(val) {
    this.msg = val;
    this.audioDisabledMsg = false;
    if ((val.match(/<([^>/]+)>/))) {
      this.audioDisabledMsg = true;
    }
  }


  //  newcode

  //  sendMsgClear
  openModalFileClearMsg() {
    const modalDialog = this.dialog.open(ModalComponent, {
      disableClose: true,
      data: modalSlotRemvClear
    });
    modalDialog.afterClosed().subscribe(data => {
      if (data === true) {
        // tslint:disable-next-line: triple-equals
        if (this.sendMessageNewArray.length == 1) {
          // tslint:disable-next-line: no-unused-expression
          (this.sendMessageNewArray[0].sendMessage.audioFileId) ? this.cancelledIds(this.sendMessageNewArray[0].sendMessage.audioFileId) : '';
          this.sendMessageNewArray[0].sendMessage.audioFileId = null;
          this.sendMessageNewArray[0].sendMessage.audioFileSize = null;
          this.fileUploadStatusMsg = false;
        } else {
          // tslint:disable-next-line: no-unused-expression
          (this.sendMessagee.audioFileId) ? this.cancelledIds(this.sendMessagee.audioFileId) : '';
          this.sendMessagee.audioFileId = null;
          this.sendMessagee.audioFileSize = null;
          this.fileUploadStatusMsg = false;
        }
        this.fileInputMsg.nativeElement.value = '';
      }
    });

  }

  // AskQuest
  openModalFileClearQst(i) {
    const modalDialog = this.dialog.open(ModalComponent, {
      disableClose: true,
      data: modalSlotRemvClear
    });
    modalDialog.afterClosed().subscribe(data => {
      if (data === true) {
        // tslint:disable-next-line: no-unused-expression
        (this.getInfoNewArray[i].getInfo.promptQuestionAudioId) ? this.cancelledIds(this.getInfoNewArray[i].getInfo.promptQuestionAudioId) : '';
        this.getInfoNewArray[i].getInfo.promptQuestionAudioId = null;
        this.getInfoNewArray[i].getInfo.promptQuestionAudioFileSize = null;
        this.fileUploadStatusQuest[i] = false;
        this.fileInputQt.nativeElement.value = '';
      }
    });
  }
  // validation message
  openModalFileClearVal(i) {
    const modalDialog = this.dialog.open(ModalComponent, {
      disableClose: true,
      data: modalSlotRemvClear
    });
    modalDialog.afterClosed().subscribe(data => {
      if (data === true) {
        // tslint:disable-next-line: no-unused-expression
        (this.getInfoNewArray[i].getInfo.promptQuestionValidationMessageAudioId) ? this.cancelledIds(this.getInfoNewArray[i].getInfo.promptQuestionValidationMessageAudioId) : '';
        this.getInfoNewArray[i].getInfo.promptQuestionValidationMessageAudioId = null;
        this.getInfoNewArray[i].getInfo.promptQuestionValidationMessageAudioSize = null;
        this.fileUploadStatusValMsg[i] = false;
        this.fileInput.nativeElement.value = '';
      }
    });
  }

  //  finalRes
  openModalFileClearFr() {
    const modalDialog = this.dialog.open(ModalComponent, {
      disableClose: true,
      data: modalSlotRemvClear
    });
    modalDialog.afterClosed().subscribe(data => {
      if (data === true) {
        // tslint:disable-next-line: no-unused-expression
        (this.finalResponseNewArray.finalResponseTextAudioId) ? this.cancelledIds(this.finalResponseNewArray.finalResponseTextAudioId) : '';
        this.finalResponseNewArray.finalResponseTextAudioId = null;
        this.finalResponseNewArray.finalResponseTextAudioSize = null;
        this.fileUploadStatusRes = false;
        this.fileInputFr.nativeElement.value = '';
      }
    });
  }

  fileInputMsgClear() {
    this.openModalFileClearMsg();
  }
  fileInputQtClear(i) {
    this.openModalFileClearQst(i);
  }
  fileInputClear(i) {
    this.openModalFileClearVal(i);
  }
  fileInputFRClear() {
    this.openModalFileClearFr();
  }

  ngOnDestroy() {
    if (this.getIntentConversionListSubscription) {
      this.getIntentConversionListSubscription.unsubscribe();
    }
    if (this.getSystemSlotDropdownSubscription) {
      this.getSystemSlotDropdownSubscription.unsubscribe();
    }
    if (this.getIntentsDropdownSubscription) {
      this.getIntentsDropdownSubscription.unsubscribe();
    }
    if (this.getEntitysSubscription) {
      this.getEntitysSubscription.unsubscribe();
    }
    if (this.saveConversationFlowAudiosSubscription) {
      this.saveConversationFlowAudiosSubscription.unsubscribe();
    }
  }
  // hId;
  // changeStyleva(e){
  //   console.log(e);
  //   this.hId = e;
  // }
}



import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { CreateIntentLeftComponent } from './create-intent-left.component';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { MatMenuModule,  MatDialog, MatDialogModule, MatDialogConfig } from '@angular/material';
import { RouterModule } from '@angular/router';
import { APP_BASE_HREF } from '@angular/common';
import { ToastrModule } from 'ngx-toastr';
import { CreateIntentService } from '../../../../core/services/create-intent/create-intent.service';
import { BehaviorSubject, Observable } from 'rxjs';
import { PositionAndSlot, SystemSlotKey, ConversationStage, Conversation  } from 'src/app/core/models/intent';
import { NgxSpinnerService } from 'ngx-spinner';





class MatDialogStub {

  // public afterClosed = new BehaviorSubject(false);

  public open(template, data) {
    // this.afterClosed(true);
    return {
      afterClosed: () => {
        return Observable.of(true);
      }
    };
  }
}

class NgxSpinnerServiceStub {
  public show(spinnerType) { }

  public hide(spinnerType) { }
}
class CreateIntentServiceStub {


  // let systemSlotList={
  //   'systemSlotKeys': [
  //     {
  //       'systemSlotKeyId': 2,
  //       'systemSlotKeyName': 'GroupID'
  //     },
  //     {
  //       'systemSlotKeyId': 1,
  //       'systemSlotKeyName': 'MemberID'
  //     }
  //   ]
  // };


  public saveConversationFlowAudios(intentId, langId, chId, type, formData) {
    return Observable.of({
      res: {
        audioData: {
          status : 'success',
          audifileId: '1',
          fileSize: '2'
        },
      }
    });
  }

  public getSystemSlotDropdown() {
    return Observable.of({
      systemSlotKeys: [
        {
          systemSlotKeyId: 2,
          systemSlotKeyName: 'GroupID'
        },
        {
          systemSlotKeyId: 1,
          systemSlotKeyName: 'MemberID'
        }
      ]
    });
  }
  public getEntitys(vrmId) {
    return Observable.of({
      entities: [
        {
          entityId: 5,
          entityName: 'Claim_Number'
        },
        {
          entityId: 1,
          entityName: 'DOB'
        }]
    });
  }

  public getIntentsDropdown(vaRoleId, intentId) {
    return Observable.of({
    intents: [{intentId: 244, intentName: 'Benefit Details', intentType: 'GENERAL', intentDescription: 'Benefit Details Desc', virtualAgent: null},
              {intentId: 357, intentName: 'bg_test', intentType: 'GENERAL', intentDescription: 'bg_test', virtualAgent: null},
               {intentId: 247, intentName: 'Deductible', intentType: 'VALIDATION', intentDescription: 'Deductible Desc', virtualAgent: null}]
    });
  }


  public getIntentConversionList(intentId, langId, chId) {
    if (intentId === 61) {
  return Observable.of({
    conversation: {
      validationIntent: {
        intentId: 61,
        intentName: 'ClaimS',
        intentType: null,
        intentDescription: 'Claim status ',
        virtualAgent: null,
        businessUnit: null,
        languages: null
      },
      systemSlots: [
        {
          systemSlotId: 42,
          systemSlotKey: {
            systemSlotKeyId: 1,
            systemSlotKeyName: 'MemberID'
          }
        },
        {
          systemSlotId: 43,
          systemSlotKey: {
            systemSlotKeyId: 2,
            systemSlotKeyName: 'GroupID'
          }
        }
      ],
      conversationStages: [
        {
          sequenceNumber: 1,
          conversationStageId: 129,
          sendMessage: null,
          getInfo: {
            getInfoId: 38,
            positionAndSlots: [],
            promptQuestion: 'asdf',
            promptValidationMessage: 'asdf',
            intentSlot: {
              intentSlotId: 38,
              intentSlotName: 'asdf',
              intentSlotDescription: 'asdf',
              entity: {
                entityId: 8,
                entityName: 'Policy_Type'
              }
            }
          },
          finalResponse: null
        },
        {
          sequenceNumber: 2,
          conversationStageId: 159,
          sendMessage: {
            messageId: 53,
            messageText: 'sdfgsdgsgs%pos0%%pos1%sdfgs',
            positionAndSlots: [
              {
                position: 'pos0',
                systemSlot: {
                systemSlotKeyName: 'GroupID',
                  systemSlotKeyId: 2
                }
              },
              {
                position: 'pos1',
                systemSlot: {
                  systemSlotKeyName: 'MemberID',
                  systemSlotKeyId: 1
                }
              }
            ]
          },
          getInfo: null,
          finalResponse: null
        },
        {
          sequenceNumber: 3,
          conversationStageId: 133,
          sendMessage: {
            messageId: 39,
            messageText: 'esarfas',
            positionAndSlots: []
          },
          getInfo: null,
          finalResponse: null
        },
        {
          sequenceNumber: 4,
          conversationStageId: 134,
          sendMessage: {
            messageId: 40,
            messageText: 'dasfsda',
            positionAndSlots: []
          },
          getInfo: null,
          finalResponse: null
        },
        {
          sequenceNumber: 5,
          conversationStageId: 130,
          sendMessage: null,
          getInfo: {
            getInfoId: 39,
            positionAndSlots: [],
            promptQuestion: 'asdf',
            promptValidationMessage: 'asdf',
            intentSlot: {
              intentSlotId: 39,
              intentSlotName: 'sdafasd',
              intentSlotDescription: 'asdf',
              entity: {
                entityId: 3,
                entityName: 'MTPIN'
              }
            }

          },
          finalResponse: null
        },
        {
          sequenceNumber: 6,
          conversationStageId: 132,
          sendMessage: null,
          getInfo: {
            getInfoId: 40,
            promptQuestionAudioId: '1',
            promptQuestionValidationMessageAudioId: '20',
            positionAndSlots: [
              {
                position: 'pos0',
                systemSlot: {
                  systemSlotKeyName: 'GroupID',
                  systemSlotKeyId: 2
                }
              },
              {
                position: 'pos1',
                systemSlot: {
                  systemSlotKeyName: 'MemberID',
                  systemSlotKeyId: 1
                }
              }
            ],
            promptQuestion: 'sdfgsd%pos0%%pos1%sdfgsdgsdgs',
            promptValidationMessage: 'asf',
            intentSlot: {
              intentSlotId: 40,
              intentSlotName: 'new ',
              intentSlotDescription: 'asdf',
              entity: {
                entityId: 7,
                entityName: 'sys.date'
              }
            }
          },
          finalResponse: null
        },
        {
          sequenceNumber: 7,
          conversationStageId: 171,
          sendMessage: null,
          getInfo: null,
          finalResponse: {
            finalResponseId: 67,
          finalResponseText: 'final claim status  %pos0% and  %pos1% intent',
            positionAndSlots: [
              {
                finalResponseSlotId: 709,
                position: 'pos1',
                intentSlot: {
                intentSlotId: 40,
                  intentSlotName: 'new ',
                  intentSlotDescription: 'asdf',
                  entity: {
                    entityId: 7,
                    entityName: 'sys.date'
                  }
                },
                responseSlot: null
              },
              {
                finalResponseSlotId: 708,
                position: 'pos0',
                intentSlot: null,
                responseSlot: {
                  responseSlotId: 39,
                  responseSlotName: 'data',
                  responseSlotDescription: 'dasf'
                }
              }
            ]
          }
        }
      ],
      responseSlots: [
        {
          responseSlotId: 39,
          responseSlotName: 'data',
          responseSlotDescription: 'dasf'
        }
      ]
    }
  });
}
}

}

describe('CreateIntentLeftComponent', () => {
  let component: CreateIntentLeftComponent;
  let fixture: ComponentFixture<CreateIntentLeftComponent>;
  const positionSlot = new PositionAndSlot();
  const systemSlotsKeyInst = new SystemSlotKey();
  const conversationStagePojo = new ConversationStage();

  const systemSlotList = {
    systemSlotKeys: [
      {
        systemSlotKeyId: 2,
        systemSlotKeyName: 'GroupID'
      },
      {
        systemSlotKeyId: 1,
        systemSlotKeyName: 'MemberID'
      }
    ]
  };



  const entityList = {
    entities: [
      {
        entityId: 5,
        entityName: 'Claim_Number'
      },
      {
        entityId: 1,
        entityName: 'DOB'
      },
      {
        entityId: 3,
        entityName: 'MTPIN'
      },
      {
        entityId: 4,
        entityName: 'Phone Number'
      },
      {
        entityId: 8,
        entityName: 'Policy_Type'
      },
      {
        entityId: 2,
        entityName: 'SSN'
      },
      {
        entityId: 7,
        entityName: 'sys.date'
      },
      {
        entityId: 6,
        entityName: 'sys.number'
      }
    ]
  };

  // tslint:disable-next-line: prefer-const
  let getInfoNewArray = {
    conversationStages: [
      {
        sequenceNumber: 5,
        conversationStageId: 130,
        sendMessage: null,
        getInfo: {
          getInfoId: 39,
          promptQuestionAudioId: '1',
          promptQuestionValidationMessageAudioId: '22',
          positionAndSlots: [],
          promptQuestion: 'asdf',
          promptValidationMessage: 'asdf',
          intentSlot: {
            intentSlotId: 39,
            intentSlotName: 'sdafasd',
            intentSlotDescription: 'asdf',
            entity: {
              entityId: 3,
              entityName: 'MTPIN'
            }
          }

        },
        finalResponse: null
      },
      {
        sequenceNumber: 6,
        conversationStageId: 132,
        sendMessage: null,
        getInfo: {
          getInfoId: 40,
          promptQuestionAudioId: '1',
          promptQuestionValidationMessageAudioId: '20',
          positionAndSlots: [
            {
              position: 'pos0',
              systemSlot: {
                systemSlotKeyName: 'GroupID',
                systemSlotKeyId: 2
              }
            },
            {
              position: 'pos1',
              systemSlot: {
                systemSlotKeyName: 'MemberID',
                systemSlotKeyId: 1
              }
            }
          ],
          promptQuestion: 'sdfgsd%pos0%%pos1%sdfgsdgsdgs',
          promptValidationMessage: 'asf',
          intentSlot: {
            intentSlotId: 40,
            intentSlotName: 'new ',
            intentSlotDescription: 'asdf',
            entity: {
              entityId: 7,
              entityName: 'sys.date'
            }
          }
        },
        finalResponse: null
      }
    ],
  };
 // tslint:disable-next-line: prefer-const
  let conversationList = {
    conversation: {
      validationIntent: null,
        conversationStages: [
        {
          conversationStageId: null,
          finalResponse: null,
          getInfo: {
            getInfoId: '',
            intentSlotRcPojo: {
              html: '<div style=\'border-radius:10px;background:#f1f1f1;overflow:hidden;\'><img src=\'%pos0%\' style=\'overflow: hidden;width:100%; height:50%;\'/><div style=\'padding:15px;text-align:center;\'>%pos1%</div></div>',
              id: null,
              intentSlotRichCardTemplate: {
                templateId: 3
              },
              slotMap: {
                pos0: 'dfgdf',
                pos1: 'gdfgd'
              },
              dataMap: {},
              richCardInfo: '',
              renderHtml: '<div style=\'border-radius:10px;background:#f1f1f1;overflow:hidden;\'><img src=\'dfgdf\' style=\'overflow: hidden;width:100%; height:50%;\'/><div style=\'padding:15px;text-align:center;\'>gdfgd</div></div>'
            },
            positionAndSlots: [],
            promptQuestion: 'quest%pos0%%pos1%',
            promptValidationMessage: 'fsf',
            intentSlot: {
              intenSlotId: null,
              intentSlotName: 'first',
              intentSlotDescription: 'second',
              entity: {
                entityId: 62,
                entityName: 'benefit_service'
              }
            },
            promptQuestionAudioId: '1',
            promptQuestionAudioFileSize: '20',
            promptQuestionValidationMessageAudioId: '21',
            promptQuestionValidationMessageAudioSize: '22'
          },
          sendMessage: null,
          sequenceNumber: 1
        },
        {
          conversationStageId: null,
          finalResponse: null,
          getInfo: {
            getInfoId: '',
            intentSlotRcPojo: {
              html: '',
              id: null,
              intentSlotRichCardTemplate: {
                templateId: 4
              },
              slotMap: {
                pos0: 'image',
                pos1: 'desc',
                pos2: 'val1'
              },
              dataMap: {},
              richCardInfo: '',
              renderHtml: ''
            },
            positionAndSlots: [
              {
                position: 'pos0',
                systemSlot: {
                  systemSlotKeyName: 'GroupID',
                  systemSlotKeyId: 2
                }
              },
              {
                position: 'pos1',
                systemSlot: {
                  systemSlotKeyName: 'MemberID',
                  systemSlotKeyId: 1
                }
              }
            ],
            promptQuestion: 'quest%pos0%%pos1%',
            promptValidationMessage: 'fsf',
            intentSlot: {
              intenSlotId: null,
              intentSlotName: 'first',
              intentSlotDescription: 'second',
              entity: {
                entityId: 62,
                entityName: 'benefit_service'
              }
            },
            promptQuestionAudioId: null,
            promptQuestionAudioFileSize: null,
            promptQuestionValidationMessageAudioId: null,
            promptQuestionValidationMessageAudioSize: null
          },
          sendMessage: null,
          sequenceNumber: 1
        },
        {
          sendMessage: {
            messageId: null,
            messageText: 'rerwe%pos0%%pos1%',
            positionAndSlots: [
              {
                position: 'pos0',
                systemSlot: {
                  systemSlotKeyName: 'GroupID',
                  systemSlotKeyId: 2
                }
              },
              {
                position: 'pos1',
                systemSlot: {
                  systemSlotKeyName: 'MemberID',
                  systemSlotKeyId: 1
                }
              }
            ],
            audioFileId: null,
            audioFileSize: null
          },
          sequenceNumber: 2
        },
        {
          sequenceNumber: 3,
          conversationStageId: 860,
          sendMessage: null,
          getInfo: null,
          finalResponse: {
            finalResponseId: 349,
            finalResponseText: 'We are very happy to hear that you are extending these Health benefits to other family members. You can contact 1-800 toll free number to contact our Account Specialist will assist you with it instantly %pos0%  %pos1% ',
            intenRichCardResponse: {
              html: '',
              id: null,
              intentSlotRichCardTemplatePojo: {
                templateId: 4
              },
              slotMap: {
                pos0: 'image',
                pos1: 'descr',
                pos2: 'v11'
              },
              dataMap: {},
              richCardInfo: '',
              renderHtml: ''
            },
            positionAndSlots: [
              {
                position: 'pos0',
                systemSlot: {
                  systemSlotKeyName: 'GroupID',
                  systemSlotKeyId: 2
                }
              },
              {
                position: 'pos1',
                intentSlot: {
                  intentSlotName: 'first'
                }
              }
            ],
            finalResponseTextAudioId: null,
            finalResponseTextAudioSize: null
          }
        }
      ],
      responseSlots: [],
      cancelledIds: []
    }
  };

   // tslint:disable-next-line: prefer-const
  let sendMessageNewArray = {
    conversationStages: [
      {
        sendMessage: {
          messageId: null,
          messageText: 'rerwe%pos0%%pos1%',
          positionAndSlots: [
            {
              position: 'pos0',
              systemSlot: {
                systemSlotKeyName: 'GroupID',
                systemSlotKeyId: 2
              }
            },
            {
              position: 'pos1',
              systemSlot: {
                systemSlotKeyName: 'MemberID',
                systemSlotKeyId: 1
              }
            }
          ],
          audioFileId: null,
          audioFileSize: null
        },
        sequenceNumber: 2
      },
    ]
  };

  const conversationListFinalResp = {
    conversation: {
      conversationStages: [
        {
          sequenceNumber: 3,
          conversationStageId: 860,
          sendMessage: null,
          getInfo: null,
          finalResponse: {
            finalResponseId: 349,
            finalResponseText: 'We are very happy to hear that you are extending these Health benefits to other family members. You can contact 1-800 toll free number to contact our Account Specialist will assist you with it instantly %pos0%  %pos1% ',
            intenRichCardResponse: {
              html: '',
              id: null,
              intentSlotRichCardTemplatePojo: {
                templateId: 4
              },
              slotMap: {
                pos0: 'image',
                pos1: 'descr',
                pos2: 'v11'
              },
              dataMap: {
                1: {
                imageURL: 'USA',
                title: 'string'
              }
            },
              richCardInfo: {
                elementKey: ['imageURL', 'staticTxtBold', 'slotLabelAry'],
                html: '',
                editField: {type: 'inputImage', placeholder: 'Image slots',
                         maxlength: '', minlength: '', isSlotNeed: true, spellcheck: false,
                         fieldValue: [{url: 'image'}]}},
                         staticTxtBold: '',
                           renderHtml: ''
            },
            positionAndSlots: [
              {
                position: 'pos0',
                systemSlot: {
                  systemSlotKeyName: 'GroupID',
                  systemSlotKeyId: 2
                }
              },
              {
                position: 'pos1',
                intentSlot: {
                  intentSlotName: 'first'
                }
              }
            ],
            finalResponseTextAudioId: '1',
            finalResponseTextAudioSize: '2'
          }
        }
      ],
      responseSlots: [
        {
          responseSlotId: 39,
          responseSlotName: 'data',
          responseSlotDescription: 'dasf'
        }
      ]
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateIntentLeftComponent ],
      providers: [
        { provide: CreateIntentService, useClass: CreateIntentServiceStub },
        { provide: NgxSpinnerService, useClass: NgxSpinnerServiceStub },
        { provide: MatDialog, useClass: MatDialogStub }

      ],
      imports: [
        BrowserAnimationsModule,
        RouterTestingModule,
        HttpClientTestingModule,
        RouterModule.forRoot([]),
        AccordionModule.forRoot(),
        ToastrModule.forRoot(),
        FormsModule,
        ReactiveFormsModule,
        MatDialogModule,
        MatMenuModule,
        NgSelectModule,
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateIntentLeftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });



  it('validationIsActive method', () => {
    component.validationIsActive();
  });

  it('checkValidationTab method', () => {
    component.valEntityDropDown = undefined;
    component.checkValidationTab();
    component.changeVal('DOB');
  });



  it('it should call getConversationList, getIntentsDropdowns method', () => {
    const validationIsActiveSpy = spyOn(component, 'validationIsActive');
    const intentId = 61;
    const langId = '1';
    const chId = '2';
    const vaRoleId = '2';
    component.getConversationList(intentId, langId, chId);
    expect(validationIsActiveSpy).toHaveBeenCalled();
  });

  it('it should call methodExecutionGetConversationList method for IVR Channel', () => {
    component.isSendMsgActive  = true;
    component.channelRef = 'IVR',
    component.methodExecutionGetConversationList(conversationList.conversation);
    expect(component.isSendMsgActive).toBeTruthy();
    expect(component.channelRef).toContain('IVR');
  });

  it('it should call removeInfoSlot method for IVR Channel', () => {
    component.getInfoNewArray = getInfoNewArray.conversationStages;
    component.removeInfoSlot('1');
    // tslint:disable-next-line: no-unused-expression
    expect(component.getInfoNewArray).toContain;
    component.removeInfoSlot('0');
    // tslint:disable-next-line: no-unused-expression
    expect(component.getInfoNewArray).toContain;
    component.addInfoSlotPromis();
    // tslint:disable-next-line: no-unused-expression
    expect(component.getInfoNewArray).toContain;
  });

  it('it should call resetuploadChangeStatusValMsg method for IVR Channel', () => {
    component.resetuploadChangeStatusValMsg(getInfoNewArray.conversationStages);
  });

  // it('it should call getFinalResSendMsgTxt method for IVR Channel', () => {
  //   component.getFinalResSendMsgTxt(conversationListFinalResp.conversation.conversationStages);
  // });

  it('it should call addmsg method for IVR Channel', () => {
    component.sendMessageNewArray = conversationList.conversation.conversationStages;
    const data = conversationList.conversation.conversationStages[2];
    component.addMsg('data');
    component.addMsg('');
    component.delMsg(0);
    component.editMsg(0, data);
    component.updateMsg('datga');
    expect(component.sendMessageNewArray.length).toBeGreaterThanOrEqual(0);
    component.updateMsg('');
    component.onClickSendMsg('<systemSlot>');
    expect(component.sendMessageNewArray.length).toBeGreaterThanOrEqual(0);
    component.showSlotSendMsgAddingRigntClkPopUp('<systemSlot>');
    // component.onClickSystemSlot('<systemSlot>');
  });

  it('it should call showSlotAddingRigntClkPopUp method for IVR Channel', () => {
    component.sendMessageNewArray = sendMessageNewArray.conversationStages;
    component.showSlotSendMsgAddingRigntClkPopUp('<systemSlot>');
    // tslint:disable-next-line: no-unused-expression
    expect(component.sendMessageNewArray).toContain;

  });


  it('it should call common methods', () => {
    component.saveConversationFlowAudio('61', 1, 2, 'PROMPTMSG', 'sdfas', 0);
    component.openModalFileError('primary', 'secondaty');
    component.checkSlotValQt('check value <intentslot>', 0);
    component.checkSlotValRes('check value <intentslot>');
    component.checkSlotValMsg('check value <intentslot>');
    component.onClickSendMsgSlotItems('<systemSlot>');
    component.showDuplicateErrorMsgEntity();
    component.showGetInfoErrSpecial();
    component.showGetInfoErr();
    component.updateFinalText(conversationListFinalResp.conversation);

  });

  it('it should call audioFile methods', () => {
  component.fileInputMsgClear();
  component.fileInputQtClear('0');
  component.fileInputClear('0');
  component.fileInputFRClear();

  });

  it('it should call audioFile else methods', () => {
    component.sendMessageNewArray = sendMessageNewArray.conversationStages;
    component.channelRef = 'IVR';
    component.fileInputMsgClear();
    expect(component.sendMessageNewArray.length).toBeGreaterThanOrEqual(0);
    component.onClickSendMsg('<sf>');
    expect(component.channelRef).toContain('IVR');
    });
    // it('it should call setValueForEditField method for IVR Channel', () => {
    //   component.setValueForEditField(conversationListFinalResp.conversation.conversationStages[0].finalResponse.intenRichCardResponse,'l1 @1','v_1',0,'richCrdGetInfo');
    // });
});

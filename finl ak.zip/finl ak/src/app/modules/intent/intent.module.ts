// leaves.module.ts
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, OnInit, ViewChild, Output, EventEmitter, Input, Renderer2, ElementRef, ViewContainerRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { IntentListingComponent } from './intent-listing/intent-listing.component';
import { IntentRoutingModule } from './intent-routing.module';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgxSpinnerModule } from 'ngx-spinner';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { NgxCacheIfModule } from 'ngx-cache-if';
// import { TextElipsisComponent } from '../../shared/components/utils/text-elipses.component';
import { SharedModule } from 'src/app/shared.module';
import { MatMenuModule } from '@angular/material/menu';
import { MatListModule } from '@angular/material/list';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { MatChipsModule,  MatDialogModule} from '@angular/material';
import { MatIconModule } from '@angular/material/icon';
import { RichCardDialogComponent } from './create-intent/rich-card-dialog/rich-card-dialog.component';



@NgModule({
  declarations: [
    IntentListingComponent,
    // TextElipsisComponent,
    RichCardDialogComponent,

  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    NgSelectModule,
    NgxSpinnerModule,
    InfiniteScrollModule,
    ScrollingModule,
    MatSlideToggleModule,
    NgxCacheIfModule,
    IntentRoutingModule ,
    SharedModule,
    MatMenuModule,
    MatListModule,
    DragDropModule,
    MatDialogModule,
    MatChipsModule,
    MatIconModule,
   ],
   entryComponents: [
    RichCardDialogComponent
  ],
   schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
})
export class IntentModule { }

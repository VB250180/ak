import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConversationalMetricsRoutingModule } from './conversational-metrics-routing.module';
import { LiveMetricsComponent } from '.././conversational-metrics/live-metrics/live-metrics.component';
import { OperationMetricsComponent } from '.././conversational-metrics/operational-metrics/operation-metrics.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { NgSelectModule } from '@ng-select/ng-select';
import { ChartsModule } from 'ng2-charts';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
@NgModule({
  imports: [
    CommonModule,
    ConversationalMetricsRoutingModule,
    NgxSpinnerModule,
    AccordionModule.forRoot(),
    ScrollingModule,
    InfiniteScrollModule,
    ReactiveFormsModule,
    FormsModule,
    NgSelectModule,
    ChartsModule,
    NgxChartsModule,
    NgxDaterangepickerMd,
    NgMultiSelectDropDownModule.forRoot()
  ],
  declarations: [LiveMetricsComponent, OperationMetricsComponent]
})
export class ConversationalMetricsModule { }

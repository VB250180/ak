import { Component, NgModule } from '@angular/core';
import { ConversationalMetricsService } from '../../../core/services/conversational-metrics/conversational-metrics.service';
import { IntentService } from '../../../core/services/intent/intent.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LiveMetricsComponent } from './live-metrics.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';

class IntentServiceStub {
  public getInputs(userId: number): Observable<any> {
    console.log('user id is ', userId);
    if (userId === 1 || userId === 0 || userId === null) {
      return of({
        virtualAgentRoleMaps: [{ vrmId: 1 }, { vrmId: 2 }]
      });
    } else {
      return throwError('Error Exists');
    }
  }
}

class ConversationalMetricsServiceStub {
  public livemetricdata(mode, va, channel, language, postdata, paramUserid): Observable<any> {
    console.log('coming here or not??');
    if (mode === 'live' && va === 0) {
      return Observable.of([
        {
          data: { averagesessionTime: '3 hrs 51 mins 57 secs', livesessioncount: 98 }
        },
        {
          data: {
            intentcount: 16, totalintent: 49, intentaccuracy: 32.65,
            topintents: [{ value: 15, name: 'status of a policy' }, { value: 1, name: 'Nelflix' },
            { value: 14, name: 'status of a policy' }, { value: 2, name: 'Nelflix' },
            { value: 13, name: 'status of a policy' }, { value: 3, name: 'Nelflix' },
            { value: 12, name: 'status of a policy' }, { value: 4, name: 'Nelflix' },
            { value: 11, name: 'status of a policy' }, { value: 5, name: 'Nelflix' },
            { value: 10, name: 'status of a policy' }, { value: 6, name: 'Nelflix' }
          ]
          }
        },
        {
          data: { updated_date: '2020-04-29T11:37:44.373Z' }
        }]);
    } else if (mode === 'live' && va === 1) {
      return Observable.of([
        {
          data: { averagesessionTime: '3 hrs 51 mins 57 secs', livesessioncount: 98 }
        },
        {
          data: {
            intentcount: 16, totalintent: 49,
            topintents: []
          }
        },
        {
          data: { updated_date: '2020-04-29T11:37:44.373Z' }
        }]);
    } else {
      return Observable.of({
        errorBody: {}
      });
    }
  }
}

class AuthenticationServiceStub {
  getCurrentUserId() {
    return 1;
  }
}

describe('LiveMetricsComponent', () => {
  let component: LiveMetricsComponent;
  let fixture: ComponentFixture<LiveMetricsComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: IntentService, useClass: IntentServiceStub },
        { provide: ConversationalMetricsService, useClass: ConversationalMetricsServiceStub },
        { provide: AuthenticationService, useClass: AuthenticationServiceStub }
      ],
      declarations: [LiveMetricsComponent],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LiveMetricsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });



  it('ngOnInit should call towo methods getdropdown and getreportdata', () => {
    const getdropdownValuesSpy = spyOn(component, 'getdropdownValues');
    const getReportDataSpy = spyOn(component, 'getReportData');
    component.userId = 1;
    component.ngOnInit();
    expect(getdropdownValuesSpy).toHaveBeenCalled();
    expect(getReportDataSpy).toHaveBeenCalledWith('live', 0, 0, 0);
  });

  it('refresh method calling', () => {
    component.channels = [{ id: 1 }, { id: 2 }];
    component.languages = [{ id: 1 }, { id: 2 }];
    const getReportDataSpy = spyOn(component, 'getReportData');
    component.refresh();
    expect(component.channels).toEqual([]);
    expect(component.languages).toEqual([]);
    expect(getReportDataSpy).toHaveBeenCalledWith('live', 0, 0, 0);
  });

  it('statusFilter should initialize intentFilter values and call getReportData method once', () => {
    const getReportDataSpy = spyOn(component, 'getReportData');
    const status = 0;
    const isRequestNeeded = false;
    component.statusFilter(status, isRequestNeeded);
    expect(component.intentFilter.va).toEqual(status);
    expect(component.intentFilter.channel).toEqual(0);
    expect(component.intentFilter.language).toEqual(0);
    expect(component.IntentListingForm.controls['channel'].value).toEqual(0);
    expect(component.IntentListingForm.controls['language'].value).toEqual(0);
    expect(getReportDataSpy).toHaveBeenCalledTimes(1);
  });

  it('statusFilter should initialize intentFilter values and call getIntentList method twice', () => {
    const getReportDataSpy = spyOn(component, 'getReportData');
    const status = 0;
    const isRequestNeeded = true;

    component.statusFilter(status, isRequestNeeded);

    expect(component.intentFilter.va).toEqual(status);
    expect(component.intentFilter.channel).toEqual(0);
    expect(component.intentFilter.language).toEqual(0);
    expect(component.IntentListingForm.controls['channel'].value).toEqual(0);
    expect(component.IntentListingForm.controls['language'].value).toEqual(0);
    expect(getReportDataSpy).toHaveBeenCalledTimes(1);
  });

  it('statusFilter should  call getReportData', () => {
    const getReportDataSpy = spyOn(component, 'getReportData');
    const status = 1;
    const isRequestNeeded = false;
    component.statusFilter(status, isRequestNeeded);
    expect(getReportDataSpy).toHaveBeenCalledTimes(1);
  });

  it('languagefilter method calling', () => {

    const getReportDataSpy = spyOn(component, 'getReportData');
    const language = {
      id: '1'
    };
    component.languageFilter(language);
    expect(component.intentFilter.language).toEqual(language);
    expect(getReportDataSpy).toHaveBeenCalledWith('live', 0, 0, component.intentFilter.language);
  });

  it('chanenelfilter method calling', () => {

    const getReportDataSpy = spyOn(component, 'getReportData');
    const channel = {
      id: '1'
    };
    component.channelFilter(channel);
    expect(component.intentFilter.channel).toEqual(channel);
    expect(getReportDataSpy).toHaveBeenCalledWith('live', 0, component.intentFilter.channel, 0);
  });

  it('getReportData method calling', () => {
    const modeval = 'live';
    const vadata = 1;
    const chnldata = 0;
    const langdata = 0;
    component.getReportData(modeval, vadata, chnldata, langdata);
    expect(component.liveAccuracy).toEqual(0);
  });

  it('callIntentListByparam method calling', () => {

    component.callIntentListByparam();
    expect(component.intentFilter.va).toEqual(0);
    expect(component.intentFilter.channel).toEqual(0);
    expect(component.intentFilter.language).toEqual(0);
  });

  it('yAxisTickFormatting method calling', () => {
    const value = 1;
    const result = component.yAxisTickFormatting(value);
    expect(result).toEqual(value);
  });

  it('yAxisTickFormatting method calling', () => {
    const value = 1.4;
    const result = component.yAxisTickFormatting(value);
    expect(result).toEqual('');
  });
});

import { Component, NgModule, OnInit, OnDestroy } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { ConversationalMetricsService } from '../../../core/services/conversational-metrics/conversational-metrics.service';
import { FormControl, FormGroup, ReactiveFormsModule, FormsModule, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import moment from 'moment';
import { IntentService } from '../../../core/services/intent/intent.service';
import { Subscription } from 'rxjs';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';

@Component({
  selector: 'app-metrics',
  templateUrl: './live-metrics.component.html',
  styleUrls: ['./live-metrics.component.scss']
})
export class LiveMetricsComponent implements OnInit, OnDestroy {
  intentFilter: any = {
    va: 0,
    channel: 0,
    language: 0
  };
  userId = 0;
  channel: any = [];
  language: any = [];
  IntentListingForm: FormGroup;
  livemetricdataSubscription: Subscription;
  getInputsSubscription: Subscription;
  channels: any = [];
  languages: any = [];
  vaById: any = {};
  vaLists: any = [];
  liveSessions: any;
  liveAccuracy: any;
  averageSession: any;
  totalProgress: any;
  progress: any;
  user: any = [];
  lastUpdatedDate: any;
  updatedDate: any;
  updatedTime: any;
  colorsary = [];
  top10Intents = [];
  verticalbarView: any[] = [400, 500];
  showXAxis = false;
  showYAxis = true;
  gradient = false;
  showLegend = false;
  showXAxisLabel = true;
  xAxisLabel = 'Intents';
  showYAxisLabel = true;
  yAxisLabel = 'Count';
  colorScheme = {
    domain: ['#b2d4f5', '#fcc3a7', '#8fd1bb', '#f8b4c9', '#d3bdeb', '#83d1da', '#99a0f9', '#8fd1bb', '#d1d9dc', '#fccaca', '#AAAAAA']
  };
  public doughnutChart1Options: any = {
    cutoutPercentage: 90,
    elements: {
      arc: {
        borderWidth: 0
      }
    },
    tooltips: {
      enabled: false
    }
  };
  public pieChart2Colors = [
    {
      backgroundColor: ['#57AB57', '#ccc'],
    },
  ];
  yAxisTickFormatting = (value: number) => {
    if (Math.floor(value) !== value) {
      return '';
    }
    return value;
  }



  constructor(
    private intentService: IntentService,
    private reportService: ConversationalMetricsService,
    private spinner: NgxSpinnerService,
    private authService: AuthenticationService
  ) {
    this.userId = this.authService.getCurrentUserId();
    this.IntentListingForm = new FormGroup({
      va: new FormControl(null, Validators.required),
      channel: new FormControl(null, Validators.required),
      language: new FormControl(null, Validators.required),

    });
  }

  ngOnInit() {
    this.getdropdownValues();
    this.getReportData('live', 0, 0, 0);
    console.log(this.intentFilter);
  }

  getReportData(modeval, vadata, chnldata, langdata) {
    this.liveSessions = 0;
    this.liveAccuracy = 0;
    this.averageSession = 0;
    this.top10Intents = [];
    this.spinner.show();
    console.log(this.intentFilter);
    const va = vadata;
    const chnl = chnldata;
    const lang = langdata;
    const mode = modeval;
    this.colorsary = [];
    const params = {
      startDate: moment(new Date()).format('YYYY-MM-DD'),
      endDate: moment(new Date()).format('YYYY-MM-DD'),
      channel: chnl,
      va,
      lang,
      userId: this.authService.getCurrentUserId(),
      active: 'true'
    };
    const paramUid = {
      userId: this.authService.getCurrentUserId()
    };
    this.livemetricdataSubscription = this.reportService.livemetricdata(mode, va, chnl, lang, params, paramUid).subscribe((res: any) => {
      this.spinner.hide();
      let datl;
      this.liveSessions = res[0]['data']['livesessioncount'];
      this.user = res[2]['data'];
      const takedate = moment(new Date(this.user.updated_date)).format('DD MMMM YYYY');
      const taketime = moment(new Date(this.user.updated_date)).format('LTS');
      console.log(takedate);
      this.updatedDate = takedate;
      this.updatedTime = taketime;
      this.lastUpdatedDate = this.user.updated_date;
      console.log('lastupated server time', this.lastUpdatedDate);
      if (res[1]['data']['intentaccuracy']) {
        datl = res[1]['data']['intentaccuracy'];
      } else {
        datl = 0;
      }
      this.liveAccuracy = datl;
      this.averageSession = res[0]['data']['averagesessionTime'];
      if (res[1]['data']['topintents'].length > 0) {
        const sortedInput = res[1]['data']['topintents'].sort((a, b) => b.value - a.value);
        const ary = [];
        this.colorsary = [];
        for (let i = 0; i < sortedInput.length; i++) {
          if (i <= 9) {
            const itemstyle = {
              background: this.colorScheme.domain[i]
            };
            sortedInput[i].colors = itemstyle;
            ary.push(sortedInput[i]);
            this.colorsary.push(sortedInput[i]);
            console.log(this.colorsary);
          }
        }
        const inval = 10 - ary.length;
        if (inval > 0) {
          for (let i = 0; i < inval; i++) {
            ary.push({ value: 0, name: 'null' + i });
          }
        }
        this.top10Intents = ary;
        console.log('topintents desc', this.top10Intents);
      }
    },
      err => console.error(err));

  }

  refresh() {
    this.channels = [];
    this.languages = [];
    this.intentFilter.va = 0, this.intentFilter.channel = 0, this.intentFilter.language = 0;
    this.getReportData('live', 0, 0, 0);
  }

  getdropdownValues() {
    this.getInputsSubscription = this.intentService.getInputs(this.userId).subscribe((res: any) => {
      this.vaLists = res.virtualAgentRoleMaps;
      for (let i = 0; i < res['virtualAgentRoleMaps'].length; i++) {
        this.vaById[res['virtualAgentRoleMaps'][i].vrmId] = res['virtualAgentRoleMaps'][i];
      }
      console.log(this.vaById);
      setTimeout(() => {
        this.callIntentListByparam();
      }, 1000);

    }, (err: any) => { console.error('Error In Intent Listinbg dropdown'); console.error(err); });
  }

  callIntentListByparam() {
    this.spinner.hide();
    console.log('--------------> ');
    this.intentFilter.va = 0, this.intentFilter.channel = 0, this.intentFilter.language = 0;
  }

  statusFilter(status: string | number, isRequestNeeded: boolean) {
    console.log('On va change --> ', status, isRequestNeeded);
    console.log(this.intentFilter);
    if (status === 0 || status === '0') {
      this.intentFilter.va = status, this.intentFilter.channel = 0, this.intentFilter.language = 0;
      this.languages = [], this.channels = [];
      this.IntentListingForm.patchValue({ channel: 0, language: 0 });
    } else {
      this.languages = this.vaById[status].languages;
      this.channels = this.vaById[status].channels;
    }
    if (isRequestNeeded) {
      this.intentFilter.va = status, this.intentFilter.channel = 0, this.intentFilter.language = 0;
      this.IntentListingForm.patchValue({
        channel: this.intentFilter.channel,
        language: this.intentFilter.language,
      });
    }
    this.getReportData('live', this.intentFilter.va, this.intentFilter.channel, this.intentFilter.language);
  }

  channelFilter(channel: { id: any; }) {
    console.log('channelFilter ====> ', channel);
    this.intentFilter.channel = channel;
    this.getReportData('live', this.intentFilter.va, this.intentFilter.channel, this.intentFilter.language);

  }

  languageFilter(language: { id: any; }) {
    console.log(' languageFilter ====> ', language);
    this.intentFilter.language = language;
    this.getReportData('live', this.intentFilter.va, this.intentFilter.channel, this.intentFilter.language);
  }

  ngOnDestroy() {
    if (this.livemetricdataSubscription) {
      this.livemetricdataSubscription.unsubscribe();
    }
    if (this.getInputsSubscription) {
      this.getInputsSubscription.unsubscribe();
    }
  }

}

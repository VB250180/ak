import { Component, NgModule, OnInit, OnDestroy } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { ConversationalMetricsService } from '../../../core/services/conversational-metrics/conversational-metrics.service';
import { IntentService } from '../../../core/services/intent/intent.service';
import { FormControl, FormGroup, ReactiveFormsModule, FormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { MultiDataSet, Label } from 'ng2-charts';
import { ChartType } from 'chart.js';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import moment from 'moment';
import { Subscription } from 'rxjs';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';

@Component({
  selector: 'app-operationmetrics',
  templateUrl: './operation-metrics.component.html',
  styleUrls: ['./operation-metrics.component.scss']
})
export class OperationMetricsComponent implements OnInit, OnDestroy {
  intentFilter: any = {
    va: 0,
    channel: 0,
    language: 0
  };
  userId = 0;
  channel: any = [];
  language: any = [];
  IntentListingForm: FormGroup;
  joindataSubscription: Subscription;
  getInputsSubscription: Subscription;
  channels: any = [];
  languages: any = [];
  vaById: any = {};
  vaLists: any = [];
  len: number;
  todayTab = false;
  weekTab = false;
  monthTab = true;
  customTab = false;
  liveSessions: any;
  liveAccuracy: any;
  averageSession: any;
  today: any;
  public doughnutChart1Options: any = {
    cutoutPercentage: 90,
    elements: {
      arc: {
        borderWidth: 0
      }
    },
    tooltips: {
      enabled: false
    }
  };
  public doughnutChart2Options: any = {
    cutoutPercentage: 90,
    elements: {
      arc: {
        borderWidth: 0
      }
    },
    tooltips: {
      enabled: false
    }
  };
  colorsaryIntemts = [];
  colorsaryReasons = [];
  lastUpdatedDate: any;
  updatedDate: any;
  updatedTime: any;
  user;


  public classifychartsoptions: any = {
    cutoutPercentage: 90,
    elements: {
      arc: {
        borderWidth: 0
      }
    },
    tooltips: {
      enabled: true
    },
    legend: {
      position: 'bottom',
      labels: {
        fontSize: 10,
        usePointStyle: true
      }
    }
  };
  // loadvalue = 0



  public pieChart2Colors = [
    { backgroundColor: ['#57AB57', '#ccc'] },
  ];

  public classifycolors = [
    { backgroundColor: ['#e597d2', '#d3bdeb', '#f79191'] },
  ];
  selected: { fromDate: Date, endDate: Date };

  // total sesion pie chart
  public totalsessionLabels: Label[] = [];
  public totalsessionData = [];
  public totalsessionChartType: ChartType = 'pie';

  public callhandlingLabels: Label[] = [];
  public callhandlingData = [];
  public callhandlingChartType: ChartType = 'doughnut';
  totalses: any;

  public clasifyLabels: Label[] = [];
  public clasifyData = [];
  public clasifyChartType: ChartType = 'doughnut';
  averagessionleng: any;
  intentServedaccuracy: any;
  roundofhandlingdata: any;
  top10Intents = [];
  top10Reasons = [];

  verticalbarView1: any[] = [550, 200];
  showXAxis1 = false;
  showYAxis1 = true;
  gradient1 = false;
  showLegend1 = false;
  showXAxisLabel1 = true;
  xAxisLabel1 = 'Intents';
  showYAxisLabel1 = true;
  yAxisLabel1 = 'Count';
  colorScheme1 = {
    domain: ['#b2d4f5', '#fcc3a7', '#8fd1bb', '#f8b4c9', '#d3bdeb', '#83d1da', '#99a0f9', '#8fd1bb', '#d1d9dc', '#fccaca', '#AAAAAA']
  };

  verticalbarView: any[] = [500, 200];
  showXAxis = true;
  showYAxis = true;
  gradient = false;
  showLegend = false;
  showXAxisLabel = true;
  xAxisLabel = 'Intents';
  showYAxisLabel = true;
  yAxisLabel = 'Count';
  colorScheme = {
    domain: ['#b2d4f5', '#fcc3a7', '#8fd1bb', '#f8b4c9', '#d3bdeb', '#83d1da', '#99a0f9', '#8fd1bb', '#d1d9dc', '#fccaca', '#AAAAAA']
  };



  constructor(
    private intentService: IntentService,
    private reportService: ConversationalMetricsService,
    private spinner: NgxSpinnerService,
    private authService: AuthenticationService) {
    this.userId = this.authService.getCurrentUserId();
    this.today = moment();
    this.IntentListingForm = new FormGroup({
      va: new FormControl(null, Validators.required),
      channel: new FormControl(null, Validators.required),
      language: new FormControl(null, Validators.required)
    });

  }



  ngOnInit() {
    this.getdropdownValues();
    this.aTab('MTD');
    // this.getOpReportData('live', 0, 0, 0, this.selected.fromDate, this.selected.endDate);
    console.log(this.intentFilter);
  }

  yAxisTickFormatting = (value: number) => {
    if (Math.floor(value) !== value) {
      return '';
    }
    return value;
  }

  refresh() {
    this.channels = [];
    this.languages = [];
    this.intentFilter.va = 0, this.intentFilter.channel = 0, this.intentFilter.language = 0;
    this.aTab('MTD');
  }

  getOpReportData(modeval, vadata, chnldata, langdata, fdate, todate) {

    this.liveSessions = 0;
    this.liveAccuracy = 0;
    this.averageSession = 0;
    this.top10Intents = [];
    this.intentServedaccuracy = 0;
    this.totalses = 0;
    this.clasifyLabels = [];
    this.clasifyData = [];
    this.averagessionleng = 0;
    this.top10Reasons = [];
    this.totalsessionLabels = [];
    this.totalsessionData = [];
    this.totalsessionChartType = 'pie';
    this.callhandlingLabels = [];
    this.roundofhandlingdata = 0;
    this.callhandlingData = [];
    this.spinner.show();
    console.log(this.intentFilter);

    const params = {
      startDate: moment(fdate).format('YYYY-MM-DD'),
      endDate: moment(todate).format('YYYY-MM-DD'),
      channel: chnldata,
      va: vadata,
      lang: langdata,
      userId: this.userId
    };

    const top10params = {
      startDate: moment(fdate).format('YYYY-MM-DD'),
      endDate: moment(todate).format('YYYY-MM-DD'),
      channel: chnldata,
      va: vadata,
      lang: langdata,
      userId: this.userId,
      active: 'false'
    };
    const paramUid = {
      userId: this.userId
    };
    console.log(params);
    this.colorsaryReasons = [];
    this.colorsaryIntemts = [];
    this.joindataSubscription = this.reportService.joindata(params, top10params, paramUid).subscribe((res: any) => {
      console.log(res);
      this.spinner.hide();
      this.user = res[4]['data'];
      const takedate = moment(new Date(this.user.updated_date)).format('DD MMMM YYYY');
      const taketime = moment(new Date(this.user.updated_date)).format('LTS');
      console.log(takedate);
      this.updatedDate = takedate;
      this.updatedTime = taketime;
      this.lastUpdatedDate = this.user.updated_date;
      console.log('lastupated server time', this.lastUpdatedDate);
      if (res[1]['status'] === 200) {
        // let sortedInput =  [ { 'value': 1, 'name': 'Live_test1' },
        // { 'value': 4, 'name': 'Live_test2' },
        // { 'value': 5, 'name': 'Live_test3' },
        // { 'value': 7, 'name': 'Live_test4' },
        // { 'value': 14, 'name': 'Live_test5' },
        // { 'value': 22, 'name': 'Live_test6' },
        // { 'value': 33, 'name': 'Live_test7' },
        // { 'value': 14, 'name': 'Live_test8' },
        // { 'value': 31, 'name': 'Live_test9' },
        // { 'value': 11, 'name': 'Live_test10' },
        // { 'value': 15, 'name': 'Live_test11' }]
        if (res[1]['data']['topintents']) {
          const sortedInput = res[1]['data']['topintents'].sort((a, b) => b.value - a.value);
          const ary = [];
          for (let i = 0; i < sortedInput.length; i++) {
            if (i <= 9) {
              const itemstyle = {
                background: this.colorScheme.domain[i]
              };

              sortedInput[i].colors = itemstyle;
              ary.push(sortedInput[i]);
              this.colorsaryIntemts.push(sortedInput[i]);
              // console.log(this.colorsaryIntemts);
            }
          }
          console.log(ary);
          const inval = 10 - ary.length;
          if (inval > 0) {
            for (let j = 0; j < inval; j++) {
              ary.push({ value: 0, name: 'null' + j });
            }
          }
          this.top10Intents = ary;
          console.log('top10', this.top10Intents);
        } else {
          this.top10Intents = [];
        }
        this.intentServedaccuracy = Math.round(res[1]['data']['intentaccuracy']);
        console.log('intentservedacc', this.intentServedaccuracy);
      }
      if (res[2]['status'] === 200) {
        this.clasifyLabels = [res[2]['data']['data'][0]['name'], res[2]['data']['data'][1]['name'], res[2]['data']['data'][2]['name']];
        this.clasifyData = [res[2]['data']['data'][0]['value'], res[2]['data']['data'][1]['value'], res[2]['data']['data'][2]['value']];
        this.averagessionleng = res[2]['data']['averageminutes'];
      }
      if (res[0]['status'] === 'success') {
        this.liveSessions = res[0]['data']['livesessioncount'];
        this.liveAccuracy = res[0]['data']['liveaccuracyoercent'];
        this.averageSession = res[0]['data']['averagesessionTime'];
        this.totalses = res[0]['data']['totalsession'];
        console.log('tottalses', this.totalses);
        if (res[0]['data']['data'][0]['name']) {
          this.totalsessionLabels = [res[0]['data']['data'][0]['name'], res[0]['data']['data'][1]['name']];
          if (res[0]['data']['data'][0]['value'] === 0 && res[0]['data']['data'][1]['value'] === 0) {
            this.totalsessionData = [];
          } else {
            this.totalsessionData = [res[0]['data']['data'][0]['value'], res[0]['data']['data'][1]['value']];
          }
        }
        console.log('total session data', this.totalsessionData);
        this.totalsessionChartType = 'doughnut';

        console.log('dta is there');
        this.callhandlingLabels = [res[0]['data']['data'][2]['name']];
        this.roundofhandlingdata = Math.round(res[0]['data']['data'][2]['value']);
        this.callhandlingData = [this.roundofhandlingdata, 100 - this.roundofhandlingdata];
        this.callhandlingChartType = 'doughnut';
      } else {
        this.roundofhandlingdata = 0;
        this.callhandlingData = [this.roundofhandlingdata, 100 - this.roundofhandlingdata];
        console.log('callhandlingData', this.callhandlingData);
        console.log('total session data', this.totalsessionData);
        this.totalsessionData = [];
      }
      if (res[3]['status'] === 200) {
        const sortedInput1 = res[3]['data']['topreasons'].sort((a, b) => b.value - a.value);
        const ary = [];
        for (let k = 0; k < sortedInput1.length; k++) {
          if (k < 9) {
            const itemstyle = {
              background: this.colorScheme.domain[k]
            };
            sortedInput1[k].colors = itemstyle;
            ary.push(sortedInput1[k]);
            this.colorsaryReasons.push(sortedInput1[k]);
            console.log(this.colorsaryReasons);
          }
        }
        const inval = 10 - ary.length;
        if (inval > 0) {
          for (let i = 0; i < inval; i++) {
            ary.push({ value: 0, name: 'null' + i });

          }
        }
        this.top10Reasons = ary;
        console.log('reasons', this.top10Reasons);
      }


    },
      err => console.error(err));

  }

  getdropdownValues() {
    this.getInputsSubscription = this.intentService.getInputs(this.userId).subscribe((res: any) => {
      this.vaLists = res.virtualAgentRoleMaps;
      for (let i = 0; i < res['virtualAgentRoleMaps'].length; i++) {
        this.vaById[res['virtualAgentRoleMaps'][i].vrmId] = res['virtualAgentRoleMaps'][i];
      }
      console.log(this.vaById);
      setTimeout(() => {
        this.callIntentListByparam();
      }, 1000);

    }, (err: any) => { console.error('Error In Intent Listinbg dropdown'); console.error(err); });
  }

  callIntentListByparam() {
    this.spinner.hide();
    console.log('--------------> ');
    this.intentFilter.va = 0, this.intentFilter.channel = 0, this.intentFilter.language = 0;

  }

  statusFilter(status: string | number, isRequestNeeded: boolean) {
    console.log('On va change --> ', status, isRequestNeeded);
    console.log(this.intentFilter);
    if (status === 0 || status === '0') {
      this.intentFilter.va = status, this.intentFilter.channel = 0, this.intentFilter.language = 0;
      this.languages = [], this.channels = [];
      this.IntentListingForm.patchValue({ channel: 0, language: 0 });
    } else {
      this.languages = this.vaById[status].languages;
      this.channels = this.vaById[status].channels;
    }

    if (isRequestNeeded) {
      this.intentFilter.va = status, this.intentFilter.channel = 0, this.intentFilter.language = 0;
      this.IntentListingForm.patchValue({
        channel: this.intentFilter.channel,
        language: this.intentFilter.language,
      });

    }
    this.getOpReportData('live', this.intentFilter.va, this.intentFilter.channel, this.intentFilter.language, this.selected.fromDate, this.selected.endDate
    );
  }

  channelFilter(channel: { id: any; }) {
    console.log('channelFilter ====> ', channel);
    this.intentFilter.channel = channel;
    this.getOpReportData('live', this.intentFilter.va, this.intentFilter.channel, this.intentFilter.language, this.selected.fromDate, this.selected.endDate);

  }

  oplanguageFilter(language: { id: any; }) {
    console.log(' languageFilter ====> ', language);
    this.intentFilter.language = language;
    this.getOpReportData('live', this.intentFilter.va, this.intentFilter.channel, this.intentFilter.language, this.selected.fromDate, this.selected.endDate);
  }

  aTab(data) {
    console.log(data);
    if (data === 'Today') {
      this.selected = {
        fromDate: new Date(),
        endDate: new Date()
      };
      console.log(this.selected);
      this.todayTab = true;
      this.weekTab = false;
      this.monthTab = false;
      this.customTab = false;
      this.getOpReportData('live', this.intentFilter.va, this.intentFilter.channel, this.intentFilter.language, this.selected.fromDate, this.selected.endDate);
    } else if (data === 'WTD') {
      const edate = new Date();
      const sevenDaysAgo = new Date(edate);
      sevenDaysAgo.setDate(edate.getDate() - 7);
      const sdate = sevenDaysAgo;
      this.selected = {
        fromDate: sdate,
        endDate: edate
      };
      console.log(this.selected);
      this.todayTab = false;
      this.weekTab = true;
      this.monthTab = false;
      this.customTab = false;
      this.getOpReportData('live', this.intentFilter.va, this.intentFilter.channel, this.intentFilter.language, this.selected.fromDate, this.selected.endDate);
    } else if (data === 'MTD') {
      const edate = new Date();
      const myDate = new Date();
      const sdate = new Date(myDate.getFullYear(), myDate.getMonth(), 1);
      this.selected = {
        fromDate: sdate,
        endDate: edate
      };
      this.todayTab = false;
      this.weekTab = false;
      this.monthTab = true;
      this.customTab = false;
      this.getOpReportData('live', this.intentFilter.va, this.intentFilter.channel, this.intentFilter.language, this.selected.fromDate, this.selected.endDate);
    } else if (data === 'customDate') {
      console.log('cus');
      this.todayTab = false;
      this.weekTab = false;
      this.monthTab = false;
      this.customTab = true;
    }

  }
  rangeClick(ev) {
    // this.loadvalue = 1
    // console.log(new Date(this.selected.fromDate));
    // console.log(new Date(this.selected.endDate));
    if (ev.fromDate != null && ev.endDate != null) {
      this.getOpReportData('live', this.intentFilter.va, this.intentFilter.channel, this.intentFilter.language, new Date(this.selected.fromDate), new Date(this.selected.endDate));
    }
  }

  ngOnDestroy() {
    if (this.joindataSubscription) {
      this.joindataSubscription.unsubscribe();
    }
    if (this.getInputsSubscription) {
      this.getInputsSubscription.unsubscribe();
    }
  }
}

import { Component, NgModule } from '@angular/core';
import { ConversationalMetricsService } from '../../../core/services/conversational-metrics/conversational-metrics.service';
import { IntentService } from '../../../core/services/intent/intent.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { OperationMetricsComponent } from './operation-metrics.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { ValueConverter } from '@angular/compiler/src/render3/view/template';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';

class IntentServiceStub {
    public getInputs(userId: number): Observable<any> {
        console.log('user id is ', userId);
        if (userId === 1 || userId === 0 || userId === null) {
            return of({
                virtualAgentRoleMaps: [{ vrmId: 1 }, { vrmId: 2 }]
            });
        } else {
            return throwError('Error Exists');
        }
    }
}

class ConversationalMetricsServiceStub {
    public joindata(params, top10params, paramUid): Observable<any> {
        console.log('coming here, phew', params);
        if (params.va === 1 || params.va === 0) {
            return Observable.of([
                {
                    status: 'success',
                    data: {
                        averagesessionTime: '719203742031m 73s',
                        totalsession: 29,
                        data: [
                            {
                                name: 'Conversation transfered',
                                value: 5
                            },
                            {
                                name: 'Conversation Served',
                                value: 24
                            },
                            {
                                name: 'Handling Capacity',
                                value: 82.75862068965517
                            }
                        ]
                    }
                },
                {
                    status: 200,
                    data: {
                        intentaccuracy: 62.07,
                        intentcount: 18,
                        topintents: [{ value: 15, name: 'status of a policy' }, { value: 1, name: 'Nelflix' },
                        { value: 14, name: 'status of a policy' }, { value: 2, name: 'Nelflix' },
                        { value: 13, name: 'status of a policy' }, { value: 3, name: 'Nelflix' },
                        { value: 12, name: 'status of a policy' }, { value: 4, name: 'Nelflix' },
                        { value: 11, name: 'status of a policy' }, { value: 5, name: 'Nelflix' },
                        { value: 10, name: 'status of a policy' }, { value: 6, name: 'Nelflix' }
                        ]
                    }
                },
                {
                    status: 200,
                    data: {
                        averageminutes: '1m 29s',
                        data: [{ name: '0-10sec', value: 6 }, { name: '11-20sec', value: 11 }, { name: '>20sec', value: 33 }]
                    }
                },
                {
                    status: 200,
                    data: {

                        topreasons: [{ value: 15, name: 'status of a policy' }, { value: 1, name: 'Nelflix' }]
                    }
                },
                {
                    data: { updated_date: '2020-04-29T11:37:44.373Z' }
                }]);
        } else if (params.va === 2) {
            return Observable.of([
                {
                    status: 'not',
                    data: {
                        averagesessionTime: '719203742031m 73s',
                        totalsession: 29,
                        data: [
                            {
                                name: 'Conversation transfered',
                                value: 5
                            },
                            {
                                name: 'Conversation Served',
                                value: 24
                            },
                            {
                                name: 'Handling Capacity',
                                value: 82.75862068965517
                            }
                        ]
                    }
                },
                {
                    status: 300,
                    data: {
                        intentaccuracy: 62.07,
                        intentcount: 18,
                        topintents: [{ value: 15, name: 'status of a policy' }, { value: 1, name: 'Nelflix' },
                        { value: 14, name: 'status of a policy' }, { value: 2, name: 'Nelflix' },
                        { value: 13, name: 'status of a policy' }, { value: 3, name: 'Nelflix' },
                        { value: 12, name: 'status of a policy' }, { value: 4, name: 'Nelflix' },
                        { value: 11, name: 'status of a policy' }, { value: 5, name: 'Nelflix' },
                        { value: 10, name: 'status of a policy' }, { value: 6, name: 'Nelflix' }
                        ]
                    }
                },
                {
                    status: 300,
                    data: {
                        averageminutes: '1m 29s',
                        data: [{ name: '0-10sec', value: 6 }, { name: '11-20sec', value: 11 }, { name: '>20sec', value: 33 }]
                    }
                },
                {
                    status: 300,
                    data: {

                        topreasons: [{ value: 15, name: 'status of a policy' }, { value: 1, name: 'Nelflix' }]
                    }
                },
                {
                    data: { updated_date: '2020-04-29T11:37:44.373Z' }
                }]);
        } else if (params.va === 3) {
            return Observable.of([
                {
                    status: 'success',
                    data: {
                        averagesessionTime: '719203742031m 73s',
                        totalsession: 29,
                        data: [{ id: 1 }]
                    }
                },
                {
                    status: 200,
                    data: {
                        intentaccuracy: 62.07,
                        intentcount: 18
                    }
                },
                {
                    status: 200,
                    data: {
                        averageminutes: '1m 29s',
                        data: [{ name: '0-10sec', value: 6 }, { name: '11-20sec', value: 11 }, { name: '>20sec', value: 33 }]
                    }
                },
                {
                    status: 200,
                    data: {

                        topreasons: [{ value: 15, name: 'status of a policy' }, { value: 1, name: 'Nelflix' }]
                    }
                },
                {
                    data: { updated_date: '2020-04-29T11:37:44.373Z' }
                }]);
        } else {
            return Observable.of({
                errorBody: {}
            });
        }
    }
}

class AuthenticationServiceStub {
    getCurrentUserId() {
        return 1;
    }
}

describe('OperationMetricsComponent', () => {
    let component: OperationMetricsComponent;
    let fixture: ComponentFixture<OperationMetricsComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            providers: [
                { provide: IntentService, useClass: IntentServiceStub },
                { provide: AuthenticationService, useClass: AuthenticationServiceStub },
                { provide: ConversationalMetricsService, useClass: ConversationalMetricsServiceStub }
            ],
            declarations: [OperationMetricsComponent],
            schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(OperationMetricsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('ngOnInit should call towo methods getdropdown and atab', () => {
        const getdropdownValuesSpy = spyOn(component, 'getdropdownValues');
        const aTabSpy = spyOn(component, 'aTab');
        component.userId = 1;
        component.ngOnInit();
        expect(getdropdownValuesSpy).toHaveBeenCalled();
        expect(aTabSpy).toHaveBeenCalledWith('MTD');
    });

    it('refresh method calling', () => {
        component.channels = [{ id: 1 }, { id: 2 }];
        component.languages = [{ id: 1 }, { id: 2 }];
        const aTabSpy = spyOn(component, 'aTab');
        component.refresh();
        expect(component.channels).toEqual([]);
        expect(component.languages).toEqual([]);
        expect(aTabSpy).toHaveBeenCalledWith('MTD');
    });

    it('statusFilter should initialize intentFilter values and call getReportData method once', () => {
        const getOpReportDataSpy = spyOn(component, 'getOpReportData');
        const status = 0;
        const isRequestNeeded = false;
        component.statusFilter(status, isRequestNeeded);
        expect(component.intentFilter.va).toEqual(status);
        expect(component.intentFilter.channel).toEqual(0);
        expect(component.intentFilter.language).toEqual(0);
        expect(component.IntentListingForm.controls['channel'].value).toEqual(0);
        expect(component.IntentListingForm.controls['language'].value).toEqual(0);
        expect(getOpReportDataSpy).toHaveBeenCalledTimes(1);
    });

    it('statusFilter should initialize intentFilter values and call getIntentList method twice', () => {
        const getOpReportDataSpy = spyOn(component, 'getOpReportData');
        const status = 0;
        const isRequestNeeded = true;

        component.statusFilter(status, isRequestNeeded);

        expect(component.intentFilter.va).toEqual(status);
        expect(component.intentFilter.channel).toEqual(0);
        expect(component.intentFilter.language).toEqual(0);
        expect(component.IntentListingForm.controls['channel'].value).toEqual(0);
        expect(component.IntentListingForm.controls['language'].value).toEqual(0);
        expect(getOpReportDataSpy).toHaveBeenCalledTimes(1);
    });

    it('statusFilter should  call getReportData', () => {
        const getOpReportDataSpy = spyOn(component, 'getOpReportData');
        const status = 1;
        const isRequestNeeded = false;
        component.statusFilter(status, isRequestNeeded);
        expect(getOpReportDataSpy).toHaveBeenCalledTimes(1);
    });


    it('languagefilterop method calling', () => {

        const getOpReportDataSpy = spyOn(component, 'getOpReportData');
        const language = {
            id: '1'
        };
        component.oplanguageFilter(language);
        component.selected.fromDate = new Date();
        component.selected.endDate = new Date();
        expect(component.intentFilter.language).toEqual(language);

        expect(getOpReportDataSpy).toHaveBeenCalledTimes(1);
    });

    it('chanenelfilterop method calling', () => {
        const getOpReportDataSpy = spyOn(component, 'getOpReportData');
        const channel = {
            id: '1'
        };
        component.channelFilter(channel);
        expect(component.intentFilter.channel).toEqual(channel);
        expect(getOpReportDataSpy).toHaveBeenCalledTimes(1);
    });
    it('yAxisTickFormatting method calling', () => {
        const value = 1;
        const result = component.yAxisTickFormatting(value);
        expect(result).toEqual(value);
    });

    it('yAxisTickFormatting method calling', () => {
        const value = 1.4;
        const result = component.yAxisTickFormatting(value);
        expect(result).toEqual('');
    });

    it('rangeclick method calling', () => {
        const value = {
            fromDate: 'aaa',
            endDate: 'bbbb'
        };
        component.rangeClick(value);
    });

    it('rangeclick method  not equal to null calling', () => {
        const getOpReportDataSpy = spyOn(component, 'getOpReportData');
        const value = {
            fromDate: 'aaa',
            endDate: 'bbbb'
        };
        component.rangeClick(value);

        expect(getOpReportDataSpy).toHaveBeenCalledTimes(1);
    });

    it('atab method calling and pass Today param', () => {
        const getOpReportDataSpy = spyOn(component, 'getOpReportData');
        const data = 'Today';
        component.aTab(data);
        expect(component.todayTab).toBeTruthy();
        expect(component.weekTab).toBeFalsy();
        expect(component.monthTab).toBeFalsy();
        expect(component.customTab).toBeFalsy();
        expect(getOpReportDataSpy).toHaveBeenCalledTimes(1);
    });

    it('atab method calling and pass WTD param', () => {
        const getOpReportDataSpy = spyOn(component, 'getOpReportData');
        const data = 'WTD';
        component.aTab(data);
        expect(component.todayTab).toBeFalsy();
        expect(component.weekTab).toBeTruthy();
        expect(component.monthTab).toBeFalsy();
        expect(component.customTab).toBeFalsy();
        expect(getOpReportDataSpy).toHaveBeenCalledTimes(1);
    });

    it('atab method calling and pass MTD param', () => {
        const getOpReportDataSpy = spyOn(component, 'getOpReportData');
        const data = 'MTD';
        component.aTab(data);
        expect(component.todayTab).toBeFalsy();
        expect(component.weekTab).toBeFalsy();
        expect(component.monthTab).toBeTruthy();
        expect(component.customTab).toBeFalsy();
        expect(getOpReportDataSpy).toHaveBeenCalledTimes(1);
    });

    it('atab method calling and pass custom param', () => {
        const getOpReportDataSpy = spyOn(component, 'getOpReportData');
        const data = 'customDate';
        component.aTab(data);
        expect(component.todayTab).toBeFalsy();
        expect(component.weekTab).toBeFalsy();
        expect(component.monthTab).toBeFalsy();
        expect(component.customTab).toBeTruthy();
        expect(getOpReportDataSpy).toHaveBeenCalledTimes(0);
    });

    it('getOpReportData method calling', () => {
        const modeval = 'live';
        const vadata = 1;
        const chnldata = 0;
        const langdata = 0;
        const frmdate = new Date();
        const endDate = new Date();
        component.getOpReportData(modeval, vadata, chnldata, langdata, frmdate, endDate);
        expect(component.top10Intents.length).toEqual(10);
    });

    it('getOpReportData method calling', () => {
        const modeval = 'live';
        const vadata = 2;
        const chnldata = 0;
        const langdata = 0;
        const frmdate = new Date();
        const endDate = new Date();
        component.getOpReportData(modeval, vadata, chnldata, langdata, frmdate, endDate);
        expect(component.top10Intents).toEqual([]);
    });

    it('getOpReportData method calling', () => {
        const modeval = 'live';
        const vadata = 3;
        const chnldata = 0;
        const langdata = 0;
        const frmdate = new Date();
        const endDate = new Date();
        component.getOpReportData(modeval, vadata, chnldata, langdata, frmdate, endDate);
        expect(component.colorsaryIntemts).toEqual([]);
    });
});

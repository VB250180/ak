import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LiveMetricsComponent } from './live-metrics/live-metrics.component';
import { OperationMetricsComponent } from './operational-metrics/operation-metrics.component';
const routes: Routes = [
  { path: 'live-metrics', component: LiveMetricsComponent },
  { path: 'operation-metrics', component: OperationMetricsComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConversationalMetricsRoutingModule { }

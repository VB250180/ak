import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BestResponseComponent } from './best-response.component';
import { Component } from '@angular/core';

describe('BestResponseComponent', () => {
  let testHostComponent: BestResponseComponent;
  let testHostFixture: ComponentFixture<BestResponseComponent>;
  // let testHostComponent: BestResponseComponent;
  // let testHostFixture: ComponentFixture<BestResponseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BestResponseComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    testHostFixture = TestBed.createComponent(BestResponseComponent);
    testHostComponent = testHostFixture.componentInstance;
    testHostComponent.slotName = { intentName: 'ticket_booking', confidence: 84.15360450744629 };
    testHostFixture.detectChanges();
  });

  it('should show Intent Name', () => {
    expect(testHostFixture.nativeElement.querySelector('span.slotname').innerText).toEqual('ticket_booking');
  });
  it('should show Intent confidence', () => {
    expect(testHostFixture.nativeElement.querySelector('span.slotper').innerText).toEqual('84%');
  });

});

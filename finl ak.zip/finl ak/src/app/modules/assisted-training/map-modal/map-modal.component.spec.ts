import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MapModalComponent } from './map-modal.component';
import { Component, NgModule } from '@angular/core';
import { MatDialogModule, MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { OverlayContainer } from '@angular/cdk/overlay';
import { MatButtonModule } from '@angular/material';

class MatDialogRefStub {
  public close(value) { }
}


describe('MapModalComponent', () => {
  let component: MapModalComponent;
  let fixture: ComponentFixture<MapModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MapModalComponent],
      imports: [
        MatButtonModule,
        MatDialogModule
      ],
      providers: [
        { provide: MatDialogRef, useClass: MatDialogRefStub },
        { provide: MAT_DIALOG_DATA, useValue: {} }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MapModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('onMapIntent should cloase the modal with true', () => {
    const spy = spyOn(TestBed.get(MatDialogRef), 'close');

    component.onMapIntent();

    expect(spy).toHaveBeenCalledWith(true);
  });

  it('OnCancel should cloase the modal with false', () => {
    const spy = spyOn(TestBed.get(MatDialogRef), 'close');

    component.OnCancel();

    expect(spy).toHaveBeenCalledWith(false);
  });
});



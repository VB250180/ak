import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
@Component({
  selector: 'app-map-modal',
  templateUrl: './map-modal.component.html',
  styleUrls: ['./map-modal.component.scss']
})
export class MapModalComponent {

  constructor(public dialogRef: MatDialogRef<MapModalComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any, ) { }

  onMapIntent(): void {
    this.dialogRef.close(true);
  }

  OnCancel() {
    this.dialogRef.close(false);
  }

}

import {
  Component,
  OnInit,
  TemplateRef,
  ViewChild,
  OnDestroy
} from '@angular/core';
import {
  FormControl,
  FormGroup,
  Validators,
  FormBuilder
} from '@angular/forms';

import { ActivatedRoute, Router } from '@angular/router';
import { MapModalComponent } from '../assisted-training/map-modal/map-modal.component';
import { AssistedTrainingService } from '../../core/services/assisted-training/assisted-training.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { BsDropdownConfig } from 'ngx-bootstrap/dropdown';
import { MatDialog } from '@angular/material/dialog';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import moment from 'moment';
import { formatDate } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { TextSelectEvent } from '../../shared/directives/text-select.directive';
import { SelectionRectangle } from '../../core/models/selectionRectangle';
import { IntentType, intentTypeList } from '../../core/models/intentType';
import { chooseColorClassByLastDigit, getObjById, isEmptyObj } from '../../core/utils/akeira-utils';
import * as cloneDeep from 'lodash/cloneDeep';
import { CreateIntentService } from '../../core/services/create-intent/create-intent.service';
import { ModalComponent } from '../../shared/components/modal/modal.component';
import { modalErrorConfig, modalDeleteConfig, modalResponseTrainedSuccess } from '../../core/utils/const-message';
import { Subscription } from 'rxjs';
import { VirtualDetailsService } from 'src/app/core/services/va-details/virtual-agent-details.service';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';

@Component({
  selector: 'app-assisted-training',
  templateUrl: './assisted-training.component.html',
  styleUrls: ['./assisted-training.component.scss'],
  providers: [{ provide: BsDropdownConfig, useValue: { autoClose: false } }],
})
export class AssistedTrainingComponent implements OnInit, OnDestroy {
  // Added dummy value for  build
  // Start
  id;
  locale;
  start;
  // End
  conversationList: any;
  alwaysShowCalendars: boolean;
  showRangeLabelOnInput: boolean;
  keepCalendarOpeningWithRange: boolean;
  editCategoryForm = [];
  // minDate: moment.Moment = moment().subtract(6, 'days');
  // maxDate: moment.Moment = moment().add(2, 'month');

  ranges: any = [moment().subtract(6, 'days'), moment()];
  selected = { start: moment().subtract(6, 'days'), end: moment() };
  tomorrow: any;

  modalRef: BsModalRef;
  config = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: 'my-modal'
  };
  config2 = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: 'my-modal2'
  };
  myDate = new Date();
  date: any;
  selectedCity: any;
  selectedIntentName: string[];
  unmapObjectIndex = new Map<string, any>();

  AssistedTrainingForm: FormGroup;
  serviceValue: any;
  statusValue: any = [];
  status: any;
  channel: any;
  language: any;
  filterValues: any;
  isLoaded = false;
  options: any = [];
  channels: any = [];
  languages: any = [];
  listDetails: any;
  scopeInputs: any = [];
  mappedInputs: any = [];
  outscopeInputs: any = [];
  allInputsKeyValue: Set<any> = new Set<any>();
  allInputsValue: any = {};

  sessionId: any = [];
  scopeLength: any;
  mappedLength: any;
  outscopeLength: any;
  display = false;
  events: Event[] = [];
  mwidth: number;
  mLength: number;
  swidth: number;
  sLength: number;
  owidth: number;
  oLength: number;
  totalInputs: number;
  dateLimit: number;
  vaIdDrodown: any;
  languageIdDrodown: any;
  channelIdDrodown: any;

  channelId: number;
  pageNumber = 1;
  toDate: any = '';
  fromDate: any = '';
  Entities: any;
  response: any;
  intentListData: any = [];
  intentSlotList: any = [];
  intentSlotColorList: any = [];
  isIntentLive: true;
  IsHidden = true;
  ArrayList: any = [];
  searchText = '';
  textarea: any;
  selectionValue = false;
  log: any; selection: any;
  unmappedJson: any = [];
  selectedValue: any[] = []; selectedIntentId: any; intentSlotId: any = []; intentSlotValue: any = [];
  currentSelectedtxt = '';
  count = 0;
  counter = 1;
  pos: any;
  vaName: any;
  vaId: any;
  vaDesc: any;
  vaChan: any;
  vaLang: any;
  vaChanId: any;
  vaLangId: any;
  vaById: any = {};
  BreakException = {};
  intentType: IntentType[] = intentTypeList;
  showloader = false;
  selectedIntents = [];

  ifbestResponseIntent = false;
  bestResponseSlots = [];
  editEnable = false;
  editItem: any = '';

  modalRefInfo: BsModalRef;
  configModal = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: 'my-modal2'
  };

  createFormGroup: FormGroup;
  innnerHTMLStr: any;
  flag = false;
  created: boolean;
  public hostRectangle: SelectionRectangle | null;
  private selectedText: string;
  public dropdownError: string;
  selectedPharseKey: string;
  posStart = -1;
  posEnd = -1;

  modalRefTrainInput: BsModalRef;
  trainInputconfig = {
    animated: true,
    keyboard: true,
    backdrop: false,
    ignoreBackdropClick: false,
    class: 'my-modaltraining'
  };
  toastrConfig = {
    timeOut: 3000
  };
  userId = 0;
  vsDataLoadedSubscribe: Subscription;
  getInputsSubscribe: Subscription;
  searchIntentSubscribe: Subscription;
  getUnmappedUserInputSubscribe: Subscription;
  languageChangeSubscribe: Subscription;
  createIntentSubscribe: Subscription;
  saveUnmappedInputsSubscribe: Subscription;
  addTrainingPhraseDialogFlowSubscribe: Subscription;
  deleteUnmappedUserInputsSubscribe: Subscription;
  getUnmappedUserInputScrollSubscribe: Subscription;
  rangeClicked(start, e) { }

  constructor(
    private trainingService: AssistedTrainingService,
    private spinner: NgxSpinnerService,
    private modalService: BsModalService,
    private activatedroute: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder,
    private toastr: ToastrService,
    public createIntentService: CreateIntentService,
    public dialog: MatDialog,
    private virtualDetailsService: VirtualDetailsService,
    private authService: AuthenticationService
  ) {
    this.AssistedTrainingForm = new FormGroup({
      status: new FormControl(null, Validators.required),
      channel: new FormControl(null, Validators.required),
      language: new FormControl(null, Validators.required)
    });
    this.createFormGroup = this.fb.group({});
    this.createFormGroup.addControl('name', new FormControl('', [Validators.required]));
    this.createFormGroup.addControl('description', new FormControl('', [Validators.required]));
    this.createFormGroup.addControl('intentType', new FormControl('', [Validators.required]));

    // this.createFormGroup = new FormGroup({
    //   name: new FormControl(' ', [Validators.required]),
    //   description: new FormControl(' ', [Validators.required])
    // });

    this.userId = this.authService.getCurrentUserId();

    this.alwaysShowCalendars = true;
    this.tomorrow = moment();
    this.dateLimit = 6;
    this.clearHostRectangle();
  }
  ngOnDestroy(): void {
    if (this.vsDataLoadedSubscribe) {
      this.vsDataLoadedSubscribe.unsubscribe();
    }
    if (this.getInputsSubscribe) {
      this.getInputsSubscribe.unsubscribe();
    }
    if (this.searchIntentSubscribe) {
      this.searchIntentSubscribe.unsubscribe();
    }
    if (this.getUnmappedUserInputSubscribe) {
      this.getUnmappedUserInputSubscribe.unsubscribe();
    }
    if (this.languageChangeSubscribe) {
      this.languageChangeSubscribe.unsubscribe();
    }
    if (this.createIntentSubscribe) {
      this.createIntentSubscribe.unsubscribe();
    }
    if (this.addTrainingPhraseDialogFlowSubscribe) {
      this.addTrainingPhraseDialogFlowSubscribe.unsubscribe();
    }
    if (this.deleteUnmappedUserInputsSubscribe) {
      this.deleteUnmappedUserInputsSubscribe.unsubscribe();
    }
    if (this.getUnmappedUserInputScrollSubscribe) {
      this.getUnmappedUserInputScrollSubscribe.unsubscribe();
    }
  }

  ngOnInit() {
    this.spinner.show();
    this.clearAssistedTrainingtags();
    this.activatedroute.paramMap.subscribe(params => {
      console.log('assisted-training page params --->', params);
      this.vaName = params.get('name');
      this.vaId = params.get('id');
      this.vaDesc = params.get('desc');
      this.vaChan = params.get('channel');
      this.vaLang = params.get('lang');
      this.vaChanId = params.get('chId');
      this.vaLangId = params.get('langId');
      console.log('this.vaId', this.vaId);
      this.vsDataLoadedSubscribe = this.virtualDetailsService.requiredDataLoaded.subscribe(data => {
        if (data === true) {
          const selectionDetails = {
            vrmAgentDetails: this.virtualDetailsService.getVirtualAgentById(Number(this.vaId)),
            vrmAgentChannelDetails: this.virtualDetailsService.getChannelsByVrmId(Number(this.vaId)).find(channel => channel.channelId === Number(this.vaChanId)),
            vrmAgentLanguageDetails: this.vaLang
          };
          this.virtualDetailsService.currentAgentLoaded.next(selectionDetails);
        }
      });
    });

    // current date formater
    // this.date = new Date();
    // this.toDate = formatDate(this.date, 'yyyy-MM-dd', 'en');
    // this.date.setDate(this.date.getDate() - 7);
    // this.fromDate = formatDate(this.date, 'yyyy-MM-dd', 'en');
    // console.log('date ranges are', this.fromDate, '--', this.toDate);
    this.getDropdownInput();
  }

  getDropdownInput() {
    // Get all dropdown value
    this.getInputsSubscribe = this.trainingService.getInputs(this.userId).subscribe((res: any[]) => {
      console.log('trainingService.getInputs --->', res);

      this.serviceValue = res['virtualAgentRoleMaps'];
      for (let i = 0; i < res['virtualAgentRoleMaps'].length; i++) {
        this.vaById[res['virtualAgentRoleMaps'][i].vrmId] = res['virtualAgentRoleMaps'][i];
      }
      this.setDropdownValues();
      this.searchIntentFunc();
    },
      err => { this.spinner.hide(); console.error('Error In trainingService.getInputs'); console.error(err); }
    );
  }


  setDropdownValues() {
    this.isLoaded = true;
    this.channels = []; this.languages = [];
    this.channels = this.vaById[this.vaId].channels;
    this.languages = this.vaById[this.vaId].languages;
    (this.vaById[this.vaId]['vrmIsLive'] === false) ? this.status = 'Test' : this.status = 'Live';
    this.channel = this.vaChan;
    this.AssistedTrainingForm.get('channel').setValue(this.vaChan);
    this.language = this.vaLang;
    this.AssistedTrainingForm.get('language').setValue(this.vaLang);
    this.channelIdDrodown = this.vaChanId;
    this.languageIdDrodown = this.vaLangId;
    this.vaIdDrodown = this.vaId;

    this.serviceCallUnmappedInputs(this.channelIdDrodown, this.fromDate, this.languageIdDrodown, this.pageNumber, this.toDate, this.vaIdDrodown, this.searchText);

    console.log(this.channelIdDrodown, this.languageIdDrodown, this.vaIdDrodown);
  }

  // Fetch search Intent
  searchIntentFunc() {
    this.intentListData = [];
    this.searchIntentSubscribe = this.trainingService
      .searchIntent(this.vaIdDrodown, this.languageIdDrodown, this.channelIdDrodown)
      .subscribe((res: any[]) => {
        console.log('Search Entities Data', res);
        this.response = res;
        for (let k = 0; k < this.response.length; k++) {
          this.intentListData.push(res[k]['intent']);
        }
        this.intentListData = [...this.intentListData];
      },
        err => { this.spinner.hide(); console.error(err); }
      );
  }

  // code to fetch service for left panel unmapped user inputs
  serviceCallUnmappedInputs(chn, fromDate, langId, pageNo, toDate, VA, text) {
    const serachtxt = text !== undefined && text !== 'undefined' ? text : '';
    this.clearAssistedTrainingtags();
    this.getUnmappedUserInputSubscribe = this.trainingService.getUnmappedUserInput(chn, langId, pageNo, VA, serachtxt, fromDate, toDate).subscribe((list: any[]) => {
      console.log(list);
      this.allInputsKeyValue = new Set<any>();
      this.allInputsValue = {};
      this.conversationListDetails(list);
    }, err => {
      console.log(err);
      this.spinner.hide();
    });
  }
  // code to trigger event onselection of channel
  channelFilter() {
    this.spinner.show();
    this.clearAssistedTrainingtags();
    // console.log('-----> ', this.AssistedTrainingForm.get('channel').value);
    this.channelIdDrodown = this.AssistedTrainingForm.get('channel').value;
    this.unmapObjectIndex.clear();
    this.serviceCallUnmappedInputs(this.channelIdDrodown, this.fromDate, this.languageIdDrodown, this.pageNumber, this.toDate, this.vaIdDrodown, this.searchText);
  }
  // code to trigger event onselection of language
  languageFilter() {
    this.spinner.show();
    this.clearAssistedTrainingtags();
    // console.log('-----> ', this.AssistedTrainingForm.get('language').value);
    this.languageIdDrodown = this.AssistedTrainingForm.get('language').value;
    this.unmapObjectIndex.clear();
    this.intentListData = [];
    this.languageChangeSubscribe = this.trainingService.languageChange(this.channelIdDrodown, this.fromDate, this.languageIdDrodown, this.pageNumber, this.toDate, this.vaIdDrodown, this.searchText)
      .subscribe((res: any[]) => {
        const searchIntent = res[0];
        const getIntents = res[1];

        console.log('Search Entities Data', searchIntent);
        this.response = res[0];
        for (let k = 0; k < this.response.length; k++) {
          this.intentListData.push(this.response[k]['intent']);
        }
        this.intentListData = [...this.intentListData];
        console.log(getIntents, this.intentListData);
        this.allInputsKeyValue = new Set<any>();
        this.allInputsValue = {};
        this.conversationListDetails(getIntents);
      },
        err => { this.spinner.hide(); console.error(err); }
      );
  }

  onSearch(text: any) {
    this.spinner.show();
    this.counter = 1;
    this.searchText = text;
    this.clearAssistedTrainingtags();
    this.serviceCallUnmappedInputs(this.channelIdDrodown, this.fromDate, this.languageIdDrodown, 1, this.toDate, this.vaIdDrodown, this.searchText);
    console.log(this.searchText, this.vaId, this.vaIdDrodown);
  }

  // code to triggger eventon date selection
  choosedDate(e) {
    this.toDate = formatDate(this.selected.end['_d'], 'yyyy-MM-dd', 'en');
    this.fromDate = formatDate(this.selected.start['_d'], 'yyyy-MM-dd', 'en');
    console.log(e, this.toDate, this.fromDate, this.channels, this.channelIdDrodown, this.fromDate, this.languageIdDrodown, this.pageNumber, true, this.toDate, this.vaIdDrodown, this.AssistedTrainingForm.value.channel);
  }

  submitFilter(e) {
    console.log(e, this.toDate, this.fromDate, this.channels, this.channelIdDrodown, this.fromDate, this.languageIdDrodown, this.pageNumber, true, this.toDate, this.vaIdDrodown, this.AssistedTrainingForm.value.channel);
    console.log(this.channelIdDrodown, this.languageIdDrodown, this.vaIdDrodown);
    this.serviceCallUnmappedInputs(this.channelIdDrodown, this.fromDate, this.languageIdDrodown, this.pageNumber, this.toDate, this.vaIdDrodown, this.searchText);
  }

  cancelFilter(e) {
    this.fromDate = '';
    this.toDate = '';
    this.serviceCallUnmappedInputs(this.channelIdDrodown, this.fromDate, this.languageIdDrodown, this.pageNumber, this.toDate, this.vaIdDrodown, this.searchText);
  }

  cancelCreate() {
    this.createFormGroup.reset();
  }

  // code to populate values in left panel
  conversationListDetails(list) {
    this.mLength = list.mappedCount;
    this.sLength = list.inScopeCount;
    this.oLength = list.outOfScopeCount;
    this.totalInputs = list.mappedCount + list.inScopeCount + list.outOfScopeCount;

    this.mwidth = Math.round((this.mLength / this.totalInputs) * 100);
    this.swidth = Math.round((this.sLength / this.totalInputs) * 100);
    this.owidth = Math.round((this.oLength / this.totalInputs) * 100);

    for (let k = 0; k < list.conversationList.length; k++) {
      this.conversationListProcess(list.conversationList[k]['sessionId'], list.conversationList[k]);
    }
    console.log('this.allInputs --->', this.allInputsKeyValue);
    this.spinner.hide();
  }

  conversationListProcess(sessionId, conversationList) {
    this.scopeInputs = []; this.mappedInputs = []; this.outscopeInputs = [];
    for (let j = 0; j < conversationList.mapppedPhrases.length; j++) {
      const map = conversationList.mapppedPhrases[j];
      console.log('mapped phrases', map);
      map['sessionId'] = sessionId;
      map['isSelected'] = false;
      map['onedit'] = false;
      map['phraseType'] = 'mapppedPhrases';
      map['mappedData'] = this.mappedPhraseGenerator(
        conversationList.mapppedPhrases[j], conversationList.sessionId
      );
      this.mappedInputs.push(map);
      console.log(this.mappedInputs.length, conversationList.mapppedPhrases[j], conversationList.sessionId);
    }
    for (let j = 0; j < conversationList.outOfScopePhrases.length; j++) {
      const map = conversationList.outOfScopePhrases[j];
      map['intentslots'] = {};
      map['intentId'] = null;
      map['isSelected'] = false;
      map['onedit'] = false;
      map['phraseType'] = 'outscopePhrases';
      map['sessionId'] = sessionId;
      map['mappedData'] = {
        displayValue: conversationList.outOfScopePhrases[j].value,
        sessionId: conversationList.sessionId,
        mappedHighlightData: this.genrateHighlightdata(conversationList.outOfScopePhrases[j].value, false, '')
      };
      this.outscopeInputs.push(map);
    }
    for (let j = 0; j < conversationList.inScopePhrases.length; j++) {
      const map = conversationList.inScopePhrases[j];
      map['intentslots'] = {};
      map['intentId'] = null;
      map['isSelected'] = false;
      map['onedit'] = false;
      map['phraseType'] = 'inScopePhrases';
      map['sessionId'] = sessionId;
      map['mappedData'] = {
        displayValue: conversationList.inScopePhrases[j].value,
        sessionId: conversationList.sessionId,
        mappedHighlightData: this.genrateHighlightdata(conversationList.inScopePhrases[j].value, false, '')
      };
      this.scopeInputs.push(map);
    }
    const pushDt = {
      mapppedPhrases: this.mappedInputs,
      inScopePhrases: this.scopeInputs,
      sessionId: conversationList.sessionId,
      outscopePhrases: this.outscopeInputs
    };
    // this.allInputs[conversationList.sessionId] = pushDt;
    this.allInputsKeyValue.add(pushDt);
    this.allInputsValue[conversationList.sessionId] = pushDt;
  }


  mappedPhraseGenerator(mapphrases, id) {
    let displayValuedt = mapphrases.value;
    const rxp = /%([^%/]+)%/g;
    let curMatch;
    console.log(mapphrases);
    if (mapphrases.intentslots != null) {
      // tslint:disable-next-line: no-conditional-assignment
      while ((curMatch = rxp.exec(mapphrases.value))) {
        console.log(curMatch[1]);
        displayValuedt = displayValuedt.replace(curMatch[1], mapphrases.intentslots[curMatch[1]].value);
        console.log(curMatch[1], displayValuedt);
      }
      displayValuedt = displayValuedt.replace(/%/g, '');
      const displayData = {
        displayValue: displayValuedt,
        intentId: mapphrases.intentId,
        sessionId: id,
        mappedHighlightData: this.genrateHighlightdata(displayValuedt, true, mapphrases.intentslots),
        intentslots: mapphrases.intentslots
      };

      console.log(displayData);
      return displayData;
    } else {
      const displayData = {
        displayValue: mapphrases.value,
        intentId: mapphrases.intentId,
        sessionId: id,
        mappedHighlightData: this.genrateHighlightdata(mapphrases.value, false, ''),
        intentslots: {}
      };
      return displayData;
    }
  }

  genrateHighlightdata(txt: string, isMapped: boolean, intentslots) {
    const txtArray = txt.split(' ');
    // tslint:disable-next-line: prefer-const
    let renderJson = [];
    txtArray.forEach((e, i) => { renderJson.push({ index: i, value: e, isHighlight: false, key: ('pos' + i) }); });
    if (isMapped) {
      const outputColorArray = [].concat(...this.colorArrayGenrater(intentslots));
      console.log('outputColorArray', outputColorArray);
      // tslint:disable-next-line: forin , prefer-const
      for (let i in renderJson) {
        // tslint:disable-next-line: prefer-const
        for (let j in outputColorArray) {
          if (renderJson[i]['key'] === outputColorArray[j]) {
            renderJson[i]['isHighlight'] = true;
            break;
          }
        }
      }
      console.log(renderJson);
    }
    return renderJson;
  }

  // code to trigger event accordion expansion
  expandPanel(input) {
    this.display = true;
    this.scopeInputs = []; this.mappedInputs = []; this.outscopeInputs = [];
  }

  clearAssistedTrainingtags() {
    this.unmapObjectIndex.clear(); this.selectedIntentName = []; this.selectedIntentId = '', this.intentSlotColorList = [];
  }

  // modal popup on click of map intent
  openDialog(): void {
    console.log('---->', this.editEnable);
    if (!this.editEnable) {
      if (this.unmapObjectIndex.size > 0 && this.selectedIntentId !== undefined && this.selectedIntentId !== '') {
        const dialogRef = this.dialog.open(MapModalComponent, {
          data: 'open dialog'
        });

        dialogRef.afterClosed().subscribe(result => {
          if (result === true) {
            this.saveUnmappedUserInputsRequest();
          }
        });
      } else {
        this.showPopup('Warning', `Please select any one Intent from the 'Map Intent' option`, 'warn');
      }
    } else {
      this.showPopup('Warning', `You have another edit action in progress. Please complete it.`, 'warn');
    }
  }

  openModals(template2: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template2, this.config);
  }

  showContent(value, checkboxId) {
    console.log('intentListData --> ', this.intentListData, value.intentId);
    if (this.selectedIntentId === value.intentId) {
      console.log('Intent already thr');
    } else {
      this.clearunmapIntentSlotsData();
      this.displaySlotsList();
      this.selectedIntentName = []; this.selectedIntentId = '';
      if (value.intentId != null) {
        try {
          console.log('-- ', value.intentId);
          this.intentListData.forEach(e => {
            if (e.id === value.intentId) {
              this.selectedIntentName = e.value;
              this.selectedIntentId = e.id;
              throw this.BreakException;
            }
          });
        } catch (e) {
          this.displaySlotsList();
          if (e !== this.BreakException) { throw e; }
        }
      } else {
        this.intentSlotColorList = [];
      }
    }
    this.setupPhraseData(value, checkboxId);
  }

  clearunmapIntentSlotsData() {
    if (this.unmapObjectIndex.size > 0) {
      // tslint:disable-next-line: prefer-const
      for (let key of this.unmapObjectIndex.keys()) {
        this.unmapObjectIndex.get(key).intentslots = {};
        this.unmapObjectIndex.get(key).value = this.unmapObjectIndex.get(key).mappedData.displayValue;
        this.coloringPhrase(this.unmapObjectIndex.get(key));
      }
    }
  }

  setupPhraseData(value, checkboxId) {
    if (!this.unmapObjectIndex.has(checkboxId)) {
      value['intentName'] = this.selectedIntentName;
      const phraseObj = JSON.parse(JSON.stringify(value));
      console.log('----phraseObj---> ', phraseObj, '---> ', isEmptyObj(phraseObj));
      // tslint:disable-next-line: no-unused-expression
      isEmptyObj(phraseObj['intentslots']) ? '' : phraseObj['value'] = this.coloringPhrase(phraseObj);
      this.unmapObjectIndex.set(checkboxId, phraseObj);
      this.showBestResponseTab(checkboxId, false);
    } else {
      this.unmapObjectIndex.delete(checkboxId);
      this.clearBestResponse();
    }
    console.log('showContent --> ', checkboxId, this.unmapObjectIndex, this.unmapObjectIndex.size);
  }

  // code to create new Intent
  createNewIntent() {
    this.created = true;
    this.spinner.show();
    const body = {
      intentDescription: this.createFormGroup.value.description,
      intentName: this.createFormGroup.value.name,
      isIntentLive: false,
      intentType: this.createFormGroup.value.intentType
    };
    console.log(body);
    this.createIntentSubscribe = this.trainingService.createIntent(body, this.vaIdDrodown).subscribe(res => {
      console.log(res);
      if (res['intent'] != null) {
        this.showPopup('Info', 'Intent is created successfully', 'info');
      } else {
        this.showPopup('Error', res['errorBody'].summary, 'warn');
      }
      this.searchIntentFunc();
      this.spinner.hide();
    }, err => {
      this.showPopup('Error', 'Intent is not created', 'warn');
      this.spinner.hide();
    });
    this.createFormGroup.reset();
  }

  checkEmpty(txt: string) {
    return (this.selectedIntentId !== undefined && this.selectedIntentId !== '') ? true : false;
  }

  public renderRectangles(event: TextSelectEvent, key: string): void {

    console.group('Text Select Event');
    console.log('Event:', event);
    console.log('Text:', event.text);
    console.log('start:', event.posStart);
    console.log('end:', event.posEnd);
    console.log('Viewport Rectangle:', event.viewportRectangle);
    console.log('Host Rectangle:', event.hostRectangle);
    console.groupEnd();

    // If a new selection has been created, the viewport and host rectangles will
    // exist. Or, if a selection is being removed, the rectangles will be null.
    if (event.hostRectangle) {
      this.hostRectangle = event.viewportRectangle;
      this.selectedPharseKey = key;
      this.selectedText = event.text;
      if (event.posStart > event.posEnd) {
        this.posStart = event.posEnd;
        this.posEnd = event.posStart;
      } else {
        this.posStart = event.posStart;
        this.posEnd = event.posEnd;
      }
      this.posStart = this.checkForFirstSpace() ? this.posStart = (this.posStart + 1) : this.posStart;
      this.showIntentSlotsDropdown();
    } else {
      this.clearHostRectangle();
    }
  }

  clearHostRectangle = () => {
    this.hostRectangle = null;
    this.selectedText = '';
    this.selectedPharseKey = '';
  }

  checkForFirstSpace = () => this.selectedText.search(/^\S.*$/) === -1;

  showIntentSlotsDropdown() {
    const currentWords = this.selectedText.replace(/^\s+/, '').replace(/\s+$/, '');
    if (this.checkEmpty(this.selectedIntentId) && this.checkEmpty(currentWords)) {
      let displayedtext;
      let regex;
      let isCurrectWords;
      if (this.unmapObjectIndex.get(this.selectedPharseKey) !== undefined) {
        displayedtext = this.unmapObjectIndex.get(this.selectedPharseKey).mappedData.displayValue;
        regex = new RegExp('\\b(' + currentWords + ')\\b');
        isCurrectWords = displayedtext.search(regex);
      }
      console.log('$$$$ ', displayedtext, '---', currentWords, '---', isCurrectWords);
      this.currentSelectedtxt = currentWords;
      if (isCurrectWords > -1) {
        const mappedSlot = this.unmapObjectIndex.get(this.selectedPharseKey).intentslots;
        const slotAry = [];
        // tslint:disable-next-line: prefer-const
        for (let key of Object.keys(mappedSlot)) {
          slotAry.push(mappedSlot[key].intentSlot.id);
        }
        this.openSlotsDropdown(slotAry);
      } else {
        this.dropdownError = 'Select proper words';
        this.intentSlotList = [];
      }
    } else {
      this.clearHostRectangle();
    }
  }

  openSlotsDropdown(slotAry) {
    this.dropdownError = 'Choose an Intent slot';
    this.intentSlotList = [];
    this.pushIntentSlots(this.intentSlotList, slotAry);
    if (this.selectedIntentName.length === 0) {
      this.intentSlotList = [];
    }
  }

  pushIntentSlots(slotsList, slotAry) {
    for (let k = 0; k < this.response.length; k++) {
      if (this.response[k]['intent'].value === this.selectedIntentName) {
        for (let i = 0; i < this.response[k]['intentSlots'].length; i++) {
          // tslint:disable-next-line: prefer-const
          let slot = this.response[k]['intentSlots'][i];
          slot['active'] = true;
          slot['color'] = chooseColorClassByLastDigit(i);
          for (let x = 0; x < slotAry.length; x++) {
            // tslint:disable-next-line: no-unused-expression
            slotAry[x] === slot['id'] ? slot['active'] = false : '';
          }
          slotsList.push(slot);
        }
      }
    }
  }

  displaySlotsList() {
    this.intentSlotColorList = [];
    this.pushIntentSlots(this.intentSlotColorList, []);
  }

  saveUnmappedUserInputsRequest() {
    this.spinner.show();
    const q = cloneDeep(this.unmapObjectIndex);
    console.log('q ------> ', q, this.unmapObjectIndex);
    const sendData = [];
    // tslint:disable-next-line: prefer-const
    for (let key of q.keys()) {
      console.log('On save datat key ----> ', q.get(key));
      q.get(key)['intentId'] = this.selectedIntentId;
      sendData.push(q.get(key));
    }

    console.log('sendData -->', q);

    this.saveUnmappedInputsSubscribe = this.trainingService.saveUnmappedInputs(sendData).subscribe(res => {
      console.log(res, sendData);
      if (res['errorBody'] != null) {
        this.showPopup('Error', res['errorBody'].summary, 'warn');
      } else {
        this.clearAssistedTrainingtags();
        this.showPopup('Info', 'Intent is mapped successfully', 'info');
        this.serviceCallUnmappedInputs(this.channelIdDrodown, this.fromDate, this.languageIdDrodown, this.pageNumber, this.toDate, this.vaIdDrodown, this.searchText);
      }
    }, err => {
      this.showPopup('Error', 'Intent is not mapped ,Internal Error', 'warn');
      console.error(err);
      this.spinner.hide();
    });

    this.selectedValue = []; this.selectedIntentName = []; this.selectedIntents = [];
  }

  getPOSTIONoftxt(txtary: any, mappedHighlightData: any) {
    console.log(txtary, mappedHighlightData);
    const posArydt = [];
    let position = 'pos' + this.posStart++;
    posArydt.push(position);
    while (this.posStart <= this.posEnd) {
      // tslint:disable-next-line: prefer-const
      let i = this.posStart++;
      posArydt.push('pos' + i);
      position += '~pos' + i;
    }
    return { posAry: posArydt, pos: position };
  }

  getIntentSlotValue(x) {
    console.log('========> ', x, this.currentSelectedtxt, this.selectedPharseKey);
    // tslint:disable-next-line: prefer-const
    let phraseObj = this.unmapObjectIndex.get(this.selectedPharseKey);
    console.log('========> phraseObj ', phraseObj);
    // tslint:disable-next-line: prefer-const
    let txtary = this.currentSelectedtxt.split(' ');
    // tslint:disable-next-line: prefer-const
    let posData = this.getPOSTIONoftxt(txtary, phraseObj.mappedData.mappedHighlightData);
    console.log('getPOSTIONoftxt -->', posData.pos);

    // tslint:disable-next-line: forin , prefer-const
    for (let i in posData.posAry) {
      const regex = new RegExp('\\b(' + posData.posAry[i] + ')\\b');
      // tslint:disable-next-line: prefer-const
      for (let key in phraseObj['intentslots']) {
        if (key.search(regex) >= 0) {
          delete phraseObj['intentslots'][key];
          break;
        }
      }
    }

    phraseObj['intentId'] = this.selectedIntentId;
    phraseObj['intentslots'][posData.pos] = {
      intentSlot: {
        id: x.id,
        value: x.value
      },
      value: this.currentSelectedtxt
    };
    phraseObj['value'] = phraseObj['mappedData']['displayValue'];
    phraseObj['value'] = this.coloringPhrase(phraseObj);

    this.unmapObjectIndex.set(this.selectedPharseKey, phraseObj);
    console.log('this.unmapObjectIndex ', this.unmapObjectIndex);

    // Clearing all selection text and data
    document.getSelection().removeAllRanges();
    this.clearHostRectangle();
  }
  coloringPhrase(o) {
    const outputColorArray = [].concat(...this.colorArrayGenrater(o['intentslots']));
    // console.log('outputColorArray ------------> ', outputColorArray);
    return this.colorDisplayTextAndGenrateInnerPhase(o, outputColorArray);
  }

  colorArrayGenrater(intentslots) {
    const colorArray = [];
    // tslint:disable-next-line: prefer-const
    for (let key of Object.keys(intentslots)) {
      console.log(key, key.length, ' -> ' + JSON.stringify(intentslots[key]));
      colorArray.push(key.split('~'));
    }
    return colorArray;
  }

  getColorStylebyIntentID = (id: number) => {
    const c = getObjById(this.intentSlotColorList, id);
    console.log('---> ', id, c);
    return c[0]['color'];
  }

  colorDisplayTextAndGenrateInnerPhase(o, outputColorArray) {
    console.log(o, outputColorArray);
    let innerPhase = '';
    let dontAdd = false;
    const rxp = /%[ /]%/g;
    const mappedHighlightData = o['mappedData']['mappedHighlightData'];
    // tslint:disable-next-line: forin , prefer-const
    for (let i in o['mappedData']['mappedHighlightData']) {
      mappedHighlightData[i]['isHighlight'] = false;
      // tslint:disable-next-line: prefer-const
      for (let j in outputColorArray) {
        // console.log(mappedHighlightData[i]['key'], outputColorArray[j])
        if (mappedHighlightData[i]['key'] === outputColorArray[j]) {
          mappedHighlightData[i]['isHighlight'] = true;
          let intentSlotId = 0;
          // tslint:disable-next-line: prefer-const
          for (let key of Object.keys(o['intentslots'])) {
            if (key.includes(outputColorArray[j])) {
              intentSlotId = o['intentslots'][key]['intentSlot']['id'];
            }
          }
          mappedHighlightData[i]['colorClass'] = this.getColorStylebyIntentID(intentSlotId);
          innerPhase += '%' + mappedHighlightData[i]['key'] + '% ';
          dontAdd = false;
          break;
        } else {
          dontAdd = true;
        }
      }
      // tslint:disable-next-line: no-unused-expression
      dontAdd ? innerPhase += mappedHighlightData[i]['value'] + ' ' : '';
    }
    innerPhase = innerPhase.replace(/^\s+/, '').replace(/\s+$/, '');
    let txtArray = [];
    let clearAry = [];
    // tslint:disable-next-line: prefer-const
    for (let key of Object.keys(o['intentslots'])) {
      const arykey = [];
      if (key.includes('~')) {
        arykey.push(key.split('~'));
        txtArray = innerPhase.split(' ');
        let firstTime = true;
        // tslint:disable-next-line:forin , prefer-const
        for (let x in txtArray) {
          const rxpPer = /[%]/g;
          // tslint:disable-next-line: prefer-const
          let yesPerThr = rxpPer.test(txtArray[x]);
          txtArray[x] = txtArray[x].replace(/[%]/g, '');
          // console.log('yesPerThr', yesPerThr, txtArray[x]);
          if (key.includes(txtArray[x])) {
            if (firstTime) { txtArray[x] = '%' + key + '%'; firstTime = false; } else { txtArray[x] = ''; }
          } else {
            txtArray[x] = yesPerThr ? '%' + txtArray[x] + '%' : txtArray[x];
          }
        }
        clearAry = txtArray.filter(n => n);
      }
      innerPhase = clearAry.length > 0 ? clearAry.join(' ') : innerPhase;
    }
    console.log('innerPhase  -->', innerPhase);
    // tslint:disable-next-line: no-unused-expression
    innerPhase === '' ? innerPhase = o['mappedData']['displayValue'] : '';
    return innerPhase;
  }

  preventClose(event: MouseEvent) {
    event.stopImmediatePropagation();
  }

  intentChanged(value) {
    console.log('selectedInten --> ', value, this.unmapObjectIndex);
    this.selectedIntentName = value.value;
    this.selectedIntentId = value.id;
    this.clearunmapIntentSlotsData();
    console.log('unmap status', this.unmapObjectIndex);
    this.displaySlotsList();
  }

  onScroll() {
    console.log('scroll --->');
    this.showloader = true;
    this.counter += 1;
    this.getUnmappedUserInputScrollSubscribe = this.trainingService.getUnmappedUserInput(this.channelIdDrodown, this.languageIdDrodown, this.counter, this.vaIdDrodown, this.searchText, this.fromDate, this.toDate).subscribe((res: any[]) => {
      const conversationSession = res['conversationList'];
      for (let k = 0; k < conversationSession.length; k++) {
        this.conversationListProcess(conversationSession[k]['sessionId'], conversationSession[k]);
      }
      this.showloader = false;
    },
      err => { this.spinner.hide(); console.error(err); }
    );
  }

  clearIntentSlot(id, session, phraseType) {
    const checkboxId = 'c-m-' + session + '-' + id;
    const phraseObj = this.unmapObjectIndex.get(checkboxId);
    console.log('dt', phraseObj);
    phraseObj['intentslots'] = {};
    phraseObj['value'] = phraseObj['mappedData']['displayValue'];
    phraseObj['value'] = this.coloringPhrase(phraseObj);
    this.unmapObjectIndex.set(checkboxId, phraseObj);
    console.log('rfv --->', this.unmapObjectIndex.get(checkboxId));
  }

  ideaIntent(id, session, phraseType) {
    const checkboxId = 'c-m-' + session + '-' + id;
    this.showBestResponseTab(checkboxId, true);
  }

  showBestResponseTab(id, isIdea) {
    this.clearBestResponse();
    if (this.unmapObjectIndex.size === 1 || isIdea) {
      const phraseObj = this.unmapObjectIndex.get(id);
      if (phraseObj.hasOwnProperty('nextBestPredictions') && phraseObj['nextBestPredictions'].length > 0) {
        console.log('nextBestPredictions ', phraseObj['nextBestPredictions']);
        this.checkIfIntentThr(phraseObj['nextBestPredictions']);
        // tslint:disable-next-line: no-unused-expression
        this.bestResponseSlots.length > 0 ? this.ifbestResponseIntent = true : '';
      } else {
        this.clearBestResponse();
      }
    } else {
      this.clearBestResponse();
    }
  }

  clearBestResponse() {
    this.bestResponseSlots = [];
    this.ifbestResponseIntent = false;
  }

  checkIfIntentThr(p) {
    // tslint:disable-next-line: forin , prefer-const
    for (let x in p) {
      // tslint:disable-next-line: forin , prefer-const
      for (let v in this.intentListData) {
        if (this.intentListData[v]['value'].toLowerCase() === p[x]['intentName'].toLowerCase()) {
          this.bestResponseSlots.push(p[x]);
        }
      }
    }
  }

  setIntent(slot) {
    console.log('Slot choosen ', slot);
    this.clearunmapIntentSlotsData();
    this.displaySlotsList();
    this.selectedIntentName = []; this.selectedIntentId = '';
    try {
      this.intentListData.forEach(e => {
        console.log(e.value.toLowerCase() === slot.intentName.toLowerCase(), e.value.toLowerCase(), slot.intentName.toLowerCase());
        if (e.value.toLowerCase() === slot.intentName.toLowerCase()) {
          this.selectedIntentName = e.value;
          this.selectedIntentId = e.id;
          throw this.BreakException;
        }
      });
    } catch (e) {
      this.displaySlotsList();
      if (e !== this.BreakException) { throw e; }
    }
  }

  clearPhaseData(clearId, clearSessionId, clearPhraseType) {
    this.spinner.show();
    console.log('bg(((((', clearId, clearSessionId, clearPhraseType);
    const checkboxId = 'c-m-' + clearSessionId + '-' + clearId;
    this.unmapObjectIndex.delete(checkboxId);
    // tslint:disable-next-line: prefer-const
    for (let e of this.allInputsKeyValue) {
      console.log(e);
      if (e.sessionId === clearSessionId) {
        const n = e[clearPhraseType];
        // tslint:disable-next-line: prefer-const
        for (let dt of n) {
          console.log(dt);
          if (dt.id === clearId) {
            dt['isSelected'] = false;
            break;
          }
        }
        break;
      }
    }
    this.spinner.hide();
  }

  openModalRightRemove(id, sessionId, phraseType) {
    modalDeleteConfig.secondaryText = 'Are you sure want to remove a phrase?';
    const dialogRef = this.dialog.open(ModalComponent, {
      disableClose: true,
      data: modalDeleteConfig
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.clearPhaseData(id, sessionId, phraseType);
      }
    });
  }

  // code to delete input
  deleteUnmappedUser(ummappedid) {
    this.spinner.show();
    this.deleteUnmappedUserInputsSubscribe = this.trainingService
      .deleteUnmappedUserInputs(ummappedid)
      .subscribe(res => {
        this.serviceCallUnmappedInputs(this.channelIdDrodown, this.fromDate, this.languageIdDrodown, this.pageNumber, this.toDate, this.vaIdDrodown, this.searchText);
      },
        err => { this.spinner.hide(); console.error(err); }
      );
  }

  openModalLeftDelete(ummappedid) {
    modalDeleteConfig.secondaryText = 'Are you sure want to delete a phrase?';
    const dialogRef = this.dialog.open(ModalComponent, {
      disableClose: true,
      data: modalDeleteConfig
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.deleteUnmappedUser(ummappedid);
      }
    });
  }

  openModalTrainInput() {
    modalDeleteConfig.primaryText = 'Confirm';
    modalDeleteConfig.secondaryText = 'Do you want to Train Inputs?';
    modalDeleteConfig.popUpType = 'warn';
    const dialogRef = this.dialog.open(ModalComponent, {
      disableClose: true,
      data: modalDeleteConfig
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.trainInputEvent();
      }
    });
  }

  trainInputEvent() {
    this.addTrainingPhraseDialogFlowSubscribe = this.createIntentService.addTrainingPhraseDialogFlow(this.vaLangId, this.vaId)
      .subscribe(res => console.log(res),
        (error: any) => {
          console.log('trainInputEvent ', error);
          const responsetxt = error.error.text;
          console.log('responsetxt ', responsetxt);
          // if (responsetxt == 'Trained') {
          //   this.toastr.success('', 'Training is Scheduled', this.toastrConfig);
          // }
          if (responsetxt === 'Training in Progress') {
            this.toastr.warning('', `The VA is currently being trained. Request you to try the 'Train Inputs' option again after some time. `, this.toastrConfig);
          }
          // else {
          //   this.toastr.error('', 'Error While scheduling! Try agian later', this.toastrConfig);
          // }
        });
    // this.toastr.success('', 'Training is Scheduled', this.toastrConfig);
  }

  showPopup(title: string, msg: string, logo: string) {
    modalErrorConfig.primaryText = title;
    modalErrorConfig.secondaryText = msg;
    modalErrorConfig.popUpType = logo;

    this.dialog.open(ModalComponent, { disableClose: true, data: modalErrorConfig });
  }

  editIntent(id, sessionId, phraseType) {
    const checkboxId = 'c-m-' + sessionId + '-' + id;
    // console.log(this.unmapObjectIndex.get(checkboxId));
    if (!this.editEnable) {
      const phraseObj = cloneDeep(this.unmapObjectIndex.get(checkboxId));
      phraseObj['onedit'] = true;
      this.unmapObjectIndex.set(checkboxId, phraseObj);
      this.editEnable = true;
    } else {
      this.showPopup('Warning', `You have another edit action in progress. Please complete it.`, 'warn');
    }
  }

  saveEditPhrase(id, sessionIddt, phraseType, edittxt) {
    const checkboxId = 'c-m-' + sessionIddt + '-' + id;
    const txt = edittxt.toString().trim();
    console.log(edittxt, this.unmapObjectIndex.get(checkboxId));
    if (this.validateEditPhrase(txt)) {
      // tslint:disable-next-line: prefer-const
      let phraseObj = cloneDeep(this.unmapObjectIndex.get(checkboxId));
      phraseObj['onedit'] = false;
      phraseObj['intentslots'] = {};
      phraseObj['value'] = txt;
      phraseObj['mappedData'] = {
        displayValue: txt,
        sessionId: sessionIddt,
        mappedHighlightData: this.genrateHighlightdata(txt, false, '')
      };
      this.unmapObjectIndex.set(checkboxId, phraseObj);
      this.editEnable = false;
    } else {
      this.showPopup('Warning', `Edited text must not contain Special Character`, 'warn');
    }
  }

  validateEditPhrase(edittxt) {
    console.log(edittxt);
    const regex = /^[a-z|A-Z|0-9]+(?: [a-z|A-Z|0-9]+)*$/gy;
    if (edittxt != null && edittxt !== 'undefined' && edittxt !== '') {
      return (regex.test(edittxt) ? true : false);
    } else {
      return false;
    }
  }

}

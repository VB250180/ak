import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';

@Component({
  selector: 'app-template',
  templateUrl: './template.component.html',
  styleUrls: ['./template.component.scss']
})
export class TempalateComponent implements OnInit {

  yestrue = true;
  constructor() {
  }

  ngOnInit() {
  }
}




// leaves.module.ts
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, OnInit, ViewChild, Output, EventEmitter, Input, Renderer2, ElementRef, ViewContainerRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { EntityRoutingModule } from './entity-routing.module';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgxSpinnerModule } from 'ngx-spinner';
import { SharedModule } from 'src/app/shared.module';
import { MatMenuModule } from '@angular/material/menu';
import { MatListModule } from '@angular/material/list';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { MatIconModule } from '@angular/material/icon';
import { EntityListingComponent } from './entity-listing/entity-listing.component';
import { CreateEntityComponent } from './create-entity/create-entity.component';
import { MatFormFieldModule, MatButtonModule, MatInputModule, MatSelectModule, MatChipsModule, MatDialogModule } from '@angular/material';
import { TagInputModule } from 'ngx-chips';



@NgModule({
  declarations: [
    EntityListingComponent,
    CreateEntityComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    NgSelectModule,
    NgxSpinnerModule,
    SharedModule,
    MatMenuModule,
    MatListModule,
    DragDropModule,
    MatDialogModule,
    MatChipsModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    EntityRoutingModule,
    TagInputModule,

   ],
   schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
})
export class EntityModule { }

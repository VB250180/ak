// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { CreateEntityComponent } from './create-entity.component';

// describe('CreateEntityComponent', () => {
//   let component: CreateEntityComponent;
//   let fixture: ComponentFixture<CreateEntityComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ CreateEntityComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(CreateEntityComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });


import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';

import { CreateEntityComponent } from './create-entity.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { RouterModule } from '@angular/router';
import { APP_BASE_HREF } from '@angular/common';
import { of } from 'rxjs';
import { CreateEntityService } from '../../../core/services/create-entity/create-entity.service';
import { SearchFilterPipe } from 'src/app/shared/pipes/searchfilter.pipe';
import { MatDialogModule } from '@angular/material';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
declare var $: any;

describe('CreateEntityComponent', () => {
  let createEntityService;
  let component: CreateEntityComponent;
  let fixture: ComponentFixture<CreateEntityComponent>;
  // let systemSlotList={
  //   "systemSlotKeys": [
  //     {
  //       "systemSlotKeyId": 2,
  //       "systemSlotKeyName": "GroupID"
  //     },
  //     {
  //       "systemSlotKeyId": 1,
  //       "systemSlotKeyName": "MemberID"
  //     }
  //   ]
  // };


  // let entityList={
  //   "entities": [
  //     {
  //       "entityId": 5,
  //       "entityName": "Claim_Number"
  //     },
  //     {
  //       "entityId": 1,
  //       "entityName": "DOB"
  //     },
  //     {
  //       "entityId": 3,
  //       "entityName": "MTPIN"
  //     },
  //     {
  //       "entityId": 4,
  //       "entityName": "Phone Number"
  //     },
  //     {
  //       "entityId": 8,
  //       "entityName": "Policy_Type"
  //     },
  //     {
  //       "entityId": 2,
  //       "entityName": "SSN"
  //     },
  //     {
  //       "entityId": 7,
  //       "entityName": "sys.date"
  //     },
  //     {
  //       "entityId": 6,
  //       "entityName": "sys.number"
  //     }
  //   ]
  // };

  // let conversationList={
  //   "conversation": {
  //     "validationIntent": {
  //       "intentId": 61,
  //       "intentName": "ClaimS",
  //       "intentType": null,
  //       "intentDescription": "Claim status ",
  //       "virtualAgent": null,
  //       "businessUnit": null,
  //       "languages": null
  //     },
  //     "systemSlots": [
  //       {
  //         "systemSlotId": 42,
  //         "systemSlotKey": {
  //           "systemSlotKeyId": 1,
  //           "systemSlotKeyName": "MemberID"
  //         }
  //       },
  //       {
  //         "systemSlotId": 43,
  //         "systemSlotKey": {
  //           "systemSlotKeyId": 2,
  //           "systemSlotKeyName": "GroupID"
  //         }
  //       }
  //     ],
  //     "conversationStages": [
  //       {
  //         "sequenceNumber": 1,
  //         "conversationStageId": 129,
  //         "sendMessage": null,
  //         "getInfo": {
  //           "getInfoId": 38,
  //           "promptQuestion": "asdf",
  //           "promptValidationMessage": "asdf",
  //           "intentSlot": {
  //             "intentSlotId": 38,
  //             "intentSlotName": "asdf",
  //             "intentSlotDescription": "asdf",
  //             "entity": {
  //               "entityId": 8,
  //               "entityName": "Policy_Type"
  //             }
  //           }
  //         },
  //         "finalResponse": null
  //       },
  //       {
  //         "sequenceNumber": 2,
  //         "conversationStageId": 159,
  //         "sendMessage": {
  //           "messageId": 53,
  //           "messageText": "dsfgsdg"
  //         },
  //         "getInfo": null,
  //         "finalResponse": null
  //       },
  //       {
  //         "sequenceNumber": 3,
  //         "conversationStageId": 133,
  //         "sendMessage": {
  //           "messageId": 39,
  //           "messageText": "esarfas"
  //         },
  //         "getInfo": null,
  //         "finalResponse": null
  //       },
  //       {
  //         "sequenceNumber": 4,
  //         "conversationStageId": 134,
  //         "sendMessage": {
  //           "messageId": 40,
  //           "messageText": "dasfsda"
  //         },
  //         "getInfo": null,
  //         "finalResponse": null
  //       },
  //       {
  //         "sequenceNumber": 5,
  //         "conversationStageId": 130,
  //         "sendMessage": null,
  //         "getInfo": {
  //           "getInfoId": 39,
  //           "promptQuestion": "asdf",
  //           "promptValidationMessage": "asdf",
  //           "intentSlot": {
  //             "intentSlotId": 39,
  //             "intentSlotName": "sdafasd",
  //             "intentSlotDescription": "asdf",
  //             "entity": {
  //               "entityId": 3,
  //               "entityName": "MTPIN"
  //             }
  //           }

  //         },
  //         "finalResponse": null
  //       },
  //       {
  //         "sequenceNumber": 6,
  //         "conversationStageId": 132,
  //         "sendMessage": null,
  //         "getInfo": {
  //           "getInfoId": 40,
  //           "promptQuestion": "asf",
  //           "promptValidationMessage": "asf",
  //           "intentSlot": {
  //             "intentSlotId": 40,
  //             "intentSlotName": "new ",
  //             "intentSlotDescription": "asdf",
  //             "entity": {
  //               "entityId": 7,
  //               "entityName": "sys.date"
  //             }
  //           }
  //         },
  //         "finalResponse": null
  //       },
  //       {
  //         "sequenceNumber": 7,
  //         "conversationStageId": 171,
  //         "sendMessage": null,
  //         "getInfo": null,
  //         "finalResponse": {
  //           "finalResponseId": 67,
  //           "finalResponseText": "final claim status  %pos0% and  %pos1% intent",
  //           "positionAndSlots": [
  //             {
  //               "finalResponseSlotId": 709,
  //               "position": "pos1",
  //               "intentSlot": {
  //                 "intentSlotId": 40,
  //                 "intentSlotName": "new ",
  //                 "intentSlotDescription": "asdf",
  //                 "entity": {
  //                   "entityId": 7,
  //                   "entityName": "sys.date"
  //                 }
  //               },
  //               "responseSlot": null
  //             },
  //             {
  //               "finalResponseSlotId": 708,
  //               "position": "pos0",
  //               "intentSlot": null,
  //               "responseSlot": {
  //                 "responseSlotId": 39,
  //                 "responseSlotName": "data",
  //                 "responseSlotDescription": "dasf"
  //               }
  //             }
  //           ]
  //         }
  //       }
  //     ],
  //     "responseSlots": [
  //       {
  //         "responseSlotId": 39,
  //         "responseSlotName": "data",
  //         "responseSlotDescription": "dasf"
  //       }
  //     ]
  //   }
  // };


  class AuthenticationServiceStub {
    getCurrentUserId() {
      return 1;
    }
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CreateEntityComponent, SearchFilterPipe],
      providers: [
        CreateEntityService,
        { provide: AuthenticationService, useClass: AuthenticationServiceStub },
        { provide: APP_BASE_HREF, useValue: '/' },
        // { provide: CreateIntentService}

      ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        RouterTestingModule,
        HttpClientTestingModule,
        MatDialogModule,
        RouterModule.forRoot([]),
        DragDropModule,
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(inject([CreateEntityService], s => {
    createEntityService = s;
    fixture = TestBed.createComponent(CreateEntityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  // it("should call getEntityList and return list", async(() => {
  //   spyOn(createEntityService, 'getEnityConversionList').and.returnValue(of(conversationList.conversation))
  //   component.getConversationList(61,1,2);
  //   }));


  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // it('check methods', () => {
  //   component.addNewArrayRefval();
  //   component.getEntity(1,2);
  //   component.virtualAgents();
  //   component.vaChange("1");
  //   component.OnChangeSynonyms("chennai");
  //   component.searchDuplicateVal("chennai");
  //   component.saveEntityData();
  //   component.saveEntity();
  //   component.updateEntity();
  //   component.onCancel();
  //   component.openModalErrorPopUp("err");
  //   component.openModalPopUp("1");

  // });


});

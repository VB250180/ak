import { Component, OnInit, OnDestroy } from '@angular/core';
import { EntityObj, EntityRefernceValuePojoList, EntitySynonymsValueList, Language, VaDropDown } from '../../../core/models/entity';
import * as cloneDeep from 'lodash/cloneDeep';
import { ItemsList } from '@ng-select/ng-select/lib/items-list';
import { CreateEntityService } from '../../../core/services/create-entity/create-entity.service';
import { format } from 'url';
import { EntitiesService } from 'src/app/core/services/entity/entity.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';
import { filterByNluConfigured } from '../../../core/utils/akeira-utils';
import { findSynonymsSlotCharLimit } from '../../../core/utils/akeira-utils';
import { Subscription } from 'rxjs';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
declare var $: any;



@Component({
  selector: 'app-create-entity',
  templateUrl: './create-entity.component.html',
  styleUrls: ['./create-entity.component.scss']
})
export class CreateEntityComponent implements OnInit, OnDestroy {
  model: any = {};
  entityObj = new EntityObj();
  query: any = null;
  entityRefernceValuePojoListObj = new EntityRefernceValuePojoList();
  entitySynonymsValueList = new Array<EntitySynonymsValueList>();
  vrmId; vaAgents; lang;
  entityObjNew;
  entityDupValue: boolean;
  showUpdateBtn = true;
  isActiveSaveBtn = true;
  isEntityDisabled = false;
  isAlphCheckEntityName = false;
  isAddBtnActive = false;
  synSlotLimit = false;
  BreakException = {};
  userId = 0;
  vaID = null;
  langId; flag: any;
  editIndex;
  getVAdetailsByUserIdSubscription: Subscription;
  getLanguagessByVaIdSubscription: Subscription;
  getEntitySubscription: Subscription;
  saveEntitySubscription: Subscription;
  updateEntitySubscription: Subscription;
  constructor(
    private route: ActivatedRoute,
    private entitiesService: EntitiesService,
    private createEntityService: CreateEntityService,
    private matDialog: MatDialog,
    private router: Router,
    private authService: AuthenticationService
    ) {
    this.addNewArrayRefval();
    this.userId = this.authService.getCurrentUserId();
  }
  // default empty array
  addNewArrayRefval() {
    const entityRefernceValuePojoListObj = new EntityRefernceValuePojoList();
    this.entityObj.entityRefernceValuePojoList.push(entityRefernceValuePojoListObj);
  }
  // addNewArrayRefvalObjNew() {
  //   let entityRefernceValuePojoListObj = new EntityRefernceValuePojoList();
  //   this.entityObjNew.entityRefernceValuePojoList.push(entityRefernceValuePojoListObj);
  // }

  ngOnInit() {
    this.route.paramMap.subscribe((params: any) => {
      this.vaID = params.params.vaID;
      const entId = params.params.entId;
      this.langId = params.params.langId;
      if (this.vaID !== undefined) {
        this.isEntityDisabled = true;
        this.getEntity(entId, this.langId);
        this.isActiveSaveBtn = false;
      }
    });
    this.virtualAgents();

    $(document).on('keypress', 'input', (e) => {
      const startPos = e.currentTarget.selectionStart;
      if (e.which === 32 && startPos === 0) {
        e.preventDefault();
      }
    });

    //     $("input").bind("keypress",function(e){
    //     var patt = /([a-z][0-9][\.\_])*/i; /* this is the pattern u want to test */
    //     var value = this.value + String.fromCharCode(e.keyCode);
    //     var result = patt.test(value ); /* result = true or false */
    //     /* here you can do anything now */
    // });
  }

  getEntity(entId, langId) {
    this.getEntitySubscription = this.createEntityService.getEntity(entId, langId)
      .subscribe((res: any) => {
        this.model.vrmId = this.vaID;
        this.entityObj = res.entityResponseObject;
        const entityRefernceValuePojoListObj = new EntityRefernceValuePojoList();
        this.entityObj.entityRefernceValuePojoList.push(entityRefernceValuePojoListObj);
        this.entityObjNew = cloneDeep(this.entityObj);


      });
  }
  // getListofVA
  virtualAgents() {
    this.getVAdetailsByUserIdSubscription = this.entitiesService.getVAdetailsByUserId(this.userId)
      .subscribe((res: any) => {
        this.vaAgents = filterByNluConfigured(res.virtualAgents);
        console.log(this.vaAgents);
        if (this.vaID !== undefined) {
          this.vaChange(this.vaID);
        }
      });
  }

  clearValueOnVaChange() {
    if (this.entityObj.entityRefernceValuePojoList.length > 1) {
      this.entityObj.entityRefernceValuePojoList = [];
      this.entityObjNew.entityRefernceValuePojoList = [];
      const entityRefernceValuePojoListObj = new EntityRefernceValuePojoList();
      this.entityObj.entityRefernceValuePojoList.push(entityRefernceValuePojoListObj);
    }
  }
  langChange(e) {
    this.clearValueOnVaChange();
  }
  // on VA Change
  vaChange(e) {
    if (this.vaID == null) {
      this.clearValueOnVaChange();
    }
    const vaId = e;
    this.getLanguagessByVaIdSubscription = this.entitiesService.getLanguagessByVaId(vaId)
      .subscribe((res: any) => {
        this.lang = res.languageEngineMaps;
        if (this.vaID != null) {
          setTimeout(() => {
            this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1].languageMasterPojo.langId = this.langId;
          }, 500);
        }
      });
  }
  // default first synonyms value
  OnChangeSynonyms(value) {
    this.entityDupValue = false;
    this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1].entitySynonymsValueList = [];
    this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1].entitySynonymsValueList.push({ entitySynonymsValue: value });
  }
  onbtnColorChange(value) {
    (value === '') ? this.isAddBtnActive = false : this.isAddBtnActive = true;
  }
  searchDuplicateVal(value) {
    if (this.entityObjNew !== undefined) {
      const duplicateVal = this.entityObjNew.entityRefernceValuePojoList.filter(item => item.entityReferenceValue === value);
      (duplicateVal.length === 0) ? this.saveEntityData() : this.entityDupValue = true;
    } else {
      this.saveEntityData();
    }
  }

  specialCharPresent(entName) {
    const alphaExp = /^[a-zA-Z]+$/;
    if ((entName.charAt(0)).match(alphaExp)) {
      this.isAlphCheckEntityName = false;
      this.funSpecialCharChk(entName);
    } else {
      this.isAlphCheckEntityName = true;
      return false;
    }
  }

  funSpecialCharChk(entName) {
    const patt = /^[a-zA-Z0-9\-\_]*$/;
    if (patt.test(entName)) {
      this.isAlphCheckEntityName = false;
    } else {
      this.isAlphCheckEntityName = true;
      return false;
    }
  }
  entityAddValue(f) {
    this.synSlotLimit = false;
    if (f.form.valid) {
      if (this.isAlphCheckEntityName === false) {
        const sysnExceedLimit = findSynonymsSlotCharLimit(f.form.value.entitySynonymsValue);
        (sysnExceedLimit === true) ? this.searchDuplicateVal(f.form.value.entityReferenceValue) : this.synSlotLimit = true;
      }
    }
  }
  saveEntityData() {
    this.entityDupValue = false;
    this.isAddBtnActive = false;
    this.addNewArrayRefval();
    this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1].languageMasterPojo.langId = this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 2].languageMasterPojo.langId;
    this.entityObjNew = cloneDeep(this.entityObj);
  }
  // saveEntity new data
  saveEntity() {
    if (this.entityObjNew.entityRefernceValuePojoList.length > 1) {
      this.entityObjNew.entityRefernceValuePojoList.pop();
      this.saveEntitySubscription = this.createEntityService.saveEntity(this.model.vrmId, this.entityObjNew)
        .subscribe((res: any) => {
          if (res.errorBody != null) {
            this.openModalErrorPopUp(res['errorBody'].summary);
          } else {
            this.entityObjNew = res.entityResponseObject;
            const entityRefernceValuePojoListObj = new EntityRefernceValuePojoList();
            this.entityObjNew.entityRefernceValuePojoList.push(entityRefernceValuePojoListObj);
            this.openModalPopUp(this.flag);
          }
        });
    } else {
      this.openModalPopUpUpdateErr('2');
    }
  }
  updateEntity() {
    console.log('entity updated details bfr ', this.entityObjNew, this.entityObj);
    this.entityObjNew.entityDescription = this.entityObj.entityDescription;

    console.log('entity updated details aftr ', this.entityObjNew, this.entityObj);

    if (this.entityObjNew.entityRefernceValuePojoList.length > 1) {
      this.entityObjNew.entityRefernceValuePojoList.pop();
      console.log('descvalue', this.entityObj.entityDescription);
      this.updateEntitySubscription = this.createEntityService.updateEntity(this.model.vrmId, this.entityObjNew)
        .subscribe((res: any) => {
          if (res.errorBody != null) {
            this.openModalErrorPopUp(res['errorBody'].summary);
          } else {
            this.entityObjNew = res.entityResponseObject;
            const entityRefernceValuePojoListObj = new EntityRefernceValuePojoList();
            this.entityObjNew.entityRefernceValuePojoList.push(entityRefernceValuePojoListObj);
            this.openModalPopUp('1');
            this.entityObjNew = res.entityResponseObject;
          }
        });
    } else {
      this.openModalPopUpUpdateErr('2');
    }
  }

  // edit Entity
  editEntity(entityObj, i) {
    this.editIndex = i;
    this.showUpdateBtn = false;
    this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1] = entityObj;
    this.entityObjNew = cloneDeep(this.entityObjNew);
  }

  entityUpdateValue(f) {
    this.synSlotLimit = false;
    if (f.form.valid) {
      const sysnExceedLimit = findSynonymsSlotCharLimit(f.form.value.entitySynonymsValue);
      (sysnExceedLimit === true) ? this.submitUpdateEntity() : this.synSlotLimit = true;
    }
  }

  submitUpdateEntity() {
    if (this.isAlphCheckEntityName === false) {
      this.entityObj.entityRefernceValuePojoList[this.editIndex] = this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1];
      const entityRefernceValuePojoListObj = new EntityRefernceValuePojoList();
      this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1] = entityRefernceValuePojoListObj;
      this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1].languageMasterPojo.langId = this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 2].languageMasterPojo.langId;
      this.entityObjNew = cloneDeep(this.entityObj);
      this.showUpdateBtn = true;
      this.isAddBtnActive = false;
    }
  }




  deleteEntity(i, obj) {
    this.entityObjNew.entityRefernceValuePojoList.splice(i, 1);
    this.entityObj = cloneDeep(this.entityObjNew);
    this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1].languageMasterPojo.langId = obj.languageMasterPojo.langId;
    this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1].entityReferenceValue = null;
    this.entityObj.entityRefernceValuePojoList[this.entityObj.entityRefernceValuePojoList.length - 1].entitySynonymsValueList = [];
    this.showUpdateBtn = true;
  }


  onCancel() {
    if (this.flag === 1) {
      this.router.navigate(['/entity/listing']);
    }
  }
  openModalPopUp(flag) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = '800px';
    dialogConfig.data = {
      primaryText: 'You have successfully created a new Entity which you can view and edit in the Entity listing page ',
      secondaryText: '',
      hasPrimaryBtn: true,
      primaryBtnText: 'Create another',
      hasSecondaryBtn: true,
      secondaryBtnText: 'Go to Entity Listing Page',
      suggestedText: '',
      popUpType: 'save',
      hasCancelBtn: false
    };
    if (flag === 1) {
      dialogConfig.data.primaryText = 'You have successfully updated an Entity which you can view and edit in the Entity listing page ';
    }
    const modalDialog = this.matDialog.open(ModalComponent, dialogConfig);
    modalDialog.afterClosed().subscribe(data => {
      console.log('material data', data);
      if (data === 'secondary') {
        this.router.navigate(['/entity/listing']);
      } else {
        this.redirectTo('/entity/create');
        // this.router.navigate(['/create-entity'])
      }
    });
  }

  redirectTo(uri: string) {
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() =>
      this.router.navigate([uri]));
  }
  enterSynonymsLimit(sysn) {
  }

  openModalErrorPopUp(err) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = '800px';
    dialogConfig.data = {
      primaryText: err,
      hasPrimaryBtn: true,
      primaryBtnText: 'Ok',
      suggestedText: '',
      popUpType: 'error',
      hasCancelBtn: true
    };
    const modalDialog = this.matDialog.open(ModalComponent, dialogConfig);
    modalDialog.afterClosed().subscribe(data => {
      console.log('material data err', data);
      if (data === true) {
        this.redirectTo('/create-entity');
      } else {
        this.router.navigate(['/entity/listing']);
      }
    });
  }


  openModalPopUpUpdateErr(flag) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = '500px';
    dialogConfig.data = {
      primaryText: 'Entity not saved !!!',
      secondaryText: `Please create at least one Entity value for a specific language`,
      hasPrimaryBtn: true,
      primaryBtnText: 'OK',
      hasSecondaryBtn: true,
      // secondaryBtnText: 'Go to va Entity Listing Page',
      suggestedText: '',
      popUpType: 'save',
      hasCancelBtn: false
    };
    const modalDialog = this.matDialog.open(ModalComponent, dialogConfig);
    modalDialog.afterClosed().subscribe(data => {
    });
  }
  // dropdownBindvalue
  compareVal(c1: VaDropDown, c2: VaDropDown) {
    // tslint:disable-next-line: triple-equals
    if (c2 == c1) {
      return c2;
    }
    // return c1 && c2 ? c1.vaId === c2.vaId : c1 === c2;
  }
  compareLang(l1: Language, l2: Language) {
    // tslint:disable-next-line: triple-equals
    if (l2 == l1) {
      return l2;
    }
    // return 11 && 11 ? l1.langEngId === l2.langEngId : l1 === l2;
  }

  ngOnDestroy() {
    if (this.getVAdetailsByUserIdSubscription) {
      this.getVAdetailsByUserIdSubscription.unsubscribe();
    }
    if (this.getLanguagessByVaIdSubscription) {
      this.getLanguagessByVaIdSubscription.unsubscribe();
    }
    if (this.getEntitySubscription) {
      this.getEntitySubscription.unsubscribe();
    }
    if (this.saveEntitySubscription) {
      this.saveEntitySubscription.unsubscribe();
    }
    if (this.updateEntitySubscription) {
      this.updateEntitySubscription.unsubscribe();
    }
  }

}

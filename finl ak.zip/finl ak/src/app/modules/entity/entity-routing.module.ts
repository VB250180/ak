import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateEntityComponent } from './create-entity/create-entity.component';
import { EntityListingComponent } from './entity-listing/entity-listing.component';
import { AuthGuard } from 'src/app/core/guards/auth.guard';

const routes: Routes = [
  { path: 'create', component: CreateEntityComponent },
  { path: 'create/:vaID/:entId/:langId', component: CreateEntityComponent, canActivate: [AuthGuard] },
  { path: 'listing', component: EntityListingComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EntityRoutingModule { }

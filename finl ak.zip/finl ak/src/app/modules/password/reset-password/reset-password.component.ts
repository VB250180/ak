import { Component, Inject, OnDestroy } from '@angular/core';
import { NgModule, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { MustMatch } from 'src/app/shared/components/login/login.component';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig } from '@angular/material';
import { LocaleService } from 'src/app/core/services/locale/locale.service';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})

export class ResetPasswordComponent implements OnInit, OnDestroy {
  resetpassword: FormGroup;
  public userId: string;
  resetPasswordSubscription: Subscription;
  simulatorBaseUrl: string;
  hideoldpass = true;
  hidenewpass = true;
  hideconfirmpass = true;
  loginLocale: any;
  forgotpassLocale: any;
  resetpassLocale: any;
  resetsuccesslocale: any;

  loginFormDisplay = true;
  forgetPasswordForm = false;
  loginFormResetEmial = false;
  forgetPasswordSuccessForm = false;
  loginformGroup: FormGroup;

  upperVal = /(.*[A-Z].*)/;
  charVal = /[@#$%^&+=]/;
  submitted: boolean;
  loading: boolean;
  error: '';
  returnUrl: string;
  errorMsg: string;
  resetpasswordonsuccess = true;
  resetPasswordNewUser: boolean;
  tokenName: any;

  constructor(
    private fb: FormBuilder, private router: Router,
    private locale: LocaleService, private matDialog: MatDialog,
    private authenticationService: AuthenticationService
  ) {
    this.loginLocale = this.locale.loginPage;
    this.forgotpassLocale = this.locale.forgotPasswordPage;
    this.resetpassLocale = this.locale.resetPasswordPage;
    this.resetsuccesslocale = this.locale.resetPasswordSuccessPage;
    if (localStorage.getItem('currentUser') !== 'undefined' && localStorage.getItem('currentUser') !== undefined) {
      this.tokenName = JSON.parse(localStorage.getItem('currentUser')).jwToken;
    }
    console.log('token const', this.tokenName);
  }

  ngOnInit() {
    this.createResetPasswordForm();
  }

  createResetPasswordForm() {
    this.resetpassword = this.fb.group({
      oldpass: ['', [Validators.required]],
      newpass: ['', [Validators.required, Validators.minLength(8), Validators.pattern(/^(?=.{8,})(?=.*[A-Z])(?=.*[@#$%^&+=]).*$/)]],
      confirmpass: ['', [Validators.required, Validators.minLength(8), Validators.pattern(/^(?=.{8,})(?=.*[A-Z])(?=.*[@#$%^&+=]).*$/)]],
    }, {
      validator: MustMatch('newpass', 'confirmpass')
    });
  }

  // resetClose() {
  //   this.loginFormDisplay = true;
  //   this.loginFormResetEmial = false;
  //   this.forgetPasswordForm = false;
  //   //this.dialogRef.close(this.resetpassword.value)
  // }


  // method when reset button clicked
  ResetSucess() {
    this.resetpasswordonsuccess = false;
    console.log('reset dat', this.resetpassword.value);

    const dialogConfigReset = new MatDialogConfig();
    dialogConfigReset.disableClose = true;
    dialogConfigReset.width = '800px';
    dialogConfigReset.data = {
      primaryText: '',
      hasPrimaryBtn: true,
      primaryBtnText: 'Ok',
      popUpType: 'warn',
      hasCancelBtn: true
    };

    if (localStorage.getItem('currentUser') !== undefined) {
      this.resetPasswordSubscription = this.authenticationService.resetPassword(this.resetpassword.value, this.authenticationService.getCurrentUserId(), this.authenticationService.getCurrentUserName()).subscribe(res => {
        console.log('reset dat form', res);
        // res.errorBody != null ? dialogConfigReset.data.primaryText = 'Please enter correctly your old password' : dialogConfigReset.data.primaryText = 'Your password has been reset successfully'
        if (res.loginPojo) {
          console.log('localstorage details for a new user', localStorage);
          // this.resetPasswordNewUser = true;
          dialogConfigReset.data.primaryText = 'Your password has been reset successfully',
            dialogConfigReset.data.popUpType = 'success';
        } else if (res.errorBody !== null) {
          (res.errorBody.summary.indexOf('password') !== -1) ? dialogConfigReset.data.primaryText = 'Your new password must be different from your old password' : dialogConfigReset.data.primaryText = 'The Old Password you provided is incorrect. Please retry';
        }
        const modalDialog = this.matDialog.open(ModalComponent, dialogConfigReset);
        modalDialog.afterClosed().subscribe(data => {
          console.log(data, res.errorBody);
          res.errorBody !== null ? this.router.navigate(['/password/reset']) : this.logout();
          this.resetpasswordonsuccess = true;
        });
      });
    }
  }

  Cancel() {
    this.router.navigateByUrl('/dashboard/agent-list');
  }

  logout() {
    // this.authenticationService.logoutLocally();
    localStorage.removeItem('currentUser');
    this.authenticationService.currentUserSubject.next(null);
    this.router.navigateByUrl('/login');
  }

  ngOnDestroy() {
    if (this.resetPasswordSubscription) {
      this.resetPasswordSubscription.unsubscribe();
    }
  }
}

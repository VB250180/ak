import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResetPasswordComponent } from './reset-password.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, Component, TemplateRef } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable, BehaviorSubject, of } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialogConfig, MatDialog, MatDialogModule } from '@angular/material';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';


class AuthenticationServiceStub {
  public currentUserSubject = new BehaviorSubject(null);

  public logout() {
  }

  public getCurrentUserName() {
    return 'name';
  }

  public getCurrentUserId() {
    return '1';
  }

  public resetPassword({ newpass, oldpass }, userId, username) {
    return of({
      loginPojo: {
        userId: 0,
        username: 'skandha',
        email: 'string',
        phoneNumber: 'string',
        jwToken: 'string',
        password: oldpass,
        newPassword: newpass,
        confirmPassword: newpass,
        roleId: 0,
        roleName: 'string'
      }, errorBody: null
    });
  }
}


class PasswordServiceStub {
  constructor() { }

  public resetPassword({ newpass, oldpass }, userId, username): Observable<any> {
    return of({
      loginPojo: {
        userId: 0,
        username: 'skandha',
        email: 'string',
        phoneNumber: 'string',
        jwToken: 'string',
        password: oldpass,
        newPassword: newpass,
        confirmPassword: newpass,
        roleId: 0,
        roleName: 'string'
      }, errorBody: null
    });
  }

  public logout(): Observable<any> {
    if (name === 'skandha') {
      return of({
        loginPojo: {
          userId: 10,
          username: '',
          email: '',
          phoneNumber: '',
          jwToken: '',
          password: '',
          newPassword: '',
          confirmPassword: '',
          roleId: 0,
          roleName: ''
        }, errorBody: null
      });
    }
  }

}

class MatDialogStub {
  public open() {
    return {
      afterClosed: () => {
        return of(true);
      }
    };
  }
}



class MockRouter {
  navigateByUrl(url: string) { return url; }
}


describe('ResetPasswordComponent', () => {
  let component: ResetPasswordComponent;
  let fixture: ComponentFixture<ResetPasswordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ResetPasswordComponent],
      imports: [FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
        RouterTestingModule,
        MatDialogModule,
      ],
      providers: [
        { provide: Router, useClass: MockRouter },
        { provide: MatDialog, useClass: MatDialogStub },
        { provide: AuthenticationService, useClass: AuthenticationServiceStub }],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResetPasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    let storageDetails = {};
    const mockLocalStorage = {
      getItem: (key: string): string => {
        return key in storageDetails ? storageDetails[key] : null;
      },
      setItem: (key: string, value: string) => {
        storageDetails[key] = `${value}`;
      },
      removeItem: (key: string) => {
        delete storageDetails[key];
      },
      clear: () => {
        storageDetails = {};
      }
    };

    spyOn(localStorage, 'getItem').and.callFake(mockLocalStorage.getItem);
    spyOn(localStorage, 'setItem').and.callFake(mockLocalStorage.setItem);
    spyOn(localStorage, 'removeItem').and.callFake(mockLocalStorage.removeItem);
    spyOn(localStorage, 'clear').and.callFake(mockLocalStorage.clear);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call ngOninint', () => {
    const createPasswordForm = spyOn(component, 'createResetPasswordForm');
    component.ngOnInit();
    expect(createPasswordForm).toHaveBeenCalled();
  });

  it('should call createResetPasswordForm', () => {
    component.resetpassword.controls['oldpass'].setValue('admin');
    component.resetpassword.controls['newpass'].setValue('adminpass');
    component.resetpassword.controls['confirmpass'].setValue('adminpass');

    component.createResetPasswordForm();
    expect(component.resetpassword.controls['oldpass'].value).toBe('');
    expect(component.resetpassword.controls['newpass'].value).toBe('');
    expect(component.resetpassword.controls['confirmpass'].value).toBe('');
  });


  it('should call close reset success', () => {
    component.resetpasswordonsuccess = false;
    component.ResetSucess();

    expect(component.resetpasswordonsuccess).toBeTruthy();
  });

  it('should call method cancel', () => {
    const router = TestBed.get(Router);
    const spy = spyOn(router, 'navigateByUrl');
    component.Cancel();
    expect(spy).toHaveBeenCalledWith('/dashboard/agent-list');
  });


  it('on click on reset of password', () => {
    const router = TestBed.get(Router);
    const spy = spyOn(router, 'navigateByUrl');
    component.logout();
    expect(spy).toHaveBeenCalledWith('/login');
  });
});

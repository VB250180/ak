import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ForgotPasswordComponent } from './forgot-password.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, Component, TemplateRef } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable, BehaviorSubject, of } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialogConfig, MatDialog, MatDialogModule } from '@angular/material';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';

class PasswordServiceStub {
  currentUserSubject = new BehaviorSubject(true);

  constructor() { }

  public forgotPasswordLinkValidateToken(jwtokentovalidate): Observable<any> {
      return of({
        loginPojo: {
          userId: 0,
          username: 'string',
          email: 'string',
          phoneNumber: 'string',
          jwToken: 'jwtokentovalidate',
          password: 'string',
          newPassword: 'string',
          confirmPassword: 'string',
          roleId: 0,
          roleName: 'string'
        }, errorBody: null
      });
  }

  public resetPassword({newpassword, confirmpassword}, userId, username): Observable<any> {
    return of({
      loginPojo: {
        userId,
        username,
        email: 'sam@uniphore.com',
        phoneNumber: '9087987654',
        jwToken: 'string',
        password: '',
        newPassword: '',
        confirmPassword: '',
        roleId: 1,
        roleName: 'vaadmin'
      }, errorBody: null
    });
}

  public logout(): Observable<any> {
    if (name === 'skandha') {
      return of({
        loginPojo: {
          userId: 10,
          username: '',
          email: '',
          phoneNumber: '',
          jwToken: '',
          password: '',
          newPassword: '',
          confirmPassword: '',
          roleId: 0,
          roleName: ''
        }, errorBody: null
      });
    }
  }
}

class ActivatedRouteStub {
  params = {
    tokeId: 'name',
    get: (property) => {
      console.log('coming in get', this.params[property]);
      return this.params[property];
    }
  };
  public queryParams = new BehaviorSubject(this.params);
}

class MockRouter {
  public navigateByUrl(url: string) { return url; }

  public navigate(url: string) { return url; }

}

class MatDialogStub {
  public open() {
    return {
      afterClosed: () => {
        return of(true);
      }
    };
  }
}

describe('ForgotPasswordComponent', () => {
  let component: ForgotPasswordComponent;
  let fixture: ComponentFixture<ForgotPasswordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ForgotPasswordComponent],
      imports: [FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
        RouterTestingModule,
        MatDialogModule,
      ],
      providers: [
        { provide: AuthenticationService, useClass: PasswordServiceStub },
        { provide: Router, useClass: MockRouter },
        { provide: ActivatedRoute, useClass: ActivatedRouteStub },
        { provide: MatDialog, useClass: MatDialogStub }],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ForgotPasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    let storageDetails = {};
    const mockLocalStorage = {
      getItem: (currentUser) => {
        return currentUser in storageDetails ? storageDetails[currentUser] : null;
      },
      removeItem: (key: string) => {
        delete storageDetails[key];
      },
      clear: () => {
        storageDetails = {};
      }
    };

    spyOn(Storage.prototype, 'getItem').and.callFake(mockLocalStorage.getItem);
    spyOn(localStorage, 'removeItem').and.callFake(mockLocalStorage.removeItem);
    spyOn(localStorage, 'clear').and.callFake(mockLocalStorage.clear);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call ngOninint', () => {
    const createPasswordForm = spyOn(component, 'createForgotPasswordForm');
    component.ngOnInit();
    expect(createPasswordForm).toHaveBeenCalled();
  });

  it('should call createForgotPasswordForm', () => {
    component.forgotpassword.controls['newpass'].setValue('adminpass');
    component.forgotpassword.controls['confirmpass'].setValue('adminpass');

    component.createForgotPasswordForm();
    expect(component.forgotpassword.controls['newpass'].value).toBe('');
    expect(component.forgotpassword.controls['confirmpass'].value).toBe('');
  });


  it('should call close reset success', () => {
    component.resetpasswordonsuccess = false;
    component.Reset();
    expect(component.resetpasswordonsuccess).toBeFalsy();
  });

  // it('on click of cancel ,testcase', () => {
  //   let router = fixture.debugElement.injector.get(Router);
  //   const routerSpy = spyOn(router, 'navigateByUrl');
  //   component.Cancel();
  //   expect(routerSpy).toHaveBeenCalled();
  // });

});

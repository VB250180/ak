import { Component, Inject, OnDestroy } from '@angular/core';
import { NgModule, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { MustMatch } from 'src/app/shared/components/login/login.component';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig } from '@angular/material';
import { LocaleService } from 'src/app/core/services/locale/locale.service';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';
import { Subscription } from 'rxjs';


@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})

export class ForgotPasswordComponent implements OnInit, OnDestroy {
  forgotpassword: FormGroup;
  public userId: string;
  resetPasswordSubscription: Subscription;
  queryParmsSubscription: Subscription;
  forgotPasswordLinkValidateTokenSubscription: Subscription;
  simulatorBaseUrl: string;
  hideoldpass = true;
  hidenewpass = true;
  hideconfirmpass = true;
  loginLocale: any;
  forgotpassLocale: any;
  resetpassLocale: any;
  resetsuccesslocale: any;

  loginFormDisplay = true;
  forgetPasswordForm = false;
  loginFormResetEmial = false;
  forgetPasswordSuccessForm = false;
  loginformGroup: FormGroup;

  upperVal = /(.*[A-Z].*)/;
  charVal = /[@#$%^&+=]/;
  submitted: boolean;
  loading: boolean;
  error: '';
  returnUrl: string;
  errorMsg: string;
  resetpasswordonsuccess = true;
  resetPasswordNewUser = true;
  userName: any;
  setTokenErrStyle: boolean;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private locale: LocaleService,
    private matDialog: MatDialog,
    private authenticationService: AuthenticationService,
  ) {
    this.loginLocale = this.locale.loginPage;
    this.forgotpassLocale = this.locale.forgotPasswordPage;
    this.resetpassLocale = this.locale.resetPasswordPage;
    this.resetsuccesslocale = this.locale.resetPasswordSuccessPage;
  }

  ngOnInit() {
    let token: any;
    this.createForgotPasswordForm();
    this.queryParmsSubscription = this.activatedRoute.queryParams.subscribe(params => {
      console.log('params', params);
      token = params['tokenId'];
    });

    this.forgotPasswordLinkValidateTokenSubscription = this.authenticationService
      .forgotPasswordLinkValidateToken(token).subscribe(res => {
        console.log(res);
        if (res['loginPojo'] != null) {
          this.userId = res['loginPojo'].userId;
          this.userName = res['loginPojo'].userName;
        } else {
          this.resetpasswordonsuccess = false;
          this.openModalPopup('Your new password link is expired. Kindly click on ‘forgot password’ to generate a new link', 'err');
        }
      });
  }

  createForgotPasswordForm() {
    this.forgotpassword = this.fb.group({
      newpass: ['', [Validators.required, Validators.minLength(8), Validators.pattern(/^(?=.{8,})(?=.*[A-Z])(?=.*[@#$%^&+=]).*$/)]],
      confirmpass: ['', [Validators.required, Validators.minLength(8), Validators.pattern(/^(?=.{8,})(?=.*[A-Z])(?=.*[@#$%^&+=!*()]).*$/)]],
    }, {
      validator: MustMatch('newpass', 'confirmpass')
    });
  }

  // method when reset button clicked
  Reset() {
    this.resetpasswordonsuccess = false;
    console.log('reset dat', this.forgotpassword.value);
    this.resetPasswordSubscription = this.authenticationService.resetPassword(this.forgotpassword.value, this.userId, this.userName).subscribe(res => {
      console.log('forgot reset data dat form', res);
      if (res.loginPojo) {
        this.openModalPopup('Your password has been reset successfully', 'success');
      } else if (res.errorBody !== null) {
        (res.errorBody.summary.indexOf('password') !== -1) ? this.openModalPopup('Your new password must be different from your old password', 'err') : this.openModalPopup('We encountered an error, Please retry', 'err');
      }
    });
  }

  openModalPopup(msg, status) {
    const dialogConfigForgotPassword = new MatDialogConfig();
    dialogConfigForgotPassword.disableClose = true;
    dialogConfigForgotPassword.width = '800px';
    dialogConfigForgotPassword.data = {
      primaryText: msg,
      hasPrimaryBtn: true,
      primaryBtnText: 'Ok',
      popUpType: '',
      hasCancelBtn: true
    };
    dialogConfigForgotPassword.data.popUpType = (status === 'success') ? 'success' : 'warn';
    const modalDialog = this.matDialog.open(ModalComponent, dialogConfigForgotPassword);
    modalDialog.afterClosed().subscribe(data => {
      (status === 'err') ? window.location.reload() : this.router.navigate(['/login']);
      console.log(data);
    });
  }

  ngOnDestroy() {
    if (this.resetPasswordSubscription) {
      this.resetPasswordSubscription.unsubscribe();
    }
    if (this.forgotPasswordLinkValidateTokenSubscription) {
      this.forgotPasswordLinkValidateTokenSubscription.unsubscribe();
    }
    if (this.queryParmsSubscription) {
      this.queryParmsSubscription.unsubscribe();
    }
  }
}




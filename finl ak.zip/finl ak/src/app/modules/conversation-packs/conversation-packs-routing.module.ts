import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ConversationPacksComponent } from './conversation-packs.component';

const routes: Routes = [
  { path: 'packs', component: ConversationPacksComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConversationPacksRoutingModule { }

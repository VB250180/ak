import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConversationPacksRoutingModule } from './conversation-packs-routing.module';
import { NgxSpinnerModule } from 'ngx-spinner';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { NgSelectModule } from '@ng-select/ng-select';
import { ChartsModule } from 'ng2-charts';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import { ConversationPacksComponent } from './conversation-packs.component';
import { ConversationPacksHeaderComponent } from './conversation-packs-header/conversation-packs-header.component';
import { ConversationPacksListComponent } from './conversation-packs-list/conversation-packs-list.component';
import { ConversationPackIntentListComponent } from './conversation-pack-intent-list/conversation-pack-intent-list.component';
import { IntentConflictModalComponent } from './intent-conflict-modal/intent-conflict-modal.component';
import { MatDialogModule } from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
    ConversationPacksRoutingModule,
    NgxSpinnerModule,
    AccordionModule.forRoot(),
    ScrollingModule,
    InfiniteScrollModule,
    ReactiveFormsModule,
    FormsModule,
    NgSelectModule,
    ChartsModule,
    NgxChartsModule,
    MatDialogModule,
    NgxDaterangepickerMd,
    NgMultiSelectDropDownModule.forRoot()
  ],

  declarations: [
    ConversationPacksComponent,
    ConversationPacksHeaderComponent,
    ConversationPacksListComponent,
    ConversationPackIntentListComponent,
    IntentConflictModalComponent
  ],
  entryComponents: [IntentConflictModalComponent]
})
export class ConversationPacksModule { }

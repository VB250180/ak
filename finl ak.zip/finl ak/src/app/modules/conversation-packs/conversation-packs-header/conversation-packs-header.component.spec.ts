import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialog, MatDialogModule, MatDialogConfig } from '@angular/material';
import { BehaviorSubject, Observable } from 'rxjs';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ToastrModule } from 'ngx-toastr';
import { RouterTestingModule } from '@angular/router/testing';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';
import { ConversationPacksHeaderComponent } from './conversation-packs-header.component';
import { ConversationPacksService } from '../../../core/services/conversation-packs/conversation-packs.service';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { VirtualDetailsService } from 'src/app/core/services/va-details/virtual-agent-details.service';

class ConversationPacksServiceStub {
    initialSettingsChanged = new BehaviorSubject(null);

    public getConversationPacks(data) {
        return Observable.of({
            conversationPacks: [{
                cpId: 4,
                cpName: 'Health Care',
                intents: [
                    {
                        cp_intentId: 5,
                        intentName: 'Deductible',
                        intentType: 'GENERAL',
                        intentDescription: 'Deductible Desc'
                        , intentConflict: null,
                        languages: [{
                            cp_ilmId: 9,
                            cp_ilm_json: null,
                            language: {
                                langName: 'English',
                                langId: 1
                            },
                            channels: [{
                                cp_icmId: 21,
                                cp_icm_json: null,
                                channel: {
                                    virtualAgentRoleChannelMapId: null,
                                    channelId: 2,
                                    channelName: 'IVR',
                                    key: null
                                }
                            }]
                        }, {
                            cp_ilmId: 13,
                            cp_ilm_json: null,
                            language: {
                                langName: 'Spanish',
                                langId: 11
                            }, channels: [{
                                cp_icmId: 29,
                                cp_icm_json: null,
                                channel: {
                                    virtualAgentRoleChannelMapId: null,
                                    channelId: 2,
                                    channelName: 'IVR',
                                    key: null
                                }
                            }]
                        }]
                    },
                    {
                        cp_intentId: 6,
                        intentName: 'Benefit Details',
                        intentType: 'GENERAL',
                        intentDescription: 'Benefit Details Desc',
                        intentConflict: null,
                        languages: [{
                            cp_ilmId: 10,
                            cp_ilm_json: null,
                            language: {
                                langName: 'English',
                                langId: 1
                            },
                            channels: [{
                                cp_icmId: 22,
                                cp_icm_json: null,
                                channel: {
                                    virtualAgentRoleChannelMapId: null,
                                    channelId: 2,
                                    channelName: 'IVR',
                                    key: null
                                }
                            }]
                        },
                        {
                            cp_ilmId: 14,
                            cp_ilm_json: null,
                            language: {
                                langName: 'Spanish',
                                langId: 11
                            },
                            channels: [{
                                cp_icmId: 30,
                                cp_icm_json: null,
                                channel: {
                                    virtualAgentRoleChannelMapId: null,
                                    channelId: 2,
                                    channelName: 'IVR',
                                    key: null
                                }
                            }]
                        }]
                    },
                    {
                        cp_intentId: 7,
                        intentName: 'Claim',
                        intentType: 'GENERAL',
                        intentDescription: 'Claim Desc',
                        intentConflict: null,
                        languages: [{
                            cp_ilmId: 11,
                            cp_ilm_json: null,
                            language: {
                                langName: 'English',
                                langId: 1
                            },
                            channels: [{
                                cp_icmId: 23,
                                cp_icm_json: null,
                                channel: {
                                    virtualAgentRoleChannelMapId: null,
                                    channelId: 2,
                                    channelName: 'IVR',
                                    key: null
                                }
                            }]
                        },
                        {
                            cp_ilmId: 15,
                            cp_ilm_json: null,
                            language: {
                                langName: 'Spanish',
                                langId: 11
                            },
                            channels: [{
                                cp_icmId: 31,
                                cp_icm_json: null,
                                channel: {
                                    virtualAgentRoleChannelMapId: null,
                                    channelId: 2,
                                    channelName: 'IVR',
                                    key: null
                                }
                            }]
                        }]
                    }],
                languages: [{
                    langName: 'English',
                    langId: 1
                },
                {
                    langName: 'Spanish',
                    langId: 11
                }],
                channels: [{
                    virtualAgentRoleChannelMapId: null,
                    channelId: 2,
                    channelName: 'IVR',
                    key: null
                }]
            },
            {
                cpId: 5,
                cpName: 'Insurance',
                intents: [
                    {
                        cp_intentId: 12,
                        intentName: 'Fund Value',
                        intentType: 'GENERAL',
                        intentDescription: 'Fund Value Desc',
                        intentConflict: null,
                        languages: [{
                            cp_ilmId: 23,
                            cp_ilm_json: null,
                            language: {
                                langName: 'English',
                                langId: 1
                            },
                            channels: [{
                                cp_icmId: 49,
                                cp_icm_json: null,
                                channel: {
                                    virtualAgentRoleChannelMapId: null,
                                    channelId: 2,
                                    channelName: 'IVR',
                                    key: null
                                }
                            }]
                        },
                        {
                            cp_ilmId: 27,
                            cp_ilm_json: null,
                            language: {
                                langName: 'Spanish',
                                langId: 11
                            },
                            channels: [{
                                cp_icmId: 57,
                                cp_icm_json: null,
                                channel: {
                                    virtualAgentRoleChannelMapId: null,
                                    channelId: 2,
                                    channelName: 'IVR', key: null
                                }
                            }]
                        }]
                    },
                    {
                        cp_intentId: 13,
                        intentName: 'Policy status',
                        intentType: 'GENERAL',
                        intentDescription: 'Policy status Desc',
                        intentConflict: null,
                        languages: [{
                            cp_ilmId: 24,
                            cp_ilm_json: null,
                            language: {
                                langName: 'English',
                                langId: 1
                            },
                            channels: [{
                                cp_icmId: 50,
                                cp_icm_json: null,
                                channel: {
                                    virtualAgentRoleChannelMapId: null,
                                    channelId: 2,
                                    channelName: 'IVR',
                                    key: null
                                }
                            }]
                        },
                        {
                            cp_ilmId: 28,
                            cp_ilm_json: null,
                            language: {
                                langName: 'Spanish',
                                langId: 11
                            },
                            channels: [{
                                cp_icmId: 58,
                                cp_icm_json: null,
                                channel: {
                                    virtualAgentRoleChannelMapId: null,
                                    channelId: 2,
                                    channelName: 'IVR',
                                    key: null
                                }
                            }]
                        }]
                    },
                ],
                languages: [{
                    langName: 'English',
                    langId: 1
                },
                {
                    langName: 'Spanish',
                    langId: 11
                }],
                channels: [{
                    virtualAgentRoleChannelMapId: null,
                    channelId: 2,
                    channelName: 'IVR',
                    key: null
                }]
            }]
        });
    }
}

class VirtualDetailsServiceStub {
    requiredDataLoaded = new BehaviorSubject(true);

    public getVirtualAgents() {
        return [
            { vrmName: 'Agent1', vrmIsLive: false },
            { vrmName: 'Agent2', vrmIsLive: true },
            { vrmName: 'Agent3', vrmIsLive: false },
        ];
    }

    public getChannelsByVrmId(vrmId) {
        if (vrmId === 1) {
            return [{ channelId: 1, channelName: 'WEB' }, { channelId: 2, channelName: 'IVR' }];
        } else {
            return [];
        }
    }

    public getLanguagesByVrmId(vrmId) {
        if (vrmId === 1) {
            return [{ langId: 1, langName: 'WEB' }, { langId: 1, langName: 'WEB' }];
        } else {
            return [];
        }
    }
}

describe('ConversationPacksHeaderComponent', () => {
    let component: ConversationPacksHeaderComponent;
    let fixture: ComponentFixture<ConversationPacksHeaderComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ConversationPacksHeaderComponent],
            providers: [
                { provide: ConversationPacksService, useClass: ConversationPacksServiceStub },
                { provide: VirtualDetailsService, useClass: VirtualDetailsServiceStub }
            ],
            imports: [
                FormsModule,
                ReactiveFormsModule,
                BrowserAnimationsModule,
                HttpClientTestingModule,
                NgxSpinnerModule,
                ToastrModule.forRoot(),
                MatDialogModule,
                RouterTestingModule,
                NgSelectModule,
                NgMultiSelectDropDownModule
            ],
            schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ConversationPacksHeaderComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('ngOnInit should call onInitialSettingChanged and set pageNo to 1', () => {
        const initialSettingsSpy = spyOn(component, 'initialSettings');
        component.vaDetails = [];

        component.ngOnInit();

        expect(component.vaDetails.length).toEqual(2);
        expect(component.conversationPacksForm.controls['vaAgent'].value).toEqual({ vrmName: 'Agent1', vrmIsLive: false, vaInitials: 'A' });
        expect(initialSettingsSpy).toHaveBeenCalled();
    });

    it('initialSettings should set channel and language and emit those details', () => {
        const service = TestBed.get(ConversationPacksService);
        let result;
        service.initialSettingsChanged.subscribe(data => {
            result = data;
        });
        component.vaDetails = [{ vrmId: 1 }];

        component.initialSettings();

        expect(component.channels.length).toEqual(2);
        expect(component.languages.length).toEqual(2);
        expect(result).toBeTruthy();
    });

    it('initialSettings should not set channel and language and emit false', () => {
        let result;
        const service = TestBed.get(ConversationPacksService);
        service.initialSettingsChanged.subscribe(data => {
            result = data;
        });
        component.vaDetails = [{ vrmId: 2 }];

        component.initialSettings();

        expect(component.channels.length).toEqual(0);
        expect(component.languages.length).toEqual(0);
        expect(result).toBeFalsy();
    });

    it('onVAAgentSelected should reset vaChannels and vaLanguages and emit false', () => {
        let result;
        const service = TestBed.get(ConversationPacksService);
        service.initialSettingsChanged.subscribe(data => {
            result = data;
        });
        component.vaDetails = [{ vrmId: 2 }];
        const event = { vrmId: 1 };
        component.conversationPacksForm.controls['vaChannels'].setValue([
            { channelId: 1, channelName: 'WEB' }, { channelId: 2, channelName: 'IVR' }]);
        component.conversationPacksForm.controls['vaLanguages'].setValue([
            { langId: 1, langName: 'WEB' }, { langId: 1, langName: 'WEB' }]);

        component.onVAAgentSelected(event);

        expect(component.conversationPacksForm.controls['vaChannels'].value).toEqual(null);
        expect(component.conversationPacksForm.controls['vaLanguages'].value).toEqual(null);
        expect(result).toBeFalsy();
    });

    it('onSelectAll should reset vaChannels and vaLanguages and emit false', () => {
        let result;
        const service = TestBed.get(ConversationPacksService);
        service.initialSettingsChanged.subscribe(data => {
            console.log('$$$$$', data);
            result = data;
        });
        const event = { vrmId: 1 };
        const controlName = 'vaAgent';
        component.conversationPacksForm.controls['vaChannels'].setValue([
            { channelId: 1, channelName: 'WEB' }, { channelId: 2, channelName: 'IVR' }]);
        component.conversationPacksForm.controls['vaLanguages'].setValue([
            { langId: 1, langName: 'WEB' }, { langId: 1, langName: 'WEB' }]);

        component.onSelectAll(event, controlName);

        expect(result).toBeTruthy();
    });

    it('onSelectAll should reset vaChannels and vaLanguages and emit false', () => {
        let result;
        const service = TestBed.get(ConversationPacksService);
        service.initialSettingsChanged.subscribe(data => {
            console.log('$$$$$', data);
            result = data;
        });
        const event = { vrmId: 1 };
        const controlName = 'vaAgent';

        component.onSelectAll(event, controlName);

        expect(result).toBeFalsy();
    });

    it('onChannelAndLanguageSelected should emit selected value', () => {
        let result;
        const service = TestBed.get(ConversationPacksService);
        service.initialSettingsChanged.subscribe(data => {
            console.log('$$$$$', data);
            result = data;
        });
        const event = { vrmId: 1 };
        const controlName = 'vaAgent';
        component.conversationPacksForm.controls['vaChannels'].setValue(event);
        component.conversationPacksForm.controls['vaChannels'].setValue([
            { channelId: 1, channelName: 'WEB' }, { channelId: 2, channelName: 'IVR' }]);
        component.conversationPacksForm.controls['vaLanguages'].setValue([
            { langId: 1, langName: 'WEB' }, { langId: 1, langName: 'WEB' }]);

        component.onChannelAndLanguageSelected();

        expect(result).toBeTruthy();
    });

    it('onChannelAndLanguageSelected should emit false', () => {
        let result;
        const service = TestBed.get(ConversationPacksService);
        service.initialSettingsChanged.subscribe(data => {
            console.log('$$$$$', data);
            result = data;
        });
        const event = { vrmId: 1 };
        const controlName = 'vaAgent';
        component.conversationPacksForm.controls['vaChannels'].setValue(event);
        component.conversationPacksForm.controls['vaChannels'].setValue([
            { channelId: 1, channelName: 'WEB' }, { channelId: 2, channelName: 'IVR' }]);

        component.onChannelAndLanguageSelected();

        expect(result).toBeFalsy();
    });
});

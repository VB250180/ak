import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Component, OnInit, ViewChild, ElementRef, AfterViewChecked, OnDestroy } from '@angular/core';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';
import { ConversationPacksService } from '../../core/services/conversation-packs/conversation-packs.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-conversation-packs',
  templateUrl: './conversation-packs.component.html',
  styleUrls: ['./conversation-packs.component.scss']
})
export class ConversationPacksComponent implements OnInit, OnDestroy {

  showIntentList = false;
  selectedVAAgent;
  conversationPackSearchForm: FormGroup;
  isVASelected = false;
  initialSettingsDone = false;
  searchValue: string;
  selectedVirtualAgent;
  conversationPacksList = [];
  vaDetails;
  pageNo = 1;
  vrmId;
  conversationPack;
  getConversationPacksSubscription: Subscription;
  initialSettingsChangedSubscription: Subscription;

  dropdownSettings = {
    singleSelection: false,
    idField: 'name',
    textField: 'name',
    enableCheckAll: true,
    selectAllText: 'All',
    unSelectAllText: 'Unselect All',
    allowSearchFilter: false,
    limitSelection: -1,
    clearSearchFilter: true,
    maxHeight: 197,
    itemsShowLimit: 1,
    // noDataAvailablePlaceholderText: 'No data available',
    // closeDropDownOnSelection: true,
    showSelectedItemsAtTop: false,
    defaultOpen: false
  };

  conversationPacksForm: FormGroup;

  constructor(
    private matDialog: MatDialog,
    private conversationPacksService: ConversationPacksService,
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit() {
    this.initialSettingsChangedSubscription = this.conversationPacksService
      .initialSettingsChanged.subscribe(response => {
        console.log('initial settings changed? ', response);
        this.onInitialSettingChanged(response);
        this.pageNo = 1;
      });
    this.conversationPacksForm = new FormGroup({
      vaAgent: new FormControl('', Validators.required),
      vaChannels: new FormControl('', Validators.required),
      vaLanguages: new FormControl('', Validators.required)
    });
    this.conversationPackSearchForm = new FormGroup({
      search: new FormControl('')
    });
    this.conversationPacksForm.controls['vaChannels'].disable();
    this.conversationPacksForm.controls['vaLanguages'].disable();
    // this.getConversationPacks();
  }

  onInitialSettingChanged(event) {
    if (event) {
      this.initialSettingsDone = true;
      this.showIntentList = false;
      this.vrmId = event.vaAgent.vrmId;
      this.selectedVirtualAgent = event;
      console.log(event);
      this.conversationPacksList = [];
      this.getConversationPacks();
    } else {
      this.initialSettingsDone = false;
      this.showIntentList = false;
      this.selectedVirtualAgent = undefined;
      this.conversationPacksList = [];
      console.log(event);
    }
  }

  getConversationPacks() {
    this.spinner.show();
    const channelList = [];
    const langList = [];
    this.selectedVirtualAgent.vaChannels.forEach(channel => {
      channelList.push(channel.channelId);
    });
    this.selectedVirtualAgent.vaLanguages.forEach(lang => {
      langList.push(lang.langId);
    });
    const data = {
      channels: channelList,
      languages: langList,
      cpName: this.searchValue ? this.searchValue : '',
      vaRoleId: this.selectedVirtualAgent.vaAgent.vrmId,
      // channels: [1, 2, 3],
      // languages: [1, 2],
      pageNo: this.pageNo// 1
    };
    this.getConversationPacksSubscription = this.conversationPacksService
      .getConversationPacks(data).subscribe(response => {
        if (this.searchValue && this.searchValue.length > 0 && this.pageNo === 1) {
          this.conversationPacksList = response['conversationPacks'];
        } else if (this.conversationPacksList.length > 0 && this.pageNo === 1) {
          this.conversationPacksList = response['conversationPacks'];
        } else {
          this.conversationPacksList = [...this.conversationPacksList, ...response['conversationPacks']];
        }
        this.spinner.hide();
      });
  }

  onCpSearch(event) {
    console.log('getting the event also', event);
    this.pageNo = 1;
    this.searchValue = event;
    this.getConversationPacks();
  }

  onScroll(pageNo) {
    console.log(pageNo, 'pageNo');
    this.pageNo = pageNo;
    this.getConversationPacks();
    console.log(this.conversationPacksList);
  }

  onConversationPackSelected(conversationPack) {
    console.log('conversationPack selected', conversationPack);
    this.showIntentList = true;
    this.conversationPack = conversationPack;
  }

  importSelected() {
    console.log('import selected');
    const dialogConfigImport = new MatDialogConfig();
    dialogConfigImport.disableClose = true;
    dialogConfigImport.width = '800px';
    dialogConfigImport.data = {
      primaryText: 'These are the intents that you have chosen to import',
      hasPrimaryBtn: true,
      primaryBtnText: 'Ok',
      popUpType: 'save',
      hasCancelBtn: true,
      secondaryBtnText: 'Cancel',
      suggestedText: 'Intent1 , Intent2, Intent3'
    };

    const modalDialog = this.matDialog.open(ModalComponent, dialogConfigImport);
    modalDialog.afterClosed().subscribe(data => {
      console.log('import', data);
      if (data) {
        this.openOtherModal();
      }
    });
  }

  openOtherModal() {
    const dialogConfigImport = new MatDialogConfig();
    dialogConfigImport.disableClose = true;
    dialogConfigImport.width = '800px';
    dialogConfigImport.data = {
      primaryText: 'Please wait while we import your intents',
      hasPrimaryBtn: true,
      primaryBtnText: 'Ok',
      // popUpType: 'save',
      // hasCancelBtn: true,
      // secondaryBtnText: 'Cancel',
    };
    const modalDialog = this.matDialog.open(ModalComponent, dialogConfigImport);
    modalDialog.afterClosed().subscribe(data => {
      console.log('import', data);
      //  data == true ? this.openOtherModal() : ''
    });
  }

  ngOnDestroy() {
    if (this.getConversationPacksSubscription) {
      this.getConversationPacksSubscription.unsubscribe();
    }
    if (this.initialSettingsChangedSubscription) {
      this.initialSettingsChangedSubscription.unsubscribe();
    }
  }
}

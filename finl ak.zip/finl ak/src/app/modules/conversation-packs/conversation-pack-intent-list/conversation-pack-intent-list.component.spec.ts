import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConversationPackIntentListComponent } from './conversation-pack-intent-list.component';
import { ConversationPacksService } from '../../../core/services/conversation-packs/conversation-packs.service';
import { BehaviorSubject, of, throwError } from 'rxjs';
import { FormsModule, ReactiveFormsModule, FormControl } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MatDialogModule, MatDialog } from '@angular/material';
import { Router } from '@angular/router';

class ConversationPacksServiceStub {

  initialSettingsChanged = new BehaviorSubject({
    vaAgent: { vrmName: 'Name', vrmDescription: 'Description' },
    vaChannels: [{ channelName: 'Name' }],
    vaLanguages: [{ langName: 'Name' }]
  });

  public importConversationPack(vrmId, reqData) {
    if (vrmId === 1 || vrmId === 2) {
      return of({});
    } else {
      return throwError('Error Exists!');
    }
  }

  public checkIntentConflict(vrmId, reqData) {
    if (vrmId === 1) {
      return of({
        data: 'Intents Conflicted',
        intents: [{ intentName: 'Hello Intent' }]
      });
    } else {
      return of({
        data: 'Intents are not Conflicated'
      });
    }
  }
}

class MatDialogStub {
  public open(template, data) {
    // this.afterClosed(true);
    if (data.data.hasOwnProperty('formData') || data.data.hasPrimaryBtn) {
      return {
        afterClosed: () => {
          return of(true);
        }
      };
    } else {
      return {
        close: () => {
          return true;
        }
      };
    }
  }
}

describe('ConversationPackIntentListComponent', () => {
  let component: ConversationPackIntentListComponent;
  let fixture: ComponentFixture<ConversationPackIntentListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ConversationPackIntentListComponent],
      providers: [
        { provide: ConversationPacksService, useClass: ConversationPacksServiceStub },
        { provide: MatDialog, useClass: MatDialogStub },
      ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        RouterTestingModule,
        HttpClientTestingModule,
        MatDialogModule
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConversationPackIntentListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('ngOnInit should initialize selectedVA', () => {
    const data = {
      vaAgent: { vrmName: 'Name', vrmDescription: 'Description' },
      vaChannels: [{ channelName: 'Name' }],
      vaLanguages: [{ langName: 'Name' }]
    };

    component.ngOnInit();

    expect(component.selectedVA).toEqual(data);
  });

  it('ngOnChanges should call tableDataGen method', () => {
    const tableDataGenSpy = spyOn(component, 'tableDataGen');
    const changes = {
      conversationPack: {
        firstChange: false
      }
    };

    component.ngOnChanges(changes);

    expect(component.showImportSelectedBtn).toBeFalsy();
    expect(component.intentListResponse).toEqual([]);
    expect(component.intentConflictList).toEqual([]);
    expect(tableDataGenSpy).toHaveBeenCalled();
  });

  it('ngOnChanges should call tableDataGen method', () => {
    const tableDataGenSpy = spyOn(component, 'tableDataGen');
    component.showImportSelectedBtn = true;
    const changes = {
      conversationPack: {
        firstChange: true
      }
    };

    component.ngOnChanges(changes);

    expect(component.showImportSelectedBtn).toBeTruthy();
    expect(tableDataGenSpy).toHaveBeenCalledTimes(0);
  });

  it('tableDataGen should call tableDataGen method', () => {
    component.conversationPack = {
      intents: [{
        cp_intentId: 1,
        intentName: 'name1',
        intentConflict: null,
        languages: [
          { language: { langName: 'English' }, channels: [{ chName: 'WEB' }] },
          { language: { langName: 'Spanish' }, channels: [{ chName: 'IVR' }] }
        ]
      },
      {
        cp_intentId: 2,
        intentName: 'name2',
        intentConflict: null,
        languages: [{ language: { langName: 'English' }, channels: [{ chName: 'IVR' }] }]
      }]
    };

    component.tableDataGen();

    expect(component.intentListResponse.length).toEqual(3);
  });

  it('onSelectAllClicked should set showImportSelectedBtn to true', () => {
    const event = {
      target: {
        checked: true
      }
    };
    component.intentListForm.addControl('a', new FormControl());
    component.intentListForm.controls['a'].setValue(false);

    component.onSelectAllClicked(event);

    expect(component.showImportSelectedBtn).toBeTruthy();
    expect(component.intentListForm.get('a').value).toBeTruthy();
  });

  it('onSelectOrDeSelect should set control selectAll to false', () => {
    const event = {
      target: {
        checked: false
      }
    };
    component.intentListForm.addControl('a', new FormControl());
    component.intentListForm.controls['a'].setValue(true);

    component.onSelectAllClicked(event);

    expect(component.showImportSelectedBtn).toBeFalsy();
    expect(component.intentListForm.get('a').value).toBeFalsy();
  });

  it('onSelectOrDeSelect should set control selectAll to false', () => {
    const event = {
      target: {
        checked: true
      }
    };
    const controlName = 'name1';
    component.intentListForm.addControl('name1', new FormControl());
    component.intentListForm.addControl('selectAll', new FormControl());
    component.intentListForm.addControl('name2', new FormControl());

    component.onSelectOrDeSelect(event, controlName);

    expect(component.showImportSelectedBtn).toBeTruthy();
    expect(component.intentListForm.get('name1').value).toBeTruthy();
    expect(component.intentListForm.get('selectAll').value).toBeFalsy();
  });

  it('onSelectOrDeSelect should set showImportSelectedBtn to true', () => {
    const event = {
      target: {
        checked: true
      }
    };
    const controlName = 'name1';
    component.intentListForm.addControl('name1', new FormControl());
    component.intentListForm.addControl('selectAll', new FormControl());
    component.intentListForm.addControl('name2', new FormControl());
    component.intentListForm.controls['name1'].setValue(false);
    component.intentListForm.controls['name2'].setValue(true);

    component.onSelectOrDeSelect(event, controlName);

    expect(component.showImportSelectedBtn).toBeTruthy();
    expect(component.intentListForm.get('name1').value).toBeTruthy();
    expect(component.intentListForm.get('selectAll').value).toBeTruthy();
  });

  it('onSelectOrDeSelect should set showImportSelectedBtn to false', () => {
    const event = {
      target: {
        checked: false
      }
    };
    const controlName = 'name1';
    component.intentListForm.addControl('name1', new FormControl());
    component.intentListForm.addControl('selectAll', new FormControl());
    component.intentListForm.addControl('name2', new FormControl());
    component.intentListForm.controls['name1'].setValue(true);
    component.intentListForm.controls['name2'].setValue(false);

    component.onSelectOrDeSelect(event, controlName);

    expect(component.intentListForm.get('name1').value).toBeFalsy();
    expect(component.showImportSelectedBtn).toBeFalsy();
  });

  it('onSelectOrDeSelect should set showImportSelectedBtn to true', () => {
    const event = {
      target: {
        checked: false
      }
    };
    const controlName = 'name1';
    component.intentListForm.addControl('name1', new FormControl());
    component.intentListForm.addControl('selectAll', new FormControl());
    component.intentListForm.addControl('name2', new FormControl());
    component.intentListForm.controls['name1'].setValue(true);
    component.intentListForm.controls['name2'].setValue(true);

    component.onSelectOrDeSelect(event, controlName);

    expect(component.intentListForm.get('name1').value).toBeFalsy();
    expect(component.showImportSelectedBtn).toBeTruthy();
  });

  it('importSelected should call openImportSuccessModal method', () => {
    const openImportSuccessModalSpy = spyOn(component, 'openImportSuccessModal');
    component.vrmId = 2;
    component.intentListForm.addControl('1', new FormControl());
    component.intentListForm.addControl('2', new FormControl());
    component.intentListForm.addControl('3', new FormControl());
    component.intentListForm.controls['1'].setValue(true);
    component.intentListForm.controls['3'].setValue(true);

    component.intentListResponse = [{ id: 1, intentId: 1 }, { id: 2, intentId: 1 }, { id: 3, intentId: 2 }];
    component.conversationPack = {
      intents: [{
        cp_intentId: 1,
        intentName: 'name1',
        intentConflict: null,
        languages: [
          { language: { langName: 'English' }, channels: [{ chName: 'WEB' }] },
          { language: { langName: 'Spanish' }, channels: [{ chName: 'IVR' }] }
        ]
      },
      {
        cp_intentId: 2,
        intentName: 'name2',
        intentConflict: null,
        languages: [{ language: { langName: 'English' }, channels: [{ chName: 'IVR' }] }]
      }]
    };

    component.importSelected();

    expect(openImportSuccessModalSpy).toHaveBeenCalled();
  });

  it('importSelected should call importConversations method', () => {
    const importConversationsSpy = spyOn(component, 'importConversations');
    component.vrmId = 1;
    component.intentListForm.addControl('1', new FormControl());
    component.intentListForm.addControl('2', new FormControl());
    component.intentListForm.addControl('3', new FormControl());
    component.intentListForm.controls['1'].setValue(true);
    component.intentListForm.controls['3'].setValue(true);

    component.intentListResponse = [{ id: 1, intentId: 1, intentName: 'Hello Intent' }, { id: 2, intentId: 1 }, { id: 3, intentId: 2 }];
    component.conversationPack = {
      intents: [{
        cp_intentId: 1,
        intentName: 'name1',
        intentConflict: null,
        languages: [
          { language: { langName: 'English' }, channels: [{ chName: 'WEB' }] },
          { language: { langName: 'Spanish' }, channels: [{ chName: 'IVR' }] }
        ]
      },
      {
        cp_intentId: 2,
        intentName: 'name2',
        intentConflict: null,
        languages: [{ language: { langName: 'English' }, channels: [{ chName: 'IVR' }] }]
      }]
    };

    component.importSelected();

    expect(component.intentConflictList.length).toEqual(1);
    expect(importConversationsSpy).toHaveBeenCalled();
  });

  it('prepareReqData should return reqData with two intent', () => {
    const importConversationsSpy = spyOn(component, 'importConversations');
    component.vrmId = 1;
    component.intentListForm.addControl('1', new FormControl());
    component.intentListForm.addControl('2', new FormControl());
    component.intentListForm.addControl('3', new FormControl());
    component.intentListForm.controls['1'].setValue(true);
    component.intentListForm.controls['3'].setValue(true);

    component.intentListResponse = [{ id: 1, intentId: 1, intentName: 'Hello Intent' }, { id: 2, intentId: 1 }, { id: 3, intentId: 2 }];
    component.conversationPack = {
      intents: [{
        cp_intentId: 1,
        intentName: 'name1',
        intentConflict: null,
        languages: [
          { language: { langName: 'English' }, channels: [{ chName: 'WEB' }] },
          { language: { langName: 'Spanish' }, channels: [{ chName: 'IVR' }] }
        ]
      },
      {
        cp_intentId: 2,
        intentName: 'name2',
        intentConflict: null,
        languages: [{ language: { langName: 'English' }, channels: [{ chName: 'IVR' }] }]
      }]
    };

    const result = component.prepareReqData();

    expect(result.intents.length).toEqual(2);
  });

  it('prepareReqData should return reqData with one intent only', () => {
    const importConversationsSpy = spyOn(component, 'importConversations');
    component.vrmId = 1;
    component.intentListForm.addControl('1', new FormControl());
    component.intentListForm.addControl('2', new FormControl());
    component.intentListForm.addControl('3', new FormControl());
    component.intentListForm.controls['1'].setValue(false);
    component.intentListForm.controls['3'].setValue(true);

    component.intentListResponse = [{ id: 1, intentId: 1, intentName: 'Hello Intent' }, { id: 2, intentId: 1 }, { id: 3, intentId: 2 }];
    component.conversationPack = {
      intents: [{
        cp_intentId: 1,
        intentName: 'name1',
        intentConflict: null,
        languages: [
          { language: { langName: 'English' }, channels: [{ chName: 'WEB' }] },
          { language: { langName: 'Spanish' }, channels: [{ chName: 'IVR' }] }
        ]
      },
      {
        cp_intentId: 2,
        intentName: 'name2',
        intentConflict: null,
        languages: [{ language: { langName: 'English' }, channels: [{ chName: 'IVR' }] }]
      }]
    };

    const result = component.prepareReqData();

    expect(result.intents.length).toEqual(1);
  });

  it('prepareReqData should not return reqData', () => {
    const importConversationsSpy = spyOn(component, 'importConversations');
    component.vrmId = 1;
    component.intentListForm.addControl('1', new FormControl());
    component.intentListForm.addControl('2', new FormControl());
    component.intentListForm.addControl('3', new FormControl());
    component.intentListForm.controls['1'].setValue(false);
    component.intentListForm.controls['3'].setValue(true);

    component.intentListResponse = [{ id: 1, intentId: 1, intentName: 'Hello Intent' }, { id: 2, intentId: 1 }, { id: 3, intentId: 2 }];
    component.conversationPack = {};

    const result = component.prepareReqData();

    expect(result).toEqual(undefined);
  });

  it('prepareReqData should return reqData intentConflict true', () => {
    const importConversationsSpy = spyOn(component, 'importConversations');
    component.vrmId = 1;
    component.intentListForm.addControl('1', new FormControl());
    component.intentListForm.addControl('2', new FormControl());
    component.intentListForm.addControl('3', new FormControl());
    component.intentListForm.controls['1'].setValue(true);
    component.intentListForm.controls['3'].setValue(true);

    component.intentListResponse = [{ id: 1, intentId: 1, intentName: 'Hello Intent' }, { id: 2, intentId: 1 }, { id: 3, intentId: 2 }];
    component.intentConflictList = [{ id: 1, intentId: 1, intentConflict: true }];
    component.conversationPack = {
      intents: [{
        cp_intentId: 1,
        intentName: 'name1',
        intentConflict: null,
        languages: [
          { language: { langName: 'English' }, channels: [{ chName: 'WEB' }] },
          { language: { langName: 'Spanish' }, channels: [{ chName: 'IVR' }] }
        ]
      },
      {
        cp_intentId: 2,
        intentName: 'name2',
        intentConflict: null,
        languages: [{ language: { langName: 'English' }, channels: [{ chName: 'IVR' }] }]
      }]
    };

    const result = component.prepareReqData();

    expect(result.intents.length).toEqual(2);
    expect(result.intents[0].intentConflict).toBeTruthy();
  });

  it('prepareReqData should call openImportSuccessModal', () => {
    const prepareReqDataSpy = spyOn(component, 'prepareReqData');
    const openImportSuccessModalSpy = spyOn(component, 'openImportSuccessModal');
    component.vrmId = 1;

    component.importConversations();

    expect(prepareReqDataSpy).toHaveBeenCalled();
    expect(openImportSuccessModalSpy).toHaveBeenCalled();
  });

  it('prepareReqData should not call openImportSuccessModal', () => {
    const prepareReqDataSpy = spyOn(component, 'prepareReqData');
    const openImportSuccessModalSpy = spyOn(component, 'openImportSuccessModal');
    component.vrmId = 3;

    component.importConversations();

    expect(prepareReqDataSpy).toHaveBeenCalled();
    expect(openImportSuccessModalSpy).toHaveBeenCalledTimes(0);
  });

  it('openOtherModal should return modal reference', () => {
    const result = component.openOtherModal();

    expect(result).toBeTruthy();
  });

  it('openImportSuccessModal should navigate to intent list page', () => {
    const spy = spyOn(TestBed.get(Router), 'navigate');

    component.openImportSuccessModal();

    expect(spy).toHaveBeenCalled();
  });

  it('onSearchIntentList should set intentListResponse according to search value and set selectAll control to false', () => {
    component.allIntents = [{ id: 1, intentName: 'Hello Intent' }, { id: 2, intentName: 'Hello Intent1' },
    { id: 3, intentName: 'no Intent1' }, { id: 4, intentName: 'no Intent2' }];

    component.intentListResponse = [{ id: 1, intentName: 'Hello Intent' }, { id: 2, intentName: 'Hello Intent1' },
    { id: 3, intentName: 'no Intent1' }, { id: 4, intentName: 'no Intent2' }];

    const event = 'Hello INTENT';

    component.onSearchIntentList(event);

    expect(component.intentListResponse.length).toEqual(2);
    expect(component.intentListForm.get('selectAll').value).toBeFalsy();
  });

  it('onSearchIntentList should set intentListResponse according to search value and set selectAll control to true', () => {
    component.allIntents = [{ id: 1, intentName: 'Hello Intent' }, { id: 2, intentName: 'Hello Intent1' }];
    component.intentListResponse = [{ id: 1, intentName: 'Hello Intent' }, { id: 2, intentName: 'Hello Intent1' }];
    component.intentListForm.addControl('1', new FormControl());
    component.intentListForm.addControl('2', new FormControl());
    component.intentListForm.controls['1'].setValue(true);
    component.intentListForm.controls['2'].setValue(true);

    const event = 'HelloINTENT';

    component.onSearchIntentList(event);

    expect(component.intentListResponse.length).toEqual(2);
    expect(component.intentListForm.get('selectAll').value).toBeTruthy();
  });
});

import { Component, OnInit, Input, Output, EventEmitter, OnChanges, OnDestroy } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { ConversationPacksService } from '../../../core/services/conversation-packs/conversation-packs.service';
import { IntentConflictModalComponent } from './../intent-conflict-modal/intent-conflict-modal.component';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-conversation-pack-intent-list',
  templateUrl: './conversation-pack-intent-list.component.html',
  styleUrls: ['./conversation-pack-intent-list.component.scss']
})
export class ConversationPackIntentListComponent implements OnInit, OnChanges, OnDestroy {

  conversationPackSearchForm: FormGroup;
  intentListForm: FormGroup;
  showImportSelectedBtn = false;
  selectedVA;
  intentListResponse = [];
  allIntents = [];
  intentConflictList = [];
  initialSettingsChangedSubscription: Subscription;
  checkIntentConflictSubscription: Subscription;
  importConversationPackSubscriptionOne: Subscription;
  importConversationPackSubscriptionTwo: Subscription;

  @Input() conversationPack;
  @Input() vrmId;
  @Input() showIntentList;
  @Output() importClicked = new EventEmitter();


  constructor(
    private matDialog: MatDialog,
    private conversationPacksService: ConversationPacksService,
    private router: Router
  ) { }

  ngOnInit() {
    this.conversationPackSearchForm = new FormGroup({
      search: new FormControl('')
    });
    this.intentListForm = new FormGroup({
      selectAll: new FormControl(null)
    });
    this.initialSettingsChangedSubscription = this.conversationPacksService.initialSettingsChanged
      .subscribe(data => {
        if (data) {
          this.selectedVA = data;
        }
      });
    // this.tableDataGen();
  }

  ngOnChanges(changes) {
    if (changes.hasOwnProperty('conversationPack') && !changes.conversationPack.firstChange) {
      this.intentListForm = new FormGroup({
        selectAll: new FormControl(null)
      });
      this.showImportSelectedBtn = false;
      this.intentListResponse = [];
      this.intentConflictList = [];
      this.tableDataGen();
    }
  }

  tableDataGen() {
    let count = 0;
    console.log('conversationPack', this.conversationPack);
    for (const intent of this.conversationPack.intents) {
      intent.intentConflict = false;
      for (const language of intent.languages) {
        const pushdata = {
          id: count++,
          intentId: intent.cp_intentId,
          intentName: intent.intentName,
          langName: language.language.langName,
          language,
          channels: language.channels,
          channelsStatus: ''
        };
        this.intentListResponse.push(pushdata);
      }
    }
    console.log('intentListResponse', this.intentListResponse);
    this.allIntents = JSON.parse(JSON.stringify(this.intentListResponse));
    this.intentListResponse.forEach(intent => {
      this.intentListForm.addControl(intent.id, new FormControl());
    });
  }

  onSelectAllClicked(event) {
    if (event.target.checked) {
      this.showImportSelectedBtn = true;
      Object.keys(this.intentListForm.controls).forEach(control => {
        this.intentListForm.get(control).setValue(true);
      });
    } else {
      this.showImportSelectedBtn = false;
      Object.keys(this.intentListForm.controls).forEach(control => {
        this.intentListForm.get(control).setValue(false);
      });
    }
  }

  onSelectOrDeSelect(event, controlName) {
    if (event.target.checked) {
      this.intentListForm.controls[controlName].setValue(true);
      this.showImportSelectedBtn = true;
      let flag = false;
      Object.keys(this.intentListForm.controls).forEach(control => {
        if (this.intentListForm.get(control).value || control === 'selectAll') {
          this.showImportSelectedBtn = true;
        } else {
          flag = true;
        }
      });
      if (!flag) {
        this.intentListForm.controls['selectAll'].setValue(true);
      }
    } else {
      let flag = false;
      this.intentListForm.controls[controlName].setValue(false);
      this.intentListForm.controls['selectAll'].setValue(false);
      Object.keys(this.intentListForm.controls).forEach(control => {
        if (this.intentListForm.get(control).value) {
          this.showImportSelectedBtn = true;
          flag = true;
        }
      });
      if (!flag) {
        this.showImportSelectedBtn = false;
      }
    }
  }

  importSelected() {
    console.log('coming here');
    const reqData = this.prepareReqData();
    console.log('reqData', reqData);
    if (reqData.intents.length > 0) {
      this.checkIntentConflictSubscription = this.conversationPacksService
        .checkIntentConflict(this.vrmId, reqData).subscribe(response => {
          this.intentConflictList = [];
          if (response['data'] === 'Intents Conflicted') {
            if (response['intents'].length > 0) {
              response['intents'].forEach(intent => {
                this.intentListResponse.forEach(reqIntent => {
                  if (reqIntent.intentName === intent.intentName) {
                    reqIntent.intentConflict = true;
                    this.intentConflictList.push(reqIntent);
                  }
                });
              });
              const dialogConfigImport = new MatDialogConfig();
              dialogConfigImport.disableClose = true;
              dialogConfigImport.width = '800px';
              dialogConfigImport.data = {
                primaryText: 'These are the intents that you have chosen to import',
                hasPrimaryBtn: true,
                primaryBtnText: 'Done',
                popUpType: 'import',
                hasCancelBtn: true,
                secondaryBtnText: 'Cancel',
                formData: this.intentListForm,
                intents: this.intentConflictList
              };

              const modalDialog = this.matDialog.open(IntentConflictModalComponent, dialogConfigImport);
              modalDialog.afterClosed().subscribe(data => {
                if (data) {
                  this.importConversations();
                }
              });
            }
          } else if (response['data'] === 'Intents are not Conflicated') {
            const dialogRef = this.openOtherModal();
            this.importConversationPackSubscriptionOne = this.conversationPacksService
              .importConversationPack(this.vrmId, reqData).subscribe(() => {
                dialogRef.close();
                this.openImportSuccessModal();
              }, err => dialogRef.close());
          }
        });

    }

  }

  prepareReqData() {
    console.log(this.conversationPack);
    if (this.conversationPack.hasOwnProperty('intents') && this.conversationPack.intents.length > 0) {
      const reqData = JSON.parse(JSON.stringify(this.conversationPack));
      reqData.intents.forEach(intent => {
        intent.languages.splice(0, intent.languages.length);
      });
      Object.keys(this.intentListForm.controls).forEach(control => {
        if (this.intentListForm.controls[control].value) {
          let intentOverride = false;
          this.intentListResponse.forEach(item => {
            console.log(typeof String(item.id), typeof control);
            console.log(String(item.id) === control);
          });
          const index = this.intentListResponse.findIndex(item => String(item.id) === control);
          const conflictIndex = this.intentConflictList.findIndex(item => String(item.id) === control);
          if (conflictIndex > -1 && this.intentConflictList[conflictIndex].intentConflict) {
            intentOverride = true;
          }
          if (index > -1) {
            const intentIndex = reqData.intents.findIndex(intent => intent.cp_intentId === this.intentListResponse[index].intentId);
            reqData.intents[intentIndex].intentConflict = intentOverride;
            reqData.intents[intentIndex].languages.push(this.intentListResponse[index].language);
          }
        }
      });

      const data = JSON.parse(JSON.stringify(reqData));

      reqData.intents = [];
      reqData.intents = data.intents.filter((intent, index) => {
        if (intent.languages.length > 0) {
          return intent;
        }
      });
      return reqData;
    }
  }

  importConversations() {
    const reqData = this.prepareReqData();
    console.log('Final reqData', reqData, this.intentConflictList);
    const dialogRef = this.openOtherModal();
    this.importConversationPackSubscriptionTwo = this.conversationPacksService
      .importConversationPack(this.vrmId, reqData).subscribe(response => {
        dialogRef.close();
        this.openImportSuccessModal();
      }, err => dialogRef.close());
  }

  openOtherModal() {
    const dialogConfigImport = new MatDialogConfig();
    dialogConfigImport.disableClose = true;
    dialogConfigImport.width = '800px';
    dialogConfigImport.data = {
      primaryText: 'Please wait while we import your intents',
    };

    const modalDialog = this.matDialog.open(ModalComponent, dialogConfigImport);
    return modalDialog;
  }

  openImportSuccessModal() {
    const dialogConfigImport = new MatDialogConfig();
    dialogConfigImport.disableClose = true;
    dialogConfigImport.width = '800px';
    dialogConfigImport.data = {
      primaryText: 'Your Intents have been successfully Imported.',
      hasPrimaryBtn: true,
      primaryBtnText: 'Ok',
      popUpType: 'success',
      hasCancelBtn: false
    };
    const modalDialog = this.matDialog.open(ModalComponent, dialogConfigImport);
    modalDialog.afterClosed().subscribe(data => {
      this.router.navigate([`/intent/listing/${this.vrmId}/
      ${this.selectedVA.vaAgent.vrmName}/${this.selectedVA.vaAgent.vrmDescription}/
      ${this.selectedVA.vaChannels[0].channelName}/${this.selectedVA.vaLanguages[0].langName}/0/0`]);
    });
  }

  onSearchIntentList(event) {
    const intents = JSON.parse(JSON.stringify(this.allIntents));
    this.intentListResponse = intents.filter((intent, index) => {
      if (intent.intentName.toLowerCase().match(event.toLowerCase()) ||
        intent.intentName.toLowerCase().split(' ').join('').match(event.toLowerCase())) {
        if (!this.intentListForm.controls.hasOwnProperty(intent.id)) {
          this.intentListForm.addControl(intent.id, new FormControl(''));
        }
        return intent;
      } else {
        this.intentListResponse.splice(index, 1);
        this.intentListForm.removeControl(intent.id);
      }
    });

    let flag = false;
    Object.keys(this.intentListForm.controls).forEach(control => {
      if (!this.intentListForm.get(control).value && control !== 'selectAll') {
        flag = true;
      }
    });
    if (!flag) {
      this.intentListForm.controls['selectAll'].setValue(true);
    } else {
      this.intentListForm.controls['selectAll'].setValue(false);
    }
  }

  ngOnDestroy() {
    if (this.initialSettingsChangedSubscription) {
      this.initialSettingsChangedSubscription.unsubscribe();
    }
    if (this.checkIntentConflictSubscription) {
      this.checkIntentConflictSubscription.unsubscribe();
    }
    if (this.importConversationPackSubscriptionOne) {
      this.importConversationPackSubscriptionOne.unsubscribe();
    }
    if (this.importConversationPackSubscriptionTwo) {
      this.importConversationPackSubscriptionTwo.unsubscribe();
    }
  }

}

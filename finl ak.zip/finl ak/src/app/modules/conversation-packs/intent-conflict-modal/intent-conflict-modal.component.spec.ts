import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IntentConflictModalComponent } from './intent-conflict-modal.component';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormsModule, ReactiveFormsModule, FormGroup } from '@angular/forms';

class MatDialogRefStub {
  public close(value) { }
}

describe('IntentConflictModalComponent', () => {
  let component: IntentConflictModalComponent;
  let fixture: ComponentFixture<IntentConflictModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [IntentConflictModalComponent],
      imports: [FormsModule, ReactiveFormsModule],
      providers: [
        { provide: MatDialogRef, useClass: MatDialogRefStub },
        {
          provide: MAT_DIALOG_DATA, useValue: {
            formData: new FormGroup({})
          }
        }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntentConflictModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('doneClicked should close the modal with true', () => {
    const spy = spyOn(TestBed.get(MatDialogRef), 'close');

    component.doneClicked();

    expect(spy).toHaveBeenCalledWith(true);
  });

  it('cancelClicked should cloase the modal with false', () => {
    const spy = spyOn(TestBed.get(MatDialogRef), 'close');

    component.cancelClicked();

    expect(spy).toHaveBeenCalledWith(false);
  });

  it('onSelectOrDeselect shouldset intentConflict to true', () => {
    const event = {
      target: {
        checked: true
      }
    };

    const intent = {
      intentConflict: false
    };

    component.onSelectOrDeselect(event, intent);

    expect(intent.intentConflict).toBeTruthy();
  });

  it('onSelectOrDeselect should set intentConflict to false', () => {
    const event = {
      target: {
        checked: false
      }
    };

    const intent = {
      intentConflict: true
    };

    component.onSelectOrDeselect(event, intent);

    expect(intent.intentConflict).toBeFalsy();
  });
});

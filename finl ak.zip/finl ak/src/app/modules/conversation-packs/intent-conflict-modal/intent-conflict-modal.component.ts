import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-intent-conflict-modal',
  templateUrl: './intent-conflict-modal.component.html',
  styleUrls: ['./intent-conflict-modal.component.scss']
})
export class IntentConflictModalComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<IntentConflictModalComponent>,
    @Inject(MAT_DIALOG_DATA) public modalData: any
  ) { }

  ngOnInit() {
  }

  doneClicked() {
    this.dialogRef.close(true);
  }

  cancelClicked() {
    this.dialogRef.close(false);
  }

  onSelectOrDeselect(event, intent) {
    if (event.target.checked) {
      intent.intentConflict = true;
    } else {
      intent.intentConflict = false;
    }
  }

}

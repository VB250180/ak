import { Component, OnInit, Input, Output, EventEmitter, OnDestroy } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ConversationPacksService } from '../../../core/services/conversation-packs/conversation-packs.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-conversation-packs-list',
  templateUrl: './conversation-packs-list.component.html',
  styleUrls: ['./conversation-packs-list.component.scss']
})
export class ConversationPacksListComponent implements OnInit, OnDestroy {

  conversationPackSearchForm: FormGroup;
  @Input() conversationPacksList;
  @Input() vaDetails;
  @Input() initialSettingsDone;
  @Output() scrolledToEnd = new EventEmitter();
  @Output() conversationPackSelected = new EventEmitter();
  @Output() searched = new EventEmitter();
  pageNo = 1;
  initialSettingsChangedSubscription: Subscription;

  constructor(private conversationPacksService: ConversationPacksService) { }

  ngOnInit() {
    this.initialSettingsChangedSubscription = this.conversationPacksService.initialSettingsChanged
      .subscribe(response => {
        this.pageNo = 1;
      });
    this.conversationPackSearchForm = new FormGroup({
      search: new FormControl('')
    });
  }

  onScroll() {
    this.pageNo += 1;
    this.scrolledToEnd.emit(this.pageNo);
  }

  onConversationPackSelected(conversationPack) {
    this.conversationPackSelected.emit(conversationPack);
  }

  onSearchConversationPacks(event) {
    this.pageNo = 1;
    this.searched.emit(event);
  }

  ngOnDestroy() {
    if (this.initialSettingsChangedSubscription) {
      this.initialSettingsChangedSubscription.unsubscribe();
    }
  }
}

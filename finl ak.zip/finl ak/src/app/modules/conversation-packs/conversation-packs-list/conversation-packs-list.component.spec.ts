import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConversationPacksListComponent } from './conversation-packs-list.component';
import { ConversationPacksService } from '../../../core/services/conversation-packs/conversation-packs.service';
import { BehaviorSubject, Subscription } from 'rxjs';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

class ConversationPacksServiceStub {
  initialSettingsChanged = new BehaviorSubject(true);
}

describe('ConversationPacksListComponent', () => {
  let component: ConversationPacksListComponent;
  let fixture: ComponentFixture<ConversationPacksListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ConversationPacksListComponent],
      providers: [{ provide: ConversationPacksService, useClass: ConversationPacksServiceStub }],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
        InfiniteScrollModule
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConversationPacksListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('ngOnInit should set pageNo to 1', () => {
    component.pageNo = 2;

    component.ngOnInit();

    expect(component.pageNo).toEqual(1);
  });

  it('onScroll should increment pageNo and emit scrolledToEnd event', () => {
    const scrolledToEndSpy = spyOn(component.scrolledToEnd, 'emit');
    component.pageNo = 1;

    component.onScroll();

    expect(component.pageNo).toEqual(2);
    expect(scrolledToEndSpy).toHaveBeenCalled();
  });

  it('onConversationPackSelected should emit conversationPackSelected event', () => {
    const conversationPackSelectedSpy = spyOn(component.conversationPackSelected, 'emit');
    const conversationPack = {};

    component.onConversationPackSelected(conversationPack);

    expect(conversationPackSelectedSpy).toHaveBeenCalledWith(conversationPack);
  });

  it('onSearchConversationPacks should increment pageNo and emit searched event', () => {
    const searchedSpy = spyOn(component.searched, 'emit');
    const event = {};

    component.onSearchConversationPacks(event);

    expect(searchedSpy).toHaveBeenCalledWith(event);
  });

  it('ngOnDestroy should not unsubscribe from subscription', () => {
    const initialSettingsChangedSubscriptionSpy = spyOn(component.initialSettingsChangedSubscription, 'unsubscribe');
    component.initialSettingsChangedSubscription = undefined;

    component.ngOnDestroy();

    expect(initialSettingsChangedSubscriptionSpy).toHaveBeenCalledTimes(0);
  });

});

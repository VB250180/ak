import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ConversationPacksComponent } from './conversation-packs.component';
import { MatDialog, MatDialogModule, MatDialogConfig } from '@angular/material';
import { ConversationPacksService } from '../../core/services/conversation-packs/conversation-packs.service';
import { BehaviorSubject, Observable } from 'rxjs';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ToastrModule } from 'ngx-toastr';
import { RouterTestingModule } from '@angular/router/testing';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';

class ConversationPacksServiceStub {
  initialSettingsChanged = new BehaviorSubject(null);

  public getConversationPacks(data) {
    return Observable.of({
      conversationPacks: [{
        cpId: 4,
        cpName: 'Health Care',
        intents: [
          {
            cp_intentId: 5,
            intentName: 'Deductible',
            intentType: 'GENERAL',
            intentDescription: 'Deductible Desc'
            , intentConflict: null,
            languages: [{
              cp_ilmId: 9,
              cp_ilm_json: null,
              language: {
                langName: 'English',
                langId: 1
              },
              channels: [{
                cp_icmId: 21,
                cp_icm_json: null,
                channel: {
                  virtualAgentRoleChannelMapId: null,
                  channelId: 2,
                  channelName: 'IVR',
                  key: null
                }
              }]
            }, {
              cp_ilmId: 13,
              cp_ilm_json: null,
              language: {
                langName: 'Spanish',
                langId: 11
              }, channels: [{
                cp_icmId: 29,
                cp_icm_json: null,
                channel: {
                  virtualAgentRoleChannelMapId: null,
                  channelId: 2,
                  channelName: 'IVR',
                  key: null
                }
              }]
            }]
          },
          {
            cp_intentId: 6,
            intentName: 'Benefit Details',
            intentType: 'GENERAL',
            intentDescription: 'Benefit Details Desc',
            intentConflict: null,
            languages: [{
              cp_ilmId: 10,
              cp_ilm_json: null,
              language: {
                langName: 'English',
                langId: 1
              },
              channels: [{
                cp_icmId: 22,
                cp_icm_json: null,
                channel: {
                  virtualAgentRoleChannelMapId: null,
                  channelId: 2,
                  channelName: 'IVR',
                  key: null
                }
              }]
            },
            {
              cp_ilmId: 14,
              cp_ilm_json: null,
              language: {
                langName: 'Spanish',
                langId: 11
              },
              channels: [{
                cp_icmId: 30,
                cp_icm_json: null,
                channel: {
                  virtualAgentRoleChannelMapId: null,
                  channelId: 2,
                  channelName: 'IVR',
                  key: null
                }
              }]
            }]
          },
          {
            cp_intentId: 7,
            intentName: 'Claim',
            intentType: 'GENERAL',
            intentDescription: 'Claim Desc',
            intentConflict: null,
            languages: [{
              cp_ilmId: 11,
              cp_ilm_json: null,
              language: {
                langName: 'English',
                langId: 1
              },
              channels: [{
                cp_icmId: 23,
                cp_icm_json: null,
                channel: {
                  virtualAgentRoleChannelMapId: null,
                  channelId: 2,
                  channelName: 'IVR',
                  key: null
                }
              }]
            },
            {
              cp_ilmId: 15,
              cp_ilm_json: null,
              language: {
                langName: 'Spanish',
                langId: 11
              },
              channels: [{
                cp_icmId: 31,
                cp_icm_json: null,
                channel: {
                  virtualAgentRoleChannelMapId: null,
                  channelId: 2,
                  channelName: 'IVR',
                  key: null
                }
              }]
            }]
          }],
        languages: [{
          langName: 'English',
          langId: 1
        },
        {
          langName: 'Spanish',
          langId: 11
        }],
        channels: [{
          virtualAgentRoleChannelMapId: null,
          channelId: 2,
          channelName: 'IVR',
          key: null
        }]
      },
      {
        cpId: 5,
        cpName: 'Insurance',
        intents: [
          {
            cp_intentId: 12,
            intentName: 'Fund Value',
            intentType: 'GENERAL',
            intentDescription: 'Fund Value Desc',
            intentConflict: null,
            languages: [{
              cp_ilmId: 23,
              cp_ilm_json: null,
              language: {
                langName: 'English',
                langId: 1
              },
              channels: [{
                cp_icmId: 49,
                cp_icm_json: null,
                channel: {
                  virtualAgentRoleChannelMapId: null,
                  channelId: 2,
                  channelName: 'IVR',
                  key: null
                }
              }]
            },
            {
              cp_ilmId: 27,
              cp_ilm_json: null,
              language: {
                langName: 'Spanish',
                langId: 11
              },
              channels: [{
                cp_icmId: 57,
                cp_icm_json: null,
                channel: {
                  virtualAgentRoleChannelMapId: null,
                  channelId: 2,
                  channelName: 'IVR', key: null
                }
              }]
            }]
          },
          {
            cp_intentId: 13,
            intentName: 'Policy status',
            intentType: 'GENERAL',
            intentDescription: 'Policy status Desc',
            intentConflict: null,
            languages: [{
              cp_ilmId: 24,
              cp_ilm_json: null,
              language: {
                langName: 'English',
                langId: 1
              },
              channels: [{
                cp_icmId: 50,
                cp_icm_json: null,
                channel: {
                  virtualAgentRoleChannelMapId: null,
                  channelId: 2,
                  channelName: 'IVR',
                  key: null
                }
              }]
            },
            {
              cp_ilmId: 28,
              cp_ilm_json: null,
              language: {
                langName: 'Spanish',
                langId: 11
              },
              channels: [{
                cp_icmId: 58,
                cp_icm_json: null,
                channel: {
                  virtualAgentRoleChannelMapId: null,
                  channelId: 2,
                  channelName: 'IVR',
                  key: null
                }
              }]
            }]
          },
        ],
        languages: [{
          langName: 'English',
          langId: 1
        },
        {
          langName: 'Spanish',
          langId: 11
        }],
        channels: [{
          virtualAgentRoleChannelMapId: null,
          channelId: 2,
          channelName: 'IVR',
          key: null
        }]
      }]
    });
  }
}

class MatDialogStub {
  public open(template, data) {
    // this.afterClosed(true);
    return {
      afterClosed: () => {
        return Observable.of(true);
      }
    };
  }
}

describe('ConversationPacksComponent', () => {
  let component: ConversationPacksComponent;
  let fixture: ComponentFixture<ConversationPacksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ConversationPacksComponent],
      providers: [
        { provide: ConversationPacksService, useClass: ConversationPacksServiceStub },
        { provide: MatDialog, useClass: MatDialogStub }
      ],
      imports: [FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
        NgxSpinnerModule,
        ToastrModule.forRoot(),
        MatDialogModule,
        RouterTestingModule,
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConversationPacksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('ngOnInit should call onInitialSettingChanged and set pageNo to 1', () => {
    const onInitialSettingChangedSpy = spyOn(component, 'onInitialSettingChanged');

    component.ngOnInit();

    expect(component.pageNo).toEqual(1);
    expect(onInitialSettingChangedSpy).toHaveBeenCalled();
  });

  it('onInitialSettingChanged should call getConversationPacks', () => {
    const getConversationPacksSpy = spyOn(component, 'getConversationPacks');
    const event = {
      vaAgent: {
        vrmId: 1
      }
    };

    component.onInitialSettingChanged(event);

    expect(component.initialSettingsDone).toBeTruthy();
    expect(component.selectedVirtualAgent).toEqual(event);
    expect(component.showIntentList).toBeFalsy();
    expect(component.vrmId).toEqual(1);
    expect(component.conversationPacksList).toEqual([]);
    expect(getConversationPacksSpy).toHaveBeenCalled();
  });

  it('onInitialSettingChanged should not call getConversationPacks', () => {
    const getConversationPacksSpy = spyOn(component, 'getConversationPacks');
    const event = undefined;

    component.onInitialSettingChanged(event);

    expect(component.initialSettingsDone).toBeFalsy();
    expect(component.selectedVirtualAgent).toEqual(event);
    expect(component.showIntentList).toBeFalsy();
    expect(component.conversationPacksList).toEqual([]);
    expect(getConversationPacksSpy).toHaveBeenCalledTimes(0);
  });

  it('getConversationPacks should initialize conversationPacksList from API response on first API call with given search value results', () => {
    const spinnerShowSpy = spyOn(TestBed.get(NgxSpinnerService), 'show');
    const spinnerHideSpy = spyOn(TestBed.get(NgxSpinnerService), 'hide');
    component.selectedVirtualAgent = {
      vaAgent: {
        vrmId: 1
      },
      vaChannels: [{ channelId: 1 }, { channelId: 2 }],
      vaLanguages: [{ langId: 1 }, { langId: 2 }]
    };
    component.pageNo = 1;
    component.searchValue = 'searching';

    component.getConversationPacks();

    expect(spinnerShowSpy).toHaveBeenCalledBefore(spinnerHideSpy);
    expect(component.conversationPacksList.length).toEqual(2);
    expect(spinnerHideSpy).toHaveBeenCalled();
  });

  it('getConversationPacks should override conversationPacksList from API response when navigating from different page', () => {
    const spinnerShowSpy = spyOn(TestBed.get(NgxSpinnerService), 'show');
    const spinnerHideSpy = spyOn(TestBed.get(NgxSpinnerService), 'hide');
    component.selectedVirtualAgent = {
      vaAgent: {
        vrmId: 1
      },
      vaChannels: [{ channelId: 1 }, { channelId: 2 }],
      vaLanguages: [{ langId: 1 }, { langId: 2 }]
    };
    component.pageNo = 1;
    component.conversationPacksList = [{ cp_id: 1 }];

    component.getConversationPacks();

    expect(spinnerShowSpy).toHaveBeenCalledBefore(spinnerHideSpy);
    expect(component.conversationPacksList.length).toEqual(2);
    expect(spinnerHideSpy).toHaveBeenCalled();
  });

  it('getConversationPacks should append to conversationPacksList on scrolling from API response', () => {
    const spinnerShowSpy = spyOn(TestBed.get(NgxSpinnerService), 'show');
    const spinnerHideSpy = spyOn(TestBed.get(NgxSpinnerService), 'hide');
    component.selectedVirtualAgent = {
      vaAgent: {
        vrmId: 1
      },
      vaChannels: [{ channelId: 1 }, { channelId: 2 }],
      vaLanguages: [{ langId: 1 }, { langId: 2 }]
    };
    component.pageNo = 2;
    component.conversationPacksList = [{ cp_id: 1 }];

    component.getConversationPacks();

    expect(spinnerShowSpy).toHaveBeenCalledBefore(spinnerHideSpy);
    expect(component.conversationPacksList.length).toEqual(3);
    expect(spinnerHideSpy).toHaveBeenCalled();
  });

  it('onCpSearch should initialize pageNo to 1 and searchValue to parameter passed and call getConversationPacks method', () => {
    const getConversationPacksSpy = spyOn(component, 'getConversationPacks');
    const event = 'searching';
    component.pageNo = 2;

    component.onCpSearch(event);

    expect(component.searchValue).toEqual(event);
    expect(component.pageNo).toEqual(1);
    expect(getConversationPacksSpy).toHaveBeenCalled();
  });

  it('onScroll should initialize pageNo parameter passed and call getConversationPacks method', () => {
    const getConversationPacksSpy = spyOn(component, 'getConversationPacks');
    const pageNo = 2;
    component.pageNo = 1;

    component.onScroll(pageNo);

    expect(component.pageNo).toEqual(2);
    expect(getConversationPacksSpy).toHaveBeenCalled();
  });

  it('onConversationPackSelected should initialize conversationPack parameter passed and set showIntentList to true', () => {
    const conversationPack = { cp_id: 1, cpName: 'Management' };
    component.showIntentList = false;

    component.onConversationPackSelected(conversationPack);

    expect(component.conversationPack).toEqual(conversationPack);
    expect(component.showIntentList).toBeTruthy();
  });

  it('importSelected should open the modal and call openOtherModal method after closed', () => {
    const openOtherModalSpy = spyOn(component, 'openOtherModal');

    component.importSelected();

    expect(openOtherModalSpy).toHaveBeenCalled();
  });

  it('openOtherModal should open the modal', () => {

    component.openOtherModal();

    expect(component).toBeTruthy();
  });
});

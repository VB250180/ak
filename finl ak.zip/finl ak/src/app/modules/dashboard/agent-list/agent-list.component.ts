import { Component, OnInit, OnDestroy } from '@angular/core';
import { ChartType, ChartDataSets, ChartOptions } from 'chart.js';
import { MultiDataSet, Label, Color } from 'ng2-charts';
import { NgxSpinnerService } from 'ngx-spinner';
import { AgentListService } from '../../../core/services/agent-list/agent-list.service';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';

@Component({
  selector: 'app-agent-list',
  templateUrl: './agent-list.component.html',
  styleUrls: ['./agent-list.component.scss']
})
export class AgentListComponent implements OnInit, OnDestroy {
  liveAgentList: Array<any> = [];
  testAgentList: Array<any> = [];
  channelList: Array<any>;
  languageList: Array<any>;
  agentFilter: any = {
    channel: 0,
    language: 0
  };
  userId = 0;
  showLiveVA = true;
  showTestVA = true;
  totalVacounts: number;
  distinctbyliveVacounts;
  distinctbytestVacounts;
  // VAFilterForm: FormGroup;
  hid = '';
  public doughnutChart1Labels: Label[] = ['', ''];
  public doughnutChart1Data: MultiDataSet = [
    [75, 25]
  ];
  public doughnutChart1Options: any = {
    cutoutPercentage: 90,
    elements: {
      arc: {
        borderWidth: 0
      }
    },
    tooltips: {
      enabled: false
    }
  };

  public pieChart1Colors = [
    {
      backgroundColor: ['#57E0D8', 'rgba(87, 224, 216, 0.1)'],
    },
  ];

  public pieChart2Colors = [
    {
      backgroundColor: ['#B1A3F9', 'rgba(177, 163, 249, 0.1)'],
    },
  ];

  public doughnutChartType: ChartType = 'pie';
  public pieChartLegend = false;


  public lineChartData: ChartDataSets[] = [
    { data: [0, 33, 0, 0], label: '', borderWidth: 1 }
  ];

  public lineChartLabels: Label[] = ['', '', '', ''];

  public lineChartOptions: (ChartOptions) = {
    responsive: true,
    maintainAspectRatio: false,
    // pointBorder: 0,
    // borderWidth: 1,
    elements: { point: { radius: 0 } },
    scales: {
      xAxes: [{
        gridLines: {
          display: false,
          drawBorder: false,
          tickMarkLength: 0
        },
      }],
      yAxes: [{
        gridLines: {
          display: false,
          drawBorder: false
        },
        ticks: {
          beginAtZero: true,
          callback(value, index, values) {
            return '';
          },
        }
      }]
    }
  };
  public lineChartColors: Color[] = [
    {
      backgroundColor: 'rgba(87, 224, 216, 0.1)',
      borderColor: '#57E0D8',
      pointBackgroundColor: '#57E0D8',
      pointBorderColor: '#57E0D8',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: '#57E0D8'
    }
  ];
  public lineChart2Colors: Color[] = [
    {
      backgroundColor: 'rgba(177, 163, 249, 0.1)',
      borderColor: '#B1A3F9',
      pointBackgroundColor: '#B1A3F9',
      pointBorderColor: '#B1A3F9',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: '#B1A3F9'
    }
  ];
  public lineChartLegend = false;
  public lineChartType = 'line';

  public showTrand = true;
  languageChannelSubscription: Subscription;
  agentListSubscription: Subscription;
  agentDahboardChartSubscription: Subscription;
  vaTrendDataSubsciption: Subscription;

  constructor(
    private agentListService: AgentListService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private authService: AuthenticationService) {
    // this.VAFilterForm = new FormGroup({
    //   channel: new FormControl(null, Validators.required),
    //   language: new FormControl(null, Validators.required),
    // });
    this.userId = this.authService.getCurrentUserId();
  }

  ngOnInit() {
    this.spinner.show();
    this.getLanguageAndChannelList();
    this.getAgentList();
  }

  ngOnDestroy() {
    if (this.languageChannelSubscription) {
      this.languageChannelSubscription.unsubscribe();
    }
    if (this.agentListSubscription) {
      this.agentListSubscription.unsubscribe();
    }
    if (this.agentDahboardChartSubscription) {
      this.agentDahboardChartSubscription.unsubscribe();
    }
    if (this.vaTrendDataSubsciption) {
      this.vaTrendDataSubsciption.unsubscribe();
    }
  }

  getLanguageAndChannelList() {
    this.languageChannelSubscription = this.agentListService.getChannels().subscribe((res: any) => {
      this.spinner.hide();
      this.channelList = res.channels;
      this.languageList = res.languages;
    },
      err => console.error(err));
  }

  getAgentList() {
    this.agentListSubscription = this.agentListService.getAgentList(this.agentFilter.channel, this.agentFilter.language, this.userId).subscribe((res: any) => {
      this.spinner.hide();
      this.filterAgentList(res.virtualAgentDashboardResponseObject.virtualAgentDashboardList);
    },
      err => console.error(err));
  }

  filterAgentList(res) {
    this.findtotalvaCount(res);
    this.liveAgentList = [];
    this.testAgentList = [];
    res.map(val => {
      val.vaDashChannelList.map(cVal => {
        cVal.vaDashLangList.map(lVal => {
          const obj = { ...val, channelData: cVal, languageData: lVal };
          if (obj.vaRoleName === 'live') {
            this.liveAgentList.push(obj);

          } else {
            this.testAgentList.push(obj);
          }
        });
      });
    });
    this.callchartdata(this.liveAgentList);
    this.valiveagentCount(this.liveAgentList);
    this.vatestagentCount(this.testAgentList);
    console.log('live agent list', this.liveAgentList);

  }

  callchartdata(data) {
    console.log('live length', data.length);
    const passarry = [];
    for (let i = 0; i < data.length; i++) {
      const params = {};
      params['vrmId'] = data[i].vaRoleMapId;
      params['channelId'] = data[i].channelData.vaRoleChannelMapId;
      params['langEngId'] = data[i].languageData.vaLangEngineMapid;
      passarry.push(params);
    }

    const params1 = {
      data: passarry,
      graphType: 'week'
    };
    const params2 = {
      data: passarry,
      graphType: 'month'
    };
    this.agentDahboardChartSubscription = this.agentListService.dashboardChart(params1, params2).subscribe((res: any) => {
      console.log('Res chart', res);
      if (res) {
        for (let i = 0; i < this.liveAgentList.length; i++) {
          if (this.liveAgentList[i].channelData.vaRoleChannelMapId === res[0].data.trenddata[i].channelId &&
            this.liveAgentList[i].languageData.vaLangEngineMapid === res[0].data.trenddata[i].langEngId &&
            this.liveAgentList[i].vaRoleMapId === res[0].data.trenddata[i].vrmId) {
            this.liveAgentList[i].languageData.vaCurrentWeekIntentAccuracy = res[0].data.trenddata[i].currenweekintentaccuracy;
            this.liveAgentList[i].languageData.vaPreviousWeekIntentAccuracy = res[0].data.trenddata[i].lastweekintentaccuracy;
            this.liveAgentList[i].languageData.vaCurrentWeekCallHandled = res[0].data.trenddata[i].currenweekcallaccuracy;
            this.liveAgentList[i].languageData.vaPreviousWeekCallHandled = res[0].data.trenddata[i].lastweekcallaccuracy;
          }
          if (this.liveAgentList[i].channelData.vaRoleChannelMapId === res[1].data.trenddata[i].channelId &&
            this.liveAgentList[i].languageData.vaLangEngineMapid === res[1].data.trenddata[i].langEngId &&
            this.liveAgentList[i].vaRoleMapId === res[1].data.trenddata[i].vrmId) {
            this.liveAgentList[i].languageData.vaCurrentMonthIntentAccuracy = res[1].data.trenddata[i].currenweekintentaccuracy;
            this.liveAgentList[i].languageData.vaPreviousMonthIntentAccuracy = res[1].data.trenddata[i].lastweekintentaccuracy;
            this.liveAgentList[i].languageData.vaCurrentMonthCallHandled = res[1].data.trenddata[i].currenweekcallaccuracy;
            this.liveAgentList[i].languageData.vaPreviousMonthCallHandled = res[1].data.trenddata[i].lastweekcallaccuracy;

          }
        }
      }
    });
  }

  findtotalvaCount(ary) {
    const data = Array.from(new Set(ary.map(({ vaDescription }) => vaDescription)));
    this.totalVacounts = data.length;
  }

  valiveagentCount(ary) {
    const data = Array.from(new Set(ary.map(({ vaDescription }) => vaDescription)));
    this.distinctbyliveVacounts = data.length;
  }

  vatestagentCount(ary) {
    const data = Array.from(new Set(ary.map(({ vaDescription }) => vaDescription)));
    this.distinctbytestVacounts = data.length;
  }

  toggleLiveAgentGraphs = (index) => {
    if (!this.liveAgentList[index].showTrand) {
      this.liveAgentList[index].showTrand = true;
    } else {
      this.liveAgentList[index].showTrand = !this.liveAgentList[index].showTrand;
    }
    if (!this.liveAgentList[index].trandData) {
      // this.spinner.show();
      this.getVATrandData(index);
    }
  }

  getVATrandData(index) {
    this.spinner.show();
    this.spinner.show();
    const params1 = {
      vrmId: this.liveAgentList[index].vaRoleMapId,
      channelId: this.liveAgentList[index].channelData.vaRoleChannelMapId,
      langEngId: this.liveAgentList[index].languageData.vaLangEngineMapid,
      graphType: 'week'
    };
    const params2 = {
      vrmId: this.liveAgentList[index].vaRoleMapId,
      channelId: this.liveAgentList[index].channelData.vaRoleChannelMapId,
      langEngId: this.liveAgentList[index].languageData.vaLangEngineMapid,
      graphType: 'month'
    };
    this.vaTrendDataSubsciption = this.agentListService.getVATrandData(params1, params2).subscribe((res: any) => {
      setTimeout(() => { this.spinner.hide(); }, 500);
      // this.agentListService.getVATrandData(this.agentFilter.channel, this.agentFilter.language, this.liveAgentList[index].vaRoleMapId).subscribe((res: any) => {
      //   setTimeout(() => { this.spinner.hide(); }, 500);
      //   console.log('Res --> ', res);
      //   this.liveAgentList[index].trandData = res.virtualAgentTrendResponseObject;
      console.log('res', res);


      const formatdata = {
        monthTrendList: res[0].data.trenddata,
        weekTrendList: res[1].data.trenddata,
        monthTrendListCallHandle: res[0].data.callhandingdata,
        weekTrendListCallHandle: res[1].data.callhandingdata
      };
      this.liveAgentList[index].trandData = formatdata;
      console.log('trend data', this.liveAgentList[index].trandData);

      this.liveAgentList[index].monthTrandData = [{ data: [], label: '', borderWidth: 1 }];
      this.liveAgentList[index].monthTrandLables = [];
      this.liveAgentList[index].trandData.monthTrendList[0].map(val => {
        this.liveAgentList[index].monthTrandData[0].data.push(val.trendvalue);
        this.liveAgentList[index].monthTrandLables.push('');
      });

      this.liveAgentList[index].weekTrandData = [{ data: [], label: '', borderWidth: 1 }];
      this.liveAgentList[index].weekTrandLables = [];
      this.liveAgentList[index].trandData.weekTrendList[0].map(val => {
        this.liveAgentList[index].weekTrandData[0].data.push(val.trendvalue);
        console.log('weeek trnd data', this.liveAgentList);
        this.liveAgentList[index].weekTrandLables.push('');
      });

      // monthTrendListCallHandle //weekTrendListCallHandle
      this.liveAgentList[index].monthTrandCallHandleData = [{ data: [], label: '', borderWidth: 1 }];
      this.liveAgentList[index].monthTrandCallHandleLables = [];
      if (this.liveAgentList[index].trandData.monthTrendListCallHandle) {
        this.liveAgentList[index].trandData.monthTrendListCallHandle[0].map(val => {
          this.liveAgentList[index].monthTrandCallHandleData[0].data.push(val.trendvalue);
          this.liveAgentList[index].monthTrandCallHandleLables.push('');
        });
      }

      this.liveAgentList[index].weekTrandCallHandleData = [{ data: [], label: '', borderWidth: 1 }];
      this.liveAgentList[index].weekTrandCallHandleLables = [];
      if (this.liveAgentList[index].trandData.weekTrendListCallHandle) {
        this.liveAgentList[index].trandData.weekTrendListCallHandle[0].map(val => {
          this.liveAgentList[index].weekTrandCallHandleData[0].data.push(val.trendvalue);
          this.liveAgentList[index].weekTrandCallHandleLables.push('');
        });
      }
      console.log('month week TrandData', this.liveAgentList[index].monthTrandData, this.liveAgentList[index].weekTrandData);
      console.log('month week TrandLables', this.liveAgentList[index].monthTrandLables, this.liveAgentList[index].weekTrandLables);
      console.log('month week CallHandle Data', this.liveAgentList[index].monthTrandCallHandleData, this.liveAgentList[index].weekTrandCallHandleData);
      console.log('month week CallHandle Lables', this.liveAgentList[index].monthTrandCallHandleLables, this.liveAgentList[index].weekTrandCallHandleLables);

    },
      err => console.error(err));
  }

  changeLiveDataTime(val, index) {
    this.liveAgentList[index].dataTime = val;
  }

  calculateIncreasePercent(currVal, preVal) {
    const percentChange = ((currVal - preVal) / preVal) * 100;
    return percentChange ? percentChange : 0;
  }

  trimVaname(value) {
    const data = value.substring(0, 20) + '...';
    return data;
  }
  toggleLiveVA() {
    this.showLiveVA = !this.showLiveVA;
  }

  toggleTestVA() {
    this.showTestVA = !this.showTestVA;
  }

  filterChanged() {
    this.spinner.show();
    this.getAgentList();
  }

  changeStyleva(index) {

    this.hid = index;
  }

  changeindex(index) {
    this.hid = 'newIndexVal';
  }

  createIntent(vaID) {
    this.router.navigateByUrl('/intent/create', { state: { vaId: vaID } });
  }

  ifGreaterThen20(v) {
    if (v.length === 20 || v.length > 20) {
      return true;
    } else {
      return false;
    }
  }
  IfLessThen20(v) {
    if (v.length < 20 ) {
      return true;
    } else {
      return false;
    }
  }

}

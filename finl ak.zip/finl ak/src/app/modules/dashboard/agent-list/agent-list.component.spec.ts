import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AgentListComponent } from './agent-list.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { AgentListService } from '../../../core/services/agent-list/agent-list.service';
import { Observable, of, throwError } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
class AgentListServiceStub {
  public getChannels(): Observable<any> {
    return of(
      {
        virtualAgent: null,
        virtualAgents: null,
        virtualAgentRoleMaps: null,
        intent: null,
        intents: null,
        conversation: null,
        trainingPhrases: null,
        virtualAgentDashboardResponseObject: null,
        virtualAgentTrendResponseObject: null,
        systemSlotKeys: null,
        count: null,
        languages: [
          {
            langName: 'English',
            langId: 1
          },
          {
            langName: 'French',
            langId: 2
          },
          {
            langName: 'Hindi',
            langId: 3
          },
          {
            langName: 'English-Indian',
            langId: 4
          }
        ],
        languageEngineMaps: null,
        channels: [
          {
            virtualAgentRoleChannelMapId: null,
            channelId: 2,
            channelName: 'IVR',
            key: null
          },
          {
            virtualAgentRoleChannelMapId: null,
            channelId: 1,
            channelName: 'WEB',
            key: null
          }
        ],
        intentLanguageChannelMaps: null,
        intentSlots: null,
        entities: null,
        sessionData: null,
        organizationData: null,
        categoryData: null,
        userData: null,
        entityResponseObject: null,
        entityResponseObjectList: null,
        conversationPacks: null,
        conversationPack: null,
        loginPojo: null,
        data: null,
        intentSlotRichCardTemplates: null,
        intentResponseRichCardTemplates: null,
        errorBody: null,
        audioData: null
      }
    );
  }
  public getAgentList(chanel: any, lang: any, userid: any): Observable<any> {
    if (chanel === 0) {
      return of(
        {
          virtualAgent: null,
          virtualAgents: null,
          virtualAgentRoleMaps: null,
          intent: null,
          intents: null,
          conversation: null,
          trainingPhrases: null,
          virtualAgentDashboardResponseObject: {
            virtualAgentDashboardList: [
              {
                vaAvatarName: 'Akeira',
                vaDescription: 'Claims Management',
                vaRoleName: 'live',
                vaTotalIntent: 17,
                vaRoleMapId: 1,
                vaDashChannelList: [
                  {
                    vaChannel: 'IVR',
                    vaRoleChannelMapId: 2,
                    vaDashLangList: [
                      {
                        vaLanguage: 'English',
                        vaLangEngineMapid: 1,
                        vaUnmappedInputs: 53,
                        vaDraftIntent: 15,
                        vaCurrentMonthIntentAccuracy: 0,
                        vaPreviousMonthIntentAccuracy: 0,
                        vaCurrentWeekIntentAccuracy: 0,
                        vaPreviousWeekIntentAccuracy: 0,
                        vaCurrentMonthCallHandled: 0,
                        vaPreviousMonthCallHandled: 0,
                        vaCurrentWeekCallHandled: 0,
                        vaPreviousWeekCallHandled: 0
                      },
                      {
                        vaLanguage: 'Spanish',
                        vaLangEngineMapid: 11,
                        vaUnmappedInputs: 0,
                        vaDraftIntent: 17,
                        vaCurrentMonthIntentAccuracy: 0,
                        vaPreviousMonthIntentAccuracy: 0,
                        vaCurrentWeekIntentAccuracy: 0,
                        vaPreviousWeekIntentAccuracy: 0,
                        vaCurrentMonthCallHandled: 0,
                        vaPreviousMonthCallHandled: 0,
                        vaCurrentWeekCallHandled: 0,
                        vaPreviousWeekCallHandled: 0
                      }
                    ]
                  }
                ]
              }
            ]
          },
          virtualAgentTrendResponseObject: null,
          systemSlotKeys: null,
          count: null,
          languages: null,
          languageEngineMaps: null,
          channels: null,
          intentLanguageChannelMaps: null,
          intentSlots: null,
          entities: null,
          sessionData: null,
          organizationData: null,
          categoryData: null,
          userData: null,
          entityResponseObject: null,
          entityResponseObjectList: null,
          conversationPacks: null,
          conversationPack: null,
          loginPojo: null,
          data: null,
          intentSlotRichCardTemplates: null,
          intentResponseRichCardTemplates: null,
          errorBody: null,
          audioData: null
        }
      );
    }    else {
      return Observable.of({
        errorBody: {}
      });
    }

  }

  public dashboardChart(params1: any, params2: any): Observable<any> {
    if (params2.graphType === 'month') {
      return of(
        [
          {
          status: 200,
          message: 'Reports retrieved successfully',
          data: {
            trenddata: [
              {
                currenweekintentaccuracy: 0,
                lastweekintentaccuracy: 0,
                currenweekcallaccuracy: 0,
                lastweekcallaccuracy: 0,
                vrmId: 1,
                channelId: 2,
                langEngId: 1
              },
              {
                currenweekintentaccuracy: 0,
                lastweekintentaccuracy: 0,
                currenweekcallaccuracy: 0,
                lastweekcallaccuracy: 0,
                vrmId: 1,
                channelId: 2,
                langEngId: 11
              },

            ]
          }
        },
        {
          status: 200,
          message: 'Reports retrieved successfully',
          data: {
            trenddata: [

              {
                currenweekintentaccuracy: 0,
                lastweekintentaccuracy: 0,
                currenweekcallaccuracy: 0,
                lastweekcallaccuracy: 0,
                vrmId: 1,
                channelId: 2,
                langEngId: 1
              },
              {
                currenweekintentaccuracy: 0,
                lastweekintentaccuracy: 0,
                currenweekcallaccuracy: 0,
                lastweekcallaccuracy: 0,
                vrmId: 1,
                channelId: 2,
                langEngId: 11
              }
            ]
          }
        }
        ]
      );
    }    else {
      return Observable.of({
        errorBody: {}
      });
    }

  }

  public getVATrandData(params1: any, params2: any): Observable<any> {
    if (params2.graphType === 'month') {
      return of(
        [
          {
            status: 200,
            message: 'Reports retrieved successfully',
            data:
            {
              trenddata:
                [[
                  {
                    startdate: '2020-04-30',
                    trendvalue: 63.35
                  },
                  {
                    startdate: '2020-05-01',
                    trendvalue: 0
                  }
                ]],
              callhandingdata:
                [[
                  {
                    startdate: '2020-04-30',
                    trendvalue: 63.35
                  },
                  {
                    startdate: '2020-05-01',
                    trendvalue: 0
                  }
                ]]
            }
          },
          {
            status: 200,
            message: 'Reports retrieved successfully',
            data:
            {
              trenddata:
                [[{ startdate: '2020-05-04T00:00:00.000Z', enddate: '2020-05-04T23:59:59.059Z', trendvalue: 0 },

                { startdate: '2020-05-05T00:00:00.000Z', enddate: '2020-05-05T23:59:59.059Z', trendvalue: 0 },
                { startdate: '2020-05-06T00:00:00.000Z', enddate: '2020-05-06T23:59:59.059Z', trendvalue: 0 }
                ]],
              callhandingdata:
                [[{ startdate: '2020-05-04T00:00:00.000Z', enddate: '2020-05-04T23:59:59.059Z', trendvalue: 0 },
                { startdate: '2020-05-05T00:00:00.000Z', enddate: '2020-05-05T23:59:59.059Z', trendvalue: 0 },
                { startdate: '2020-05-06T00:00:00.000Z', enddate: '2020-05-06T23:59:59.059Z', trendvalue: 0 }]
                ]
            }
          }
        ]
      );
    }    else {
      return Observable.of({
        errorBody: {}
      });
    }

  }

}

class AuthenticationServiceStub {
  getCurrentUserId() {
      return 1;
  }
}

// class MockRouter {
//   navigateByUrl(url: string) { return url; }
// }

describe('AgentListComponent', () => {

  let component: AgentListComponent;
  let fixture: ComponentFixture<AgentListComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: AgentListService, useClass: AgentListServiceStub },
        { provide: AuthenticationService, useClass: AuthenticationServiceStub },
        // { provide: Router, useClass: MockRouter },
      ],
      declarations: [AgentListComponent],
      imports: [FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        RouterTestingModule],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('check methods', () => {
    component.toggleLiveAgentGraphs(1);
    expect(component.liveAgentList[1].showTrand).toBe(true);

    component.toggleLiveAgentGraphs(1);
    expect(component.liveAgentList[1].showTrand).toBe(false);

    component.changeLiveDataTime('wtd', 1);
    expect(component.liveAgentList[1].dataTime).toBe('wtd');

    expect(component.calculateIncreasePercent(200, 100)).toBe(100);

    component.changeLiveDataTime('mtd', 1);
    expect(component.liveAgentList[1].dataTime).toBe('mtd');

    component.showLiveVA = false;
    component.toggleLiveVA();
    expect(component.showLiveVA).toBe(true);

    component.showTestVA = false;
    component.toggleTestVA();
    expect(component.showTestVA).toBe(true);
    component.filterChanged();
  });

  it('changeindex method calling', () => {
    const index = 1;
    component.changeindex(index);
    expect(component.hid).toEqual('newIndexVal');
  });

  it('changeStyleva method calling', () => {
    component.changeStyleva('1');
    expect(component.hid).toEqual('1');
  });

  it('should call method createIntent', () => {
    const router = TestBed.get(Router);
    const spy = spyOn(router, 'navigateByUrl');

    component.createIntent(1);
    expect(spy).toHaveBeenCalled();
  });

  it('should call method createIntent', () => {
    const value = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const result = component.trimVaname(value);
    expect(result).toEqual('ABCDEFGHIJKLMNOPQRST...');
  });

});

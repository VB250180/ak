import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
    selector: 'app-text-elipse',
    template: ' <span>{{trimmedData}}</span><span *ngIf="this.intentName.length > this.intentLength" class="hoverintentNameElips">{{this.intentName}}</span>'

})
export class TextElipsisComponent implements OnInit {
    @Input() intentName: any;
    @Input() intentLength: number;
    trimmedData: any;

    constructor() {
    }

    ngOnInit() {
        // console.log(this.intentName,this.intentName.length);
        // console.log(this.intentLength)

        if (this.intentName.length > this.intentLength) {
            this.trimmedData = this.intentName.substring(0, this.intentLength) + '...';
          }   else {
            this.trimmedData = this.intentName;
          }
    }






}

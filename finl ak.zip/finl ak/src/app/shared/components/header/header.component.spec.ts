import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderComponent } from './header.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';


class StorageStub {
  public setItem(key, value) { }

  public getItem(key) {
    console.log('$#@!', key);
    return false;
  }
}

class AuthenticationServiceStub {
  public logout() { }
}

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: Storage, useClass: StorageStub },
        { provide: AuthenticationService, useClass: AuthenticationServiceStub }
      ],
      declarations: [HeaderComponent],
      imports: [
        RouterTestingModule, FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   const logoutSpy = spyOn(component, 'logout');

  //   component.ngOnInit();

  //   expect(logoutSpy).toHaveBeenCalledTimes(0);
  // });

  // it('should call logout', () => {
  //   const logoutSpy = spyOn(TestBed.get(AuthenticationService), 'logout');

  //   component.logout();

  //   expect(logoutSpy).toHaveBeenCalled();
  // });

  // it('resetPasswordMethod should call navigate to reset page', () => {
  //   const navigateSpy = spyOn(TestBed.get(Router), 'navigate');

  //   component.resetPasswordMethod();

  //   expect(component.resetpass).toBeFalsy();
  //   expect(navigateSpy).toHaveBeenCalledWith(['/password/reset']);
  // });

});

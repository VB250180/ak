// import { Router } from '@angular/router';
// import { Location } from '@angular/common';
import { Component, OnInit, OnChanges, Input } from '@angular/core';
import { version } from '../../../../../package.json';
import { Router, ActivatedRoute } from '@angular/router';
import { environment as env } from '../../../../environments/environment';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { LocaleService } from 'src/app/core/services/locale/locale.service';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';
// import { ReportsService } from '../../reports/reports.service';
// import { Subscription } from 'rxjs';
declare var $: any;
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  public userId: string;
  resetpassword: FormGroup;

  simulatorBaseUrl: string;
  hide = true;
  loginLocale: any;
  forgotpassLocale: any;
  resetpassLocale: any;
  resetsuccesslocale: any;

  loginFormDisplay = true;
  forgetPasswordForm = false;
  loginFormResetEmial = false;
  forgetPasswordSuccessForm = false;
  loginformGroup: FormGroup;

  upperVal = /(.*[A-Z].*)/;
  charVal = /[@#$%^&+=]/;
  submitted: boolean;
  loading: boolean;
  error: '';
  returnUrl: string;
  errorMsg: string;
  userName: any;

  path = '';
  @Input() x = 0;
  @Input() y = 0;
  // showContent: any;
  public version: string = version;
  resetpass = true;
  resetPasswordSuccessful = false;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private locale: LocaleService,
    private route: ActivatedRoute,
    private authenticationService: AuthenticationService
  ) {
    this.loginLocale = this.locale.loginPage;
    this.forgotpassLocale = this.locale.forgotPasswordPage;
    this.resetpassLocale = this.locale.resetPasswordPage;
    this.resetsuccesslocale = this.locale.resetPasswordSuccessPage;
  }

  ngOnInit(): void {

    this.authenticationService.getCurrentUserName() != null ? this.userName = this.authenticationService.getCurrentUserName() : this.userName = '';

    $(document).ready(() => {
      $('.parent').hover(() => {
        $('.sub-nav').toggleClass('visible');
      });
    });

    $(document).ready(() => {
      $('.parent2').hover(() => {
        $('.sub-nav2').toggleClass('visible');
      });
    });

    if (!localStorage.getItem('currentUser')) {
      this.logout();
    }
  }


  logout() {
    this.authenticationService.logout();
  }

  resetPasswordMethod() {
    console.log('resetpassword');
    this.resetpass = false;
    this.router.navigate(['/password/reset']);
  }

}

import { Component, OnInit, Input, ViewChild, ElementRef, AfterViewChecked } from '@angular/core';

@Component({
  selector: 'app-va-chat-window',
  templateUrl: './va-chat-window.component.html',
  styleUrls: ['./va-chat-window.component.scss']
})
export class VaChatWindowComponent implements OnInit, AfterViewChecked {

  @Input() showEditView: boolean;
  @Input() showChatWindow: boolean;
  @Input() chatHistory;
  @ViewChild('scrollMe', { static: false }) private myScrollContainer: ElementRef;

  constructor() { }

  ngOnInit() {
  }

  ngAfterViewChecked() {
    this.scrollToBottom();
  }

  scrollToBottom(): void {
    try {
      this.myScrollContainer.nativeElement.scrollTop = this.myScrollContainer.nativeElement.scrollHeight;
    } catch (err) { }
  }

}

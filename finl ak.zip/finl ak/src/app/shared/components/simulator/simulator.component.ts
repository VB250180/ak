import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { Subscription } from 'rxjs';
import { VirtualDetailsService } from 'src/app/core/services/va-details/virtual-agent-details.service';

@Component({
  selector: 'app-simulator',
  templateUrl: './simulator.component.html',
  styleUrls: ['./simulator.component.scss']
})
export class SimulatorComponent implements OnInit, OnDestroy {

  showPopUp = false;
  showEditView = false;
  showChatWindow: boolean;
  selectionDetails;
  simulatorToken: string;
  sessionId: string;
  intentNumber = -1;
  intentStage = 0;
  initialSettingsDone: boolean;
  chatHistory = [];
  simulatorBaseUrl;
  requiredDataLoaded: boolean;
  previousIntentNumber: number;
  selectionDetailsUndefined = false;
  intentIdentifiedName = '';
  requiredDataLoadedSubscription: Subscription;
  currentUserSubjectSubscription: Subscription;
  createAuthenticationTokenSubscription: Subscription;
  initializeConversationSubscription: Subscription;
  sendMessageSubscription: Subscription;
  terminateConversationSubscription: Subscription;

  constructor(private virtualDetailsService: VirtualDetailsService) { }

  ngOnInit() {
    this.initialSettingsDone = false;
    this.showChatWindow = false;
    this.requiredDataLoadedSubscription = this.virtualDetailsService.requiredDataLoaded.subscribe(response => {
      this.requiredDataLoaded = response;
      this.simulatorBaseUrl = this.virtualDetailsService.getSimulatorBaseUrl();
    });
    this.currentUserSubjectSubscription = this.virtualDetailsService.currentAgentLoaded.subscribe(agentDetails => {
      if (agentDetails && agentDetails.vrmAgentDetails && agentDetails.vrmAgentDetails.isNluConfigured) {
        this.selectionDetails = agentDetails;
        this.selectionDetailsUndefined = true;
        this.showEditView = true;
      }
    });
  }

  togglePopUp() {
    this.showPopUp = !this.showPopUp;
  }

  editClicked() {
    this.showEditView = true;
  }

  onEditCancelClicked() {
    this.showEditView = false;
  }

  onDoneClicked(event) {
    if (this.selectionDetailsUndefined) {
      this.selectionDetailsUndefined = false;
      this.selectionDetails = undefined;
    }
    if (this.selectionDetails !== undefined && this.selectionDetails.hasOwnProperty('vrmAgentDetails')
      && (this.selectionDetails['vrmAgentDetails'].vrmId !== event['vrmAgentDetails'].vrmId
        || this.selectionDetails['vrmAgentChannelDetails'].channelId !== event['vrmAgentChannelDetails'].channelId)) {
      this.terminateConversation(this.sessionId, this.simulatorToken, this.selectionDetails.vrmAgentChannelDetails.virtualAgentRoleChannelMapId);
      this.selectionDetails = event;
      this.showEditView = false;
      this.intentNumber = -1;
      this.intentStage = 0;
      this.chatHistory = [];
      this.createAuthenticationToken();
    } else if (this.selectionDetails !== undefined && this.selectionDetails.hasOwnProperty('vrmAgentDetails')
      && this.selectionDetails['vrmAgentDetails'].vrmId === event['vrmAgentDetails'].vrmId
      && this.selectionDetails['vrmAgentChannelDetails'].channelId === event['vrmAgentChannelDetails'].channelId) {
      this.selectionDetails = event;
      this.showEditView = false;
    } else if (this.selectionDetails === undefined) {
      this.selectionDetails = event;
      this.showEditView = false;
      this.createAuthenticationToken();
    }
  }

  createAuthenticationToken() {
    this.createAuthenticationTokenSubscription = this.virtualDetailsService
      .createAuthenticationToken(this.simulatorBaseUrl,
        this.selectionDetails.vrmAgentChannelDetails.virtualAgentRoleChannelMapId, this.selectionDetails.vrmAgentChannelDetails.key).subscribe(data => {
          if (data['errorBody'] === null && data.hasOwnProperty('jwtResponse')
            && data['jwtResponse'].hasOwnProperty('token')) {
            this.simulatorToken = data['jwtResponse'].token;
            this.initializeConversation();
          } else {
            this.showChatWindow = true;
            this.initialSettingsDone = false;
            const chatResponse = {
              user: 'server',
              message: 'System is facing some problem. Please contact customer care in case of any enquries',
              isClientView: false
            };
            this.chatHistory.push(chatResponse);
          }
        });
  }

  initializeConversation() {
    this.initializeConversationSubscription = this.virtualDetailsService
      .initializeConversation(this.simulatorBaseUrl,
        this.selectionDetails.vrmAgentChannelDetails.virtualAgentRoleChannelMapId, this.simulatorToken)
      .subscribe(session => {
        if (session['errorBody'] === null && session.hasOwnProperty('sessionId')) {
          this.sessionId = session['sessionId'];
          this.initialSettingsDone = true;
          this.showChatWindow = true;
        } else {
          this.showChatWindow = true;
          this.initialSettingsDone = false;
          const chatResponse = {
            user: 'server',
            message: 'System is facing some problem. Please contact customer case in case of any enquries',
            isClientView: false
          };
          this.chatHistory.push(chatResponse);
        }
      });
  }

  sendMessage(message) {
    let chatResponse = {};
    const data = {
      intentNumber: this.intentNumber,
      intentStage: this.intentStage,
      language: this.selectionDetails.vrmAgentLanguageDetails,
      sessionId: this.sessionId,
      token: this.simulatorToken,
      url: this.simulatorBaseUrl,
      userRequest: message,
      virtualAgentRoleChannelMapId: this.selectionDetails.vrmAgentChannelDetails.virtualAgentRoleChannelMapId
    };
    if (message !== '') {
      const chatData = {
        user: 'client',
        // tslint:disable-next-line: object-literal-shorthand
        message: message,
        isClientView: true
      };
      this.chatHistory.push(chatData);
    }
    this.sendMessageSubscription = this.virtualDetailsService.sendMessage(data).subscribe(response => {
      if (response['errorBody'] === null) {
        this.intentNumber = response['conversationResponsePojo'].intentNumber;
        this.intentStage = response['conversationResponsePojo'].intentStage;
        if (message === '') {
          this.initialSettingsDone = true;
        }
        if (response['conversationResponsePojo'].responseCode === 200 && (response['conversationResponsePojo'].responseType === 'text' || response['conversationResponsePojo'].responseType === 'TEXT')) {
          if (response['conversationResponsePojo'].intentName != null) {
            if (this.previousIntentNumber === undefined) {
              this.intentIdentifiedName = response['conversationResponsePojo'].intentName;
              this.previousIntentNumber = this.intentNumber;
              const intentData = {
                user: 'server',
                isClientView: false,
                intentName: response['conversationResponsePojo'].intentName
              };
              this.chatHistory.push(intentData);
            }  else if (this.intentIdentifiedName !== response['conversationResponsePojo'].intentName) {
              this.intentIdentifiedName = response['conversationResponsePojo'].intentName;
              const intentData = {
                user: 'server',
                isClientView: false,
                intentName: response['conversationResponsePojo'].intentName
              };
              this.chatHistory.push(intentData);
            }
            console.log('chat history', this.chatHistory);
          }
          chatResponse = {
            user: 'server',
            message: response['conversationResponsePojo'].responsetext,
            isClientView: false,
          };
        } else if (response['conversationResponsePojo'].responseCode === 200 && response['conversationResponsePojo'].responseType === 'RICHCARD') {
          chatResponse = {
            user: 'server',
            errorMessage: 'The Intent has a Rich card in the response structure. Request you to simulate the response via the web connector. Please contact Uniphore support for enabling the web connector layer which can be tested on a browser',
            isClientView: false
          };
        }  else {
          chatResponse = {
            user: 'server',
            errorMessage: response['conversationResponsePojo'].responseDesc,
            isClientView: false
          };
        }
        this.chatHistory.push(chatResponse);
        console.log('chat history1', this.chatHistory);
        if (response['conversationResponsePojo'].liveAgentTransfer) {
          this.initialSettingsDone = false;
          this.selectionDetails = undefined;
          this.showEditView = true;
        }
        if (response['conversationResponsePojo'].pingBack) {
          this.initialSettingsDone = false;
          this.sendMessage('');
        }
      } else {
        this.initialSettingsDone = false;
        chatResponse = {
          user: 'server',
          message: 'System is facing some problem. Please contact customer case in case of any enquries',
          isClientView: false
        };
        this.chatHistory.push(chatResponse);
      }

    });
  }

  terminateConversation(sessionId, token, virtualAgentRoleChannelMapId) {
    const data = {
      // tslint:disable-next-line: object-literal-shorthand
      sessionId: sessionId,
      // tslint:disable-next-line: object-literal-shorthand
      token: token,
      url: this.simulatorBaseUrl,
      // tslint:disable-next-line: object-literal-shorthand
      virtualAgentRoleChannelMapId: virtualAgentRoleChannelMapId
    };
    this.terminateConversationSubscription = this.virtualDetailsService
      .terminateConversation(data).subscribe( res => {
        console.log('successfully terminated session', res);
        this.chatHistory = [];
      });
  }

  ngOnDestroy() {
    if (this.currentUserSubjectSubscription) {
      this.currentUserSubjectSubscription.unsubscribe();
    }
    if (this.requiredDataLoadedSubscription) {
      this.requiredDataLoadedSubscription.unsubscribe();
    }
    if (this.createAuthenticationTokenSubscription) {
      this.createAuthenticationTokenSubscription.unsubscribe();
    }
    if (this.initializeConversationSubscription) {
      this.initializeConversationSubscription.unsubscribe();
    }
    if (this.sendMessageSubscription) {
      this.sendMessageSubscription.unsubscribe();
    }
    if (this.terminateConversationSubscription) {
      this.terminateConversationSubscription.unsubscribe();
    }

  }

}

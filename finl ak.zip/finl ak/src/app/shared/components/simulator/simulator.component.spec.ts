import { Observable, of, BehaviorSubject } from 'rxjs';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SimulatorComponent } from './simulator.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { VirtualDetailsService } from 'src/app/core/services/va-details/virtual-agent-details.service';

class VirtualDetailsServiceStub {

  requiredDataLoaded = new BehaviorSubject<boolean>(true);
  currentAgentLoaded = new BehaviorSubject<any>({ vrmAgentDetails: { isNluConfigured: true }, vrmAgentChannelDetails: { virtualAgentRoleChannelMapId: 1 } });

  public createAuthenticationToken(simulatorBaseUrl, virtualAgentRoleChannelMapId, vrmAgentChannelDetails) {
    if (virtualAgentRoleChannelMapId === 1) {
      return of({
        jwtResponse: {
          token: 'token'
        },
        errorBody: null
      });
    } else {
      return Observable.of({
        errorBody: {}
      });
    }
  }

  public initializeConversation(simulatorBaseUrl, virtualAgentRoleChannelMapId, vrmAgentChannelDetails) {
    if (virtualAgentRoleChannelMapId === 1) {
      return Observable.of({
        sessionId: 'ID',
        errorBody: null
      });
    } else {
      return Observable.of({
        errorBody: {}
      });
    }
  }

  public terminateConversation(data) {
    return Observable.of({});
  }

  public sendMessage(data) {
    if (data.virtualAgentRoleChannelMapId === 1) {
      return Observable.of({
        conversationResponsePojo: {
          responseType: 'text',
          intentNumber: 2,
          intentStage: 3,
          intentName: 'intentName',
          responseCode: 200,
          responsetext: 'text'
        },
        jwtResponse: {
          token: 'token'
        },
        sessionId: null,
        errorBody: null
      });
    } else if (data.virtualAgentRoleChannelMapId === 2) {
      return Observable.of({
        conversationResponsePojo: {
          responseType: 'text',
          intentNumber: 2,
          intentStage: 3,
          responseCode: 1001,
          responsetext: 'text',
          responseDesc: 'error text'
        },
        jwtResponse: {
          token: 'token'
        },
        sessionId: null,
        errorBody: null
      });
    } else if (data.virtualAgentRoleChannelMapId === 3) {
      return Observable.of({
        conversationResponsePojo: {
          responseType: 'text',
          intentNumber: 2,
          intentStage: 3,
          responseCode: 200,
          responsetext: 'text',
          responseDesc: 'error text',
          liveAgentTransfer: true
        },
        jwtResponse: {
          token: 'token'
        },
        sessionId: null,
        errorBody: null
      });
    } else if (data.virtualAgentRoleChannelMapId === 4) {
      return Observable.of({
        conversationResponsePojo: {
          responseType: 'RICHCARD',
          intentNumber: 2,
          intentStage: 3,
          responseCode: 200,
          responsetext: 'text',
          responseDesc: 'error text',
          liveAgentTransfer: false,
          pingBack: false
        },
        jwtResponse: {
          token: 'token'
        },
        sessionId: null,
        errorBody: null
      });
    } else {
      return Observable.of({
        errorBody: {}
      });
    }
  }

  public getSimulatorBaseUrl() {
    return 'url';
  }
}

describe('SimulatorComponent', () => {
  let component: SimulatorComponent;
  let fixture: ComponentFixture<SimulatorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: VirtualDetailsService, useClass: VirtualDetailsServiceStub }
      ],
      declarations: [SimulatorComponent],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SimulatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('ngOnInit should initialize initialSettingsDone and showChatWindow to false and showEditView to true', () => {

    component.ngOnInit();

    expect(component.showChatWindow).toBeFalsy();
    expect(component.initialSettingsDone).toBeFalsy();
    expect(component.requiredDataLoaded).toBeTruthy();
    expect(component.simulatorBaseUrl).toEqual('url');
    expect(component.showEditView).toBeTruthy();
  });

  it('togglePopUp should negate showPopUp variable', () => {
    component.showPopUp = false;

    component.togglePopUp();

    expect(component.showPopUp).toBeTruthy();
  });

  it('editClicked should set showEditView to true', () => {
    component.showEditView = false;

    component.editClicked();

    expect(component.showEditView).toBeTruthy();
  });

  it('onEditCancelClicked should negate showPopUp variable', () => {
    component.showEditView = true;

    component.onEditCancelClicked();

    expect(component.showEditView).toBeFalsy();
  });

  it('onDoneClicked should set selectionDetails and call createAuthenticationToken method', () => {
    const createAuthenticationTokenSpy = spyOn(component, 'createAuthenticationToken');
    const event = {
      vrmAgentChannelDetails: {
        virtualAgentRoleChannelMapId: 0,
        key: ''
      }
    };
    component.selectionDetailsUndefined = true;

    component.onDoneClicked(event);

    expect(component.selectionDetails).toEqual(event);
    expect(component.showEditView).toBeFalsy();
    expect(createAuthenticationTokenSpy).toHaveBeenCalled();
  });

  it('onDoneClicked should not create a new session when only language is changed', () => {
    const createAuthenticationTokenSpy = spyOn(component, 'createAuthenticationToken');
    component.selectionDetailsUndefined = false;
    const event = {
      vrmAgentDetails: { vrmId: 1 },
      vrmAgentChannelDetails: {
        channelId: 1,
        key: '',
        virtualAgentRoleChannelMapId: 0
      },
      vrmAgentLanguageDetails: 'English'
    };
    component.selectionDetails = {
      vrmAgentDetails: { vrmId: 1 },
      vrmAgentChannelDetails: {
        channelId: 1,
        key: '',
        virtualAgentRoleChannelMapId: 0
      },
      vrmAgentLanguageDetails: 'French'
    };

    component.onDoneClicked(event);

    expect(component.selectionDetails).toEqual(event);
    expect(component.showEditView).toBeFalsy();
    expect(createAuthenticationTokenSpy).toHaveBeenCalledTimes(0);
  });

  it('onDoneClicked should create new session when channel is changed', () => {
    const createAuthenticationTokenSpy = spyOn(component, 'createAuthenticationToken');
    component.selectionDetailsUndefined = false;
    const event = {
      vrmAgentDetails: { vrmId: 1 },
      vrmAgentChannelDetails: {
        channelId: 1,
        key: '',
        virtualAgentRoleChannelMapId: 0
      },
      vrmAgentLanguageDetails: 'English'
    };
    component.selectionDetails = {
      vrmAgentDetails: { vrmId: 1 },
      vrmAgentChannelDetails: {
        channelId: 2,
        key: '',
        virtualAgentRoleChannelMapId: 0
      },
      vrmAgentLanguageDetails: 'English'
    };

    component.onDoneClicked(event);

    expect(component.selectionDetails).toEqual(event);
    expect(component.showEditView).toBeFalsy();
    expect(component.intentNumber).toEqual(-1);
    expect(component.intentStage).toEqual(0);
    expect(component.chatHistory).toEqual([]);
    expect(createAuthenticationTokenSpy).toHaveBeenCalled();
  });

  it('onDoneClicked should create new session when VA is changed', () => {
    const createAuthenticationTokenSpy = spyOn(component, 'createAuthenticationToken');
    component.selectionDetailsUndefined = false;
    const event = {
      vrmAgentDetails: { vrmId: 1 },
      vrmAgentChannelDetails: {
        channelId: 1,
        key: '',
        virtualAgentRoleChannelMapId: 0
      },
      vrmAgentLanguageDetails: 'English'
    };
    component.selectionDetails = {
      vrmAgentDetails: { vrmId: 2 },
      vrmAgentChannelDetails: {
        channelId: 1,
        key: '',
        virtualAgentRoleChannelMapId: 0
      },
      vrmAgentLanguageDetails: 'English'
    };

    component.onDoneClicked(event);

    expect(component.selectionDetails).toEqual(event);
    expect(component.showEditView).toBeFalsy();
    expect(component.intentNumber).toEqual(-1);
    expect(component.intentStage).toEqual(0);
    expect(component.chatHistory).toEqual([]);
    expect(createAuthenticationTokenSpy).toHaveBeenCalled();
  });

  it('createAuthenticationToken should set token and call initializeConversation method', () => {
    const initializeConversationSpy = spyOn(component, 'initializeConversation');
    component.selectionDetails = {
      vrmAgentChannelDetails: {
        virtualAgentRoleChannelMapId: 1,
        key: ''
      }
    };

    component.createAuthenticationToken();

    expect(component.simulatorToken).toEqual('token');
    expect(initializeConversationSpy).toHaveBeenCalled();
  });

  it('createAuthenticationToken should set showChatWindow to true and not call initializeConversation method', () => {
    const initializeConversationSpy = spyOn(component, 'initializeConversation');
    component.selectionDetails = {
      vrmAgentChannelDetails: {
        virtualAgentRoleChannelMapId: 0,
        key: ''
      }
    };
    const chatResponse = {
      user: 'server',
      message: 'System is facing some problem. Please contact customer care in case of any enquries',
      isClientView: false
    };

    component.createAuthenticationToken();

    expect(component.showChatWindow).toBeTruthy();
    expect(component.initialSettingsDone).toBeFalsy();
    expect(component.chatHistory).toContain(chatResponse);
    expect(initializeConversationSpy).toHaveBeenCalledTimes(0);
  });

  it('initializeConversation should set session and make showChatWindow, initialSettingsDone true', () => {
    component.selectionDetails = {
      vrmAgentChannelDetails: {
        virtualAgentRoleChannelMapId: 1,
        key: ''
      }
    };

    component.initializeConversation();

    expect(component.sessionId).toEqual('ID');
    expect(component.initialSettingsDone).toBeTruthy();
    expect(component.showChatWindow).toBeTruthy();
  });

  it('initializeConversation should set showChatWindow to true and not call initializeConversation method', () => {
    component.selectionDetails = {
      vrmAgentChannelDetails: {
        virtualAgentRoleChannelMapId: 0,
        key: ''
      }
    };
    const chatResponse = {
      user: 'server',
      message: 'System is facing some problem. Please contact customer case in case of any enquries',
      isClientView: false
    };

    component.initializeConversation();

    expect(component.showChatWindow).toBeTruthy();
    expect(component.initialSettingsDone).toBeFalsy();
    expect(component.chatHistory).toContain(chatResponse);
  });

  it('sendMessage should set initialSettingsDone to false and create chat error response', () => {
    const message = '';
    component.selectionDetails = {
      vrmAgentChannelDetails: {
        virtualAgentRoleChannelMapId: 0,
        key: ''
      }
    };
    const chatResponse = {
      user: 'server',
      message: 'System is facing some problem. Please contact customer case in case of any enquries',
      isClientView: false
    };

    component.sendMessage(message);

    expect(component.initialSettingsDone).toBeFalsy();
    expect(component.chatHistory).toContain(chatResponse);
  });

  it('sendMessage should set chatHistory with correct respone on API responseCode 200', () => {
    const message = 'Hi Akeira';
    component.selectionDetails = {
      vrmAgentChannelDetails: {
        virtualAgentRoleChannelMapId: 1,
        key: ''
      }
    };
    const chatClientRequest = {
      user: 'client',
      message: 'Hi Akeira',
      isClientView: true
    };

    const intentData = {
      user: 'server',
      isClientView: false,
      intentName: 'intentName'
    };

    const chatServerResponse = {
      user: 'server',
      message: 'text',
      isClientView: false
    };

    component.sendMessage(message);

    expect(component.intentNumber).toEqual(2);
    expect(component.intentStage).toEqual(3);
    expect(component.chatHistory).toEqual([chatClientRequest, intentData, chatServerResponse]);
  });

  it('sendMessage should set chatHistory with error respone on API responseCode other than 200', () => {
    const message = 'Hi Akeira';
    component.selectionDetails = {
      vrmAgentChannelDetails: {
        virtualAgentRoleChannelMapId: 2,
        key: ''
      }
    };
    const chatClientRequest = {
      user: 'client',
      message: 'Hi Akeira',
      isClientView: true
    };
    const chatServerResponse = {
      user: 'server',
      errorMessage: 'error text',
      isClientView: false
    };

    component.sendMessage(message);

    expect(component.intentNumber).toEqual(2);
    expect(component.intentStage).toEqual(3);
    expect(component.chatHistory).toEqual([chatClientRequest, chatServerResponse]);
  });

  it('sendMessage should initialize initialSettingsDone to false and showEditView to true if liveAgentTransfer is true in API response', () => {
    const message = 'Hi Akeira';
    component.selectionDetails = {
      vrmAgentChannelDetails: {
        virtualAgentRoleChannelMapId: 3,
        key: ''
      }
    };
    const chatClientRequest = {
      user: 'client',
      message: 'Hi Akeira',
      isClientView: true
    };
    const chatServerResponse = {
      user: 'server',
      message: 'text',
      isClientView: false
    };

    component.sendMessage(message);

    expect(component.intentNumber).toEqual(2);
    expect(component.intentStage).toEqual(3);
    expect(component.chatHistory).toEqual([chatClientRequest, chatServerResponse]);
    expect(component.initialSettingsDone).toBeFalsy();
    expect(component.selectionDetails).toEqual(undefined);
    expect(component.showEditView).toBeTruthy();
  });

  it('sendMessage should initialize initialSettingsDone to false and call sendMessage again if pingBack is true in API response', () => {
    // const sendMessageSpy = spyOn(component, 'sendMessage');
    const message = 'Hi Akeira';
    component.selectionDetails = {
      vrmAgentChannelDetails: {
        virtualAgentRoleChannelMapId: 4,
        key: ''
      }
    };
    const chatClientRequest = {
      user: 'client',
      message: 'Hi Akeira',
      isClientView: true
    };
    const chatServerResponse = {
      user: 'server',
      errorMessage: 'The Intent has a Rich card in the response structure. Request you to simulate the response via the web connector. Please contact Uniphore support for enabling the web connector layer which can be tested on a browser',
      isClientView: false
    };

    component.sendMessage(message);

    expect(component.intentNumber).toEqual(2);
    expect(component.intentStage).toEqual(3);
    expect(component.chatHistory).toEqual([chatClientRequest, chatServerResponse]);
    expect(component.initialSettingsDone).toBeFalsy();
    // expect(sendMessageSpy).toHaveBeenCalledTimes(2);
  });

  it('terminateConversation should terminate service', () => {
    const sessionId = 'ID';
    const token = 'token';
    const virtualAgentRoleChannelMapId = 1;

    component.terminateConversation(sessionId, token, virtualAgentRoleChannelMapId);

    expect(component).toBeTruthy();
  });
});

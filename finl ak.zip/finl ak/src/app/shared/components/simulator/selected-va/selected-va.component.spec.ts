import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectedVaComponent } from './selected-va.component';

describe('SelectedVaComponent', () => {
  let component: SelectedVaComponent;
  let fixture: ComponentFixture<SelectedVaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SelectedVaComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectedVaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('onEditClick should emit an event if requiredDataLoaded is true', () => {
    const editClickedSpy = spyOn(component.editClicked, 'emit');
    component.requiredDataLoaded = true;

    component.onEditClick();

    expect(editClickedSpy).toHaveBeenCalled();
  });

  it('onEditClick should not emit an event if requiredDataLoaded is false', () => {
    const editClickedSpy = spyOn(component.editClicked, 'emit');
    component.requiredDataLoaded = false;

    component.onEditClick();

    expect(editClickedSpy).toHaveBeenCalledTimes(0);
  });

  it('ngOnChanges should reduce the name length if the string length is greater than 15', () => {
    component.selectionDetails = {
      vrmAgentDetails: {
        vrmName: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
      }
    };
    const changes = {
      selectionDetails: {}
    };

    component.ngOnChanges(changes);

    expect(component.vrmFullName).toEqual('ABCDEFGHIJKLMNOPQRSTUVWXYZ');
    expect(component.displayVrmName).toEqual('ABCDEFGHIJKLM...');
  });

  it('ngOnChanges should not reduce the name length if the string length is less than 15', () => {
    component.selectionDetails = {
      vrmAgentDetails: {
        vrmName: 'ABCDEFGHIJKLM'
      }
    };
    const changes = {
      selectionDetails: {}
    };

    component.ngOnChanges(changes);

    expect(component.vrmFullName).toEqual('ABCDEFGHIJKLM');
    expect(component.displayVrmName).toEqual('ABCDEFGHIJKLM');
  });
});

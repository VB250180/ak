import { Component, OnInit, Output, EventEmitter, Input, OnChanges } from '@angular/core';

@Component({
  selector: 'app-selected-va',
  templateUrl: './selected-va.component.html',
  styleUrls: ['./selected-va.component.scss']
})
export class SelectedVaComponent implements OnInit, OnChanges {

  @Input() selectionDetails;
  @Input() requiredDataLoaded: boolean;
  @Output() editClicked = new EventEmitter();
  displayVrmName: string;
  vrmFullName: string;

  constructor() { }


  ngOnInit() {
  }

  ngOnChanges(changes) {
    if (changes.hasOwnProperty('selectionDetails') && this.selectionDetails
      && this.selectionDetails.vrmAgentDetails.vrmName.length > 15) {
      this.vrmFullName = this.selectionDetails.vrmAgentDetails.vrmName;
      this.displayVrmName = this.selectionDetails.vrmAgentDetails.vrmName.substring(0, 13).concat('...');
    } else if (this.selectionDetails) {
      this.vrmFullName = this.selectionDetails.vrmAgentDetails.vrmName;
      this.displayVrmName = this.selectionDetails.vrmAgentDetails.vrmName;
    }
  }

  onEditClick() {
    if (this.requiredDataLoaded) {
      this.editClicked.emit(true);
    }
  }

}

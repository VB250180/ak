import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalComponent } from './modal.component';
import { MatDialogModule, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, Component } from '@angular/core';
import { OverlayContainer } from '@angular/cdk/overlay';

class MatDialogRefStub {
  public close(value) { }
}

describe('ModalComponent', () => {
  let component: ModalComponent;
  let fixture: ComponentFixture<ModalComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalComponent ],
      providers: [
        { provide: MatDialogRef, useClass: MatDialogRefStub },
        { provide: MAT_DIALOG_DATA, useValue: {} }
      ]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('onMapIntent should cloase the modal with true', () => {
    const spy = spyOn(TestBed.get(MatDialogRef), 'close');

    component.onPrimaryBtnClicked();

    expect(spy).toHaveBeenCalledWith(true);
  });

  it('OnCancel should cloase the modal with false', () => {
    const spy = spyOn(TestBed.get(MatDialogRef), 'close');

    component.onCancellClicked();

    expect(spy).toHaveBeenCalledWith(false);
  });

  it('onMapIntent should cloase the modal with closed warn err', () => {
    const spy = spyOn(TestBed.get(MatDialogRef), 'close');

    component.onOkClicked();

    expect(spy).toHaveBeenCalledWith('closed warn err');
  });

  it('OnCancel should cloase the modal with secondary', () => {
    const spy = spyOn(TestBed.get(MatDialogRef), 'close');

    component.onClickOfSecondary();

    expect(spy).toHaveBeenCalledWith('secondary');
  });

});

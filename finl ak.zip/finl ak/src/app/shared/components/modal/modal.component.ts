import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss']
})
export class ModalComponent implements OnInit {

  /*

    Inject  private matDialog: MatDialog in constructor in the required component.
    Should use below code to open the modal from the required component.
    hasCancellBtn should be true if Cancell btn should be present in the modal.
    hasPrimaryBtn should be true if a btn should be present in the modal with green background.
    if hasPrimaryBtn is set to true, then primaryBtnText should be provided.
    popUpType can be set to info alert and warning based on requirement.

  */


  // const dialogConfig = new MatDialogConfig();
  //   dialogConfig.disableClose = true;
  //   dialogConfig.width = "800px";
  //   dialogConfig.data = {
  //     primaryText: 'Hello, How are you',
  //     secondaryText: 'Im fine thank you!',
  //     hasPrimaryBtn: true,
  //     primaryBtnText: 'Save',
  //     popUpType: 'warning',
  //     hasCancelBtn: true
  //   };
  //   const modalDialog = this.matDialog.open(ModalComponent, dialogConfig);
  //   modalDialog.afterClosed().subscribe(data => {
  //     console.log('material data', data);
  //   });


  constructor(
    public dialogRef: MatDialogRef<ModalComponent>,
    @Inject(MAT_DIALOG_DATA) public modalData: any
  ) { }

  ngOnInit() {
  }

  onPrimaryBtnClicked() {
    this.dialogRef.close(true);
  }

  onCancellClicked() {
    this.dialogRef.close(false);
  }

  onClickOfSecondary() {
    this.dialogRef.close('secondary');
  }

  onOkClicked() {
    this.dialogRef.close('closed warn err');
  }
}

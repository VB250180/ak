
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormControl, Validators, FormGroup, FormBuilder } from '@angular/forms';
import { version } from '../../../../../package.json';
// import { AppService } from '../../app.service';
import { Router, ActivatedRoute } from '@angular/router';
import { LocaleService } from 'src/app/core/services/locale/locale.service';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { first } from 'rxjs/operators';
import { BehaviorSubject, Subscription } from 'rxjs';
import { User } from 'src/app/core/models/user/user.model';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {
  hide = true;
  loginLocale: any;
  forgotpassLocale: any;
  resetpassLocale: any;
  resetsuccesslocale: any;

  loginFormDisplay = true;
  forgetPasswordForm = false;
  loginFormResetEmial = false;
  forgetPasswordSuccessForm = false;
  invalidCredentials = false;
  loginformGroup: FormGroup;
  resetpassword: FormGroup;

  upperVal = /(.*[A-Z].*)/;
  charVal = /[@#$%^&+=]/;
  submitted: boolean;
  loading: boolean;
  error: '';
  returnUrl: string;
  errorMsg: string;
  forgotpasswordformGroup: FormGroup;
  errorMsgName: any;
  btnReset: any;
  public version: string = version;

  private currentUserSubject: BehaviorSubject<User>;
  public currentUser: Observable<User>;
  loginSubscription: Subscription;
  loginDiffBrowserSubscription: Subscription;
  forgotPasswordSubscription: Subscription;

  constructor(private formBuilder: FormBuilder, private router: Router, private matDialog: MatDialog,
              private locale: LocaleService, private route: ActivatedRoute, private authenticationService: AuthenticationService) {
    this.loginLocale = this.locale.loginPage;
    this.forgotpassLocale = this.locale.forgotPasswordPage;
    this.resetpassLocale = this.locale.resetPasswordPage;
    this.resetsuccesslocale = this.locale.resetPasswordSuccessPage;


    if (this.authenticationService.currentUserValue) {
      this.router.navigate(['/login']);
    }
  }

  ngOnInit() {

    this.returnUrl = '/';
    this.createForm();
    this.createResetPasswordForm();
    this.forgotPasswrodForm();
    // get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/login';
  }

  ngOnDestroy() {
    if (this.loginSubscription) {
      this.loginSubscription.unsubscribe();
    }
    if (this.loginDiffBrowserSubscription) {
      this.loginDiffBrowserSubscription.unsubscribe();
    }
    if (this.forgotPasswordSubscription) {
      this.forgotPasswordSubscription.unsubscribe();
    }
  }

  createForm() {
    this.loginformGroup = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  createResetPasswordForm() {
    this.resetpassword = this.formBuilder.group({
      newpass: ['', [Validators.required, Validators.minLength(8), Validators.pattern(/^(?=.{8,})(?=.*[A-Z])(?=.*[@#$%^&+!*()=]).*$/)]],
      confirmpass: ['', [Validators.required, Validators.minLength(8), Validators.pattern(/^(?=.{8,})(?=.*[A-Z])(?=.*[@#$%^&+!*()=]).*$/)]],
    }, {
      validator: MustMatch('newpass', 'confirmpass')
    });
  }

  forgotPasswrodForm() {
    this.forgotpasswordformGroup = this.formBuilder.group({
      // tslint:disable-next-line: object-literal-key-quotes
      'username': ['', Validators.required],
    });
  }


  getError(el) {
    switch (el) {
      case 'user':
        if (this.loginformGroup.get('username').hasError('required')) {
          return 'This field is required';
        }
        break;
      case 'pass':
        if (this.loginformGroup.get('password').hasError('required')) {
          return 'This field is required';
        }
        break;
      default:
        return '';
    }
  }


  onSubmit(value, event) {
    event.preventDefault();
    this.submitted = true;
    // stop here if form is invalid
    if (this.loginformGroup.invalid) {
      return;
    }

    this.loading = true;
    this.loginSubscription = this.authenticationService.login(value.username, value.password)
      .pipe(first())
      .subscribe(
        data => {
          console.log(data);
          if (data && data.loginPojo != null) {
            // store user details and jwt token in local storage to keep user logged in between page refreshes
            localStorage.setItem('currentUser', JSON.stringify(data.loginPojo));

            if (data.loginPojo.jwToken === 'Password Reset') {
              this.router.navigate(['/password/reset']);
              console.log('data');
            } else {
              this.authenticationService.currentUserSubject.next(data.loginPojo);
              this.router.navigate(['/dashboard/agent-list']);
            }
          } else {
            data.errorBody.summary.indexOf('already') !== -1 ? this.openModal() : this.showErrMsg();
            console.log('error', this.errorMsg, data.errorBody.summary);
          }
          return data;
        },
        error => {
          this.error = error;
          this.loading = false;
        });
  }

  showErrMsg() {
    this.errorMsgName = 'Please enter a valid username and password';
    this.btnReset = 'Ok';
    this.invalidCredentials = true;
    this.forgetPasswordSuccessForm = false;
    this.loginFormResetEmial = false;
    this.loginFormDisplay = false;

    // this.errorMsg = 'Please enter a valid username and password';
    this.authenticationService.currentUserSubject.next(null);
  }

  directToLoginForm() {
    this.invalidCredentials = false;
    this.loginFormDisplay = true;
    this.loginformGroup.reset();
  }

  openModal() {
    console.log('open popup');
    const dialogConfigLoginDiffBrowser = new MatDialogConfig();
    dialogConfigLoginDiffBrowser.disableClose = true;
    dialogConfigLoginDiffBrowser.width = '800px';
    dialogConfigLoginDiffBrowser.data = {
      primaryText: 'You have logged in other browser. do you want to kill that session and log-in here',
      hasPrimaryBtn: true,
      primaryBtnText: 'Ok',
      popUpType: 'warn',
      hasCancelBtn: true,
      secondaryBtnText: 'Cancel'
    };

    const modalDialog = this.matDialog.open(ModalComponent, dialogConfigLoginDiffBrowser);
    modalDialog.afterClosed().subscribe(data => {
      console.log(data);
      if (data === true) {
        this.authenticationService.currentUserSubject.next(null);
        console.log('user wnats to login', this.loginformGroup.value);
        this.loginDiffBrowserSubscription = this.authenticationService.loginDiffBrowser(this.loginformGroup.value).subscribe(res => {
          console.log(res);
          if (res.loginPojo !== null) {
            console.log('new user', res);
            localStorage.setItem('currentUser', JSON.stringify(res.loginPojo));
            this.authenticationService.currentUserSubject.next(res.loginPojo);
            this.router.navigate(['/dashboard/agent-list']);
          }
        });
      } else {
        console.log('no user wants to stay in the same screen');
      }
    });
  }

  forgetPass() {
    this.loginFormDisplay = false;
    this.loginFormResetEmial = true;
    this.loginformGroup.reset();
    this.forgotpasswordformGroup.reset();
  }

  loginClose() {
    this.loginFormDisplay = true;
    this.loginFormResetEmial = false;
  }

  forgotClose() {
    this.loginFormDisplay = true;
    this.loginFormResetEmial = false;
    this.forgotpasswordformGroup.reset();
  }

  sendResetLink() {
    const username = this.forgotpasswordformGroup.value.username;
    console.log('username', this.forgotpasswordformGroup.value.username);
    this.forgotPasswordSubscription = this.authenticationService.forgotPassword(username).subscribe(res => {
      console.log('forgot passowrd', res);
      // this.router.navigateByUrl('/password/forgot?tokenId=');

      if (res['loginPojo'] != null) {
        this.errorMsgName = 'If account exists, an email will be sent with further instructions to reset the password.';
        this.btnReset = 'Ok';
        this.forgetPasswordSuccessForm = true;
        this.loginFormResetEmial = false;
        this.forgotpasswordformGroup.reset();
      } else if (res['errorBody'].summary.indexOf('invalid') !== -1) {
        this.errorMsgName = 'If account exists, an email will be sent with further instructions to reset the password.';
        this.btnReset = 'Ok';
        this.forgetPasswordSuccessForm = true;
        this.loginFormResetEmial = false;
      }
    });
    this.loginFormDisplay = false;
  }


  resetClose() {
    this.loginFormDisplay = true;
    this.loginFormResetEmial = false;
    this.forgetPasswordForm = false;
  }


  ResetSucess() {
    this.forgetPasswordForm = false;
    this.forgetPasswordSuccessForm = true;
  }

  redirectToForm() {
    if (this.btnReset === 'Ok') {
      this.loginformGroup.reset();
      this.redirectToLoginForm();
      this.forgotpasswordformGroup.reset();
    }
    // else if(this.btnReset == 'Login Again'){
    //   this.redirectToLoginForm();
    // }
  }

  redirectToResetForm() {
    this.loginFormResetEmial = true;
    this.loginFormDisplay = false;
    this.forgetPasswordSuccessForm = false;
  }

  redirectToLoginForm() {
    this.loginformGroup.reset();
    this.loginFormResetEmial = false;
    this.loginFormDisplay = true;
    this.forgetPasswordSuccessForm = false;
  }

}
// custom validator to check that two fields match
export function MustMatch(controlName: string, matchingControlName: string) {
  return (formGroup: FormGroup) => {
    const control = formGroup.controls[controlName];
    const matchingControl = formGroup.controls[matchingControlName];

    if (matchingControl.errors && !matchingControl.errors.mustMatch) {
      // return if another validator has already found an error on the matchingControl
      return;
    }

    // set error on matchingControl if validation fails
    if (control.value !== matchingControl.value) {
      matchingControl.setErrors({ mustMatch: true });
    } else {
      matchingControl.setErrors(null);
    }
  };
}

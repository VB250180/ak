import { Component, HostListener, OnDestroy } from '@angular/core';
// import {MatIconRegistry} from '@angular/material/icon';
// import {DomSanitizer} from '@angular/platform-browser';
import { NgModule, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgSelectModule, NgOption } from '@ng-select/ng-select';
import * as $ from 'jquery';
import { Router } from '@angular/router';
import { AuthenticationService } from './core/authentication/authentication.service';
import { User } from './core/models/user/user.model';
import { UserRole } from './core/models/user/role';
import { Subject, Subscription } from 'rxjs';
import { ModalComponent } from './shared/components/modal/modal.component';
import { VirtualDetailsService } from './core/services/va-details/virtual-agent-details.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})


export class AppComponent implements OnInit, OnDestroy {
  title = 'akeira';
  currentUser: User;
  simulatorBaseUrl: string;
  requiredDataLoaded = false;
  requiredDataLoadedSubscription: Subscription;
  currentUserSubjectSubscription: Subscription;
  currentUserSubscription: Subscription;
  getSimulatorDetailsSubscription: Subscription;

  userActivity;
  userInactive: Subject<any> = new Subject();

  constructor(public router: Router, private virtualDetailsService: VirtualDetailsService,
              private authenticationService: AuthenticationService) {
    // if (localStorage.getItem('currentUser') !== undefined && localStorage.getItem('currentUser') !== "undefined" && localStorage.getItem('currentUser') !== null) {
      this.currentUserSubscription = this.authenticationService.currentUser
        .subscribe(x => this.currentUser = x);
    // }

    // console.log(this.currentUser);

    // this.setTimeout();
    // this.userInactive.subscribe(() => console.log('user has been inactive for 10m'));
  }


  // @HostListener('window:mousemove') refreshUserState() {
  //   clearTimeout(this.userActivity);
  //   //this.setTimeout();
  // //   this.dialog.open(ModalComponent, {
  // //     disableClose: true, data: modalResponseSessionTimeOut
  // // });
  // }

  ngOnInit() {
    // if (localStorage.getItem('currentUser') !== undefined && localStorage.getItem('currentUser') !== "undefined" && localStorage.getItem('currentUser') !== null) {
      this.requiredDataLoadedSubscription = this.virtualDetailsService.requiredDataLoaded.subscribe(isLoaded => {
        this.requiredDataLoaded = isLoaded;
      });

      this.currentUserSubjectSubscription = this.authenticationService.currentUserSubject.subscribe(data => {
        if (data !== null && data.jwToken !== 'Password Reset') {
          this.getSimulatorDetailsSubscription = this.virtualDetailsService
            .getSimulatorDetails().subscribe(response => {
              if (response.hasOwnProperty('data') && response['data'] !== null) {
                this.simulatorBaseUrl = response['data'];
                this.authenticationService.setSimulatorBaseUrl(this.simulatorBaseUrl);
                this.virtualDetailsService.setSimulatorBaseUrl(this.simulatorBaseUrl);
              }
            });
          this.virtualDetailsService.getVirtualAgentsDetails();
        }
      });
    }
  // }

  get isAdmin() {
    return this.currentUser && this.currentUser.role === UserRole.Admin;
  }

  logout() {
    this.authenticationService.logout();
  }

  ngOnDestroy() {
    if (this.requiredDataLoadedSubscription) {
      this.requiredDataLoadedSubscription.unsubscribe();
    }
    if (this.currentUserSubjectSubscription) {
      this.currentUserSubjectSubscription.unsubscribe();
    }
    if (this.currentUserSubscription) {
      this.currentUserSubscription.unsubscribe();
    }
    if (this.getSimulatorDetailsSubscription) {
      this.getSimulatorDetailsSubscription.unsubscribe();
    }
  }


  // setTimeout() {
  //   this.userActivity = setTimeout(() => this.userInactive.next(undefined), 100000);
  // }

}

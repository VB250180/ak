import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, ErrorHandler } from '@angular/core';
import { NgSelectModule } from '@ng-select/ng-select';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatStepperModule } from '@angular/material/stepper';
import { MatFormFieldModule, MatInputModule, MatSelectModule, MatProgressBarModule, MatChipsModule, MatDialogModule } from '@angular/material';
import { MatMenuModule } from '@angular/material/menu';
import { NgxSpinnerModule } from 'ngx-spinner';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import { ModalModule, BsModalRef } from 'ngx-bootstrap/modal';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { MatRadioModule } from '@angular/material/radio';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ChartsModule } from 'ng2-charts';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { FilterPipe } from './filter.pipe';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { ToastrModule } from 'ngx-toastr';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { NgxCacheIfModule } from 'ngx-cache-if';
import { DebounceClickDirective } from './shared/directives/prevent-double-click.directive';
import { AnimateOnScrollModule } from 'ng2-animate-on-scroll';
import { MapModalComponent } from '../app/modules/assisted-training/map-modal/map-modal.component';
import { TagInputModule } from 'ngx-chips';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { ModalComponent } from './shared/components/modal/modal.component';
import { JwtInterceptor } from './core/interceptors/jwt.interceptor';
import { ErrorInterceptor } from './core/interceptors/error.interceptor';
import { HeaderComponent } from './shared/components/header/header.component';
import { LoginComponent } from './shared/components/login/login.component';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { SharedModule } from './shared.module';
import { TempalateComponent } from './modules/mocks/template.component';
import { GlobalErrorHandler } from './core/interceptors/global-error-handler';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FilterPipe,
    LoginComponent,
    TempalateComponent,
    // SearchFilterPipe,
    // AgentListComponent,
    DebounceClickDirective,
    MapModalComponent,
    ModalComponent,
    // IntentConflictModalComponent,
  ],
  imports: [
    BrowserModule,
    InfiniteScrollModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    MatSidenavModule,
    MatListModule,
    MatIconModule,
    MatGridListModule,
    MatStepperModule,
    MatMenuModule,
    MatChipsModule,
    NgSelectModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxSpinnerModule,
    AccordionModule.forRoot(),
    BsDropdownModule.forRoot(),
    NgxDaterangepickerMd.forRoot(),
    ModalModule.forRoot(),
    PopoverModule.forRoot(),
    NgMultiSelectDropDownModule.forRoot(),
    MatRadioModule,
    MatSlideToggleModule,
    ChartsModule,
    MatProgressBarModule,
    PopoverModule.forRoot(),
    Ng2SmartTableModule,
    ScrollingModule,
    DragDropModule,
    ToastrModule.forRoot({ timeOut: 3000, preventDuplicates: false }),
    TooltipModule.forRoot(),
    NgxCacheIfModule,
    AnimateOnScrollModule.forRoot(),
    TagInputModule,
    NgxChartsModule,
    SharedModule
  ],

  schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
  entryComponents: [
    MapModalComponent,
    ModalComponent,
    // IntentConflictModalComponent,
  ],
  providers: [BsModalRef,
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    { provide: ErrorHandler, useClass: GlobalErrorHandler },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  // apiUrl:'http://unilp081:8081', //development
  // apiUrl: 'http://10.7.138.226:8081', //Praveen
  // apiUrl: 'http://10.7.138.249:8082',
  // apiUrl: 'http://192.168.12.63:8081',
  // apiUrl: 'http://10.7.138.142:8083',
  // apiUrl:'http://10.7.138.213:8081',p
  // apiUrl:'http://localhost:8081'
  // apiUrl: 'http://172.16.15.10:8081', //Akeira server
  // apiUrl: 'http://10.7.138.142:8083',//Prem anna laptop
  // apiUrl: 'http://3.20.208.15:9902', //AWS Testing Env
  // apiUrl: 'http://10.7.138.238:8083',
  apiUrl: 'http://18.219.46.237:9902',  // AWS DEV Env
  // apiUrl : 'https://akeirademo.uniphore.com:9918',
  //  nodeapiUrl : 'http://3.20.168.149:8080'
  nodeapiUrl: 'http://18.221.207.166:9907', // nodejs testing env
  nodeapiToken: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI1ZTk0NDRjZjRiODJmZTExNDhhMzg2YTUiLCJpYXQiOjE1ODcwMjAwNTd9.qF6aOoJbFw4QGM-F81jhF7wATqF6f0D_XYbNlozNdPQ'
};


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.

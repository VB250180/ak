export const environment = {
  // apiUrl: 'http://10.7.138.249:8082', //Tetsing
  // apiUrl: 'http://localhost:9000', //localhost
  // apiUrl: 'http://192.168.12.63:8082', //63
  // apiUrl: 'http://172.16.15.10:9000',//ctrlS-172-10
  // apiUrl: 'http://10.7.138.226:8081', //Praveen
  // apiUrl: 'http://3.20.208.15:9902', //AWS Testing Env
  apiUrl: 'https://akeirademo.uniphore.com:9902', // dev aws
  // nodeapiUrl : 'http://3.20.168.149:8080',
  nodeapiUrl: 'https://akeirademo.uniphore.com:9907', // dev aws
  // nodeapiUrl : 'http://3.20.208.15:8080', //nodejs testing env
  nodeapiToken : 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI1ZTk0NDRjZjRiODJmZTExNDhhMzg2YTUiLCJpYXQiOjE1ODcwMjAwNTd9.qF6aOoJbFw4QGM-F81jhF7wATqF6f0D_XYbNlozNdPQ',
  production: true
};

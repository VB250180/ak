import { Component, OnInit } from '@angular/core';
import { ChartType, ChartDataSets, ChartOptions } from 'chart.js';
import { MultiDataSet, Label, Color, BaseChartDirective } from 'ng2-charts';
// import * as pluginAnnotations from 'chartjs-plugin-annotation';
// import { AssistedTrainingComponent } from '../assisted-training/assisted-training.component';

@Component({
  selector: 'app-agent-list',
  templateUrl: './agent-list.component.html',
  styleUrls: ['./agent-list.component.scss']
})
export class AgentListComponent implements OnInit {
  public doughnutChart1Labels: Label[] = ['', ''];
  public doughnutChart1Data: MultiDataSet = [
    [75, 25]
  ];
  public doughnutChart1Options: any = {
    cutoutPercentage: 90,
    elements: {
      arc: {
        borderWidth: 0
      }
    }
  };

  public pieChart1Colors = [
    {
      backgroundColor: ['#57E0D8', 'rgba(87, 224, 216, 0.1)'],
    },
  ];

  public pieChart2Colors = [
    {
      backgroundColor: ['#B1A3F9', 'rgba(177, 163, 249, 0.1)'],
    },
  ];

  public doughnutChartType: ChartType = 'pie';
  public pieChartLegend = false;


  public lineChartData: ChartDataSets[] = [
    { data: [5, 10, 7, 12, 14, 11, 15], label: 'Series A', borderWidth: 1 }
  ];

  public lineChartLabels: Label[] = ['', '', '', '', '', '', ''];

  public lineChartOptions: (ChartOptions) = {
    responsive: true,
    maintainAspectRatio: false,
    // pointBorder: 0,
    // borderWidth: 1,
    elements: { point: { radius: 0 } } ,
    scales: {
      xAxes: [{
        gridLines: {
          display: false,
          drawBorder: false,
          tickMarkLength: 0
        },
      }],
      yAxes: [{
        gridLines: {
          display: false,
          drawBorder: false
        },
        ticks: {
          beginAtZero: true,
          callback: function(value, index, values) {
              return '';
          },
        }
      }]
    }
  };
  public lineChartColors: Color[] = [
    {
      backgroundColor: 'rgba(87, 224, 216, 0.1)',
      borderColor: '#57E0D8',
      pointBackgroundColor: '#57E0D8',
      pointBorderColor: '#57E0D8',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: '#57E0D8'
    }
  ];
  public lineChart2Colors: Color[] = [
    {
      backgroundColor: 'rgba(177, 163, 249, 0.1)',
      borderColor: '#B1A3F9',
      pointBackgroundColor: '#B1A3F9',
      pointBorderColor: '#B1A3F9',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: '#B1A3F9'
    }
  ];
  public lineChartLegend = false;
  public lineChartType = 'line';

  public liveAgents = [1, 2, 3, 4];

  public showTrand = true;

  constructor() { }

  ngOnInit() {
  }

  toggleChange = () => {
    this.showTrand = !this.showTrand;
  }

}

import { Component, OnInit,ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, Form, Validators } from '@angular/forms';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { CreateIntentLeftComponent } from './create-intent-left/create-intent-left.component';
import { CreateIntentService } from './create-intent.service';

@Component({
  selector: 'app-create-intent',
  templateUrl: './create-intent.component.html',
  styleUrls: ['./create-intent.component.scss']
})
export class CreateIntentComponent implements OnInit {
  
    @ViewChild("leftPanel",{static: false}) componentLeftPanel: CreateIntentLeftComponent;


  // Added dummy value for  build 
  // Start
  channel;
  languages;
  channelFilter(channel){ }
  language;
  languageFilter(language){}
  // End


  intentId;
  channels: any = [{ id: 1, value: "IVR" }, { id: 2, value: "Web" }, { id: 1, value: "Mobile" }];
  // languages: any = [{ id: 1, value: "English" }, { id: 2, value: "Spanish" }, { id: 1, value: "English(US)" }];
  agents: any = [{ id: 1, value: "VA_one" }, { id: 2, value: "VA_two" }, { id: 1, value: "VA_three" }];
  units: any = [{ id: 1, value: "Health care" }, { id: 2, value: "BAnking" }];
  showIntent: boolean;
  showConversation: boolean;
  showAddPhrases: boolean;
  constructor(private fb: FormBuilder, public createIntentService: CreateIntentService) { }

  saveIntentForm: FormGroup;

  ngOnInit() {
    this.saveIntentForm = this.fb.group({
      intentName: ['', Validators.required],
      intentDescription: ['', Validators.required],
      isIntentLive: [true, Validators.required]
      // agent: ['', Validators.required],
      // language: ['', Validators.required],
      // businessUnit: ['', Validators.required]
    });

    this.saveIntentForm.patchValue({
      agent: '',
      // language: '',
      businessUnit: ''
    });

    this.intentTab();
    let roleId = 1;
    this.intentId = 5;
    this.createIntentService.getIntent(roleId, this.intentId)
      .subscribe((response: any) => {
        this.saveIntentForm.controls['intentName'].setValue(response.intent.intentName);
        this.saveIntentForm.controls['intentDescription'].setValue(response.intent.intentDescription);
        this.saveIntentForm.controls['isIntentLive'].setValue(response.intent.isIntentLive);
      });
  }



  intentTab() {
    this.showIntent = true;
    this.showConversation = false;
    this.showAddPhrases = false;
  }

  conversationTab() {
    this.showIntent = false;
    this.showConversation = true;
    this.showAddPhrases = false;
  }

  addTab() {
    this.showIntent = false;
    this.showConversation = false;
    this.showAddPhrases = true;
  }

  // uploadAudio() {
  //   this.audioupload = !this.audioupload;
  //   console.log('upload');
  // }





  saveIntentInfo() {
    if (this.intentId == null || undefined) {
      this.createIntentService.saveCreateIntent(this.saveIntentForm.value)
        .subscribe(res => { });
    } else {
      this.createIntentService.updateCreateIntent(this.intentId, this.saveIntentForm.value)
        .subscribe(res => { });
    }

  }

  saveConversationDraft(){
    this.componentLeftPanel.saveConversation();
  }



}

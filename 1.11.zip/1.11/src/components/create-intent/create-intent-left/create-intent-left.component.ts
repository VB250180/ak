import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, Form, Validators } from '@angular/forms';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { Intent, Conversation,ConversationStage} from '../model/intent';
import { CreateIntentService } from '../create-intent.service';
// import { $ } from 'protractor';
declare var $:any;
@Component({
  selector: 'app-create-intent-left',
  templateUrl: './create-intent-left.component.html',
  styleUrls: ['./create-intent-left.component.scss']
})
export class CreateIntentLeftComponent implements OnInit {
  conversation:Conversation;
  conversationStages:ConversationStage[]=[]
  intent=new Intent();
  conversationList:any;lastElement;  finalResSlot:any;

  slotPage; msgValue:any=[]; showValidation; showSendMsg; showGetInfo; showCreateInfo;showFinalRes;
  valEntity: any = [{ id: 1, value: "Date of Birth" }, { id: 2, value: "OTP" }, { id: 3, value: "Departure Date" }]
  systemslots: any = [{ systemSlotKeyId: 1, value: "Member Id(unique)" }, { systemSlotKeyId: 2, value: "Account number" }];
  agents: any = [{ id: 1, value: "VA_one" }, { id: 2, value: "VA_two" }, { id: 1, value: "VA_three" }];

  constructor(public fb: FormBuilder, public createIntentService:CreateIntentService) { }
  conversationForm: FormGroup;


  ngOnInit() {
    this.conversationForm = this.fb.group({
      valEntity: [''],
      slotValues: this.fb.array([this.fb.group({ slot: '' })]),
      msg: [''],
      getInfoValues: this.fb.array([this.fb.group({ name: '', description: '', entity: '', question: '', validationMsg: '' })]),
      finalResdataValues: this.fb.array([this.fb.group({ name: '', description: '' })]),
    });
    this.slotPage = this.systemslots.length;
    this.showCreateInfo = false;
    this.intent.systemSlots=new Array(0);
this.getConversationList();
  }
getConversationList(){
  this.createIntentService.getIntentConversionList().subscribe((data:any) => {
    this.conversationList=data.conversation;
    this.conversationStages= this.conversationList.conversationStages;
    this.lastElement = this.conversationStages.pop();
    this.conversationStages.forEach(e => {
      this.finalResSlot=this.lastElement.finalResponse;
        this.finalResSlot.positionAndSlots.forEach(e => {
         if(e.intentSlot!=null){
         var replaceStr=e.intentSlot.entity.entityName;
         }else{
          var replaceStr=e.responseSlot.responseSlotName; 
         }
         var str1="<$ "+replaceStr+" >"; 
         this.finalResSlot.finalResponseText=this.finalResSlot.finalResponseText.replace(e.position, str1);
        }); 
      });
  });
}

  drop(event: CdkDragDrop<{title: string, poster: string}[]>) {
    moveItemInArray( this.conversationStages, event.previousIndex, event.currentIndex);
  }

  // validation Block
  get slotValues() {
    return this.conversationForm.get('slotValues') as FormArray;
  }
  addSlotValue() {
    this.slotValues.push(this.fb.group({ slot: '' }));
  }
  deleteSlotValue(index) {
    if (this.slotValues.value.length > 1) {
      this.slotValues.removeAt(index);
      this.slotPage++;
    }
  }
  slotSelected(slot, idx) {
    if (this.slotPage != 1) {
      this.addSlotValue();
      this.slotPage = this.systemslots.length - 1;
    }
  }

  // sendMsg Block
  addMsg() {
    this.msgValue.push(this.conversationForm.value.msg);
  }
  delMsg() {
    this.msgValue = '';
  }

  // getInfo Block
  get getInfo() {
    return this.conversationForm.get('getInfoValues') as FormArray;
  }
  addInfoSlot() {
    if (this.showCreateInfo) {
      this.getInfo.push(this.fb.group({ name: '', description: '', entity: '', question: '', validationMsg: '' }));
    }
    this.showCreateInfo = true;
  }
  removeInfoSlot(i: number) {
    this.getInfo.removeAt(i);
  }

  // finalRes Block
  get finalRes() {
    return this.conversationForm.get('finalResdataValues') as FormArray;
  }
  addResSlot() {
    this.finalRes.push(this.fb.group({ name: '', description: '' }));
  }
  removeResSlot(i: number) {
    this.finalRes.removeAt(i);
  }

  // RightPanel Block
  mapFunc() {
    this.showValidation = "true"
  }
  sendMsgFunc() {
    this.addMsg();
    this.showSendMsg = "true"
  }
  getInfoFunc() {
    this.showGetInfo = "true"
  }
  getfinalRes(){
  this.showFinalRes="true"
  };
  saveConversation(){}
//   saveDraft;
//   saveConversation(){
//     this.intent.validationIntent={"intentId":this.conversationForm.value.valEntity.id};
//     this.conversationForm.value.slotValues.forEach((element,index) => {
//       if(element.slot.systemSlotKeyId!=undefined){
//         this.intent.systemSlotKey={"systemSlotKey":{
//           "systemSlotKeyId":element.slot.systemSlotKeyId
//         }};
//         this.intent.systemSlots[index]= this.intent.systemSlotKey;
//       }
//    });
//  this.saveDraft=({"validationIntent":this.intent.validationIntent,"systemSlots": this.intent.systemSlots})

//  this.createIntentService.saveConversations(this.saveDraft)
//  .subscribe((res:any)=>{});
//    }


 
}

export class Intent{
    validationIntent:any;
    systemSlotKey:any;
    systemSlots:any
}




    export class SystemSlotKey {
        systemSlotKeyId: number;
        systemSlotKeyName: string;
    }

    export class SystemSlot {
        systemSlotId: number;
        systemSlotKey: SystemSlotKey;
    }

    export class SendMessage {
        messageId: number;
        messageText: string;
    }

    export class Entity {
        entityId: number;
        entityName: string;
    }

    export class IntentSlot {
        intenSlotId: number;
        intentSlotName: string;
        intentSlotDescription: string;
        entity: Entity;
    }

    export class GetInfo {
        getInfoId: number;
        promptQuestion: string;
        promptValidationMessage: string;
        intentSlot: IntentSlot;
    }

    export class ResponseSlot {
        responseSlotId: number;
        responseSlotName: string;
    }

    export class PositionAndSlot {
        finalResponseSlotId: number;
        position: string;
        intentSlot?: any;
        responseSlot: ResponseSlot;
    }

    export class FinalResponse {
        finalResponseId: number;
        finalResponseText: string;
        positionAndSlots: PositionAndSlot[];
    }

    export class ConversationStage {
        sequenceNumber: number;
        conversationStageId: number;
        sendMessage: SendMessage;
        getInfo: GetInfo;
        finalResponse: FinalResponse;
    }

    export class Conversation {
        validationIntent?: any;
        systemSlots: SystemSlot[];
        conversationStages: ConversationStage[];
    }

    // export class RootObject {
    //     virtualAgent?: any;
    //     virtualAgents?: any;
    //     intent?: any;
    //     intents?: any;
    //     conversation: Conversation;
    //     trainingPhrases?: any;
    //     virtualAgentDashboardResponseObject?: any;
    //     virtualAgentTrendResponseObject?: any;
    //     errorBody?: any;
    //     count?: any;
    // }


import { TestBed } from '@angular/core/testing';

import { CreateIntentService } from './create-intent.service';

describe('CreateIntentService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CreateIntentService = TestBed.get(CreateIntentService);
    expect(service).toBeTruthy();
  });
});

// import { Router } from '@angular/router';
// import { Location } from '@angular/common';
import { Component, OnInit, OnChanges,Input } from '@angular/core';
// import { ReportsService } from '../../reports/reports.service';
// import { Subscription } from 'rxjs';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  path = '';
  // showContent: any;

  constructor() {
      //this.service.currentMessage.subscribe(data => this.showContent = data);
   }

  ngOnInit(): void { }
  @Input() x=0;
  @Input() y=0;
}

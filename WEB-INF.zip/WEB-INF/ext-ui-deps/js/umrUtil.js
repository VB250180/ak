$(document).ready(function () {
	
	/*$(function () {
        $(".loader").fadeOut();
    });*/
    $(function () {
        $(window).bind("load resize", function () {
            topOffset = 49;
            fitWindowHeight();
            width = (this.window.innerWidth > 0) ? this.window.innerWidth : this.screen.width;
            if (width < 768) {
                $('div.navbar-collapse').addClass('collapse');
                topOffset = 60; // 2-row-menu
            }
            else {
                $('div.navbar-collapse').removeClass('collapse');
            }
            height = ((this.window.innerHeight > 0) ? this.window.innerHeight : this.screen.height) - 1;
            height = height - topOffset;
            if (height < 1) height = 1;
            if (height > topOffset) {
                $("#wrapper:not(.custom-fix) #page-wrapper").css("min-height", (height) + "px");
            }
        });
    });
    // This is for resize window
    $(function () {
        $(window).bind("load resize", function () {
            width = (this.window.innerWidth > 0) ? this.window.innerWidth : this.screen.width;
            
            if (width < 1170) {
                $('body').addClass('content-wrapper');
                $(".open-close i").removeClass('icon-arrow-left-circle');
                $(".sidebar").css("overflow", "inherit").parent().css("overflow", "visible");
            }
            else {
                $('body').removeClass('content-wrapper');
                $(".open-close i").addClass('icon-arrow-left-circle');
            }
        });
    });
    // This is for click on open close button
    // Sidebar open close
    $(".open-close").on('click', function () {
        if ($("body").hasClass("content-wrapper")) {
            $("body").trigger("resize");
            $(".sidebar-nav, .slimScrollDiv").css("overflow", "hidden").parent().css("overflow", "visible");
            $("body").removeClass("content-wrapper");
            $(".open-close i").addClass("icon-arrow-left-circle");
            $(".logo span").show();
        }
        else {
            $("body").trigger("resize");
            $(".sidebar-nav, .slimScrollDiv").css("overflow", "inherit").parent().css("overflow", "visible");
            $("body").addClass("content-wrapper");
            $(".open-close i").removeClass("icon-arrow-left-circle");
            $(".logo span").hide();
        }
    });
    /*
     * Fullscreen Browsing
     */
    if ($('[data-action="fullscreen"]')[0]) {
    	var fs = $("[data-action='fullscreen']");
    	fs.on('click', function(e) {
    		e.preventDefault();
    		console.log('fullscreen clicked');
    		//Launch
    		function launchIntoFullscreen(element) {

    			if(element.requestFullscreen) {
    				element.requestFullscreen();
    			} else if(element.mozRequestFullScreen) {
    				element.mozRequestFullScreen();
    			} else if(element.webkitRequestFullscreen) {
    				element.webkitRequestFullscreen();
    			} else if(element.msRequestFullscreen) {
    				element.msRequestFullscreen();
    			}
    		}

    		//Exit
    		function exitFullscreen() {

    			if(document.exitFullscreen) {
    				document.exitFullscreen();
    			} else if(document.mozCancelFullScreen) {
    				document.mozCancelFullScreen();
    			} else if(document.webkitExitFullscreen) {
    				document.webkitExitFullscreen();
    			}
    		}

    		launchIntoFullscreen(document.documentElement);
    		fs.closest('.dropdown').removeClass('open');
    	});
    }
    
    /*
     * Custom Scrollbars
     */
    

    //Scrollbar for HTML(not mobile) but not for login page
    if (!$('html').hasClass('ismobile')) {
        if (!$('.login-content')[0]) {
            scrollbar('html', 'rgb(80, 80, 80)', '7.5px',true);
            //$("html").niceScroll({styler:"fb",cursorcolor:"#000"});
        }

        //Scrollbar Tables
        if ($('.table-responsive')[0]) {
            scrollbar('.table-responsive', 'rgba(0,0,0,0.5)', '5px');
        }

        //Scrill bar for Chosen
        if ($('.chosen-results')[0]) {
            scrollbar('.chosen-results', 'rgba(0,0,0,0.5)', '5px');
        }

        //Scroll bar for tabs
        if ($('.tab-nav')[0]) {
            scrollbar('.tab-nav', 'rgba(0,0,0,0)', '1px');
        }

        //Scroll bar for dropdowm-menu
        if ($('.dropdown-menu .c-overflow')[0]) {
            scrollbar('.dropdown-menu .c-overflow', 'rgba(0,0,0,0.5)', '0px');
        }

        //Scrollbar for rest
        if ($('.c-overflow')[0]) {
            scrollbar('.c-overflow', 'rgba(0,0,0,0.5)', '5px');
        }
    }
    //tooltip
    $(function () {
//    	$('body').tooltip({
//    		selector: '[data-toggle="tooltip"]'
//        });
    })
    //Popover
    $(function () {
//    	$('body').popover({
//    	    selector: '[data-toggle="popover"]'
//    	});
    })
    
}),$(window).scroll(collapseNavbar), $(document).ready(collapseNavbar);
$(".collapseble").click(function () {
    $(".collapseblebox").fadeToggle(350);
});

function scrollbar(className, color, cursorWidth, autohide) {
//    $(className).niceScroll({
//        cursorcolor: color,
//        cursorborder: 0,
//        cursorborderradius: 0,
//        cursorwidth: cursorWidth,
//        bouncescroll: true,
//        mousescrollstep: 100,
//        autohidemode: autohide,
//        hidecursordelay:2000
//    });
}

function collapseNavbar() {
	$(window).scrollTop() > 30 ? $("#wrapper:not(.custom-fix)").addClass("fix-top") : $("#wrapper:not(.custom-fix)").removeClass("fix-top")
}
var patternforalphanumeric=/^[a-zA-Z0-9\s_]+$/;
var cacheauMina_json;
function checkEmpty(value,err_span_id,err_msg){
	if (value.trim() === '') {
		$('#'+err_span_id).show();
		$('#'+err_span_id).html(err_msg);
		return false;
	} else {
		$('#'+err_span_id).hide();
		$('#'+err_span_id).html('');
		return true;
	}
}
function checkDropdown(value,err_span_id,err_msg) {
	if (value.length != 0 && value.val() != '' && value.val() != '0') {
		$('#'+err_span_id).hide();
		$('#'+err_span_id).html('');
		return true;
	} else {
		$('#'+err_span_id).html(err_msg);
		$('#'+err_span_id).show();
		return false;
	}
}
function checkRadioSelect(value,err_span_id,err_msg) {
	if (!value.length) {
		$('#'+err_span_id).html(err_msg);
		$('#'+err_span_id).show();
		return false;
	} else {
		$('#'+err_span_id).html("");
		$('#'+err_span_id).hide();
		return true;
	}
}

/*millisecond To Second*/
function util_millisecondToSecond(milliseconds) {
	 var seconds = roundToTwo(milliseconds / 1000);
	 return seconds;
}

function util_secondToMillisecond(seconds) {
	var milliseconds = Math.floor(seconds * 1000);
	 return milliseconds;
}


function util_numberValidationDecimal(number,minval){
	var result = false;
	if(number >= minval && number <= 9999){
		var re = new RegExp("^[0-9]+(\.[0-9]{1,2})?$");
		result = re.test(number);
	}
	return result;
}

function util_numberValidation(number,minval){
	var result = false;
	if(number >= minval && number <= 9999){
		var re = new RegExp("^[0-9]+$");
		result = re.test(number);
	}
	return result;
}

function activaTab(tab){$('.nav-tabs a[href="#' + tab + '"]').tab('show');};

function roundToTwo(num) {return +(Math.round(num + "e+2")  + "e-2");}

function ajaxCallPostFileUpload(action,formData,loaderID, callBack){
	var data;
	$.ajax({
		type : 'POST',
		url : action,
		data : formData,
		processData: false,
        contentType: false,
        statusCode: {759: function(xhr) {console.log(xhr.responseText);errorModal();},
        	629: function(data, textStatus, xhr) {window.location='ajaxSessionExpiration?exceptionMessage='+data.responseText;},
			689: function(xhr) {infoModal(xhr.responseText);}
		},
		beforeSend : function() {$(loaderID).css('display','block');},
		complete : function() {$(loaderID).css('display', 'none');},
		success : function(json) { console.log('here 1..'+json);data = json; callBack(data)},
		abort : function(data) {$(loaderID).css('display','none');console.log("abort" + data);data = 'error';errorModal();callBack(data)},
		error : function(data) {$(loaderID).css('display','none');console.log("error" + JSON.stringify(data));data = 'error';errorModal();}
	});
}

function ajaxCallPostText(action,formData,loaderID, callBack){
	var data;
	$.ajax({
		type : 'POST',
		url : action,
		data : formData,
		dataType: 'text',
		processData: false,
        contentType: false,
        statusCode: {759: function(xhr) {console.log(xhr.responseText);errorModal();},
        	629: function(data, textStatus, xhr) {window.location='ajaxSessionExpiration?exceptionMessage='+data.responseText;},
			689: function(xhr) {infoModal(xhr.responseText);}
		},
		beforeSend : function() {$(loaderID).css('display','block');},
		complete : function() {$(loaderID).css('display', 'none');},
		success : function(json) { console.log('here 1..'+json);data = json; callBack(data);},
		abort : function(data) {$(loaderID).css('display','none');console.log("abort" + data);data = 'error';errorModal();callBack(data)},
		error : function(data) {$(loaderID).css('display','none');console.log("error" + JSON.stringify(data));data = 'error';errorModal();}
	});
}

function ajaxCallPostJson(action,dataValue,loaderID, callBack){
	var data;
	$.ajax({
		type : 'post',
		url : action,
		data : dataValue,
		contentType: 'application/json; encoding=utf-8',
		statusCode: {759: function(xhr) {console.log(xhr.responseText);errorModal();},
			629: function(data, textStatus, xhr) {window.location='ajaxSessionExpiration?exceptionMessage='+data.responseText;},
			689: function(xhr) {infoModal(xhr.responseText);}
		},
		beforeSend : function() {$(loaderID).css('display', 'block');},
		complete : function() {$(loaderID).css('display', 'none');},
		success : function(dt, status, request) {
			data = dt;
			cacheauMina_json = request.getResponseHeader("cacheauMina");
			callBack(data);
		},
		abort : function(data) {$(loaderID).css('display','none');console.log("abort" + data);data = 'error';callBack(data);},
		error : function(data) {$(loaderID).css('display','none');console.log("error" + data);data = 'error';}
	});
}

function ajaxCallGet(action,dataValue,loaderID, callBack){
	var data;
	$.ajax({
		type : 'get',
		url : action+dataValue,
		statusCode: {500: function(xhr) {console.log(xhr.responseText);errorModal();},
			629: function(data, textStatus, xhr) {window.location='ajaxSessionExpiration?exceptionMessage='+data.responseText;},
			689: function(xhr) {infoModal(xhr.responseText);}
		},
		beforeSend : function() {$(loaderID).css('display', 'block');},
		complete : function() {$(loaderID).css('display', 'none');},
		success : function(dt, status, request) {
			data = dt;
			callBack(data);
		},
		abort : function(data) {$(loaderID).css('display','none');console.log("abort" + data);data = 'error';;callBack(data);},
		error : function(data) {$(loaderID).css('display','none');console.log("error" + data);data = 'error';errorModal();}
	});
}

function ajaxSyncCallGet(action,dataValue,loaderID, callBack){
	var data;
	$.ajax({
		type : 'get',
		url : action+dataValue,
		async : false,
		statusCode: {500: function(xhr) {console.log(xhr.responseText);errorModal();},
			629: function(data, textStatus, xhr) {window.location='ajaxSessionExpiration?exceptionMessage='+data.responseText;},
			689: function(xhr) {infoModal(xhr.responseText);}
		},
		beforeSend : function() {$(loaderID).css('display', 'block');},
		complete : function() {$(loaderID).css('display', 'none');},
		success : function(dt, status, request) {
			data = dt;
			callBack(data);
		},
		abort : function(data) {$(loaderID).css('display','none');console.log("abort" + data);data = 'error';;callBack(data);},
		error : function(data) {$(loaderID).css('display','none');console.log("error" + data);data = 'error';errorModal();}
	});
}

function ajaxCallGetJson(action,dataValue,loaderID, callBack){
	var data;
	$.ajax({
		type : 'get',
		url : action+encodeURIComponent(dataValue),
		contentType: 'application/json; encoding=utf-8',
		statusCode: {759: function(xhr) {console.log(xhr.responseText);errorModal();},
			629: function(data, textStatus, xhr) {window.location='ajaxSessionExpiration?exceptionMessage='+data.responseText;},
			689: function(xhr) {infoModal(xhr.responseText);}
		},
		beforeSend : function() {$(loaderID).css('display', 'block');},
		complete : function() {$(loaderID).css('display', 'none');},
		success : function(dt, status, request) {
			data = dt;
			callBack(data);
		},
		abort : function(data) {$(loaderID).css('display','none');console.log("abort" + data);data = 'error';;callBack(data);},
		error : function(data) {$(loaderID).css('display','none');console.log("error" + data);data = 'error';errorModal();}
	});
}

function ajaxCallPutJson(action,dataValue,loaderID, callBack){
	var data;
	$.ajax({
		type : 'put',
		url : action,
		data : dataValue,
		contentType: 'application/json; encoding=utf-8',
		statusCode: {759: function(xhr) {console.log(xhr.responseText);errorModal();},
			629: function(data, textStatus, xhr) {window.location='ajaxSessionExpiration?exceptionMessage='+data.responseText;},
			689: function(xhr) {infoModal(xhr.responseText);}
		},
		beforeSend : function() {$(loaderID).css('display', 'block');},
		complete : function() {$(loaderID).css('display', 'none');},
		success : function(dt, status, request) {
			data = dt;
			cacheauMina_json = request.getResponseHeader("cacheauMina");
			callBack(data);
		},
		abort : function(data) {$(loaderID).css('display','none');console.log("abort" + data);data = 'error';/*errorModal()*/;callBack(data);},
		error : function(data) {$(loaderID).css('display','none');console.log("error" + data);data = 'error';errorModal();}
	});
}

function ajaxCallPut(action,dataValue,loaderID, callBack){
	var data;
	$.ajax({
		type : 'put',
		url : action,
		data : dataValue,
		statusCode: {759: function(xhr) {console.log(xhr.responseText);errorModal();},
			629: function(data, textStatus, xhr) {window.location='ajaxSessionExpiration?exceptionMessage='+data.responseText;},
			689: function(xhr) {infoModal(xhr.responseText);}
		},
		beforeSend : function() {$(loaderID).css('display', 'block');},
		complete : function() {$(loaderID).css('display', 'none');},
		success : function(dt, status, request) {
			data = dt;
			callBack(data);
		},
		abort : function(data) {$(loaderID).css('display','none');console.log("abort" + data);data = 'error';;callBack(data);},
		error : function(data) {$(loaderID).css('display','none');console.log("error" + data);data = 'error';errorModal();}
	});
}

function ajaxCallDeleteJson(action,dataValue,loaderID, callBack){
	var data;
	$.ajax({
		type : 'delete',
		url : action,
		data : dataValue,
		contentType: 'application/json; encoding=utf-8',
		statusCode: {759: function(xhr) {console.log(xhr.responseText);errorModal();},
			629: function(data, textStatus, xhr) {window.location='ajaxSessionExpiration?exceptionMessage='+data.responseText;},
			689: function(xhr) {infoModal(xhr.responseText);}
		},
		beforeSend : function() {$(loaderID).css('display', 'block');},
		complete : function() {$(loaderID).css('display', 'none');},
		success : function(dt, status, request) {
			data = dt;
			cacheauMina_json = request.getResponseHeader("cacheauMina");
			callBack(data);
		},
		abort : function(data) {$(loaderID).css('display','none');console.log("abort" + data);data = 'error';/*errorModal()*/;callBack(data);},
		error : function(data) {$(loaderID).css('display','none');console.log("error" + data);data = 'error';errorModal();}
	});
}

//Used for reports
function ajaxCallPostJsonReport(action,dataValue,uniqueRequestSetId,uniqueRequestId, loaderID, callBack){
	var data;
	$.ajax({
		type : 'post',
		url : action,
		data : dataValue,
		headers: {"requestSetId": uniqueRequestSetId, "requestId" :uniqueRequestId},
		contentType: 'application/json; encoding=utf-8',
		statusCode: {759: function(xhr) {console.log(xhr.responseText);errorModal();},
			629: function(data, textStatus, xhr) {window.location='ajaxSessionExpiration?exceptionMessage='+data.responseText;},
			689: function(xhr) {infoModal(xhr.responseText);}
		},
		beforeSend : function() {$(loaderID).css('display', 'block');},
		complete : function() {$(loaderID).css('display', 'none');},
		success : function(dt, status, request) {
			data = dt;
			cacheauMina_json = request.getResponseHeader("cacheauMina");
			if(callBack){
			callBack(data);
			}
		},
		abort : function(data) {$(loaderID).css('display','none');console.log("abort" + data);data = 'error';/*errorModal()*/;callBack(data);},
		error : function(data) {$(loaderID).css('display','none');console.log("error" + data);data = 'error';errorModal();}
	});
}
function ajaxSyncCallPutJson(action,dataValue,loaderID, callBack){
	var data;
	$.ajax({
		type : 'put',
		url : action,
		data : dataValue,
		async : false,
		contentType: 'application/json; encoding=utf-8',
		statusCode: {759: function(xhr) {console.log(xhr.responseText);errorModal();},
			629: function(data, textStatus, xhr) {window.location='ajaxSessionExpiration?exceptionMessage='+data.responseText;},
			689: function(xhr) {infoModal(xhr.responseText);}
		},
		beforeSend : function() {$(loaderID).css('display', 'block');},
		complete : function() {$(loaderID).css('display', 'none');},
		success : function(dt, status, request) {
			data = dt;
			cacheauMina_json = request.getResponseHeader("cacheauMina");
			callBack(data);
		},
		abort : function(data) {$(loaderID).css('display','none');console.log("abort" + data);data = 'error';/*errorModal()*/;callBack(data);},
		error : function(data) {$(loaderID).css('display','none');console.log("error" + data);data = 'error';errorModal();}
	});
}

function ajaxCallPost(action,dataValue,loaderID, callBack){
	$.ajax({
		type : 'post',
		url : action,
		data : dataValue,
		statusCode: {759: function(data, textStatus, xhr) {errorModal();},
			629: function(data, textStatus, xhr) {window.location='ajaxSessionExpiration?exceptionMessage='+data.responseText;},
			689: function(data, textStatus, xhr) {infoModal(data.responseText);}
		},
		beforeSend : function() {$(loaderID).css('display','block');},
		complete : function() {$(loaderID).css('display', 'none');},
		success : function(dt, status, request) {
			cacheauMina_json = request.getResponseHeader("cacheauMina");
			callBack(dt);
		},
		abort : function(data) {$(loaderID).css('display','none');console.log("abort" + data);data = 'error';errorModal();callBack(data);},
		error : function(data, textStatus, xhr) {
			$(loaderID).css('display','none');console.log("error" + data);data = 'error';errorModal();}
	});
}
function ajaxCallDelete(action,dataValue,loaderID, callBack){
	$.ajax({
		type : 'delete',
		url : action,
		data : dataValue,
		statusCode: {759: function(data, textStatus, xhr) {errorModal();},
			629: function(data, textStatus, xhr) {window.location='ajaxSessionExpiration?exceptionMessage='+data.responseText;},
			689: function(data, textStatus, xhr) {infoModal(data.responseText);}
		},
		beforeSend : function() {$(loaderID).css('display','block');},
		complete : function() {$(loaderID).css('display', 'none');},
		success : function(dt, status, request) {
			cacheauMina_json = request.getResponseHeader("cacheauMina");
			callBack(dt);
		},
		abort : function(data) {$(loaderID).css('display','none');console.log("abort" + data);data = 'error';errorModal();callBack(data);},
		error : function(data, textStatus, xhr) {
			$(loaderID).css('display','none');console.log("error" + data);data = 'error';errorModal();}
	});
}
function ajaxSyncCallPost(action,dataValue,loaderID, callBack){
	$.ajax({
		type : 'post',
		url : action,
		data : dataValue,
		async : false,
		statusCode: {759: function(data, textStatus, xhr) {errorModal();},
			629: function(data, textStatus, xhr) {window.location='ajaxSessionExpiration?exceptionMessage='+data.responseText;},
			689: function(data, textStatus, xhr) {infoModal(data.responseText);}
		},
		beforeSend : function() {$(loaderID).css('display','block');},
		complete : function() {$(loaderID).css('display', 'none');},
		success : function(dt, status, request) {
			cacheauMina_json = request.getResponseHeader("cacheauMina");
			callBack(dt);
		},
		abort : function(data) {$(loaderID).css('display','none');console.log("abort" + data);data = 'error';errorModal();callBack(data);},
		error : function(data, textStatus, xhr) {
			$(loaderID).css('display','none');console.log("error" + data);data = 'error';errorModal();}
		});
}
function ajaxSyncCallPut(action,dataValue,loaderID, callBack){
	$.ajax({
		type : 'put',
		url : action,
		data : dataValue,
		async : false,
		statusCode: {759: function(data, textStatus, xhr) {errorModal();},
			629: function(data, textStatus, xhr) {window.location='ajaxSessionExpiration?exceptionMessage='+data.responseText;},
			689: function(data, textStatus, xhr) {infoModal(data.responseText);}
		},
		beforeSend : function() {$(loaderID).css('display','block');},
		complete : function() {$(loaderID).css('display', 'none');},
		success : function(dt, status, request) {
			cacheauMina_json = request.getResponseHeader("cacheauMina");
			callBack(dt);
		},
		abort : function(data) {$(loaderID).css('display','none');console.log("abort" + data);data = 'error';errorModal();callBack(data);},
		error : function(data, textStatus, xhr) {
			$(loaderID).css('display','none');console.log("error" + data);data = 'error';errorModal();}
		});
}

function ajaxSyncCallPostJson(action,dataValue,loaderID, callBack){
	$.ajax({
		type : 'post',
		url : action,
		data : dataValue,
		async : false,
		contentType: 'application/json; encoding=utf-8',
		statusCode: {759: function(data, textStatus, xhr) {errorModal();},
			629: function(data, textStatus, xhr) {window.location='ajaxSessionExpiration?exceptionMessage='+data.responseText;},
			689: function(data, textStatus, xhr) {infoModal(data.responseText);}
		},
		beforeSend : function() {$(loaderID).css('display','block');},
		complete : function() {$(loaderID).css('display', 'none');},
		success : function(dt, status, request) {
			cacheauMina_json = request.getResponseHeader("cacheauMina");
			callBack(dt);
		},
		abort : function(data) {$(loaderID).css('display','none');console.log("abort" + data);data = 'error';errorModal();callBack(data);},
		error : function(data, textStatus, xhr) {
			$(loaderID).css('display','none');console.log("error" + data);data = 'error';errorModal();}
		});
}

function ajaxCallPostUTF8(action,dataValue,loaderID,callBack){
	var data;
	$.ajax({
		type : 'post',
		url : action,
		data : dataValue,
		headers : {Accept : "text/plain; charset=utf-8"},
		statusCode: {759: function(xhr) {errorModal();},
			629: function(data, textStatus, xhr) {window.location='ajaxSessionExpiration?exceptionMessage='+data.responseText;},
			689: function(xhr) {infoModal(xhr.responseText);}
		},
		beforeSend : function() {$(loaderID).css('display','block');},
		complete : function() {$(loaderID).css('display', 'none');},
		success : function(json) {data = json;callBack(data)},
		abort : function(data) {$(loaderID).css('display','none');console.log("abort" + data);data = 'error';errorModal();callBack(data)},
		error : function(data) {$(loaderID).css('display','none');console.log("error" + JSON.stringify(data));data = 'error';errorModal();}
	});
}

function ajaxSyncCallPostUTF8(action,dataValue,loaderID,callBack){
	var data;
	$.ajax({
		type : 'post',
		url : action,
		data : dataValue,
		async : false,
		headers : {Accept : "text/plain; charset=utf-8"},
		statusCode: {759: function(xhr) {errorModal();},
			629: function(data, textStatus, xhr) {window.location='ajaxSessionExpiration?exceptionMessage='+data.responseText;},
			689: function(xhr) {infoModal(xhr.responseText);}
		},
		beforeSend : function() {$(loaderID).css('display','block');},
		complete : function() {$(loaderID).css('display', 'none');},
		success : function(json) {data = json;callBack(data)},
		abort : function(data) {$(loaderID).css('display','none');console.log("abort" + data);data = 'error';errorModal();callBack(data)},
		error : function(data) {$(loaderID).css('display','none');console.log("error" + JSON.stringify(data));data = 'error';errorModal();}
	});
}

function errorModal(){$('#danger_msg').html("A Technical Error has occurred. Try again sometime later.");$('#danger').modal('show');}
function infoModal(message){$('.info-body').html(message);$('#success').modal('show');}
function warnModal(message){$('.warn-body').text(message);$('#warnModal').modal('show');}
function delModal(){$('#message').modal('show');}
function clsDropdown(opID,val,text){$(opID).empty();$(opID).append($('<option></option>').val(val).html(text));}
function appendDropdown(opID,json){
	$.each(json, function(i, json) {$(opID).append($('<option></option>').val(json.key).html(json.value));});
}
function clearSpecialChar(id){
    $( '#'+id ).val($( '#'+id ).val().replace(/[1234567890`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi, ''));
}

function optionFilterAppendDropdown(id,val,appendId){
	var filterjson = _.filter(JSON.parse($(id).text()), function(o) { return (o.refId == val); })
	$.each(filterjson, function(i, item) {
		console.log('filter....'+filterjson[i].name);
		$(appendId).append('<option value="'+filterjson[i].id+'">'+filterjson[i].name+'</option>');
	});
}
function licenseNotify(){if($('#licNotify').length!=0){infoModal($('#licNotify').val());}}
function scrollToTop(){document.body.scrollTop = document.documentElement.scrollTop = 0;}
function modalFix(){$('#page-modal').append($('#tab-modal').html());$('#tab-modal').html('');}

function removeSpecialCharacter(selector){
	//onKeyPress(selector);
	onKeyUp(selector);
	onBlur(selector);
}

function onKeyPress(selector){
	var specialKeys = storeKeysCodes();
	$(selector).on('keypress', function (e) {
		var keyCode = e.keyCode == 0 ? e.charCode : e.keyCode;
        var regex = new RegExp('^[a-zA-Z0-9\\_\\s]+$');
		var str = String.fromCharCode(!e.charCode ? e.which: e.charCode);
		if((specialKeys.indexOf(keyCode) == -1) && !regex.test(str)){
			e.preventDefault();
			return;
		}
		if((specialKeys.indexOf(keyCode) != -1) && /[#$%.']/g.test(str)){
			e.preventDefault();
		}
	});
}

function storeKeysCodes(){
	var specialKeys = new Array();
    specialKeys.push(8); //Backspace
    specialKeys.push(9); //Tab
    specialKeys.push(46); //Delete
    specialKeys.push(36); //Home
    specialKeys.push(35); //End
    specialKeys.push(37); //Left
    specialKeys.push(39); //Right
    specialKeys.push(32); //Space
    specialKeys.push(95); //Underscore
    return specialKeys; 
}

function onKeyUp(selector){
	$(selector).keyup(function(e){
		removeDoubleUnderscoreAndSpace($(this));
		var value=$(this).val();
		//TODO Can start and end only with alphanumeric.
		var startRegex=new RegExp('^[\\s\\_]');	
		if(startRegex.test(value)){
			$(this).val(value.slice(1));
		}
	});
}

function removeDoubleUnderscoreAndSpace(selectorObj){
	var value=selectorObj.val();
	//TODO Double underscores and spaces not allowed together
	var regex=new RegExp('^(.*?[ _]{2,})');
	if(regex.test(value)){
		var exec=regex.exec(value)[0];
		regex=new RegExp('^(.*?[ _]{2})');
		var subExec=regex.exec(exec)[0];
		selectorObj.val(value.replace(exec, subExec.slice(0, -1)));
	}
}

function onBlur(selector){
	$(selector).blur(function(){
		var errorDiv=$(selector).closest('div.form-group');
		if(errorDiv.hasClass('custom-error')){
			errorDiv.removeClass('has-error has-danger');
			$(selector).next().text('').removeClass('error-text');
		}
	});
}

function checkLastCharacter(selector){
	var regex=new RegExp('(\_|\ )$');
	var isValid=true;
	$.each($(selector), function(){
		if(regex.test($(this).val())){
			showError(selector, 'Can start and end only with alphanumeric.');
			isValid=false;
		}
	});
	return isValid;
}

function notifyBottom(message){
	$('.alertbottom > span').empty();
	$('.alertbottom > span').text(message);
	$('.alertbottom').fadeIn(350).delay(2500).fadeOut(350);
}
function notifyBottomAlert(message){
	$('.alertbottom2 > span').empty();
	$('.alertbottom2 > span').text(message);
	$('.alertbottom2').fadeIn(350).delay(2500).fadeOut(350);
}

function showError(selector, message){
	var selectedObj=$(selector);
	selectedObj.closest('div.form-group').addClass('has-error has-danger custom-error');
	selectedObj.next().text(message).addClass('error-text');
	var keyDownFunction=function(e){
		$(e.target).closest('div.form-group').removeClass('has-error has-danger custom-error');
		$(e.target).next().text('').removeClass('error-text');
		$(selector).unbind('keydown', keyDownFunction);
	}
	$(selector).bind('keydown', keyDownFunction);
}

function clearError(selector){
	var selectorObj=$(selector);
	selectorObj.closest('div.form-group').removeClass('has-error has-danger custom-error');
	selectorObj.next().empty();
}

function showErrorHtml(selector, message){
	var selectedObj=$(selector);
	selectedObj.closest('div.form-group').addClass('has-error has-danger custom-error');
	selectedObj.next().html(message).addClass('error-text');
	var keyUpFunction=function(e){
		$(e.target).closest('div.form-group').removeClass('has-error has-danger custom-error');
		$(e.target).next().html('').removeClass('error-text');
		$(selector).unbind('keydown', keyUpFunction);
	}
	$(selector).bind('keydown', keyUpFunction);
}

function isFieldsEmpty(formId){
	var isEmpty=true;
	if($(formId).find('input:visible[required], select:visible[required]').val()){
		isEmpty=false;
	}
	if($(formId).find('radio:visible[required]:selected').length!=0){
		isEmpty=false;
	}
	return isEmpty;
}

function checkUserAction(containerId){
	var containerObj=$(containerId);
	isChanged=false;
	containerObj.on('keydown', 'input[type="text"]:visible[required], input[type="password"]:visible[required], textarea:visible[required]', function(e){
		isChanged=true;
	});
	containerObj.on('change', 'select:visible[required], input[type="radio"]:visible[required], input[type="checkbox"]:visible[required]', function(e){
		isChanged=true;
	});
	return isChanged;
}

function sortDivNames(){
    var sortedDivs=$('div.tags-hover').sort(function(a, b){
    	var aText=$(a).find('span').text().toUpperCase();
    	var bText=$(b).find('span').text().toUpperCase();
        return (aText < bText) ? -1 : (aText > bText) ? 1 : 0;
    });
    $('div.tags-hover').addClass('m-r-5');
    $('div.btn-demo').html(sortedDivs);
}

function showModal(modalMessage){
	var h4Obj=$('#success .modal-body h4');
	h4Obj.text(modalMessage);
	$('#success').modal('show');
}

function showDeleteModal(text){
	$('.del-body').text('Do you want to delete '+text+' ?');
	$('#message').modal('show');
}
function showErrorModal(text){
	$('#danger_msg').text(text);
	$('#danger').modal('show');
}

function closeDeleteModal(){
	$('#message').modal('hide');
}
function scrollTileContent(selector){
	$(selector).css('max-height', $(window).height()-$(selector).offset().top-50);
	scrollbar(selector, 'rgba(0,0,0,0.5)', '5px');
}
function setTitle(title){
	document.title=title;
}
function showLoader(loaderSelector){
	$(loaderSelector).css('display', 'block');
}
function hideLoader(loaderSelector){
	$(loaderSelector).css('display', 'none');
}
function getEmptyCallback(){
	var callBack=function(){};
	return callBack;
}
function block(selector){
	$(selector).block({ 
		message: '<img class="reportLoaderSpinner" src="e/images/loaderM.png"/>', 
		css: blockui_css, 
		overlayCSS: blockui_overlayCSS,  
		fadeIn: 0 
	});
}
function unblock(selector){
	$(selector).unblock();
}

function fitWindowHeight(){
	var windowHeight=$(window).height();
	var pageWrapper=$('.page-wrapper').css('margin-top');
	pageWrapper=parseInt(pageWrapper.substring(0, pageWrapper.length-2));
	var footerHeight=$('.footer').outerHeight();
	var mainContentHeight=windowHeight-pageWrapper-footerHeight;
	console.log('mainContentHeight: '+mainContentHeight);
	$('#main-content').css('height', mainContentHeight);
}
/**
 * b3 JS build upon c3 over d3 based reusable chart library 
 */
"use strict";
var colors = ['#1f77b4', '#aec7e8', '#ff7f0e', '#ffbb78', '#2ca02c', '#98df8a', '#d62728', '#ff9896', '#9467bd', '#c5b0d5', '#8c564b', '#c49c94', '#e377c2', '#f7b6d2', '#7f7f7f', '#c7c7c7', '#bcbd22', '#dbdb8d', '#17becf', '#9edae5'];
var color = ['#1f77b4'];
var cmap = {4:['#FF0000','#FF9C00','#ffdd05','#008000'],
        3:['#FF0000','#ffdd05','#008000'],
    2:['#FF0000','#008000'],
    1:['#008000']};
var partcolor;
var drillchart;
var indata;

function titleBox(g){
	if(g.hasOwnProperty('isDropdown') && g.isDropdown == true){
		if($('#hidden_'+g.chartId).length != 0){
		}else{
			$('#b3_'+g.chartId).remove();
			var $divtitle= '<div style="display:inline-block;z-index: 10;" class="col-md-12"><div class="col-md-1"><ul class="menuclick">'
				+'<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">'
				+'<i class="fa fa-bars"></i></a><ul class="dropdown-menu"><li>'
				+'<a href="#" class="chartHeaders" data-divheader="b3_'+g.chartId+'" data-title="b3title_'+g.chartId+'" onclick="saveAsPng(b3_'+g.chartId+',b3title_'+g.chartId+')"><i class="fa fa-download">'
				+'</i> Save as Image</a></li></ul></li></ul></div><div class="text-center col-md-8">'
				+'<strong id="b3title_'+g.chartId+'">'+g.charttitle+'</strong></div>'
				+'<div class="col-md-3"><select class="form-control m-bot15" id="'+g.dropdownId+'">'+dropdownOption()+'</select></div>';
			$('#'+g.chartId).append($divtitle);
			$('#'+g.chartId).append('<div id="b3_'+g.chartId+'" class="b3chart"></div>');
			$('#'+g.chartId).append('<input type="hidden" value="true" id="hidden_'+g.chartId+'">');


		}
	}else{
		var $divtitle='<div style="display:inline-block;z-index: 10;" class="col-md-12"><div class="col-md-1"><ul class="menuclick">'
		+'<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">'
		+'<i class="fa fa-bars"></i></a><ul class="dropdown-menu"><li>'
		+'<a href="#" class="chartHeaders" data-divheader="b3_'+g.chartId+'" data-title="b3title_'+g.chartId+'" onclick="saveAsPng(b3_'+g.chartId+',b3title_'+g.chartId+')"><i class="fa fa-download">'
		+'</i> Save as Image</a></li></ul></li></ul></div><div class="text-center col-md-11">'
		+'<strong id="b3title_'+g.chartId+'">'+g.charttitle+'</strong></div>';
		$('#'+g.chartId).append($divtitle);
		$('#'+g.chartId).append('<div id="b3_'+g.chartId+'" class="b3chart"></div>');

	}	
}


function dropdownOption(){
	var j = JSON.parse($('#brg_hidden').text());
	var options = '';
	$.each(j, function(i, item) {
		options += '<option value="'+j[i].key+'">'+j[i].value+'</option>' ;
	});
	return options;
}


function b3(g) {
	if(g.json.length > 0 && g.json != undefined && g.json != ''){
	titleBox(g);
	g.chartId = 'b3_'+g.chartId;
	switch (g.type) {
		case "bar":

			bar(g);
			$('#'+g.chartId).css('margin-top', '5%');
		break;
		case "pie":

			pie(g);
			$('#'+g.chartId).css('margin-top', '5%');
		break;
		case "stacked":

			bar(g);
			$('#'+g.chartId).css('margin-top', '5%');
		break;
		case "clustered":

			bar(g);
			$('#'+g.chartId).css('margin-top', '5%');
		break;
		case "drilldown":
			$('#'+g.chartId).css('margin-top', '5%');
			$('#'+g.chartId).parent().children(':first-child').find('.text-center').removeClass('col-md-11').addClass('col-md-10');
			$('#'+g.chartId).parent().children(':first-child').append('<input class="btn btn-primary col-md-1" id="chart_btnback" style="display: none;padding: 2px 5px;" type="button" value="Back" onclick="clickback()"/>');
			$('#'+g.chartId).parent().parent().removeClass('col-md-6').addClass('col-md-12');

			indata = g;
			drilldown();
		break;
		case "keywordcloud":
			$('#'+g.chartId).parent().children(':first-child').find('.text-center').removeClass('col-md-11').addClass('col-md-7');
			//$('#'+g.chartId).parent().children(':first-child').append('<span class="col-md-4 text-right" id="KeywordCSVDownload" style="cursor: pointer; cursor: hand;"><img alt="CSV" src="images/csv.png" width="20px"> <span style="text-decoration: underline;">Download Keyword Occurrences Report</span></span>');
			keywordcloud(g);
		break;
		case "gauge":
			$('#'+g.chartId).css('margin-left','25%');
			b3Gauge(g);
		break;
		case "line":
			$('#'+g.chartId).css('margin-top','5%');

			line(g);
		break;
		default:
			console.log("Error chart type error, Choose a type");

	}
}
else{
	if($('#hidden_'+g.chartId).val()){
		$('#b3_'+g.chartId).remove();
		$('#'+g.chartId).append('<div id="b3_'+g.chartId+'" class="b3chart" style="padding:20px">No data found</div>');
	}else{
		if(g.hasOwnProperty('isDropdown') && g.isDropdown == true){
			if($('#hidden_'+g.chartId).length != 0){
				
			}else{
				$('#b3_'+g.chartId).remove();
				var $divtitle= '<div style="display:inline-block;z-index: 950;" class="col-md-12"><div class="col-md-1"><ul class="menuclick">'
					+'<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">'
					+'<i class="fa fa-bars"></i></a><ul class="dropdown-menu"><li>'
					+'<a href="#" onclick="saveAsPng(b3_'+g.chartId+',b3title_'+g.chartId+')"><i class="fa fa-download">'
					+'</i> Save as Image</a></li></ul></li></ul></div><div class="text-center col-md-8">'
					+'<strong id="b3title_'+g.chartId+'">'+g.charttitle+'</strong></div>'
					+'<div class="col-md-3"><select class="form-control m-bot15" id="'+g.dropdownId+'">'+dropdownOption()+'</select></div>';
				$('#'+g.chartId).append($divtitle);
				$('#'+g.chartId).append('<div id="b3_'+g.chartId+'" class="b3chart">No data found</div>');
				$('#'+g.chartId).append('<input type="hidden" value="true" id="hidden_'+g.chartId+'">');
				$('#'+g.chartId).removeClass('max_min_370');
				$('#'+g.chartId).addClass('text-center');
			}
			
		}else{
			$('#'+g.chartId).append('<div class="text-center" style="font-weight: bold;">'+g.charttitle+'</div>');
			$('#'+g.chartId).append('<div class="b3chart" style="padding:20px">No data found</div>');
			$('#'+g.chartId).removeClass('max_min_370');
			$('#'+g.chartId).addClass('text-center');
		}
		
	}
}
}
 /**
 * type : bar / pie / stacked / clustered | (default =  bar).
 * chartId : Name of id in div or tag in html. | (default = chartb3).
 * height : Height of chart | (default = 240px) .
 * width : Width of chart | (default) as div default size (To set default don't declare). 
 * json: json of array to display. | (No default).
 * keyX: x axis data string '' | (default = 'x_axis_label').
 * keyY: y axis data array[string] | (default = ['value']).
 * labelBar : To show label above the bar  boolean | (default = false).
 * x_axis_name : x axis name | String | (No default).
 * y_axis_name : y axis name | String | (No default).
 * legend_display : To show the legend | boolean |  (default = false).
 * legend_position : Position of legend | String | (default = bottom).
 //Clustered and stacked
 * groupby : For Clustered bar chart |Array| Default [].
 //drilldown
 * keyDrillData : X axis drill down data | String | (default = 'children').
 * backbtnId: Back button id for drilldown chart | String | (default ="chart_btnback"),
 * isDrilldownbyUrl : To check by url or not | true | (default = 'false')


 */
 function defaultValue(d){
 
	var x_label_angel = d.json.length > 6 ? {rotate: -52,multiline: false} : '';
    var x_label_height = d.json.length > 6 ? 240 : 70;
    var chart_height = d.json.length > 6 ? 440 :340;
	var barsize = 0.5;
	var chart_type = 'bar';
	var tooltip;
	if(d.type != null || d.type != undefined || d.type != ''){
		if(d.type === 'bar'){chart_type = d.type;barsize = d.json.length < 5 ? 0.25 : 0.5;}
		else if(d.type === 'clustered'){chart_type =  'bar';}
		else if(d.type === 'stacked'){chart_type =  'bar';}
		else if(d.type === 'drilldown'){chart_type =  'bar';barsize = d.json.length < 5 ? 0.25 : 0.5;d.zoom=true}
		else if(d.type === 'line'){chart_type = 'line';}


	}
	if(chart_type === 'bar' || chart_type === 'line'){
		tooltip = {contents: function(data, defaultTitleFormat, defaultValueFormat, color) {
			var $$ = this,config = $$.config,titleFormat = config.tooltip_format_title || defaultTitleFormat,nameFormat = config.tooltip_format_name || function(name) {
            return name;},valueFormat = config.tooltip_format_value || defaultValueFormat,
			text, i, title, value;


            for (i = 0; i < data.length; i++) 
			{if (!(data[i] && (data[i].value || data[i].value === 0))) {continue;}
              if (!text) {title = titleFormat ? titleFormat(data[i].x) : data[i].x;
                            text = "<div id='tooltip' class='d3-tip'>";}
              value = valueFormat(data[i].value, data[i].ratio, data[i].id, data[i].index);


              text += "<span class='info'>" + title + "</span><br>";
              text += "<span class='value'>" + value +tooltipsym+"</span>";
              text += "</div>";}

				return text;
              }
          }
	}else if(chart_type === 'clustered' || chart_type === 'stacked' || d.type === 'drilldown'){
		tooltip = {contents: function (d, defaultTitleFormat, defaultValueFormat, color) {
				var sum = 0;var $$ = this,config = $$.config,
                        titleFormat = config.tooltip_format_title || defaultTitleFormat,title,text;
				for (i = 0; i < d.length; i++) {if (!text) {
					title = titleFormat ? titleFormat(d[i].x) : d[i].x;}
					sum += d[i].value;}
				defaultTitleFormat = function () {
					return title+" - "+sum};
				return c3.chart.internal.fn.getTooltipContent.apply(this, arguments);}


			}
	}
	var re =  {
		type:chart_type,
		chartId:(d.chartId != null ? '#'+d.chartId :"#chartb3"),
		json:d.json,
		size:d.width != undefined || d.height != undefined? {height: d.height,width: d.width} :{height:chart_height}, 
		keyX: (d.keyX !=null ) ? d.keyX : 'x_axis_label',
		keyY: (d.keyY !=null ) ? d.keyY : ['value'],
		labelBar: (d.labelBar === true) ? true : false,
		axis:{x: {type: 'category',tick: x_label_angel,height: x_label_height,
                    label: {text: d.x_axis_name != null ? d.x_axis_name : '',position: 'outer-center'}
                },
              y: {label: {text: d.y_axis_name != null ? d.y_axis_name : '',position: 'outer-middle'},
            	  min: 0,padding: {bottom: 0}/*,
            	  tick: {format: d3.format('.2f')}*/

            	}
            },
		bar:{width: {ratio: barsize}},
		legend: {show: (d.legend_display === true) ? true : false,
					position: (d.legend_position === 'right') ? 'right' :'bottom'},
		tooltip: tooltip ,
		zoom: {enabled: (d.zoom === true) ? true : false},
		groupby:undefined != d.groupby ? d.groupby : [],

	};
	return re;
}


function b3Generate(d,chartdata){
	var gen = {
		bindto: d.chartId,
        size: d.size,
        data: {
			type: d.type,
            json: d.json,
			groups: chartdata.type === 'stacked' ? [d.groupby] : '' ,
            keys: {

				x: d.keyX,
                value: chartdata.type === 'bar' || chartdata.type === 'drilldown' || chartdata.type === 'line' ? d.keyY : chartdata.type === 'clustered' || chartdata.type === 'stacked' ? d.groupby: []

			},
			labels: d.labelBar,
			colors:chartdata.type === 'clustered' && chartdata.hasOwnProperty('isPostiveScore')?colorClustered(d.groupby,chartdata.isPostiveScore,cmap[d.groupby.length]):chartdata.type === 'clustered' ? colorClustered(d.groupby,chartdata.isPostiveScore,colors) : {}, 
			color: chartdata.type === 'bar' || chartdata.type === 'drilldown' ? function(color, x) {return fillColor(colors, d.json.length)[x.index];} : chartdata.type === 'clustered' && chartdata.hasOwnProperty('isPostiveScore') ? function(color, x) {
			return color; }:'',

		},
		axis: d.axis,
		bar:d.bar,
		legend:d.legend,
		tooltip:d.toolitip,
		zoom:d.zoom

	};
	return gen;
} 
 function bar(chartdata){
	var d = defaultValue(chartdata);
	var gen = b3Generate(d,chartdata);
	var chart = c3.generate(gen);
	cssBuilder();
	return chart;










 }
 
 function line(chartdata){
	var jsonColors = {};
	jsonColors['value'] = '#1F77B4';
	var d = defaultValue(chartdata);
	var gen = b3Generate(d,chartdata);
	gen.data['colors'] = jsonColors;
	var chart = c3.generate(gen);
	cssBuilder();
 }

 function drilldown(){
	 $('#'+indata.chartId).parent().children(':first-child').find('.text-center').find('strong').html(indata.charttitle); 
	var cdata = indata;
	drillchart = null;
	$('#chart_btnback').css('display', 'none');
	var partcolor = fillColor(colors, cdata.json.length);
	if(cdata.json.length > 0){
		var c = cdata.keyDrillData !== undefined ? cdata.keyDrillData: 'children';
		if(cdata.json[0].hasOwnProperty(c) && cdata.isDrilldownbyUrl === false){
			var d = defaultValue(cdata);
			var gen = b3Generate(d,cdata);
			gen.data.onclick = function(dt, element) {
				loaddrilleddata(d.json[dt.x].children, partcolor[dt.x],cdata);

			}
			drillchart = c3.generate(gen);
			cssBuilder();
		}else if(cdata.isDrilldownbyUrl === true){
			var d = defaultValue(cdata);
			var gen = b3Generate(d,cdata);
			gen.data.onclick = function(dt, element) {
				var reqt = cdata.request_drilldown;
				reqt['groupName'] = d.json[dt.x][d.keyX];
				var callBack = function(json){
					if(json != null){loaddrilleddata(json, partcolor[dt.x]);}else{}
				}
                ajaxCallPostJson(cdata.url_drilldown,JSON.stringify(reqt),"#loader",callBack);
			}
			drillchart = c3.generate(gen);
			cssBuilder();


		}
	}
 }
function loaddrilleddata(data, colordt) {
		$('#chart_btnback').css('display', 'block');
		//var c =  indata; // need find memory map
		var c = JSON.parse(JSON.stringify(indata));
		c.x_axis_name = 'Agent';
		c.json = JSON.parse(data);
		$('#'+indata.chartId).parent().children(':first-child').find('.text-center').find('strong').html(indata.charttitle); 
		var din = defaultValue(c);
		din.keyX = 'label';
		din.keyY = ['value'];
		var gen_in = b3Generate(din,c);
		gen_in.data.color = function(color, d) {return colordt;};
		gen_in.data.onclick = function(dt, element) {
			drilldown();

		}
		drillchart = c3.generate(gen_in);
		cssBuilder();
}


function clickback(){
	drilldown();
}
 
 function pie(d){
	var data = {};
	var v = [];
	d.json.forEach(function(e) {
		v.push(e.label);
		data[e.label] = e.value;

	}) ;   
	var chart = c3.generate({
		pie: {label:{format:function(value, ratio, id) {return parseFloat(ratio*100).toFixed(1);}}},
		bindto: (d.chartId != null ? '#'+d.chartId :"#chartb3"),
		size: d.width != undefined || d.height != undefined? {height: (d.height-5),width: d.width} :{height:(340-5)},

		data: {
			type:(d.type != null || d.type != undefined || d.type != '' ? d.type :'pie'),
			json: [ data ],
			keys: {value: v,},
		},
	    color: {
	         pattern: (d.hasOwnProperty('isPostiveScore') ? colorPie(v.length,d.isPostiveScore) : colors)
	    },
		legend: {show: (d.legend_display === true) ? true : false,
					position: (d.legend_position === 'right') ? 'right' :'bottom'}
	});
	cssBuilder();
	$(d.chartId != null ? '#'+d.chartId :"#chartb3").parent().css("min-height","272px")
}
 
/*B3 GAUGE*/
var gauges = [];
var gdata;

/**
 * size : default |Number| 120.
 * chartId : Name of id in div or tag in html. | (default = chartb3).
 * label : Display name in gauge.
 * min : Range start |Number| (default = 0).
 * max : Range start |Number| (default = 100).
 * value :  value of gauge |Number| (No default). 
 **/

			
function b3Gauge(g){
	var gauges = [];
	var gdata;
	name = (g.chartId != null ? g.chartId :"chartb3") 
	var config = {
				size: undefined != g.size ? g.size:320,
				label:  undefined != g.label ? g.label : '',
				min: undefined != g.min ? g.min : 0,
				max: undefined != g.json ? (g.json > 100 ? 120 : 100 ) : 100,
				minorTicks: 5

	}		
	var range = config.max - config.min;
	/*config.yellowZones = [{ from: g.yellowRange[0], to: g.yellowRange[1] }];
	config.redZones = [{ from: g.redRange[0], to: g.redRange[1] }];*/
	config.greenZones = [{ from: config.min, to: config.max }];

	
	//config.redZones = [{ from: config.min + range*0.8, to: config.min + range*100 }];
	//config.yellowZones = [{ from:config.min + range*0.3, to: config.min + range*0.8 }];
	//config.greenZones = [{ from: config.min + range*0, to: config.max + range*0.3 }];			
	gauges[name] = new Gauge(name, config);
	gauges[name].render();
	gauges[name].redraw(g.json);
}


//Word cloud
function keywordcloud(d) {
	var width = document.getElementById(d.chartId).offsetWidth , height = d.height;
	var keywordScale = d3.scale.linear().range([ 20, 50 ]);
	var fill = d3.scale.category20();
	var keywords = d.json.filter(function(e) {
		return +e.value > 0;
	}).map(function(e) {
		return {
			text : e.label,
			size : +e.value

		};
	}).sort(function(a, b) {
		return d3.descending(a.size, b.size);
	}).slice(0, 50);

	keywordScale.domain([ d3.min(keywords, function(d) {
		return d.size
	}), d3.max(keywords, function(d) {
		return d.size
	}) ]);

	var layout = d3.layout.cloud().size([ width, height ]).words(keywords)
			.padding(1).rotate(function() {
				return ~~(Math.random() * 2) * 0;
			}).font("Tahoma").fontSize(function(d) {
				return keywordScale(d.size);
			}).on("end", drawwords);
	layout.start();

	function drawwords(words) {
		d3.select("#" + d.chartId).append("svg").attr("width", width).attr(
				"height", height).append("g").attr("transform",
				"translate(" + (width / 2) + "," + (height / 2) + ")")
				.selectAll("text").data(words).enter().append("text").style(
						"font-size", function(d) {

							return d.size + "px";
						}).style("font-family", "Tahoma").style("fill",


						function(d, i) {
							return fill(i);
						}).attr("text-anchor", "middle").attr(


						"transform",
						function(d) {
							return "translate(" + [ d.x, d.y ] + ")rotate("

									+ d.rotate + ")";
						}).text(function(d) {




					return d.text;
				});
	}
}


// download save as png
function saveAsPng(e,obj){
	var imageVariables=createImage(e,obj);
	imageVariables['image'].onload = function() {
		var canvasdata = alignCanvas(imageVariables);
		var a = document.createElement("a");
		a.id = "b3_anchor";
		a.target="_blank";
		a.download = imageVariables['saveName']+".png";
		a.href = canvasdata;
		document.body.appendChild(a);
		a.click();
	};	
}

function createImage(e,obj){
	if (document.contains(document.getElementById("b3_hidden"))) {
		document.getElementById("b3_hidden").remove();


	} 
	if(document.contains(document.getElementById("b3_anchor"))){
		document.getElementById("b3_anchor").remove();


	}
	var saveName = $('#'+obj.id).html();
	var svg = d3.select("#"+e.id).select('svg');
	var width = svg.style("width");
	var height = svg.style("height");
	d3.select('body').append('div').attr("id","b3_hidden").style('display','none'); 
	d3.select('#b3_hidden').append("canvas").attr("id","b3_svgUrl").attr("width",width).attr("height",height);
	d3.select('#b3_hidden').append('div').attr("id","b3_pngUrl");
	var html = svg.attr("version", 1.1)
        .attr("xmlns", "http://www.w3.org/2000/svg")
        .node().parentNode.innerHTML;

	
	html = html.replace(/<div[^>]*?>[\s\S]*?<\/div>/gi, '');
	var imgsrc = 'data:image/svg+xml;base64,'+ btoa(html);
	html = html.replace(/<div[^>]*?>[\s\S]*?<\/div>/gi, '');
	var imgsrc = 'data:image/svg+xml;base64,'+ btoa(html);
	var img = '<img src="'+imgsrc+'" width="'+width+'" height="'+height+'">'; 
	d3.select("#b3_svgUrl").html(img);
	var canvas = document.querySelector("#b3_svgUrl");
	var context = canvas.getContext("2d");
	canvas.width=canvas.width+100;
	canvas.height=canvas.height+100;
	var image = new Image();
	image.src = imgsrc;
	return imageVariables(canvas, image, context, saveName); 
}
function alignCanvas(imageVariables){
	var canvas=imageVariables['canvas'];
	var image=imageVariables['image'];
	var context=imageVariables['context'];
	context.font = "12pt Calibri";
	context.textAlign="center"; 
	context.fillText(imageVariables['saveName'], canvas.width/2, 10);
	context.drawImage(image, (canvas.width - image.width) * 0.5, (canvas.height - image.height) * 0.5);
    var canvasdata = canvas.toDataURL("image/svg+xml");
	return canvasdata;
}
function imageVariables(canvas, image, context, saveName){
	var object={};
	object['canvas']=canvas;
	object['image']=image;
	object['context']=context;
	object['saveName']=saveName;
	return object; 
}


// Colour Array Generator by Size
function fillColor(value, len) {
    var arr = [];
    var d = -1;
    for (var i = 0; i < len; i++) {
        if (i < value.length)
            arr.push(value[i]);
        else {
            d = d + 1;
            if (d >= value.length)
                d = 0;
            arr.push(value[d]);
        }
    }
    return arr;
}

// CSS code gen
function cssBuilder(){//,'-webkit-tap-highlight-color': 'transparent'
	$(".c3 svg").css({'font': '10px sans-serif','-webkit-tap-highlight-color': 'transparent' });
	$(".c3 path, .c3 line").attr( 'fill', 'none').attr( 'stroke', '#000');
	$(".c3 text").css({'-webkit-user-select': 'none','-moz-user-select': 'none','user-select': 'none'});
	$(".c3-legend-item-tile, .c3-xgrid-focus, .c3-ygrid, .c3-event-rect, .c3-bars path").attr('shape-rendering', 'crispEdges');
	$(".c3-chart-arc path").attr( 'stroke', '#fff');
	$(".c3-chart-arc text").attr( 'fill', '#fff');
	$(".c3-grid line").attr( 'stroke', '#aaa');
	$(".c3-grid text").attr( 'fill', '#aaa');
	$(".c3-axis-x-label").css( 'font-size', '12px');
	$(".c3-axis-y-label").css( 'font-size', '12px');
	$(".c3-xgrid, .c3-ygrid").attr( 'stroke-dasharray', '3 3');
	$(".c3-text.c3-empty").attr( 'fill', '#808080');
	$(".c3-text.c3-empty").css( 'font-size', '2em');
	$('.c3-line').attr('stroke-width','1px');
	$('.c3-circle._expanded_').css({' stroke-width':' 1px',' stroke':' white' });
	$('.c3-selected-circle').css({'fill':' white','stroke-width':' 2px'});
	$('.c3-bar').css('stroke-width',' 0' );
	$('.c3-bar._expanded_').css('fill-opacity',' 0.75');
	$('.c3-target.c3-focused').css('opacity',' 1');
	$('.c3-target.c3-focused path.c3-line, .c3-target.c3-focused path.c3-step').css('stroke-width',' 2px');
	$('.c3-target.c3-defocused').css('opacity',' 0.3 !important');
	$('.c3-region').css('fill',' steelblue','fill-opacity',' 0.1');
	$('.c3-brush .extent').css('fill-opacity',' 0.1');
	$('.c3-legend-item').css('font-size',' 12px');
	$('.c3-legend-item-hidden').css('opacity',' 0.15');
	$('.c3-legend-background').css({'opacity':' 0.75','fill':' white','stroke':' lightgray','stroke-width':' 1'});
	$('.c3-area').css({'stroke-width':' 0','opacity':' 0.2'});
	$('.c3-chart-arcs-title').css({'dominant-baseline':' middle','font-size':' 1.3em'});
	$('.c3-chart-arcs .c3-chart-arcs-background').css({'fill':' #e0e0e0','stroke':' none'});
	$('.c3-chart-arcs .c3-chart-arcs-gauge-unit').css({'fill':' #000','font-size':' 16px'});
	$('.c3-chart-arcs .c3-chart-arcs-gauge-max').css({'fill':' #777'});
	$('.c3-chart-arcs .c3-chart-arcs-gauge-min').css({'fill':' #777'});
	$('.c3-chart-arc .c3-gauge-value').css({'fill':' #000'});
	$('.c3-xgrid-focus').css('display',' none');
	$('.c3-event-rect').css('cursor',' pointer');
	$('.d3-tip').css({'line-height':' 1','font-weight':' bold','padding':' 5px 12px','background':' rgba(0, 0, 0, 0.8)',
    	'color':' #fff','border-radius':' 4px','line-height':' 15px','font-size':' 12px',
    	'min-width':' 91px',});
	$('.d3-tip .info').css({'font-size':' 11px','color':' #8897b4','display':' block',});	
	$('.tick text').css({'width':' 132px','font-size':' 11px','text-overflow':'ellipsis','font-weight':' bold'});
}
function colorClustered(json,ispostive,cin){
	var re = {},len=json.length,cx = JSON.parse(JSON.stringify(cin));
	var co = ispostive ? cin : cx.reverse();
	for (var i=0;i<len;i++) {re[json[i]]=co[i];}
	return re;
}

function colorPie(size,isPositive){
  if(size > 4){size = 4}	
  if(isPositive){return cmap[size];}else{console.log('size: ',size, JSON.stringify(cmap[size]), cmap[size]);var cx = JSON.parse(JSON.stringify(cmap[size]));return cx.reverse();}
}

$(function(){
"use strict";
    $("#jquery_jplayer_1").jPlayer({
        ready: function () {
            $(this).jPlayer("setMedia", {
				mp3: "http://jplayer.org/audio/mp3/TSP-09-The_werewolf_song.mp3?"
			});
        },
        swfPath: "js/jplayer/js",
        supplied: "mp3",
        cssSelectorAncestor: "#jp_container_1",
        smoothPlayBar: true,
        keyEnabled: true
    });
});
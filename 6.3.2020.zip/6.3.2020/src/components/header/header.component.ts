// import { Router } from '@angular/router';
// import { Location } from '@angular/common';
import { Component, OnInit, OnChanges, Input } from '@angular/core';
import { version } from '../../../package.json';
import { Router } from '@angular/router';
import {environment as env} from '../../environments/environment';
import { VirtualDetailsService } from 'src/app/shared/services/va-details/virtual-agent-details.service.js';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
// import { ReportsService } from '../../reports/reports.service';
// import { Subscription } from 'rxjs';
declare var $:any;
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  public userId : string;

  simulatorBaseUrl: string;

  path = '';
  @Input() x = 0;
  @Input() y = 0;
  // showContent: any;
  public version: string = version;
  constructor(private router:Router, private authenticationService:AuthenticationService) {

    //this.service.currentMessage.subscribe(data => this.showContent = data);
  }

  ngOnInit(): void { 
    $(document).ready(function() {
      $('.parent').hover(function() {
        $('.sub-nav').toggleClass('visible');
      });
    });

    if(!localStorage.getItem('currentUser')){
      this.logout();
    }
  }


  logout(){
    this.authenticationService.logout();
    this.router.navigateByUrl('/login');
  }
}

import { MatDialogModule } from '@angular/material';
import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { AssistedTrainingComponent } from './assisted-training.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, Component, TemplateRef } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { BsModalService, BsModalRef } from "ngx-bootstrap/modal";
import { BsDropdownConfig } from "ngx-bootstrap/dropdown";
import { ToastrService, ToastrModule } from 'ngx-toastr';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AssistedTrainingService } from './assisted-training.service';
import { of, throwError, Observable, BehaviorSubject, from, observable } from 'rxjs';
import { TextSelectEvent, TextSelectDirective } from "../../app/shared/directives/text-select.directive";
import { ActivatedRoute } from '@angular/router';
import * as moment from "moment";


class AssistedTrainingServiceStub {

  constructor() { }

  public getInputs() {
    return Observable.of({
      virtualAgents: [
        {
          virtualAgent: {
            vaId: 1,
            vaIsLive: true
          },
          channels: [],
          languages: ['en-uk', 'en-us']
        },
        {
          virtualAgent: {
            vaId: 2,
            vaIsLive: false
          },
          channels: [],
          languages: ['en-uk', 'en-us']
        }
      ]
    });
  }

  public getIntents(chn, fromDate, langId, pageNo, sort, toDate, VA, serachtxt) {
    return Observable.of({
      mappedCount: 0,
      inScopeCount: 0,
      outOfScopeCount: 4,
      conversationList: [
        {
          sessionId: 1,
          mapppedPhrases: [],
          inScopePhrases: [],
          outOfScopePhrases: [
            {
              id: 1,
              value: 'need information'
            }
          ]
        },
        {
          sessionId: 2,
          mapppedPhrases: [],
          inScopePhrases: [],
          outOfScopePhrases: [
            {
              id: 7,
              value: 'first class ticket from mumbai'
            },
            {
              id: 4,
              value: 'ticket book pannanum'
            },
            {
              id: 3,
              value: 'sollunga'
            }
          ]
        }
      ]
    });
  }

  public searchIntent(va_id, language_id) {
    return Observable.of([{
      intent: {
        id: 4,
        value: 'praveen intent'
      },
      intentSlots: []
    },
    {
      intent: {
        id: 6,
        value: 'Booking Cancellation'
      },
      intentSlots: []
    }]);
  }

  public languageChange(chn, fromDate, langId, pageNo, sort, toDate, VA, text) {
    return Observable.of([
      [{
        intent: {
          id: 4,
          value: 'praveen intent'
        },
        intentSlots: []
      },
      {
        intent: {
          id: 6,
          value: 'Booking Cancellation'
        },
        intentSlots: []
      }],
      []
    ]);
  }

  public deleteUnmappedUserInputs(unmapped_Id) { return Observable.of({}); }

  public createIntent(body, va_id) {
    if (va_id == 1) {
      return Observable.of({
        intent: {}
      })
    } else if (va_id == 2) {
      return Observable.of({
        errorBody: {
          summary: 'This is a summary'
        }
      })
    } else {
      return throwError({});
    }
  }

  public saveUnmappedInputs(inputs: any) { return Observable.of({}); }

}

class ActivatedRouteStub {
  paramsObj = {
    name: 'name',
    id: 1,
    desc: 'desc',
    channel: 'channel',
    lang: 'en-uk',
    chId: 'chId',
    langId: 'lanID',
    get: (property) => {
      console.log('coming in get', this.paramsObj[property]);
      return this.paramsObj[property];
    }
  }
  public paramMap = new BehaviorSubject(this.paramsObj);
}

class BsModalServiceStub {
  
  public show(template, config) { }
  
  public hide() { }
}

describe('AssistedTrainingComponent', () => {
  let assistedTrainingService;
  let component: AssistedTrainingComponent;
  let fixture: ComponentFixture<AssistedTrainingComponent>;
  let template: TemplateRef<any>;
  let template2: TemplateRef<any>;
  let template1: TemplateRef<any>;
  let event: TextSelectEvent;
  let modalService: BsModalService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        BsModalRef,
        { provide: AssistedTrainingService, useClass: AssistedTrainingServiceStub },
        { provide: ActivatedRoute, useClass: ActivatedRouteStub },
        { provide: BsModalService, useClass: BsModalServiceStub },
        { provide: BsDropdownConfig }
      ],
      declarations: [AssistedTrainingComponent],
      imports: [FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
        ToastrModule.forRoot(),
        BsDropdownModule.forRoot(),
        MatDialogModule,
        RouterTestingModule,
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssistedTrainingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('getDropdownInput should initialize data and call setDropdownValues and searchIntentFunc methods', async(() => {
    const setDropdownValuesSpy = spyOn(component, 'setDropdownValues');
    const searchIntentFuncSpy = spyOn(component, 'searchIntentFunc');
    component.vaId = 1;

    component.getDropdownInput();

    expect(setDropdownValuesSpy).toHaveBeenCalled();
    expect(searchIntentFuncSpy).toHaveBeenCalled();
    expect(Object.keys(component.vaById)).toEqual(['1', '2']);
  }));

  it('setDropdownValues should initialize data and call serviceCallUnmappedInputs methods', () => {
    const spy = spyOn(component, 'serviceCallUnmappedInputs');
    component.vaId = 1;

    component.setDropdownValues();

    expect(component.channels).toEqual([]);
    expect(component.languages).toEqual(['en-uk', 'en-us']);
    expect(component.status).toEqual('Live');
    expect(component.channel).toEqual('channel');
    expect(component.AssistedTrainingForm.controls['channel'].value).toEqual('channel');
    expect(component.language).toEqual('en-uk');
    expect(component.AssistedTrainingForm.controls['language'].value).toEqual('en-uk');
    expect(component.channel_Id).toEqual('chId');
    expect(component.VA_id).toEqual(component.vaId);
    expect(spy).toHaveBeenCalled();
  });


  it('searchIntentFunc method should initialize intentListData variable correctly', () => {
    component.intentListData = [];

    component.searchIntentFunc();

    expect(component.intentListData)
      .toEqual([{ id: 4, value: 'praveen intent' }, { id: 6, value: 'Booking Cancellation' }]);
  });

  it('serviceCallUnmappedInputs method should clearAssistedTrainingtags method before conversationListDetails method', () => {
    const clearAssistedTrainingtagsSpy = spyOn(component, 'clearAssistedTrainingtags');
    const conversationListDetailsSpy = spyOn(component, 'conversationListDetails');
    const chn = 'chn';
    const fromDate = '20/02/2020';
    const langId = 'en-uk';
    const pageNo = 0;
    const sort = 1;
    const toDate = '21/02/2020';
    const VA = 'VA';
    const text = 'text';

    component.serviceCallUnmappedInputs(chn, fromDate, langId, pageNo, sort, toDate, VA, text);

    expect(clearAssistedTrainingtagsSpy).toHaveBeenCalledBefore(conversationListDetailsSpy);
    expect(component.allInputs).toEqual({});
    expect(conversationListDetailsSpy).toHaveBeenCalled();
  });

  it('channelFilter should call clearAssistedTrainingtags and serviceCallUnmappedInputs methods', () => {
    const clearAssistedTrainingtagsSpy = spyOn(component, 'clearAssistedTrainingtags');
    const serviceCallUnmappedInputsSpy = spyOn(component, 'serviceCallUnmappedInputs');
    component.AssistedTrainingForm.controls['channel'].setValue('chValue');

    component.channelFilter();

    expect(clearAssistedTrainingtagsSpy).toHaveBeenCalledBefore(serviceCallUnmappedInputsSpy);
    expect(component.channel_Id).toEqual('chValue');
    expect(serviceCallUnmappedInputsSpy)
      .toHaveBeenCalledWith(component.channel_Id, component.fromDate, component.language_id,
        component.pageNumber, component.sortByDesc, component.toDate, component.VA_id, component.searchText);

  });

  it('languageFilter method should call clearAssistedTrainingtags before conversationListDetails method', () => {
    const clearAssistedTrainingtagsSpy = spyOn(component, 'clearAssistedTrainingtags');
    const conversationListDetailsSpy = spyOn(component, 'conversationListDetails');
    component.AssistedTrainingForm.controls['language'].setValue('en-us');

    component.languageFilter();

    expect(clearAssistedTrainingtagsSpy).toHaveBeenCalledBefore(conversationListDetailsSpy);
    expect(component.language_id).toEqual('en-us');
    expect(component.allInputs).toEqual({});
    expect(component.intentListData)
      .toEqual([{ id: 4, value: 'praveen intent' }, { id: 6, value: 'Booking Cancellation' }]);
    expect(conversationListDetailsSpy).toHaveBeenCalled();

  });

  it('onSearch should set counter to 1 and searchText and call clearAssistedTrainingtags and serviceCallUnmappedInputs methods', () => {
    const clearAssistedTrainingtagsSpy = spyOn(component, 'clearAssistedTrainingtags');
    const serviceCallUnmappedInputsSpy = spyOn(component, 'serviceCallUnmappedInputs');
    const text = 'search me';
    component.channels = [{ id: 1 }];
    component.languages = [{ id: 1 }];

    component.onSearch(text);

    expect(component.counter).toEqual(1);
    expect(component.searchText).toEqual(text);
    expect(clearAssistedTrainingtagsSpy).toHaveBeenCalledBefore(serviceCallUnmappedInputsSpy);
    expect(serviceCallUnmappedInputsSpy).toHaveBeenCalled();
  });

  // it('choosedDate should set toDate and fromDate variable', () => {
  //   component.choosedDate('');

  //   expect(component.toDate).toEqual(moment().format('YYYY-MM-DD'));
  //   expect(component.fromDate).toEqual(moment().subtract(6, "days").format('YYYY-MM-DD'));
  // });

  it('submitFilter should call serviceCallUnmappedInputs method', () => {
    const spy = spyOn(component, 'serviceCallUnmappedInputs');

    component.submitFilter('');

    expect(spy).toHaveBeenCalled();
  });

  it('cancelFilter should call serviceCallUnmappedInputs method', () => {
    const spy = spyOn(component, 'serviceCallUnmappedInputs');

    component.cancelFilter('');

    expect(spy).toHaveBeenCalled();
  });

  it('cancelCreate should reset createFormGroup', () => {
    component.createFormGroup.controls['name'].setValue('name');
    component.createFormGroup.controls['description'].setValue('description');
    component.createFormGroup.controls['intentType'].setValue('intentType');

    component.cancelCreate();

    expect(component.createFormGroup.controls['name'].value).toBe(null);
    expect(component.createFormGroup.controls['description'].value).toBe(null);
    expect(component.createFormGroup.controls['intentType'].value).toBe(null);
  });

  it('conversationListDetails should call conversationListProcess 2 times', () => {
    const conversationListProcessSpy = spyOn(component, 'conversationListProcess');
    const list = {
      mappedCount: 0,
      inScopeCount: 0,
      outOfScopeCount: 4,
      conversationList: [
        {
          sessionId: 1,
          mapppedPhrases: [],
          inScopePhrases: [],
          outOfScopePhrases: [
            {
              id: 1,
              value: 'need information'
            }
          ]
        },
        {
          sessionId: 2,
          mapppedPhrases: [],
          inScopePhrases: [],
          outOfScopePhrases: [
            {
              id: 7,
              value: 'first class ticket from mumbai'
            },
            {
              id: 4,
              value: 'ticket book pannanum'
            },
            {
              id: 3,
              value: 'sollunga'
            }
          ]
        }
      ]
    };

    component.conversationListDetails(list);

    expect(component.m_length).toEqual(0);
    expect(component.s_length).toEqual(0);
    expect(component.o_length).toEqual(4);
    expect(component.totalInputs).toEqual(4);
    expect(conversationListProcessSpy).toHaveBeenCalledTimes(2);
  });

  it('genrateHighlightdata method should return correct values', () => {
    const text = 'sample text';

    expect(component.genrateHighlightdata(text, false, ''))
      .toEqual([{ index: 0, value: 'sample', isHighlight: false, key: 'pos0' },
      { index: 1, value: 'text', isHighlight: false, key: 'pos1' }]);

  });

  // should work more. Did not get required details in API to mock.
  it('genrateHighlightdata method should return correct values', () => {
    const text = 'sample text';

    expect(component.genrateHighlightdata(text, true, ''))
      .toEqual([{ index: 0, value: 'sample', isHighlight: false, key: 'pos0' },
      { index: 1, value: 'text', isHighlight: false, key: 'pos1' }]);

  });

  it('expand panel method should set outscopeLength to 1', () => {
    component.expandPanel(1);

    expect(component.display).toBeTruthy();
    expect(component.scopeInputs.length).toEqual(0);
    expect(component.mappedInputs.length).toEqual(0);
    expect(component.outscopeInputs.length).toEqual(1);

  });

  it('expand panel method should set outscopeLength to 0', () => {
    component.expandPanel(3);

    expect(component.display).toBeTruthy();
    expect(component.scopeInputs.length).toEqual(0);
    expect(component.mappedInputs.length).toEqual(0);
    expect(component.outscopeInputs.length).toEqual(0);

  });

  it('clearAssistedTrainingtags should initialize selectedIntentName, selectedIntentId and intentSlotColorList to empty value', () => {
    component.clearAssistedTrainingtags();

    expect(component.selectedIntentName).toEqual([]);
    expect(component.selectedIntentId).toEqual('');
    expect(component.intentSlotColorList).toEqual([]);

  });

  it('deleteUnmappedUser should call serviceCallUnmappedInputs method', () => {
    const serviceCallUnmappedInputsSpy = spyOn(component, 'serviceCallUnmappedInputs');
    component.modalRef = TestBed.get(BsModalRef);

    component.deleteUnmappedUser();

    expect(serviceCallUnmappedInputsSpy).toHaveBeenCalled();
  });

  it('showContent should only call setupPhraseDataSpy method', () => {
    const clearunmapIntentSlotsDataSpy = spyOn(component, 'clearunmapIntentSlotsData');
    const displaySlotsListSpy = spyOn(component, 'displaySlotsList');
    const setupPhraseDataSpy = spyOn(component, 'setupPhraseData');
    const value = {
      intentId: 'id',
      value: 'value'
    };
    const checkboxId = 'chkBoxId';
    component.selectedIntentId = 'id';

    component.showContent(value, checkboxId);

    expect(clearunmapIntentSlotsDataSpy).toHaveBeenCalledTimes(0);
    expect(displaySlotsListSpy).toHaveBeenCalledTimes(0);
    expect(setupPhraseDataSpy).toHaveBeenCalledWith(value, checkboxId);
  });

  it('showContent should call displaySlotsList method 2 times', () => {
    const clearunmapIntentSlotsDataSpy = spyOn(component, 'clearunmapIntentSlotsData');
    const displaySlotsListSpy = spyOn(component, 'displaySlotsList');
    const setupPhraseDataSpy = spyOn(component, 'setupPhraseData');
    const value = {
      intentId: 4,
      value: 'value'
    };
    const checkboxId = 'chkBoxId';
    component.selectedIntentId = 'id';

    component.showContent(value, checkboxId);

    expect(clearunmapIntentSlotsDataSpy).toHaveBeenCalledTimes(1);
    expect(displaySlotsListSpy).toHaveBeenCalledTimes(2);
    expect(setupPhraseDataSpy).toHaveBeenCalledWith(value, checkboxId);
  });

  it('showContent should call displaySlotsList method only once', () => {
    const clearunmapIntentSlotsDataSpy = spyOn(component, 'clearunmapIntentSlotsData');
    const displaySlotsListSpy = spyOn(component, 'displaySlotsList');
    const setupPhraseDataSpy = spyOn(component, 'setupPhraseData');
    const value = {
      intentId: null,
      value: 'value'
    };
    const checkboxId = 'chkBoxId';
    component.selectedIntentId = 'id';

    component.showContent(value, checkboxId);

    expect(clearunmapIntentSlotsDataSpy).toHaveBeenCalledTimes(1);
    expect(displaySlotsListSpy).toHaveBeenCalledTimes(1);
    expect(setupPhraseDataSpy).toHaveBeenCalledWith(value, checkboxId);
    expect(component.intentSlotColorList).toEqual([]);
  });

  it('createNewIntent should call showPopup with Info as parameter', () => {
    const showPopupSpy = spyOn(component, 'showPopup');
    const searchIntentFuncSpy = spyOn(component, 'searchIntentFunc');
    component.createFormGroup.controls['name'].setValue('name');
    component.createFormGroup.controls['description'].setValue('description');
    component.createFormGroup.controls['intentType'].setValue('intentType');
    component.VA_id = 1;

    component.createNewIntent();

    expect(component.created).toBeTruthy();
    expect(showPopupSpy).toHaveBeenCalledWith('Info', 'Intent is created successfully');
    expect(searchIntentFuncSpy).toHaveBeenCalled();
    expect(component.createFormGroup.controls['name'].value).toBe(null);
    expect(component.createFormGroup.controls['description'].value).toBe(null);
    expect(component.createFormGroup.controls['intentType'].value).toBe(null);
  });

  it('createNewIntent should call showPopup with Info as parameter', () => {
    const showPopupSpy = spyOn(component, 'showPopup');
    const searchIntentFuncSpy = spyOn(component, 'searchIntentFunc');
    component.createFormGroup.controls['name'].setValue('name');
    component.createFormGroup.controls['description'].setValue('description');
    component.createFormGroup.controls['intentType'].setValue('intentType');
    component.VA_id = 2;

    component.createNewIntent();

    expect(component.created).toBeTruthy();
    expect(showPopupSpy).toHaveBeenCalledWith('Error', 'This is a summary');
    expect(searchIntentFuncSpy).toHaveBeenCalled();
    expect(component.createFormGroup.controls['name'].value).toBe(null);
    expect(component.createFormGroup.controls['description'].value).toBe(null);
    expect(component.createFormGroup.controls['intentType'].value).toBe(null);
  });

  it('createNewIntent should call showPopup with Info as parameter', () => {
    const showPopupSpy = spyOn(component, 'showPopup');
    const searchIntentFuncSpy = spyOn(component, 'searchIntentFunc');
    component.createFormGroup.controls['name'].setValue('name');
    component.createFormGroup.controls['description'].setValue('description');
    component.createFormGroup.controls['intentType'].setValue('intentType');
    component.VA_id = 3;

    component.createNewIntent();

    expect(component.created).toBeTruthy();
    expect(showPopupSpy).toHaveBeenCalledWith('Error', 'Intent is not created');
    expect(searchIntentFuncSpy).toHaveBeenCalledTimes(0);
    expect(component.createFormGroup.controls['name'].value).toBe(null);
    expect(component.createFormGroup.controls['description'].value).toBe(null);
    expect(component.createFormGroup.controls['intentType'].value).toBe(null);
  });

  it('checkEmpty should return true', () => {
    const text = 'dummy text'
    component.selectedIntentId = 'id';

    const result = component.checkEmpty(text);

    expect(result).toBeTruthy();
  });

  it('checkEmpty should return false when selectedIntentId is an empty string', () => {
    const text = 'dummy text'
    component.selectedIntentId = '';

    const result = component.checkEmpty(text);

    expect(result).toBeFalsy();
  });

  it('checkEmpty should return false when selectedIntentId is undefined', () => {
    const text = 'dummy text'
    component.selectedIntentId = undefined;

    const result = component.checkEmpty(text);

    expect(result).toBeFalsy();
  });

  it('clearHostRectangle should initialize hostRectangle to null and selectedPharseKey to empty string ', () => {

    component.clearHostRectangle();

    expect(component.hostRectangle).toEqual(null);
    expect(component.selectedPharseKey).toEqual('');
  });

  it('showIntentSlotsDropdown should clearHostRectangle method when selectedIntentId is undefined or is empty string', () => {
    const clearHostRectangleSpy = spyOn(component, 'clearHostRectangle');
    component.selectedIntentId = '';

    component.showIntentSlotsDropdown();

    expect(clearHostRectangleSpy).toHaveBeenCalled();
  });

  it('showIntentSlotsDropdown should not call clearHostRectangle method', () => {
    const clearHostRectangleSpy = spyOn(component, 'clearHostRectangle');
    component.selectedIntentId = 'id';

    component.showIntentSlotsDropdown();

    expect(clearHostRectangleSpy).toHaveBeenCalledTimes(0);
    expect(component.dropdownError).toEqual('Select proper words');
    expect(component.intentSlotList).toEqual([]);
  });

  it('openSlotsDropdown should call initialize dropdownError, intentSlotList and call pushIntentSlots method', () => {
    const pushIntentSlotsSpy = spyOn(component, 'pushIntentSlots');

    component.openSlotsDropdown();

    expect(component.dropdownError).toEqual('Choose an Intent slot');
    expect(component.intentSlotList).toEqual([]);
    expect(pushIntentSlotsSpy).toHaveBeenCalled()
  });

  it('displaySlotsList should initialize intentSlotColorList to empty array and call pushIntentSlots method', () => {
    const pushIntentSlotsSpy = spyOn(component, 'pushIntentSlots');

    component.displaySlotsList();

    expect(component.intentSlotList).toEqual([]);
    expect(pushIntentSlotsSpy).toHaveBeenCalled()
  });

  it('saveUnmappedUserInputsRequest should call clearAssistedTrainingtags, showPopup and serviceCallUnmappedInputs methods', () => {
    const clearAssistedTrainingtagsSpy = spyOn(component, 'clearAssistedTrainingtags');
    const showPopupSpy = spyOn(component, 'showPopup');
    const serviceCallUnmappedInputsSpy = spyOn(component, 'serviceCallUnmappedInputs');

    component.saveUnmappedUserInputsRequest();

    expect(clearAssistedTrainingtagsSpy).toHaveBeenCalled();
    expect(showPopupSpy).toHaveBeenCalledWith('Info', 'Intent is mapped successfully');
    expect(serviceCallUnmappedInputsSpy).toHaveBeenCalled();
  });

  // it('coloringPhrase should call ', () => {
  //   const colorArrayGenraterSpy = spyOn(component, 'colorArrayGenrater');
  //   const colorDisplayTextAndGenrateInnerPhaseSpy = spyOn(component, 'colorDisplayTextAndGenrateInnerPhase');
  //   const o = {
  //     intentslots: { a: '' }
  //   }
  //   component.coloringPhrase(o);

  //   expect(colorArrayGenraterSpy).toHaveBeenCalled();
  //   expect(colorDisplayTextAndGenrateInnerPhaseSpy).toHaveBeenCalled();


  // });

  it('intentChanged method should call displaySlotsList method', () => {
    const displaySlotsListSpy = spyOn(component, 'displaySlotsList');    
    const value = {
      id: 'id',
      value: 'value'
    };

    component.intentChanged(value);

    expect(component.selectedIntentName).toEqual('value');
    expect(component.selectedIntentId).toEqual('id');
    expect(displaySlotsListSpy).toHaveBeenCalled();
  });

  it('showPopup should initialize modal header and message and open pop up', () => {
    const modalService = TestBed.get(BsModalService);
    const spy = spyOn(modalService, 'show');
    const title = 'title';
    const msg = 'msg';

    component.showPopup(title, msg);

    expect(component.modalHeader).toEqual(title);
    expect(component.modalMsg).toEqual(msg);
    expect(spy).toHaveBeenCalled();
  });

  it('openModals method should call show method', () => {
    const modalService = TestBed.get(BsModalService);
    const spy = spyOn(modalService, 'show');

    component.openModals(template);

    expect(spy).toHaveBeenCalled();
  });

  it('openModalClear method should call show method', () => {
    const modalService = TestBed.get(BsModalService);
    const spy = spyOn(modalService, 'show');
    const id = 1;
    const session = 'session';
    const phraseType = 'phraseType';

    component.openModalClear(template, id, session, phraseType);

    expect(component.clearSessionId).toEqual(session);
    expect(component.clearId).toEqual(id);
    expect(component.clearPhraseType).toEqual(phraseType);
    expect(spy).toHaveBeenCalled();
  });

  it('openModalTrainInput methods', () => {
    const modalService = TestBed.get(BsModalService);
    const spy = spyOn(modalService, 'show');

    component.openModalTrainInput(template);

    expect(spy).toHaveBeenCalled();
  });

  it('openDialog methods should call show method', () => {
    const modalService = TestBed.get(BsModalService);
    const spy = spyOn(modalService, 'show');

    component.openDialog();

    expect(component.modalHeader).toEqual('Warning !!');
    expect(component.modalMsg).toEqual('Select atleat one user input');
    expect(spy).toHaveBeenCalled();
  });

  it('onScroll should increment counter and call conversationListProcess method', () => {
    const spy = spyOn(component, 'conversationListProcess');
    component.counter = 1;

    component.onScroll();

    expect(component.counter).toEqual(2);
    expect(spy).toHaveBeenCalled();
  });

  // it('check methods', () => {

  // });
});

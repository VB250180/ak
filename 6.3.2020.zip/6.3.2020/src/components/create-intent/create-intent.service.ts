import { Injectable } from '@angular/core';
import { Observable, of, forkJoin } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { catchError, map, tap, delay, filter, scan } from 'rxjs/operators';
import { environment as env } from '../../environments/environment';
import { HttpHeaders } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CreateIntentService {

  private messageSource = new BehaviorSubject<any>("");
  currentMessage = this.messageSource.asObservable();


  constructor(private http: HttpClient) { }

  changeMessage(message: string) {
    this.messageSource.next(message)
  }

  public saveCreateIntent(vaRoleId, saveIntentForm) {
    return this.http.post(env.apiUrl + '/virtualAgent/' + vaRoleId + '/intents', saveIntentForm);
  }
  public updateCreateIntent(vaRoleId, intentId, saveIntentForm) {
    return this.http.put(env.apiUrl + '/virtualAgent/' + vaRoleId + '/intents/' + intentId, saveIntentForm);
  }
  public getIntent(roleId, intentId) {
    return this.http.get(env.apiUrl + '/virtualAgent/' + roleId + '/intents/' + intentId);
  }
  public getIntentConversionList(intentId, langId, chId): Observable<any> {
    return this.http.get<any>(env.apiUrl + '/intent/' + intentId + '/language/' + langId + '/channel/' + chId + '/conversationFlow');
  }
  public saveConversations(saveConversation, intentId, langEngId, channelId) {
    return this.http.put(env.apiUrl + '/intent/' + intentId + '/language/' + langEngId + '/channel/' + channelId + '/conversationFlow', saveConversation);
  }

  public getSystemSlotDropdown() {
    return this.http.get(env.apiUrl + '/systemSlotKeys');
  }
  public getIntentsDropdown(vaRoleId, intentId) {
    return this.http.get(env.apiUrl + '/virtualAgent/' + vaRoleId + '/intents/' + '?ignoreIntentId=' + intentId);
  }

  public addTrainingPhrase(intentId, langId, pageNo, text) {
    console.log(intentId, pageNo, langId, env.apiUrl + '/intent/' + intentId + '/language/' + langId + '/trainingPhrases/pageNumber/' + pageNo + "?" + 'trainingPhrase=' + text);
    return this.http.get(env.apiUrl + '/intent/' + intentId + '/language/' + langId + '/trainingPhrases/pageNumber/' + pageNo + "?" + 'trainingPhrase=' + text);
  }

  public requestaddTrainingPhraseAndintentSlots(intentId, langId, pageNo, text): Observable<any[]> {
    return forkJoin([this.addTrainingPhrase(intentId, langId, pageNo, text), this.intentSlots(intentId, langId)]);
  }

  public deleteTrainingPhrase(intentId, langId, phraseId, text) {
    return this.http.delete(env.apiUrl + '/intent/' + intentId + '/language/' + langId + '/trainingPhrases?trainingPhraseIds=' + phraseId);
  }

  public intentSlots(intentId, langId) {
    return this.http.get(env.apiUrl + '/intents/' + intentId + '/language/' + langId + '/intentSlots');
  }

  public addPhraseDetails(intentId, langId, phrases) {
    console.log('addphrases', phrases, intentId, langId);
    return this.http.put(env.apiUrl + '/intent/' + intentId + '/language/' + langId + '/trainingPhrases', phrases);
  }
  public getEntitys() {
    return this.http.get(env.apiUrl + '/entities');
  }
  public virtualAgent() {
    return this.http.get(env.apiUrl + '/virtualAgents');
  }

  public addTrainingPhraseDialogFlow(langId, vaId) {
    return this.http.get(env.apiUrl + '/addTrainingPhraseDialogFlow?' + 'langId=' + langId + '&vaId=' + vaId);
  }

  public getVAdetailsByUserId(userId:number) : Observable<any> {
    return this.http.get<any>(env.apiUrl + '/user/'+userId+'/virtualAgentsByUser/');
  }

}

import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { VirtualAgentService } from '../../../core/services/virtual-agent/virtual-agent.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { ModalComponent } from 'src/app/shared/components/modal/modal.component';
import { getCurrentUserId } from '../../../core/utils/akeira-utils';

@Component({
  selector: 'app-virtual-agent-creation',
  templateUrl: './virtual-agent-creation.component.html',
  styleUrls: ['./virtual-agent-creation.component.scss']
})
export class VirtualAgentCreationComponent implements OnInit {
  createAgentForm: FormGroup;
  dropdownList = [];
  languages = [];
  channels = [];
  channelsList = [];
  languageList = [];
  deselectedValues = [];
  selectedItems = [];
  dropdownSettings: IDropdownSettings = {};

  public loadContent: boolean = false;
  public data = [];
  public settings = {};
  public chnsettings = {};

  saveResponse = [];

  Organizations = [];
  BusinessUnits = [];
  bunit: any;
  orgs: any;
  flag: any;
  vaId: any;
  userId: any;
  agentorg: any;
  agentOrgId: any;
  agentCatId: any;
  agentCatName: any;
  agentDetails: any;


  constructor(private fb: FormBuilder, private vaService: VirtualAgentService,
    private route: ActivatedRoute, private spinner: NgxSpinnerService, private matDialog: MatDialog, private router: Router) {
    this.createAgentForm = this.fb.group({
      avatarName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(15)]],
      agentName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(15)]],
      agentDescription: ['', [Validators.maxLength(50)]],
      agentOrganization: ["", [Validators.required]],
      agentBusinessUnit: ["", [Validators.required]],
      agentLanguages: ["", [Validators.required]],
      agentChannels: ["", [Validators.required]]
    });

    this.route.paramMap.subscribe((params: any) => {
      console.log('params -->', params);
      this.flag = params.params.flag;
      this.vaId = params.params.vaId;

      this.userId = getCurrentUserId();
    });
  }

  ngOnInit() {

    if (this.flag == 1) {
      this.spinner.show();
      console.log(this.userId);
      this.vaService.getVirtualAgent(this.vaId).subscribe(res => {
        console.log(res);
        this.agentDetails = res['virtualAgent']
        console.log(res['virtualAgent'], this.agentDetails);
        this.Organizations = [{ orgId: this.agentDetails.businessUnitData.organization.orgId, organizationName: this.agentDetails.businessUnitData.organization.organizationName }];
        this.BusinessUnits = [{ catId: this.agentDetails.businessUnitData.catId, categoryName: this.agentDetails.businessUnitData.categoryName }]

        this.createAgentForm.patchValue({
          avatarName: this.agentDetails.vaAvatarName,
          agentName: this.agentDetails.vaName,
          agentDescription: this.agentDetails.vaDescription,
          agentOrganization: this.Organizations[0].orgId,
          agentBusinessUnit: this.BusinessUnits[0].catId,
          agentLanguages: this.agentDetails.languages,
          agentChannels: this.agentDetails.channels
        });

        this.getLangs();
        this.getChnls();

        this.languages.push(this.agentDetails.languages),
          this.channels = this.agentDetails.channels,
          this.orgs = this.Organizations,
          this.bunit = this.BusinessUnits
      }, err => {
        console.error(err);
      });
      this.spinner.hide();
    }
    else {
      this.getOrgs();
    }

    this.languages = [];
    this.channels = [];

    this.settings = {
      singleSelection: false,
      idField: 'langEngId',
      textField: 'langName',
      enableCheckAll: true,
      selectAllText: 'Select All',
      unSelectAllText: 'Unselect All',
      allowSearchFilter: true,
      limitSelection: -1,
      clearSearchFilter: true,
      maxHeight: 197,
      itemsShowLimit: 1,
      searchPlaceholderText: 'search here',
      // noDataAvailablePlaceholderText: 'No data available',
      // closeDropDownOnSelection: true,
      showSelectedItemsAtTop: false,
      defaultOpen: false
    };
    this.chnsettings = {
      singleSelection: false,
      idField: 'channelId',
      textField: 'channelName',
      enableCheckAll: true,
      selectAllText: 'Select All',
      unSelectAllText: 'Unselect All',
      allowSearchFilter: true,
      limitSelection: -1,
      clearSearchFilter: true,
      maxHeight: 197,
      itemsShowLimit: 1,
      searchPlaceholderText: 'search here',
      // noDataAvailablePlaceholderText: 'No data available',
      // closeDropDownOnSelection: true,
      showSelectedItemsAtTop: false,
      defaultOpen: false
    };

  }

  public noWhitespaceValidator(control: FormControl) {
    const isWhitespace = (control.value || '').trim().length === 0;
    const isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true };
  }

  public onFilterChange(item: any) {
    console.log(item);
  }
  // public onDropDownClose(item: any) {
  //   console.log(item);
  // }

  public onSelectAll(items: any) {
    console.log(items);
  }


  getOrgs() {
    this.vaService.orgData(this.userId).subscribe(res => {
      this.Organizations = res['organizationData']
      console.log(this.Organizations);
    })
  }

  getChnls() {
    this.vaService.chnData().subscribe(res => {
      this.channels = res['channels'];
    });
  }

  getBusUnit() {
    this.vaService.busUnitData(this.createAgentForm.value.agentOrganization, this.userId).subscribe(res => {
      this.BusinessUnits = res['categoryData']
    })
  }

  getLangs() {
    this.vaService.langData(this.createAgentForm.value.agentBusinessUnit).subscribe(res => {
      this.languages = res['languageEngineMaps']
    });
  }

  orgChange(orgId) {
    this.createAgentForm.patchValue({
      agentBusinessUnit: '',
      agentLanguages: [],
      agentChannels: []
    });
    this.orgs = this.Organizations.filter(x => x.orgId == orgId);
    this.getBusUnit();
  }

  businessUnitChange(unitId) {
    this.createAgentForm.patchValue({
      agentLanguages: [],
      agentChannels: []
    });
    this.bunit = this.BusinessUnits.filter(x => x.catId == unitId);
    this.getLangs();
    this.getChnls();
  }


  deselectPopUp(value) {
    if (value == 'lang') {
      this.openModalPopUpDeselect(value);
      this.createAgentForm.patchValue({
        agentLanguages: this.agentDetails.languages,
        agentChannels: this.agentDetails.channels
      });
    }
    else {
      this.openModalPopUpDeselect(value);
      this.createAgentForm.patchValue({
        agentChannels: this.agentDetails.channels
      });
    }
  }

  onLanguageSelect(item) {
    if (this.flag == 1) {
      this.createAgentForm.patchValue({
        agentChannels: this.agentDetails.channels
      });
    }
    else {
      this.createAgentForm.patchValue({
        agentChannels: []
      })
    }
  }


  onLanguageDeSelect(item) {
    if (this.flag == 1) {
      for (let i = 0; i < this.agentDetails.languages.length; i++) {
        if (this.agentDetails.languages[i].langName == item.langName) {
          let value = 'lang';
          this.deselectPopUp(value);
        }
      }
    }
  }

  onDeselectAllLanguages() {
    let value = 'lang';
    this.flag == 1 ? this.deselectPopUp(value) : '';
  }

  public onChannelSelect(chn: any) {
    this.channelsList = [];
    this.channelsList.push(chn);
  }

  onDeSelectChannels(item) {
    if (this.flag == 1) {
      for (let i = 0; i < this.agentDetails.channels.length; i++) {
        if (this.agentDetails.channels[i].channelName == item.channelName) {
          let value = 'chn';
          this.deselectPopUp(value);
        }
      }
    }
  }

  onDeSelectAllChannels() {
    let value = 'chn';
    this.flag == 1 ? this.deselectPopUp(value) : '';
  }

  onSave() {
    console.log(this.createAgentForm.value);
    this.saveResponse = [
      {
        "businessUnit": this.bunit[0].categoryName,
        "businessUnitData": {
          "catId": 1,
          "nluEngine": {
            "engineId": 0,
            "engineName": ""
          },
          "organization": {
            "orgId": this.orgs[0].orgId,
            "organizationName": this.orgs[0].organizationName
          }
        },
        "userName": "",
        "channels": this.createAgentForm.value.agentChannels,
        "languages": this.createAgentForm.value.agentLanguages,
        "vaAvatarName": this.createAgentForm.value.avatarName,
        "vaDescription": this.createAgentForm.value.agentDescription,
        "vaId": "",
        "vaIsLive": true,
        "vaName": this.createAgentForm.value.agentName
      }
    ]
    if (this.flag == 1) {
      this.saveResponse[0].vaId = Number(this.vaId);
      console.log('savee', JSON.stringify(this.saveResponse[0]))
      this.vaService.updateVaResponse(this.saveResponse[0].vaId, this.saveResponse[0], this.userId).subscribe(arg => {
        console.log(arg);;
        if (arg['errorBody'] != null) {
          this.openModalErrorPopUp(arg['errorBody'].summary);
        }
        else {
          this.openModalPopUp(this.flag);
        }
      }, err => {
        console.log(err);
      });
    }
    else {
      this.vaService.sendVaSaveResponse(this.bunit[0].catId, this.userId, this.saveResponse).subscribe(arg => {
        console.log(arg);
        if (arg['errorBody'] != null) {
          this.openModalErrorPopUp(arg['errorBody'].summary);
        }
        else {
          this.openModalPopUp(this.flag);
        }
      },
        err => {
          console.log(err);
        });
    }
  }

  onCancel() {
    this.flag == 1 ? this.router.navigate(['/va-listing']) : this.router.navigate(['/agent-list']);
  }

  openModalPopUp(flag) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = "800px";
    dialogConfig.data = {
      primaryText: 'You have successfully created a new Virtual Agent',
      secondaryText: `The new Virtual agent is created and saved in the Va List page,you can view all the created Va together in the list page`,
      hasPrimaryBtn: true,
      primaryBtnText: 'Create another',
      hasSecondaryBtn: true,
      secondaryBtnText: 'Go to va List Page',
      suggestedText: `Please Contact Uniphore Customer Support to complete the VA configuration.`,
      popUpType: 'save',
      hasCancelBtn: false
    };
    flag == 1 ? dialogConfig.data.primaryText = 'You have successfully updated a new Virtual Agent' : 'You have successfully created a new Virtual Agent';
    const modalDialog = this.matDialog.open(ModalComponent, dialogConfig);
    modalDialog.afterClosed().subscribe(data => {
      if (data == 'secondary') {
        this.router.navigate(['/va-listing'])
      }
      else {
        this.router.navigate(['/va-creation'])
      }
    });
  }

  openModalErrorPopUp(err) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = "800px";
    dialogConfig.data = {
      primaryText: err,
      hasPrimaryBtn: true,
      primaryBtnText: 'Ok',
      popUpType: 'error',
      hasCancelBtn: true
    };
    const modalDialog = this.matDialog.open(ModalComponent, dialogConfig);
    modalDialog.afterClosed().subscribe(data => {
      console.log('material data err', data);
      // if (data == true) {
      //   this.router.navigate(['/va-listing'])
      // }
      // else {
      //   this.router.navigate(['/va-creation'])
      // }
    });
  }

  openModalPopUpDeselect(value) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = "500px";
    dialogConfig.data = {
      primaryText: 'Sorry, You can only add channels',
      hasPrimaryBtn: true,
      primaryBtnText: 'Ok',
      popUpType: 'error',
      hasCancelBtn: true
    };

    value == 'lang' ? dialogConfig.data.primaryText = 'Sorry, You can only add languages' : '';

    const modalDialog = this.matDialog.open(ModalComponent, dialogConfig);
    modalDialog.afterClosed().subscribe(data => {
      console.log(data);
    });
  }
}

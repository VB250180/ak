import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { catchError, map, tap, delay, filter, scan } from 'rxjs/operators';
import { environment as env } from '../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CreateEntityService {

  constructor(private http: HttpClient) { }

  public saveEntity(vrmId,entityObj): Observable<any>  {
    return this.http.post<any>(env.apiUrl + '/virtualAgent/' + vrmId + '/entities/', entityObj);
  }
  public updateEntity(vrmId,entityObj): Observable<any>  {
    return this.http.put<any>(env.apiUrl + '/virtualAgent/' + vrmId + '/entities/', entityObj);
  }
  public getEntity(entityId,lanId): Observable<any>  {
    return this.http.get<any>(env.apiUrl + '/entity/' + entityId + '/language/'+lanId+ '/entities/',);
  }

}

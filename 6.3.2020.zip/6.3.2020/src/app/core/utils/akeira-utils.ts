export const lastDigitOfNumber = (no: number) => no % 10;;
export const chooseColorClassByLastDigit = (no: number) => 'slot-c-' + lastDigitOfNumber(no);

export const getRandomRolor = () => {
    let letters = '012345'.split(''), color = '#';
    color += letters[Math.round(Math.random() * 5)];
    letters = '0123456789ABCDEF'.split('');
    for (let i = 0; i < 5; i++) {
        color += letters[Math.round(Math.random() * 15)];
    }
    return color;
}

//Object utils
export const getObjById = (x: [], id: any) => x.filter(function (o: any) { return o.id === id; });
export const isEmptyObj = (x: object) => {
    console.log('isEmptyObj ', x)
    if (x != null && x != undefined) {

        console.log('isEmptyObj ', Object.keys(x).length === 0)
        return Object.keys(x).length === 0;
    } else {

        return true;
    }
}

export const getFromLocalStorage = (key: string) => {
    return localStorage.getItem(key);
}


//String utils
export const stringify = (x: object) => JSON.stringify(x);

export const getCurrentUserId = () => Number(JSON.parse(getFromLocalStorage('currentUser')).userId);

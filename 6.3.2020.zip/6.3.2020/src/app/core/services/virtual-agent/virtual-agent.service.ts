import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment as env } from '../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class VirtualAgentService {

  editDetails:any;

  constructor(private http:HttpClient) { }

  orgData(userId){
    return this.http.get( env.apiUrl +'/user/'+userId+ '/organization');
  }

  busUnitData(orgId,userId){       
    return this.http.get( env.apiUrl + '/user/'+16+'/organization/' + orgId + '/categories/');
  }

  langData(busId){
    return this.http.get( env.apiUrl + '/category/' + busId + '/languages');
  }

  chnData(){
    return this.http.get( env.apiUrl + '/channels');
  }

  sendVaSaveResponse(catId, userId , body){
    console.log(env.apiUrl + '/user/' + userId + '/virtualAgents' , body);
    return this.http.post(env.apiUrl + '/user/' + userId + '/businessUnit/' + catId + '/virtualAgents/', body);
  }

  updateVaResponse(vaId,body,userId){
    console.log(vaId,body);
    return this.http.put( env.apiUrl + '/user/' + userId + '/virtualAgents/' + vaId , body );
  }

  getVirtualAgents(pageNum,userId,agent){
    return this.http.get( env.apiUrl + '/user/' + 16 + '/virtualAgents?channelId=0&languageId=0&pageNumber=' + pageNum + '&vaName=' + agent);
  }

  getVirtualAgent(vaId){
    return this.http.get(env.apiUrl + '/virtualAgents/' + vaId );
  }
}

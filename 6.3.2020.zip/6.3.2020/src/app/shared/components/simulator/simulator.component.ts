import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { VirtualDetailsService } from '../../services/va-details/virtual-agent-details.service';

@Component({
  selector: 'app-simulator',
  templateUrl: './simulator.component.html',
  styleUrls: ['./simulator.component.scss']
})
export class SimulatorComponent implements OnInit {

  showPopUp = false;
  showEditView = false;
  showChatWindow: boolean;
  selectionDetails;
  simulatorToken: string;
  sessionId: string;
  intentNumber = -1;
  intentStage = 0;
  initialSettingsDone: boolean;
  chatHistory = [];

  @Input() simulatorBaseUrl;
  @Input() requiredDataLoaded: boolean;

  constructor(private virtualDetailsService: VirtualDetailsService) { }

  ngOnInit() {
    this.initialSettingsDone = false;
    this.showChatWindow = false;
  }

  togglePopUp() {
    this.showPopUp = !this.showPopUp
  }

  editClicked() {
    this.showEditView = true;
  }

  onEditCancelClicked() {
    this.showEditView = false;
  }

  onDoneClicked(event) {
    console.log('lalalalalalala', event, this.selectionDetails);
    if (this.selectionDetails !== undefined && this.selectionDetails.hasOwnProperty('vrmAgentDetails')
      && (this.selectionDetails['vrmAgentDetails'].vrmId !== event['vrmAgentDetails'].vrmId
        || this.selectionDetails['vrmAgentChannelDetails'].channelId !== event['vrmAgentChannelDetails'].channelId)) {
      this.terminateConversation(this.sessionId, this.simulatorToken, this.selectionDetails.vrmAgentChannelDetails.virtualAgentRoleChannelMapId);
      this.selectionDetails = event;
      this.showEditView = false;
      this.intentNumber = -1;
      this.intentStage = 0;
      this.chatHistory = [];
      this.createAuthenticationToken();
    } else if (this.selectionDetails !== undefined && this.selectionDetails.hasOwnProperty('vrmAgentDetails')
      && this.selectionDetails['vrmAgentDetails'].vrmId === event['vrmAgentDetails'].vrmId
      && this.selectionDetails['vrmAgentChannelDetails'].channelId === event['vrmAgentChannelDetails'].channelId) {
      this.selectionDetails = event;
      this.showEditView = false;
    } else if (this.selectionDetails === undefined) {
      this.selectionDetails = event;
      this.showEditView = false;
      this.createAuthenticationToken();
    }
  }

  createAuthenticationToken() {
    this.virtualDetailsService.createAuthenticationToken(this.simulatorBaseUrl,
      this.selectionDetails.vrmAgentChannelDetails.virtualAgentRoleChannelMapId, this.selectionDetails.vrmAgentChannelDetails.key).subscribe(data => {
        if (data['errorBody'] === null && data.hasOwnProperty('jwtResponse')
          && data['jwtResponse'].hasOwnProperty('token')) {
          this.simulatorToken = data['jwtResponse'].token;
          this.initializeConversation();
        } else {
          this.showChatWindow = true;
          this.initialSettingsDone = false;
          const chatResponse = {
            user: 'server',
            message: 'System is facing some problem. Please contact customer case in case of any enquries',
            isClientView: false
          }
          this.chatHistory.push(chatResponse);
        }
      });
  }

  initializeConversation() {
    this.virtualDetailsService.initializeConversation(this.simulatorBaseUrl,
      this.selectionDetails.vrmAgentChannelDetails.virtualAgentRoleChannelMapId, this.simulatorToken)
      .subscribe(session => {
        if (session['errorBody'] === null && session.hasOwnProperty('sessionId')) {
          this.sessionId = session['sessionId'];
          this.initialSettingsDone = true;
          this.showChatWindow = true;
        } else {
          this.showChatWindow = true;
          this.initialSettingsDone = false;
          const chatResponse = {
            user: 'server',
            message: 'System is facing some problem. Please contact customer case in case of any enquries',
            isClientView: false
          }
          this.chatHistory.push(chatResponse);
        }
      });
  }

  sendMessage(message) {
    let chatResponse = {};
    const data = {
      intentNumber: this.intentNumber,
      intentStage: this.intentStage,
      language: this.selectionDetails.vrmAgentLanguageDetails,
      sessionId: this.sessionId,
      token: this.simulatorToken,
      url: this.simulatorBaseUrl,
      userRequest: message,
      virtualAgentRoleChannelMapId: this.selectionDetails.vrmAgentChannelDetails.virtualAgentRoleChannelMapId
    };
    const chatData = {
      user: 'client',
      message: message,
      isClientView: true
    }
    this.chatHistory.push(chatData);
    this.virtualDetailsService.sendMessage(data).subscribe(response => {
      if (response['errorBody'] === null) {
        this.intentNumber = response['conversationResponsePojo'].intentNumber;
        this.intentStage = response['conversationResponsePojo'].intentStage;
        if (message === '') {
          this.initialSettingsDone = true;
        }
        if (response['conversationResponsePojo'].responseCode === 200) {
          chatResponse = {
            user: 'server',
            message: response['conversationResponsePojo'].responsetext,
            isClientView: false
          }
        } else {
          chatResponse = {
            user: 'server',
            message: response['conversationResponsePojo'].responseDesc,
            isClientView: false
          }
        }
        this.chatHistory.push(chatResponse);
        if (response['conversationResponsePojo'].liveAgentTransfer) {
          this.initialSettingsDone = false;
          this.selectionDetails = undefined;
          this.showEditView = true;
        }
        if (response['conversationResponsePojo'].pingBack) {
          this.initialSettingsDone = false;
          this.sendMessage('');
        }
      } else {
        this.initialSettingsDone = false;
        chatResponse = {
          user: 'server',
          message: 'System is facing some problem. Please contact customer case in case of any enquries',
          isClientView: false
        }
        this.chatHistory.push(chatResponse);
      }

    });
  }

  terminateConversation(sessionId, token, virtualAgentRoleChannelMapId) {
    const data = {
      sessionId: sessionId,
      token: token,
      url: this.simulatorBaseUrl,
      virtualAgentRoleChannelMapId: virtualAgentRoleChannelMapId
    }
    this.virtualDetailsService.terminateConversation(data).subscribe(data => {
      console.log('successfully terminated session');
    });
  }

}

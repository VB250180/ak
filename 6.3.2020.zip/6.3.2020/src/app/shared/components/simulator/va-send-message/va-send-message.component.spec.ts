import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VaSendMessageComponent } from './va-send-message.component';

describe('VaSendMessageComponent', () => {
  let component: VaSendMessageComponent;
  let fixture: ComponentFixture<VaSendMessageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VaSendMessageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VaSendMessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit, Input, OnChanges, Output, EventEmitter, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-va-send-message',
  templateUrl: './va-send-message.component.html',
  styleUrls: ['./va-send-message.component.scss']
})
export class VaSendMessageComponent implements OnInit, OnChanges, OnDestroy {

  @Input() initialSettingsDone;
  @Output() sendMessageClicked = new EventEmitter();
  messageForm: FormGroup

  constructor() { }

  ngOnInit() {
    this.messageForm = new FormGroup({
      messageText: new FormControl('', Validators.required)
    });
    if (!this.initialSettingsDone && this.messageForm) {
      this.messageForm.controls['messageText'].disable();
    }
  }

  ngOnChanges() {
    if (this.initialSettingsDone && this.messageForm) {
      this.messageForm.controls['messageText'].enable();
    } else if (this.messageForm) {
      this.messageForm.controls['messageText'].disable();
    }
  }

  sendMessage() {
    if (this.messageForm.valid) {
      this.sendMessageClicked.emit(this.messageForm.controls['messageText'].value);
      this.messageForm.reset();
    }
  }

  ngOnDestroy() {
    console.log('Destroying VaSendMessageComponent')
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VaChatWindowComponent } from './va-chat-window.component';

describe('VaChatWindowComponent', () => {
  let component: VaChatWindowComponent;
  let fixture: ComponentFixture<VaChatWindowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VaChatWindowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VaChatWindowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

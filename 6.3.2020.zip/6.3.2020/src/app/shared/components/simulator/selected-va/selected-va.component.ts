import { Component, OnInit, Output, EventEmitter, Input, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-selected-va',
  templateUrl: './selected-va.component.html',
  styleUrls: ['./selected-va.component.scss']
})
export class SelectedVaComponent implements OnInit, OnDestroy {

  @Input() selectionDetails;
  @Input() requiredDataLoaded: boolean;
  @Output() onEditClicked = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }

  onEditClick() {
    if (this.requiredDataLoaded) {
      this.onEditClicked.emit(true);
    }
  }

  ngOnDestroy() {
    console.log('Destroying SelectedVaComponent');
  }

}

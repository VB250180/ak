import { BehaviorSubject } from 'rxjs';
import { Injectable } from '@angular/core';
import { environment as env } from '../../../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { getCurrentUserId } from '../../../core/utils/akeira-utils';

@Injectable({
    providedIn: 'root'
})
export class VirtualDetailsService {

    vrmDetails = new Map();
    vrmLanguageMap = new Map();
    vrmChannelMap = new Map();
    requiredDataLoaded = new BehaviorSubject(false);

    constructor(private httpClient: HttpClient) { }

    public getVirtualAgentsDetails() {
        this.getVirtualAgentRoleMaps().subscribe(data => {
            if (data.hasOwnProperty('virtualAgentRoleMaps') && data['virtualAgentRoleMaps'].length > 0) {
                data['virtualAgentRoleMaps'].map(virtualAgentRoleMap => {
                    const vrmObj = {
                        vrmId: virtualAgentRoleMap.vrmId,
                        vrmName: virtualAgentRoleMap.vrmName,
                        vrmIsLive: virtualAgentRoleMap.vrmIsLive,
                        isNluConfigured: virtualAgentRoleMap.isNluConfigured,
                        vrmAvatarName: virtualAgentRoleMap.vrmAvatarName,
                        vrmDescription: virtualAgentRoleMap.vrmDescription,
                        vrmBU: virtualAgentRoleMap.businessUnitData.categoryName
                    };
                    this.vrmDetails.set(virtualAgentRoleMap.vrmId, vrmObj);
                    this.vrmLanguageMap.set(virtualAgentRoleMap.vrmId, virtualAgentRoleMap.languages);
                    this.vrmChannelMap.set(virtualAgentRoleMap.vrmId, virtualAgentRoleMap.channels);
                });
                this.requiredDataLoaded.next(true);
            }
        });
    }

    public getVirtualAgents() {
        console.log('hhhhh', this.vrmDetails);
        return this.vrmDetails;
    }

    public getChannelsByVrmId(vrmID) {
        return [...this.vrmChannelMap.get(vrmID)];
    }

    public getLanguagesByVrmId(vrmId) {
        return [...this.vrmLanguageMap.get(vrmId)];
    }

    public getVirtualAgentRoleMaps() {
        return this.httpClient.get(env.apiUrl + '/user/' + getCurrentUserId() + '/virtualAgentRoleMaps/');
    }

    public getSimulatorDetails() {
        return this.httpClient.get(env.apiUrl + '/virtualAgentRoleMaps/simulator');
    }

    public createAuthenticationToken(url, virtualAgentRoleChannelMapId, key) {
        return this.httpClient.post(url + 'virtualAgent/channel/' + virtualAgentRoleChannelMapId + '/authenticate/?password=' + key, {});
    }

    public initializeConversation(url, virtualAgentRoleChannelMapId, token) {
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token,
            })
        };
        const body = {};
        return this.httpClient.post(url + 'virtualAgent/channel/' + virtualAgentRoleChannelMapId + '/initConversation', body, httpOptions);
    }

    public sendMessage(data) {
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + data.token,
            })
        };
        const body = {
            clientName: null,
            intentNumber: data.intentNumber,
            intentStage: data.intentStage,
            language: data.language,
            sessionId: data.sessionId,
            userRequest: data.userRequest
        };
        return this.httpClient.post(data.url + 'virtualAgent/channel/' + data.virtualAgentRoleChannelMapId + '/webBot',
            body, httpOptions);
    }

    terminateConversation(data) {
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + data.token,
            })
        };
        const body = {
            sessionId: data.sessionId,
        };
        return this.httpClient.post(data.url + 'virtualAgent/channel/' + data.virtualAgentRoleChannelMapId + '/terminateConversation',
            data.sessionId, httpOptions);
    }
}
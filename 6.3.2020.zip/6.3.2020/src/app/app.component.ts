import { VirtualDetailsService } from './shared/services/va-details/virtual-agent-details.service';
import { Component } from '@angular/core';
// import {MatIconRegistry} from '@angular/material/icon';
// import {DomSanitizer} from '@angular/platform-browser';
import { NgModule, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgSelectModule, NgOption } from '@ng-select/ng-select';
import * as $ from 'jquery';
import { Router } from '@angular/router';
import { AuthenticationService } from './core/authentication/authentication.service';
import { User } from './core/models/user/user.model';
import { UserRole } from './core/models/user/role';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

  
export class AppComponent implements OnInit{
  title = 'akiera';
  currentUser: User;
  simulatorBaseUrl: string;
  requiredDataLoaded = false;
  
  constructor( public router: Router,  private virtualDetailsService: VirtualDetailsService,
      private authenticationService: AuthenticationService){
        this.authenticationService.currentUser.subscribe(x => this.currentUser = x);
  }

  ngOnInit() {
    this.virtualDetailsService.requiredDataLoaded.subscribe(isLoaded => {
      this.requiredDataLoaded = isLoaded;
    });
    this.authenticationService.currentUserSubject.subscribe(data => {
      console.log(data);
      if (data !== null) {
        this.virtualDetailsService.getSimulatorDetails().subscribe(response => {
          if (response.hasOwnProperty('data') && response['data'] !== null) {
            this.simulatorBaseUrl = response['data'];
            console.log('simulatorBaseUrl', this.simulatorBaseUrl);
          }
        });
        this.virtualDetailsService.getVirtualAgentsDetails();
      }
    });
  }

  get isAdmin() {
    return this.currentUser && this.currentUser.role === UserRole.Admin;
  }

  logout() {
    this.authenticationService.logout();
    this.router.navigate(['/login']);
  }
}
